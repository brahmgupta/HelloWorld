import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title = 'ng-wrapper-for-stencil';

  public myClick() {
    console.log('it worked');
  }

  public valueChange() {
    console.log('it worked');
  }
}
