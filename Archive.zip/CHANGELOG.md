<!-- markdownlint-disable MD001 MD024 -->
# AGL Design System Changelog

> All notable changes to this project will be documented in this file.
>
> This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) from `v1.0.0` onwards.
>
> `v0.*.*` versions did not adhere to semantic versioning and contained various breaking changes as the initial library was being developed.

## vnext

### Breaking Changes

-

### Features

- `agl-ds-button`: added "center" to the icon-position prop
- Add new component `agl-ds-tile`  -  [DCCT-5902]
- Add new component, list containers `agl-ds-list` `agl-ds-list-item` to Core  -  [DCCT-6034]

### Bug Fixes

- `agl-ds-button`: Fixed bug in tertiary button type to not have a min or max width and to only expand to its contents.

## 9.5.0 (2021-06-17)

- `agl-ds-radio-button type=icon`: Added additional icons to the icon set for radio buttons.
- (internal) Updated the `svgo` config to optimise library svg files

## 9.4.2 (2021-06-10)

### Bug Fixes

- `agl-ds-segmented-card`: updated header height and font-weight

## 9.4.1 (2021-06-08)

### Bug Fixes

- `agl-ds-segmented-card`: Fix toggling issue of segmented card header

## 9.4.0 (2021-06-08)

### Features

- `agl-ds-segmented-card`: add `headerType` and `headerContent` properties. add `other-list` slot

## 9.3.1 (2021-06-04)

### Bug Fixes

- `agl-ds-guided-banner`: fixed back arrow to be the correct colour
- update stories to use https://via.placeholder.com/ for example images rather than https://placehold.it/ due to certificate issues with https://placehold.it/

## 9.3.0 (2021-05-26)

### Features

- `agl-ds-badge'`: left align content when type is `secondary` and increase the spacing between the "dot" and the text

### Bug Fixes

- `agl-ds-stepper` : Bug Fix. When stepper is placed into a flex container, the right overflow arrow on showed incorrectly.
- `agl-ds-radio-button type=icon` : fixed bug where radio button background was showing thru svg when an icon type radio button group was added inside a radio button panel.

## 9.2.0 (2021-05-24)

### Features

- Added four additional icons (`agl_icon_dig_calendar_48px`, `agl_icon_dig_calendar_dollar_48px`, `agl_icon_dig_plan_add_32px`, `agl_icon_dig_plan_edit_32px`) to the icon set for radio buttons.
- Added a display of available icons by name and icon into the radio button storybook.

### Bug Fixes

- `agl-ds-hint-validation-message`: Enforced text-align = left for the hint and validation messages as they were being centered in some instances.
- `agl-ds-fulfilment-container`: Fixed bug in the non sticky footer variant where the side bar was the wrong width
- `agl-ds-checkbox`: set vertical alignment and change the border colour to darker shade for checkbox. (DCCT-5442)
- fixed a11y issues on a number of components in order to pass the automated axe test

## 9.1.0 (2021-05-04)

### Features

- `agl-ds-button`: Button has been re-built. Also has an active state and rotate icon functionality.
- `agl-ds-menu-dropdown-trigger`: will pass its active state when using `agl-ds-button` as slotted trigger.
- `agl-ds-button`: Fixed bug where the tertiary button was incorrectly showing an underline when there was an icon
- `agl-ds-fulfilment-container`: added sticky-location = none which places the side panel in the document flow at the bottom of the component.
- `agl-ds-textbox`: Added hint-text as a slot to compliment the hint-text prop to allow for the addition of HTML

### Bug Fixes

- `agl-ds-manual-address-entry`: Fix the bug to set the po box number in the address string.

## 9.0.0 (2021-05-03)

### Breaking Changes

- `agl-ds-manual-address-entry`: Update all po box type values in the manual address component (as well as added new items to the list).

### Features

- `agl-ds-button`: Button has been re-built. Also has an active state and rotate icon functionality
- `agl-ds-menu-dropdown-trigger`: will pass its active state when using `agl-ds-button` as slotted trigger
- `agl-ds-form-field-label` : Changed the subheading to be appearance = muted. Also fixed rendering bug which prevented storybook styled-as knob from changing the subheading font size.
- `agl-ds-radio-button type=panel` : Changed the font size for text in the radio button to be medium.

## 8.10.1 (2021-04-20)

### Features

- A new "sample spas" folder has been added to the repo. This is intended to aid in testing of changes to the Design System. At the moment it has Spa's running Angular 9, 10 and 11. The plan is to add stencil and maybe react later.
- Added automated Axe tests for the storybook stories. Note this has not yet been added to the CI pipeline, also that several stories are still failing as this is a work in progress.
- (internal) renamed the visual regression baseline image files
- `agl-ds-fulfilment-container` : expose public method to adjust the main content height as per the sidebar height.

## 8.10.0 (2021-04-16)

### Features

- Added automated Axe tests for the storybook stories. Note this has not yet been enabled in the build pipeline as several stories are still failing as this is a work in progress.
- (internal) renamed the visual regression baseline image files

### Bug Fixes

- `agl-ds-fulfilment-container` : setting the min-height of the main content height according to the sidebar height.

## 8.9.3 (2021-04-14)

### Bug Fixes

- `agl-ds-menu-dropdown-item`: selected/entered item on Angular SPA would rely on emitted event `(menuItemSelected)` instead of passing action via property

### Documentation

- Updated the list of code owners and npm package publishers to include Al Torney and John Seuren

## 8.9.2 (2021-04-12)

### Bug Fixes

- reverting the fulfilment container fix (in version 8.1.0) to adjust the height of content section according to sidebar section

## 8.9.1 (2021-04-09)

### Bug Fixes

- `agl-ds-modal`: converted `disableWhileWait` prop into public method (DCCT-5354)
- remove the "engines" property from package.json as it was impacting installation in consuming systems that enforce it via yarn (npm does not enforce engine versions)

## 8.9.0 (2021-04-09)

### Features

- `agl-ds-menu-dropdown`: added menu-dropdown component to cater for a popup list of action contents.
- `agl-ds-menu-dropdown-trigger`: added specific trigger area component to be use inside `agl-ds-menu-dropdown`.
- `agl-ds-menu-dropdown-item`: added specific menu-item component to be use inside `agl-ds-menu-dropdown`.

### Bug Fixes

- Capitalised state abbreviations in manual address entry component (DCCT-5470)

## 8.8.0 (2021-04-08)

### Features

- `agl-ds-modal`: added `disableWhileWait` option to enable/disable close of modal on click event on shaded modal backdrop or escape

## 8.7.0 (2021-04-06)

### Features

- (internal) open the manual address search modal, modal with footer and expand the dynamic dropdown component during visual regression tests
- (internal) visual regression tests now run on the storybook artifact (rather than on a separate build output)

### Bug Fixes

- Downgraded the @stencil/angular-output-target package from 0.0.5 (completed in Release 8.3.0) back to 0.0.2 as there is a bug in the package that prevents the use of "strictTemplates": true to the angularCompilerOptions ( ie for and Angular Spa versions 9, 10 and 11 that consumes the Design System). The bug produces the following build error: `Property 'subscribe' does not exist on type 'EventEmitter<any>'.`

## 8.6.0 (2021-03-30)

### Features

- (internal) Visual regression tests for each storybook story are now run in Chrome for desktop sized viewports

### Bug Fixes

- Fix for some components firing events twice when the design library is consumed in an Angular based application via the `AglDsComponentLibraryModule` wrapper
- `agl-ds-stepper` : Fix the incorrect value for active step number

## 8.5.0 (2021-03-23)

### Features

- `agl-ds-selection-card-group`: added group selection card that allows validation for the group. Also allows ability to add heading and a sub heading for the group.

### Bug Fixes

- `agl-ds-selection-card`: Rewrote selection card and fixed accessibility issue where the screen reader wouldn't read the associated label for the checkbox
- remove the use of https://loremflickr.com images from storybook stories as they change over time and will cause visual regression tests to fail

## 8.4.0 (2021-03-22)

### Features

- `alg-ds-icon`: added alt text to svg and images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text
- `alg-ds-illustration`: added alt text to svg and images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text
- `agl-ds-modal-footer`: added loading indicator for buttons
- split the readme.md into separate docs for consuming vs contributing

- `agl-ds-button`: added rotateButtonIcon method to rotate the button icon. Its to be used in situations like where the button is used as a trigger in `agl-ds-menu`
- `agl-ds-button`: added setButtonState method so that the state of the button can be changed programmatically. Its to be used in situations like where the button is the trigger component in `agl-ds-menu`.
- `agl-ds-button`: added iconSize prop to change the icon size

### Bug Fixes

- `agl-ds-radio-button`: fixed bug on slide down of type panel where the panel contents would show over the top of the other buttons
- fixed stories to have valid slotted html
- `agl-ds-modal`: fixed overflow bug for a large amount of content
- `agl-ds-tooltip`: fixed bug where tooltip trigger would not wrap correctly
- `agl-ds-checkbox`: fixed bug where the size of the tick in the checkbox changed under different circumstances
- `agl-ds-dropdown`: fixed position of the arrow to be closer to the right hand side of the dropdown
- removed formatting errors from changelog
- `agl-ds-button`: rebuilt the button to clean up the scss file to 1) remove an accessibility bug, 2) allow for the programmatic setting of the button state.

## 8.3.0 (2021-03-09)

### Features

- (internal) upgrade from Stencil 2.0.3 to 2.4.0 <https://github.com/ionic-team/stencil/blob/master/CHANGELOG.md#-240-2021-01-28> and various development dependencies. Note the minimum version of Node for design library development is now 14.15.5
- (internal) Bump the minimum version of Node for design library development to 14.15.5 (as per Stencil's recommendation)
- added the component name to the checkSlottedContentForInvalidHTML error message to help with the identification of incorrectly slotted content
- `agl-ds-p`: added the span tag as acceptable slotted content to cater for screen reader only text
- `agl-ds-stepper` : added slot content check

### Bug Fixes

- updated `agl-ds-guided-banner` to fix font sizes and make spacing between text elements consistent.
- fixed a typings issue that may have prevented compilation in consuming systems due to `JSX.Element` being referenced in `selection-card.d.ts`
- add `agl-ds-theme-pd` to the Angular wrapper module so that it can be used in Angular consuming systems
- `agl-ds-modal`: fixed bug where a large amount text in the content area was spilling out of the modal. The modal now correctly implements an automatic scroll bar
- reinstated default stroke and fill colours for the svgs so that they can be viewed in a viewer ie within VSCode. As it stands all colours were replaced with css variables making them un-viewable
- `agl-ds-stepper`: Updated the stepper to be be accessible. The mobile view may need to be revisited when we have better accessibility advice.
- `agl-ds-dropdown`: fixed bug where drop down arrow was not rendering correctly
- `agl-ds-fulfilment-container`: updated dropdown arrow on mobile to rotate correctly
- `agl-ds-manual-address-entry`: fixed bug where using keyboard to navigate out of street type selection would put a 0 in the street type textbox.
- `agl-ds-autocomplete`: fixed bug where using keyboard to navigate into available options (down arrow) would sometime jump straight to the bottom of the list then a random item in the list after that.

## 8.2.2 (2021-03-02)

### Bug Fixes

- Implemented new `customOptions` prop on the `agl-ds-dropdownbox` for consuming SPA's to dynamically change the available options in a `agl-ds-dropdownbox`.  This is to replace the original implementation which did not work in certain scenarios.

## 8.2.1 (2021-03-01)

### Bug Fixes

- `agl-ds-guided-banner`: Update padding-top for guided-banner with Back button
- fixed issue with $error colour as it was not accessible. Updated value to #ce2a3e

## 8.2.0 (2021-02-24)

### Features

- Storybook: Added in ability to switch between AGL and Power Direct themes on the global toolbar
- isolate the flatpickr package imports to the `agl-ds-beta-date-picker-do-not-use` component so that the library is not imported into utils.ts which greatly increases the size of the utils.js file

### Bug Fixes

- `agl-ds-tooltip`: fixed bug where the tooltip panel was not showing over the border of the radio button panel
- `agl-ds-tooltip`: fixed tooltip padding so that the trigger does not push away from the items above and below. i.e the trigger area now flows over the items above and below.
- `agl-ds-dropdown`: fixed bug where an external style sheet was adding a border-radius to button part of the dropdown
- fix min/max date handling in `agl-ds-beta-date-picker-do-not-use` when values were set to `undefined`

## 8.1.0 (2021-02-23)

### Features

- Upgraded Storybook from v5.3 to v6.1

### Bug Fixes

- `agl-ds-fufilment-container`: change to adjust the height of the main content if the side bar content height is more than the main content height
- `agl-ds-stepper`: Adding null checks for stepper service
- Where applicable, changed $c-tertiary-04 to $error
- Where applicable, changed $c-tertiary-02 to $success
- Fixed bug where `agl-ds-dropdownbox` would seem to get stuck in loops when dynamically adding / removing `agl-ds-dropdown-option`
- `agl-ds-manual-address`: update streetNumber to accept any value except empty string or whitespace only.

## 8.0.0 (2021-02-22)

### Breaking Changes

- Consuming **Stencil** SPA's will need to install [stencil-inline-svg](https://www.npmjs.com/package/stencil-inline-svg).  As SVGs internal to the design system are now inlined, when installing the latest Design System on a stencil SPA it will then convert them back to base64 encoded. This will break various component that have chevron / icons etc.... To support the DLS moving forward, please install this plugin and configure as per the instructions.
- Whilst the updates for theming are not technically a breaking change, when installing this latest version, consuming SPA's should do a regression test visually to ensure everything is still as is. (Mainly around icons / chevron's etc....)
- removed `$c-button-accent-01` through to `$c-button-accent-06` saas variables as they are not to be used internally in the design system any more
- changed `$button-accent-01` to be `$primary-01-tint-70` which was its closest match
- changed `$button-accent-02` to be `$primary-01-tint-90` which was its closest match
- changed `$button-accent-03` to be `$primary-01-tint-30` which was its closest match
- Theming will not work entirely in IE11.  Things like background colours for checkbox , buttons etc will not respect saas variables per theming component.

### Features

- Added in theming support for Power Direct in component `agl-ds-theme-pd`.
- Where required, SVG's are now inlined into component rather than base64 encoded.
- added Esc to close the `agl-ds-manual-address` and `agl-ds-modal` components

### Bug Fixes

- fix malformed <https://placehold.it> urls used in storybook knobs and increase the image resolution on the images that are referenced
- fixed hint and validation message on `agl-ds-manual-address` ( incorrect text was introduced with the removal of enums)
- fixed bug in `agl-ds-manual-address`, the radio button was not checked when the user entered the modal
- fixed `agl-ds-manual-address` and `agl-ds-modal` to work with NVDA screen reader
- fixed `agl-ds-manual-address` and `agl-ds-modal` to pass storybook accessibility tests when 2 are on one page
- fixed `agl-ds-manual-address` : changed the H1 to H2 for the heading as it fails accessibility.
- combined props, appearance and animation type into AnimationType for `agl-ds-modal` (appearance has been deprecated)
- fixed `agl-ds-modal` to work with shadowDom trigger buttons
- deprecated the trigger button parameter in the modal.openModal(obj) method. Use the modal.setTriggerButton(param) instead. Note the anonymous function the method requires (see storyBook docs)
- `agl-ds-autocomplete` : fixed accessibility bug - set aria-activedescendant = '' instead of false as it is not a valid value
- `agl-ds-notification-card` : added bubbling of the event from the button click. TODO Need to change the name of buttonClick from generic name to something more specific
- `agl-ds-tooltip`: fixed bug where trigger button was showing over the tooltip
- `agl-ds-tooltip`: fixed bug where trigger button was showing over the `agl-ds-dropdown` list
- `agl-ds-radiobutton`: fixed bug where a large collapsed panel was causing the panel parent to have a large bottom margin
- `agl-ds-dropdownbox`: fixed bug where dynamically adding / removing options from a Dropdown would break the functionality due to the Dropdown option `id` prop not being reset each time

## 7.6.2 (2021-02-15)

### Bug Fixes

- agl-ds-beta-date-picker-do-not-use: angular build not rendering

## 7.6.1 (2021-02-15)

### Bug Fixes

- agl-ds-radio-button: fix panel transition issue
- agl-ds-textbox: add tickbox onto mobile view
- agl-ds-hint-validation-message: keep min-height when there's no hint or validation text

## 7.6.0 (2021-02-10)

### Features

- agl-ds-tooltip: added auto read of tooltip for screen readers when the trigger button is selected in browse mode (ie arrow navigation for NVDA) and in forms mode (ie tab navigation for NVDA)
- agl-ds-tooltip: added hover for the trigger button
- added a beta version datepicker component (do not use as it's not production ready)

### Bug Fixes

- agl-ds-tooltip: removed the close button as it is not required on a tooltip
- agl-ds-tooltip: added tag slot protection to ensure semantic html
- agl-ds-p: added agl-ds-tooltip to the tag slot protection to ensure semantic html
- fixed agl-ds-radio-buttons: so that screen readers announce that there is expanded content on relevant panel radio buttons
- fixed bug where focus ring was showing when user tabbed into image radio buttons
- agl-ds-icon: reduced the size of the small version of the icon from 36px to 32px at the request of UX

## 7.5.1 (2021-02-02)

### Bug Fixes

- Handle valid text box and text overflow in the `agl-ds-textbox` component

## 7.5.0 (2021-01-27)

### Features

- Added screen reader test page to storybook
- added sr-context to agl-ds-checkbox
- updated readme to include a note on disabling fields

### Bug Fixes

- fixed the gutter between icon and image radio buttons to match the grid. The gutter is also now responsive in line with the grid.
- fixed the grid to have the correct gutter for large when only the medium class is applied ie col-md-6 before incorrectly presented the gutter as 24 px at the large breakpoint. Now it correctly gives 32px at the large break point if only col-md-x is used.
- fixed the background colour on the icon and image radio buttons to be white instead of transparent so that they work over a coloured background. ie in the panel radio buttons
- removed aria-labelledby from agl-ds-checkbox as it was causing NVDA to read the label twice in chrome. It is not required
- changed the hideFocusRingWhenUsingMouse function to add the agl-ds-using-mouse class using mousemove rather than mousedown as an auto screen scroll (ie with a link click) is interpreted as a mousedown event and this breaks the displaying of the focus ring
- fixed a focus bug on agl-ds-error-summary to allow the screen reader to read the whole summary text
- changed agl-ds-spacer to internally use a span rather than a div so it can be used in more situations
- changed agl-ds-checkbox to not use the shadow DOM
- fixed agl-ds-form-field-label so that the screen reader reads it correctly
- changed agl-ds-link to make use of an elements setFocus method if available when using the # anchor
- add ellipses to input boxes on overflow
- Add valid status for text input box
- stopped the propagation of the valueChange event from the agl-ds-radio-button. ie When a radio button is placed into a radio button panel it stops a child from firing the parents valueChange event.

## 7.4.0 (2021-01-15)

### Features

- Add ellipses to input boxes on overflow
- Add valid status for text input box
- Add valid status for auto complete
- Add valid status for address lookup

### Bug Fixes

- Updated `agl-ds-fulfillment` container to change error-summary (deprecated) slot to notification. Also some minor layout fixes including aligning the notification card with the content
- allow space in street number in manual address entry
- Fixed bug in radio button group where a previously checked radio button could not become "unchecked" if the selected value for the radio button group was programmatically set back to `null` or `undefined`

## 7.3.0 (2020-12-21)

### Features

- Added new icons types to the `agl-ds-radio-button` component:
  - agl\_icon\_dig\_voip\_no\_32px
  - agl\_icon\_dig\_voip\_yes\_32px

### Bug Fixes

- fixed the last active step in the mobile view and hover style of the `agl-ds-stepper` component

## 7.2.0 (2020-12-16)

### Features

- Add an `error` appearance option to `agl-ds-text`
- Add a `showCloseIcon` property to display a dismiss “x” option at the right top of the `agl-ds-notification` component

## 7.1.1 (2020-12-11)

### Bug Fixes

- changed the `agl-ds-stepper` to use the shadow dom
- `agl-ds-stepper` component updated to handle click event of the completed step and fixed a bug in loading the mobile layout
- added the html button tag to the overall CSS reset (`_reset.scss)` for the focus ring

## 7.1.0 (2020-12-08)

### Features

- Add `agl-ds-stepper` and `agl-ds-step` components.
- Update `agl-ds-fulfillment` container to add new slot for stepper component.

### Bug Fixes

- Update `agl-ds-fulfillment container` to fix layout issues where the error summary was not lining up with the main content.
- Fixed `TypeError: unable to get property 'toUpperCase' of undefined` issues with slot content validation in IE11 and Edge 16,
- Fixed incorrect font weights in the `agl-ds-link` component

## 7.0.0 (2020-11-27)

### Breaking Changes

- Removed the use of exported enum types in favour of [string union type aliases](https://2ality.com/2020/02/enum-alternatives-typescript.html#unions-of-string-literal-types), this will improve type safety and intellisense support in consuming systems. If you have been referencing design system enums, you will need to migrate to the new string union equivalent.
- The `suppressMargin`="true" property has been removed from `agl-ds-h(1-6)`, `agl-ds-illustration` and `agl-ds-p` tags in favour of `bottomMargin`="none"
- The title slot in `agl-ds-spotlight` has been removed in favour of the description slot
- The default value of the `poBoxType` property used by the `agl-ds-manual-address-entry` and `agl-ds-address-search` components has been changed from '' to null

### Features

- Add intellisense support for Angular applications when using VSCode as an IDE. See [consuming the AGL Design Library version 7.0.0 onwards](https://github.com/AGLEnergy/AGL.DesignSystem#angular-consuming-the-agl-design-library-version-700-onwards) for further details.

### Bug Fixes

- (internal) Fix potential race condition in day-of-month-picker.e2e.ts

## 6.31.0 (2020-11-25)

### Features

- Update the `agl-ds-selection-card` story to include editable slot content and add slot notes to the docs
- Added `agl-ds-day-of-month-picker` component.

### Bug Fixes

- Changed agl-ds-link to have a fontweight of semibold
- Restore the emitter of change events in radio button groups to emit value of radio selected instead of HTML element

## 6.30.0 (2020-11-20)

### Features

- Added a new composite `agl-ds-selection-card` card component
- Added named slots to notification card for rich text message and call-to-action
- Storybook: migrate from the deprecated [Notes Addon](https://www.npmjs.com/package/@storybook/addon-notes) to the newer [Docs Addon](https://www.npmjs.com/package/@storybook/addon-docs)
- (internal) migration of Storybook stories from `storiesOf` to `component story format (CSF)`
- (internal) migration of Storybook stories to use [lit-html](https://lit-html.polymer-project.org/) templates

### Bug Fixes

- Fixed bug where child radio buttons could not be set programmatically when slotted into a radio button panel
- Removed slot validation for the "alt" version of the library. Also added `<br>` to `agl-ds-heading` and `<span>` to `agl-ds-text` tag validation whitelist
- add focus-ring to image-text-card: triptych variant

## 6.29.0 (2020-11-12)

### Features

- Added secondary styling for `agl-ds-link` appearance property

### Bug Fixes

- Fixed padding within `agl-ds-notification`

## 6.28.0 (2020-11-11)

### Features

- (angular) added reactive forms compatibility to the `agl-ds-dropdownbox` component

## 6.27.0 (2020-11-10)

### Features

- Added extra-content slot to `agl-ds-fulfilment-container`

### Bug Fixes

- Fixed bug with sub header not showing in `agl-ds-radio-button`

## 6.26.0 (2020-11-06)

### Features

- (internal) remove the explicit references to knobs and a11y storybook addons in each story - use common config in preview.js
- Deprecated singleColumn for the `agl-ds-radio-button-group` component in favour of "layout"

### Bug Fixes

- Accordion label was rendered in Arial font
- Fixed bug in agl-ds-form-field where the colour of the heading/legend was not applied
- Increased the size of the image in agl-ds-banner from set width (178px) to 264px
- Added stencil-router to the agl-ds-guided-banner slot validation whitelist
- Dropdown button didn't have a type specified and was defaulted to `submit`. Fix to keep the type as `button` so that form submit is not triggered on click.

## 6.25.1 (2020-11-02)

### Bug Fixes

- Radio button panel does not expand in Angular

## 6.25.0 (2020-11-02)

### Features

- Added HTML tag validation of slotted contents to all components that use slots
- Added note to Readme regarding the use of the focus ring in consuming systems.
- Updated Notification Card border radius
- Updated Notification Card Filled background colour
- Update Navigation Card, Heading text with bottom margin to 16px

### Bug Fixes

- Fix the html in various storybook stories to make it valid html
- Fix for card component hover interaction on FireFox

## 6.24.0 (2020-10-27)

### Features

- Added error state to basic `agl-ds-radio-buttons`
- Added image type to `agl-ds-radio-buttons`
- Added new icons to icon radio button
  - agl\_icon\_dig\_account\_no\_32px
  - agl\_icon\_dig\_account\_yes\_32px
  - agl\_icon\_dig\_battery\_new\_32px
  - agl\_icon\_dig\_solar\_bundle\_32px
  - agl\_icon\_dig\_solar\_no\_32px
  - agl\_icon\_dig\_solar\_yes\_32px
- (internal) add a CODEOWNERS file to default pull request reviewers in GitHub

### Bug Fixes

- Deprecated $font-weight-semi-bold : use $font-weight-semibold
- `agl-ds-spotlight` component had extra padding on the card container and not on the description area.
- Fixed bug in `agl-ds-radio-button` type = panel where a prescribed selected value correctly opened the panel but did not display the contents of the panel.

## 6.23.0 (2020-10-19)

### Features

- Combine Open Sans and Titillium Web font references into a single reference url
- Update navigation card image size, making tablet and desktop views to be the same.
- Icon updated - agl_icon_digi_modem_32px.svg
- Update to Storybook 5.3.21
- (internal) Update to latest sass linters, code formatting and testing libraries

## 6.22.0 (2020-10-16)

### Features

- Updated `agl-ds-button` colours
- Added $c-primary-01-shade-20 sass variable

### Bug Fixes

- Fixed bug on `agl-ds-form-field` that removed usage of innerHTML so that click events on slotted content now work
- Fixed incorrect event types on the `agl-ds-trusted-html-content`, `agl-ds-modal` and `agl-ds-address-search` components

## 6.21.0 (2020-10-15)

### Features

- Added alternative look to the `agl-ds-dropdownbox` component with property **type**. `type="default"` offers dark dropdownbox on lighter background. `type="default-inverse"` offers lighter dropdownbox on darker background.
- Added support for `<input type="submit">` on the `agl-ds-button` component

## 6.20.1 (2020-10-13)

### Bug Fixes

- fixed incorrect Angular component name in agl-ds-component-library-module.ts (AglDsFormfieldLabel should be AglDsFormFieldLabel)

## 6.20.0 (2020-10-13)

### Features

- Added agl-ds-form-field-label component.
- Retrofitted agl-ds-form-field-label to agl-ds-radio-button-group - This change will require consumers to possibly apply the styledAs attribute to the agl-ds-group
- Added agl_icon_dig_pencil_32px icon to the icon radio buttons
- Added 10%, 30%, 50%, 70% and 90% tint to the primary, secondary and tertiary colours

### Bug Fixes

- fixed bug where the singleColumn attribute caused the miss-alignment of some types of radio buttons ie they where displayed to far left

## 6.19.1 (2020-10-12)

### Bug Fixes

- remove the background fill colour from the moving and home radio button icons

## 6.19.0 (2020-10-09)

### Features

- Added support for hiding images on mobile viewports and setting flat/elevated appearance on the agl-ds-spotlight component
- Deprecated the title slot on the agl-ds-spotlight component
- added the SingleColumn prop to the agl-ds-radio-button-group to allow for a column based layout as an alternative
- Updated the `addressInputValue` property to accept either a `string` or a previously stored `addressDetailsModel` to set the initial value of the agl-ds-address-search component.

### Bug Fixes

- fixed hover bug on agl-ds-button
- updated layout of all radio buttons to fix bug where content radio button were not displaying 3 wide on desktop
- fixed bug where the validation message on radio buttons was not positioned correctly in a Stencil Spa
- fixed bug where the error border was not displaying correctly on radio buttons
- fixed bug where users could incorrectly tab to the contents of the hidden panel in the panel type radio buttons

## 6.18.0 (2020-09-30)

### Features

- Changed colour of carbon-neutral icon of radio button to green

### Bug Fixes

- fixed padding at bottom of radio button panel when validation component is the last element
- fixed default bottom margin setting in radio button panel
- fixed bug in some instances of basic radio button where middle of button was off center
- changed the font size (on small devices) of the body medium mixin to 14px

## 6.17.0 (2020-09-29)

### Features

- Added custom focus ring to all relevant design system components
- Added bottomMargin prop to agl-ds-radio-button panel

### Bug Fixes

- Re-built radio buttons to fix keyboard access

## 6.16.0 (2020-09-24)

### Features

- (internal) upgrade from Stencil 1.14.0 to 2.0.3 <https://github.com/ionic-team/stencil/blob/master/CHANGELOG.md#-203-2020-09-03>. Note the minimum version of Node for design library development is now 12.10.0

## 6.15.0 (2020-09-24)

### Features

- Added carbon-neutral icons to radio buttons
- Made bottom sticky disappear when content slot leaves bottom of the page in fulfilment container layout

### Bug Fixes

- Fixed modal footer hiding behind bottom control bar on mobile safari.
- Fixed modal header autofocus when header is set after componentWillLoad.
- Updated styles on fulfilment container to match the design

## 6.14.0 (2020-09-21)

### Features

- Added callbackOnClick property to the agl-ds-link component

### Bug Fixes

- Fixed compilation issues when building in an angular 8 project
- Added validation of Postcode for selected state in agl-ds-manual-address-entry component
- Fix agl-ds-error-summary `Missing 'module' parameter for story with a kind of 'Composite/Error summary'. It will break your HMR` console warning in storybook

## 6.13.0 (2020-09-17)

### Features

- Added states 'NT', 'TAS' & 'ACT' for States Dropdown in Manual Address

### Bug Fixes

- Added a min-height to agl-ds-radio-button as it is sometimes appearing taller in ie 11
- Updated padding on promo card to match design
- Changed icon size on feature cards to medium and removed top padding on large screen so that it aligns with icon
- Fixed positioning of loading spinner for autocomplete in IE11
- Fixed positioning of error icon on input fields for IE11
- Fixed ie 11 bug on agl-ds-textbox bottom animation
- Fixed display issue of modal component on tiny screens
- Fixed agl-ds-p "The state/prop "bottomMargin" changed during rendering. This can potentially lead to infinite-loops and other bugs." console warning
- (internal) fix "changes detected" reloading loop when running `npm start` on macOS by moving the Angular wrapper auto-generated files out of the src folder
- (internal) fix javascript console errors on the ./src/index.html page

## 6.12.0 (2020-09-10)

### Features

- added font-weight-regular to agl-ds-text
- added a small height version of agl-ds-banner-simple
- added new agl-ds-space responsive css classes for vertical orientation

### Bug Fixes

- fixed rotation of down arrow on agl-ds-fulfillment sticky header

## 6.11.0 (2020-09-08)

### Features

- added storybook `paddings` addon
- added bottomMargin prop to agl-ds-h and agl-ds-p
- added all spaces space-00 to space-16 to the the agl-ds-spacer
- added addressSearchBlur event to address-search
- added setTextboxValue method to address-search

### Bug Fixes

- fixed alignment of agl-ds-button loader spinner on IOS
- fixed fulfillment container bug where drop down panel was not showing correctly if page scrolled
- removed rounded corners on agl-ds-textbox in IOS
- fixed address search component so that it does not get focused after manual address component is closed

## 6.10.0 (2020-09-03)

### Features

- allow the dropdown list to be closed by clicking the dropdown button
- allow up/down arrow keys to trigger a dropdown open

### Bug Fixes

- fixed IE11 UI issues with `agl-ds-illustration-text-simple`
- fixed autocomplete not firing its blur event correctly
- fixed autocomplete option not getting selected if the user clicked on the option text in IE11
- (internal) update the build scripts to fail when certain build errors occur
- (internal) fixed unit test warnings by mocking element.select function

## 6.9.3 (2020-08-28)

### Features

- Added feature on address search component to allow select address via one click
- Added default content slot to agl-ds-notification component to allow for rich content in message area

### Bug Fixes

- segmented-card width not respected in IE11 resolved.
- corrected all prop/attributes from das-case to be camelCase in all JSX code as per documentation <https://stenciljs.com/docs/properties>
- fixed agl-ds-modal being displayed on the bottom of the screen and partially hidden on mobile view
- (internal) remove ".component" from the trusted-html-content folder name

## 6.8.0 (2020-08-26)

### Features

- added border, background-colour and container-size(full) props to agl-ds-trusted-html-content. Also added scroll event
- added scroll event to agl-ds-modal

### Bug Fixes

- decreased the line-height to 1 for agl-ds-display-01 and agl-ds-display-02 mixins

## 6.7.0 (2020-08-24)

### Features

- Added agl-ds-trusted-html-content component
- Set min-width to auto on button small

### Bug Fixes

- Removed svg constant from radio button enum

## 6.6.2 (2020-08-20)

### Bug Fixes

- Fixed error when no "appearance" set on header component

## 6.6.1 (2020-08-20)

### Bug Fixes

- removed the POC toggle button reference from the Angular module

## 6.6.0 (2020-08-20)

### Features

- segmented-card updated to include `agl-ds-card appearance=elevated`
- remove the "POC/toggle" component as it was just an example from the early stages of the design system project
- ability to apply secondary level of highlight to text, p and header components

### Bug Fixes

- removed min height on agl-ds-next-steps header to correctly accommodate wrapping of header
- fixed focus error on agl-ds-link when using scroll to function
- updated $c-neutral-07 colour variable
- Updated agl-ds-modal-footer styles to allow for max button width
- Updated agl-ds-modal-footer to support IE11 correctly
- added recursive search on scroll to function in agl-ds-link

## 6.5.0 (2020-08-17)

### Features

- Changed agl-ds-text to have letter-spacing as a parameter and fixed BEM styles on agl-ds-text
- Added a new agl-ds-modal-footer component for use in the agl-ds-modal footer slot

### Bug Fixes

- Added shadowDom support for the agl-ds-link component when searching for shadowDom ids (i.e via the agl-ds-error-summary component)

## 6.4.1 (2020-08-14)

### Bug Fixes

- fix build substitutions for "agl-ds " (i.e with a space) in the "alt" version of the design system. should fix styling issues with the agl-ds-alt-text component.

## 6.4.0 (2020-08-14)

### Features

- Added medical_alarm icon to radio buttons

### Bug Fixes

- Correction of agl-ds-p and agl-ds-text attributes to camelCased for internal implementation within composite components JSX
- Changing the overflow:hidden/visible on the radio button panel, this is for controls like autocomplete to show full list when it's inside radio button panel.

## 6.3.0 (2020-08-13)

### Features

- Added modem-use-own icon to radio buttons

### Bug Fixes

- Fix center screen modal issue and modal IE issue
- fixed bug in agl-ds-fulfillment container where sticky header was not being reset correctly
- Added z-index on the agl-ds-fulfillment bottom panel
- Fix Modem icon in radio buttons, add modem icon to story
- bug fix in address search component's service to pass exclude post office for mailing address
- re-wording the hint text in manual address search state hint text
- Retrofit error summary component into manual address entry
- icon-text - prefooter title font size increased to LG

## 6.2.0 (2020-08-11)

### Features

- Add a new `withTopComponent` property to the Banner Simple component to allow for components to be placed directly above it
- Added Modem icons to radio buttons

## 6.1.0 (2020-08-10)

### Features

- Added new event addressSearchInput which fires when user search for a new address, this event will help to clear previous selection and reset error state.

## 6.0.0 (2020-08-10)

### Breaking Changes

- renamed agl-ds-product-card to agl-ds-segmented-card.

### Features

- added colour tints for primary/secondary/tertiary colours (80,60,40,20 percent)

## 5.1.0 (2020-08-10)

### Features

- Added Error Summary slot to the agl-ds-fulfillment container
- Added a show spinner property to address search component so that the consumer can decide to show/hide the spinner

### Bug Fixes

- Removed the 'checkbox' prefix from the agl-ds-checkbox `id` attribute so that it can be used with the agl-ds-error-summary component (this requires the id of the element to scroll to)
- Changed to agl-ds-illustation in simple banner, also updated paddings
- Fixed bug to show sub-banner in simple container
- Fix wrong validation text for street number in manual address entry
- Fixed image not encoded in notification card component
- Added overlay under spinner and error icon in address search component

## 5.0.0 (2020-08-05)

### Breaking Changes

- Prior to this change the agl-ds-card was passed in via the slot. Ux requirements now mean that the agl-ds-card is part of the agl-ds-fulfilment-container so it does not need to be passed in

### Features

- Added watch on agl-ds-card appearance to be able to change the border programmatically
- expose a new "manual address option selected" event for the agl-ds-address-search component

### Bug Fixes

- fixed pointer on sticky top, fixed some layout bugs (agl-ds-fulfilment-container)
- updated the margins on tablet and mobile for the full screen modal and header paddings for the full screen modal (agl-ds-modal)

## 4.0.0 (2020-08-01)

### Breaking Changes

- The sizes for illustration have changed. This will likely break existing uses of illustration and components dependant on it.

### Features

- Updated color palette with `Tints`
- Added agl-ds-error-summary component
- Added ability for agl-ds-link to scroll to element on a page
- Added id prop to checkbox

### Bug Fixes

- fix "sr-only" context and "opens in new window" should render independently on button/link components
- Updated the z-index of the modal component to a higher value so that it renders on top of all the components on the page.
- Fix style conflicts when basic radio buttons inside panel radio buttons

## 3.11.1 (2020-07-27)

- modal A11y focus to first item in header if exist; added default padding to content; update height from `100%` to `100vh`; 100% width at medium breakpoint for centerscreen modal
- fixed the layout of the fulfillment container to accommodate an AEM header section and to have the sticky sidebar header to move with the page and stick when it gets to the top

## 3.11.0 (2020-07-24)

### Features

- Updated the badge component with new styling from the design team
- Changed $c-tertiary-02 (from this #008000 to #2CAA18) and $success (from #1d781d to #008000) for accessibility
- Added colour tints.
- hide image on medium break point for the guided banner component.

### Bug Fixes

- fix "value-accessor" argument error when importing the design library into an Angular 8 application
- fixed a bug on address search when user can confirm address without put anything in for the first time due to default requiredFields value is missing.

## 3.10.2 (2020-07-20)

### Bug Fixes

- minor alignment of cta section on product-card

## 3.10.1 (2020-07-20)

- no release due to azure issues

## 3.10.0 (2020-07-20)

### Features

- Added color palette to storybook and updated the tab component colors
- Added 'size' option to the button component.

### Bug Fixes

- fixed checkbox to accommodate p tags
- prevent checkbox checked error on component init
- added shadow:true to fulfillment container

## 3.9.0 (2020-07-16)

### Features

- (internal) upgraded npm dependencies to address security vulnerabilities
- added space00 and space01 to the spacer component
- added visible and hidden classes to grid
- updated fulfillment container to have sticky dropdownmodal at top

## 3.8.0 (2020-07-16)

### Features

- Added address search component

## 3.7.0 (2020-07-15)

### Features

- create New Product Card Component
- create icon-text - feature item variant
- create icon-text - promo card variant
- Added the stencil angular wrapper for the textbox
- Added custom events to modal closures so as the consuming application can send appropriate analytic events
- Added manual address component
- Added simple container

### Bug Fixes

- Updated tertiary button to show Loading Icon in center
- Fix stencil angular wrapper to support Angular 10's stricter explicit Angular decorator requirement
- Updated Radio button component to not show validation component at all when no validation text is passed in
- Fixed dropdown component bug when press up key and emit selectedvalue when dropdown close.

## 3.6.1 (2020-07-13)

### Bug Fixes

- updated Stencil angular wrapper files to fix bug where the radiovalueaccessor was missing
- Added background colour to story of Banner Simple
- Added padding to Banner Simple
- Fixed guided container component width issue using flex-grow instead of width:calc()

## 3.6.0 (2020-07-09)

### Features

- Added a prop for top and bottom border for the spacer component
- Added background color to filter modal and removed the outliner on header slot
- Added Stencils angular wrapper. This feature is automatically added as part of the build process ( see readme for details )
- (internal) document the design library manual release process

## 3.5.0 (2020-07-09)

### Features

- Resized the loader icon to small size for all button types

### Bug Fixes

- Fixed validation component incorrect behaviour in scenario when validation text is passed in and hint text is not.
- Fixed clicking a link always going to new page issue in notification component due to an incorrect prop passed in agl-ds-link.
- Fixed default value not showing up for autocomplete component

## 3.4.0 (2020-07-07)

### Features

- Modified Banner Simple to accept a slot instead of just text
- Added left and right padding for guided container left mode
- Updated close button hover style, background color and anchor modal to the bottom on small and medium breakpoints in popup modal.
- (internal) split build scripts into smaller groups to assist with timing and build issue investigations

### Bug Fixes

- Fix gap that has appeared on the guided container after grid changes

## 3.3.0 (2020-06-30)

### Features

- Added top padding on guided container content section
- Added border top on footer slot in modal component
- Updated button interaction styling
- Added paddings for popup modal
- Added Fulfilment container layout component
- Added spacer component

### Bug Fixes

- Storybook: show viewports that correspond to the AGL design system breakpoints for small/medium/large devices, rather than the default storybook viewport sizes.
- Fixed an issue with the outer gutters on the grid not behaving as expected when reverse class was applied to the row

## 3.2.0 (2020-06-24)

### Features

- updated checkbox layout to enable stacking multiple checkbox input together; and element restructuring to enable keyboard navigation for accessibility purpose.
- added suppress bottom margin to the illustration component
- added illustration position to the illustration-text-simple component

## 3.1.0 (2020-06-23)

### Features

- Produce an agl-ds-alt prefixed version of the design library and package it into a new ./dist/alt folder within the build artifact
- Added feature in modal component to allow user to click outside to close modal
- Added feature to grid to remove the necessity to specify all 3 breakpoint variations if the have the same col number ( ie can go with sm-col-3 previously sm-col-3 md-col-3 lg-col-3)
- Added mixin to simulate the focus ring on heavily styled components ie radio buttons and checkbox
- updated checkbox layout to enable stacking multiple checkbox input together; and element restructuring to enable keyboard navigation for accessibility purpose.

### Bug Fixes

- fixed bug in radio buttons where a programatic search for labels found labels in other components not just the radio buttons
- fixed margin incorrectly added on the radio buton fieldset
- added references to the hint and validation divs to avoid a class name collision when multiple hint-validation components on the same page. The validation text was randomly not showing on all fields when set to error

## 3.0.0 (2020-06-22)

### Breaking Changes

- checkbox default layout has been changed, previous checkbox usages need to set `type="validation"` to retain its layout

### Features

- updated checkbox layout to enable stacking multiple checkbox input together; and element restructuring to enable keyboard navigation for accessibility purpose.

### Bug Fixes

- fixed bug in the heading components where the default font for an h tag overrode the styledAs font
- triptych image min-height added to ensure images have equal heights
- fixed vertical/lineheight issues on hint/validation text component

## 2.0.0 (2020-06-16)

### Breaking Changes

- renamed icons being used for radio button
- renamed chevron icon

### Features

- Added feature in modal component to allow user to click outside to close modal
- Changed navigation card icon to chevron

### Bug Fixes

- fix button icon position for medium screen size
- fix button icon visibility for active and focus button states
- fix left-filler-cell was showing white colour in guided-container.component when there is vertical scroll
- fix radio button icons not showing up on Edge, Safari, Internet Explorer

## 1.0.0 (2020-06-12)

### Breaking Changes

- use semantic versioning for the release version numbers
- renamed Textbox "type" type to TextboxType as it was causing a conflict with Radio button type in component.d.ts

### Features

- added new flex grid system
- updated colours and shadows in sass vars
- updated agl-ds-button component to show an icon along with text for both Primary and Secondary types in addition to the already existing functionality for Tertiary types.
- updated agl-ds-button component (type 'Tertiary') to show 'xs' sized icon and with reduced padding on side on icon
- updated agl-ds-guided-banner component with an optional Back Button
- new agl-ds-autocomplete component

### Bug Fixes

- fixed storybook ul styling issue
- fixed guided-container to use the grid system
- fixed icon inside the radio button component which was not rendering in consuming systems.

---

## 0.18.3 (2020-06-10)

- fix IE11 icon-text-card Prefooter should not be a flexbox

## 0.18.2 (2020-06-10)

- fixed icon inside the radio button component which was not rendering in consuming systems
- fixed image rendering on navigation-card in IE
- fixed ie 11 bugs in radio buttons and next-steps
- update pr template to add ie11 check

## 0.18.1 (2020-06-09)

- IE11 - icon-text-card update icon container min-width
- IE11 - image-text-card content max-height corrected
- inline SVG support added to triptych
- inline SVG support added to accordion

## 0.17.1 (2020-06-05)

- fix embedded asset paths in the next steps component so the tick and empty circle render in consuming systems

## 0.17.0 (2020-06-05)

- fix modal unit test warnings
- fix css url asset references not working in consuming systems. Assets are now inlined directly into the css during the build process. impacts the radio button, guided banner and checkbox components.
- allow explicit imports of svg files in tsx. fixes the right arrow icon inside the navigation card component which was not rendering in consuming systems.
- change basic radio button style
- MAJOR refactor icon-text-card, it was completely non-functional in IE11
- (internal) add css autoprefixer configuration
- Updated Button Component (type 'Tertiary') to show icon along with text

## 0.16.0 (2020-06-02)

- (internal) update to the latest npm packages dependencies including stencil/core 1.14.0 (but not storybook 5.3.9)
- icon-text-card refactored to remove internal padding that misbehaved at different breakpoints
- added next-steps component
- image-text-card refactored for design change at medium breakpoint. Renamed for consistency.
- added agl-ds-tooltip

## 0.15.0 (2020-06-01)

- fix incorrect button size for medium breakpoint
- fix styling for dropdown and textbox component
- fix to check for null on hint validation message
- add the ability to hide the back link on the guided banner component

## 0.14.0 (2020-05-27)

- added agl-ds-text component
- added agl-ds-segmented-container
- fixed spotlight height by making it more flexible and contents are aligned to the centre.
- fixed triptych anchor link clickable issue for the whole card.

## 0.13.1 (2020-05-25)

- spotlight and triptych image scaling. using CSS object-fit:cover so the image does not skew given odd shaped image being used inside it. The overflow is hidden gracefully

## 0.13.0 (2020-05-25)

- added illustration component
- added illustration-text-simple component
- added status-container layout component
- fixed accessibility bug on validation hint text component (note there is still 1 incomplete test but this is not a relevant test)
- fixed bug in body font weights
- banner-callout image scaling. using CSS object-fit:cover so the image does not skew given odd shaped image being used inside it. The overflow is hidden gracefully with circular image

## 0.12.0 (2020-05-22)

- hero banner story updated to consume button-link correctly
- fix for hero banner image scaling issue
- updated font weight on text-highlight component
- added dropdown component
- added modal component

## 0.11.0 (2020-05-20)

- added Banner Simple component
- format the storybook a11y context correctly in the link component
- documentation: correct erroneous npm install instructions
- added text-highlight component
- added an "error" type to the notification card component

## 0.10.2 (2020-05-18)

- fixed svg arrow inline code and width of the triptych component.

## 0.10.1 (2020-05-15)

- fixed IE11 banner callout issue

## 0.10.0 (2020-05-15)

- updated README.md and simplified commands for developers to load storybook during development
- (internal) update to the latest npm packages dependencies including storybook 5.3.8 and stencil/core 1.12.7
- added spotlight component.
- added triptych component.
- added banner callout component

## 0.9.1 (2020-05-12)

- fix accordion scrollHeight animation issue for all browsers
- added notification component

## 0.9.0 (2020-05-12)

- added validation/hint component
- updated look and feel of radio buttons and the fixed a bug in the selected hover state of the icon and content radio buttons
- (internal) automated the optimization of svgs under the assets folder
- fix "undefined" appearing in the navigation card title
- added radio button panel
- retrofitted the validation component to checkbox, radio buttons and textbox
- added change log publishing to storybook
- updated checkbox

## 0.8.0 (2020-05-08)

- Updated button component to render an anchor tag if href is provided else render a button
- Firefox incorrectly calculating accordion panel height
- Added textbox component
- Fixed icon-text card component - feature - large breakpoint view.

## 0.7.2 (2020-05-04)

- IE fix for accordion
- (build) run tests prior to generating the final build artifact, as the tests were altering the contents of the ./dist folder
- Added storybook source addon

## 0.7.1 (2020-04-27)

- suppressMargin on heading and paragraph
- fix tests
- correct breakpoints so they compile
- add fonts to expose for AEM
- updated heading styledAs to match TitleType rather than headingType, we are styling a h1 as title2 (eg: lg), not styling a h1 as a h4
- added radio button panel option to the radio buttons

## 0.7.0 (2020-04-27)

- updated radio button component to run errors dynamically
- fixed accessibility on radio buttons
- removed shadow dom from radio button group and set so that aria tags work between the 3 components. Also turned on css scoping
- added checkbox component
- added checkbox group component

## 0.6.1 (2020-04-21)

- updated the icon text card background
- updated loading-indicator size

## 0.6.0 (2020-04-20)

- Added link component
- updated PR template
- created icon component
- updated the icons and icons names for the radio button icon set
- updated the hover and selected state for both radio buttons and navigation card
- updated card component: hoverable, removing elevation variance
- added error state to the radio buttons
- updated the error color
- fixed padding/margin issues on the guided container
- fixed height and width of the navigation card
- updated card component: hoverable, removing elevation variance, default to 'Elevated'
- created icon text composite card
- created spinner component

## 0.5.0 (2020-04-01)

- added hero-banner component (grouped with guided banner under new directory 'banner')
- updated fonts in navigation-card, guided-banner and radio-buttons
- fixed bug preventing p tag from displaying correct appearance

## 0.4.1 (2020-03-31)

- fixed import statement on guided banner to not be relative up to above the src folder

## 0.4.0 (2020-03-31)

- added card component
- added badge component

## 0.3.1 (2020-03-23)

- fix: scss reset and global files need to be excluded from the published artifact

## 0.3.0 (2020-03-20)

- fix: systems that use *yarn* were unable to install this library
- added h1-h6 components
- added p (paragraph) component
- move storybook examples into core, composite and layout folders
- (internal) update stencil to 1.10.0
- (internal) update storybook to 5.3.17

## 0.2.1 (2020-03-11)

- added guided container
- added guided banner
- added navigation card
- added accordion
- added radio buttons
- added radio button set
- added radio button group

## 0.1.8 (2020-02-26)

- split components in build output into individual modules
- add [storybook](https://storybook.js.org)
- (internal) update stencil to 1.9.0-19

## 0.1.7 (2020-02-20)

- no changes, just testing package publishing system

## 0.1.6 (2020-02-05)

- Added export of global .scss files
<!-- markdownlint-restore -->
