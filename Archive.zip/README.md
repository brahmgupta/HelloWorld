# AGL.DesignSystem (web components)

*A Library of reusable web components that can be used across all web channels for the purpose of design consistency, speed to market, accessibility (a11y) and code reuse.*

[![Build Status](https://dev.azure.com/aglenergydev/Maharaja/_apis/build/status/AGL.DesignSystem?branchName=master)](https://dev.azure.com/aglenergydev/Maharaja/_build/latest?definitionId=976&branchName=master)

See a showcase of the available components at: <https://agl-design-system.azurewebsites.net>

To consume the web component design system in another project see: [README-CONSUMING.md](./README-CONSUMING.md)

To run this project locally and make contributions see: [README-CONTRIBUTING.md](./README-CONTRIBUTING.md)

> To contact the team we suggest the following slack channels:
>
> - `#design-system` - general questions about the project
> - `#design-system-tech` - technical questions for other developers
