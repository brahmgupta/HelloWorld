#!/bin/bash -eu

FIVE_YEARS_IN_DAYS=$((365 * 5))
openssl req -x509 -out ./ssl/localhost.crt -keyout ./ssl/localhost.key \
  -newkey rsa:2048 -nodes -sha256 \
  -days $FIVE_YEARS_IN_DAYS \
  -subj '/CN=AGL Design System Localhost' -extensions EXT -config <( \
   printf "[dn]\nCN=localhost\n[req]\ndistinguished_name = dn\n[EXT]\nsubjectAltName=DNS:localhost\nkeyUsage=digitalSignature\nextendedKeyUsage=serverAuth")
