import initStoryshots from '@storybook/addon-storyshots';
import { imageSnapshot } from '@storybook/addon-storyshots-puppeteer';
import puppeteer from 'puppeteer';

/**
 * Summary of the main visual regression dependencies
 *
 * jest: test runner by Facebook
 * @babel/preset-env: all the babel stuff to be able to run ES6 in jest
 * @storybook/addon-storyshots: addon that integrates storybook to jest
 * @storybook/addon-storyshots-puppeteer: integration of storybook to puppeteer + jest-image-snapshot
 *
 */

function execute(breakpointName, viewportWidth) {
  console.log(
    `Generating ${breakpointName} viewport storybook image snapshots from ${storybookUrl}. Ignore the 'Unexpected loaded state. Did you call 'load' twice?' console warning - it's unrelated to visual regression testing`
  );

  let browser = null;

  const getMatchOptions = ({ context: { kind, story }, url }) => {
    return {
      customSnapshotsDir: `./visual-regression-snapshots/${breakpointName}`,
      failureThreshold: 0.03, // 2% threshold, jest-image-snapshot default is 0.01
      failureThresholdType: 'percent', // other option is 'pixel'
      fullPage: true
    };
  };

  const beforeScreenshot = async (page, { context: { parameters } }) => {
    let logMessageSuffix = '';

    await page.evaluate(() => {
      /**
       * For an unknown reason some of the components under test will not load the correct font when run on an azure devops build agent
       * so we inject the required fonts into the <head> as a work around
       */
      var newLinkElement = document.createElement('link');
      newLinkElement.rel = 'stylesheet';
      newLinkElement.href =
        'https://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800|Titillium+Web:100,200,300,400,500,600,700,800';
      document.head.appendChild(newLinkElement);
    });

    await page.evaluateHandle('document.fonts.ready'); // wait for fonts to load

    const storySpecificOverrides = parameters.storyshots && parameters.storyshots.visualRegression;
    if (storySpecificOverrides && storySpecificOverrides.beforeScreenshotAsyncFunc) {
      /**
       * alternative to the native addon-storyshots-puppeteer functionality that is not as flexible.
       * see "test: puppeteerTest()" https://www.npmjs.com/package/@storybook/addon-storyshots-puppeteer
       */
      logMessageSuffix = ' execute bespoke beforeScreenshotAsyncFunc()';

      await storySpecificOverrides.beforeScreenshotAsyncFunc(page);
    }

    console.log(
      `(breakpoint: ${breakpointName}) beforeScreenshot ./src/${parameters.fileName.toString().replace('./', '')}${logMessageSuffix}`
    );

    await page.setViewport({
      width: viewportWidth,
      height: (storySpecificOverrides && storySpecificOverrides.screenshotHeight) || 25 // the value is effectively a minimum height as fullPage is set to true in getMatchOptions above
    });

    // very crude way to allow time for animations to complete and images to load. TODO find a better generic way to wait
    await page.waitForTimeout(2250); // allow time for animations to complete and images to load (like https://via.placeholder.com/40x60/0bf/fff?text=A)
  };

  const storybookUrl = `https://localhost:9001`;

  // Note that the following should work but does not load large parts of the component. TODO try again in the next version of @storybook
  // const storybookUrl = `file://${path.resolve(__dirname, '..', '..', 'storybook-static')}`;

  initStoryshots({
    framework: 'web-components',
    suite: breakpointName,
    // storyNameRegex: /menu/i, // uncomment to run specific tests
    test: imageSnapshot({
      storybookUrl,
      getMatchOptions,
      beforeScreenshot,
      getCustomBrowser: async () => {
        console.log(`(breakpoint: ${breakpointName}) launching browser instance`);
        browser = await puppeteer.launch({
          headless: true,
          /**
           * use ignoreHTTPSErrors as the self signed localhost cert will not be installed on the Azure Devops build agent
           */
          ignoreHTTPSErrors: true,
          /**
           * set '--font-render-hinting' to force consistent font rendering within headless puppeteer on ubuntu Azure build agents.
           * Puppeteer recommend setting this to "none", which can greatly improve kerning and letter spacing in your fonts.
           * See https://docs.browserless.io/blog/2020/09/30/puppeteer-print.html for details and other options
           */
          args: ['--no-sandbox', '--disable-gpu', '--disable-web-security', '--font-render-hinting=none']
        });
        return browser;
      },
      afterAll: afterAll(async () => {
        console.log(`(breakpoint: ${breakpointName}) closing browser instance`);
        await browser.close();
      })
    })
  });
}

console.log('Running ./scripts/storyshots/storyshots.js');

/**
 * for the time being (Mar 2021) we will just run 1 breakpoint in the visual regression suite until we can see this is a robust solution
 */
// execute('small', 700, 500);
// execute('medium', 950, 500)
execute('large', 1250);
