import initStoryshots from '@storybook/addon-storyshots';
import puppeteer from 'puppeteer';
import { puppeteerTest } from '@storybook/addon-storyshots-puppeteer';

/**
 * Summary of the accessibility test dependencies
 *
 * jest: test runner by Facebook
 * @babel/preset-env: all the babel stuff to be able to run ES6 in jest
 * @storybook/addon-storyshots: addon that integrates storybook to jest
 * @storybook/addon-storyshots-puppeteer: integration of storybook to puppeteer + jest-puppeteer-axe
 *
 */

function execute(breakpointName, viewportWidth) {
  console.log(
    `Running ${breakpointName} viewport storybook a11y tests against ${storybookUrl}. Ignore the 'Unexpected loaded state. Did you call 'load' twice?' console warning - it's unrelated to a11y testing`
  );
  let browser = null;

  const storybookUrl = `https://localhost:9001`;

  // Note that the following should work but does not load large parts of the component. TODO try again in the next version of @storybook
  // const storybookUrl = `file://${path.resolve(__dirname, '..', '..', 'storybook-static')}`;

  initStoryshots({
    framework: 'web-components',
    suite: breakpointName,
    // storyNameRegex: /accordion/i, // uncomment to run specific tests
    test: puppeteerTest({
      storybookUrl,
      getCustomBrowser: async () => {
        browser = await puppeteer.launch({
          ignoreHTTPSErrors: true, // use ignoreHTTPSErrors as the self signed localhost cert will not be installed on the Azure Devops build agent
          args: ['--no-sandbox ', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
        });
        return browser;
      },
      async testBody(page, options) {
        //The rule to disable is the id you will see in the command line violation results.
        const axeDisableRules = {
          'landmark-one-main': { enabled: false },
          'page-has-heading-one': { enabled: false },
          region: { enabled: false }
        };

        // if present then render the page and run any pre test manipulation of the page components
        if (options.context?.parameters?.axetest?.beforeAxeTestAsyncFunc) {
          await options.context.parameters.axetest.beforeAxeTestAsyncFunc(page);
        }

        if (!options.context.parameters?.a11y?.options?.rules) {
          options.context.parameters = { a11y: { options: { rules: {} } } };
        }
        //add the default disabled rules to those declared in the story page
        Object.assign(options.context.parameters.a11y.options.rules, axeDisableRules);
        let parameters = options.context.parameters.a11y;
        await expect(page).toPassAxeTests({ ...parameters });
      },
      afterAll: afterAll(async () => {
        await browser.close();
      })
    })
  });
}

console.log('Running ./scripts/storyshots/storyshots-axe.js');

/**
 * for the time being (Aril 2021) we will just run 1 breakpoint in the axe regression suite until we can see this is a robust solution
 */
// execute('small', 700, 500);
// execute('medium', 950, 500)
execute('large', 1250);
