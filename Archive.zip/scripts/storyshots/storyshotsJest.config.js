console.log('Processing ./scripts/storyshots/storyshotsJest.config.js');

module.exports = {
  testMatch: ['**'],
  transform: {
    '^.+\\.js?$': ['babel-jest', { configFile: './scripts/storyshots/babel.config.js' }],
    '^.+\\.(md)$': '<rootDir>/../jest/mdTransform.js'
  },
  transformIgnorePatterns: ['/node_modules/(?!lit-html).+\\.js'] // We don't need to render the stories - we are just building a list of the story urls for the screenshots to be taken
};
