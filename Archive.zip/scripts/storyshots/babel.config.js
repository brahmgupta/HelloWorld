module.exports = {
  presets: ['@babel/preset-react', '@babel/preset-env'],
  env: {
    test: {
      /**
       * Configure Jest to work with Webpack's require.context().
       * Fixes "TypeError: require.context is not a function" when the code in .storybook/preview.js is run
       */
      plugins: ['require-context-hook']
    }
  }
};
