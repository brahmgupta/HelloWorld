console.log('rename all agl-ds- and AglDs references in the codebase');

process.exit(
  execute({
    from: [new RegExp(/agl\-ds\-/, 'g'), new RegExp(/AglDs/, 'g'), new RegExp(/agl\-ds[ ]/, 'g')],
    to: ['agl-ds-alt-', 'AglDsAlt', 'agl-ds-alt '],
    files: ['./src/**', './stencil.config.ts']
  })
);

function execute(options) {
  const replace = require('replace-in-file');

  try {
    const results = replace.sync(options);
    console.log('Renamed component prefixes:', results);
    return 0;
  } catch (error) {
    console.error('Error renaming component prefixes:', error);
    return 1;
  }
}
