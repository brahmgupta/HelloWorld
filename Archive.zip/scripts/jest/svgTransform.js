const path = require('path');

module.exports = {
  process(fileContent, filename) {
    /**
     * convert //machine-name/dev/foo/bar/baz/src/assets/example.svg into src/assets/example.svg and
     * normalise to use forward slashes on windows/macOS/linux
     */
    const relativeFileName = path.relative(path.join(__dirname, '..', '..'), filename).replace(/\\/g, '/');

    // Emit placeholder text, rather than the actual svg contents, to make unit tests more readable and not dependent on actual svg content
    return 'module.exports = ' + JSON.stringify(`svg contents from: ${relativeFileName}`) + ';';
  }
};
