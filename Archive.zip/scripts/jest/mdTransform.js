module.exports = {
  process(fileContent, filename) {
    // Emit placeholder text, rather than the actual md file contents as they are not required
    return 'module.exports = ' + JSON.stringify(`markdown file contents`) + ';';
  }
};
