#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u unset variables if any command fails

# this script is intended to be run from the project root dir

desiredNodeVersion=`cat ./.nvmrc | tr -d v`

echo "set AGLDesignLibrary.NodeVersion build variable to $desiredNodeVersion"
echo '##vso[task.setvariable variable=AGLDesignLibrary.NodeVersion;]'$desiredNodeVersion
