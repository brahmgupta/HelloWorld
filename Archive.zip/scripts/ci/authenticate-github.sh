#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

# Default case for Linux sed, just use "-i"
sedi=(-i)
case "$(uname)" in
  # For macOS, use two parameters
  Darwin*) sedi=(-i "")
esac

echo "Authenticating .npmrc"
size=${#GITHUB_PUBLISHING_TOKEN}
token=$GITHUB_PUBLISHING_TOKEN
echo "The size of the GitHub token is: $size"

cp .npmrc.template .npmrc
sed "${sedi[@]}" -e "s/GITHUB_PUBLISHING_TOKEN/$token/g" .npmrc
