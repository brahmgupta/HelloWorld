#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

set +e # no longer 'fail fast' to allow an explanation for formatting failures to be echoed into the logs

echo ""
echo "##[section]validate code formatting"
npm run format:check --silent
FORMAT_CHECK_RESULT=$?
if [ $FORMAT_CHECK_RESULT -ne 0 ]; then
    echo ""
    echo "##[error]TypeScript formatting check failed - run 'npm run format:fix' to apply auto formatting from the command line."
    echo "##[command]Ensure your IDE runs prettier + stylelint formatting automatically for a smoother development experience"
    exit ${FORMAT_CHECK_RESULT}
fi

set -e # 'fail fast' again

echo ""
echo "##[section]lint SASS"
npm run lint:sass --silent

echo ""
echo "##[section]lint TypeScript"
npm run lint:ts --silent
