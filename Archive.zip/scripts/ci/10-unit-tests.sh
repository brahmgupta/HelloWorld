#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

echo ""
echo "##[section]run tests (running tests alters the build artifact so we must run it *prior* to the 'npm run build' task)..."
npm run test
