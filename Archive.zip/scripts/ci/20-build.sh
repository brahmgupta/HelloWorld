#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

echo ""
echo "##[section]clean the existing build artifact folders..."
npm run clean

echo ""
echo "##[section]run stencil js build..."
npm run build:stencil

echo ""
echo "##[section]run storybook build..."
npm run build:storybook
