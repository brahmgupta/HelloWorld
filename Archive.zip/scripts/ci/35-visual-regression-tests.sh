#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

echo ""
echo "##[section]********* Note *********"
echo "If the visual regression test suite fails then the 'diff' images are available in a build artifact."
echo "If the diff changes are correct, then run 'npm run test:visual:approve' and commit the new baseline images."

echo ""

echo "##[section]copy ./storybook-static to ./tmp/storybook-static-for-snapshot-regression to ensure that no changes" \
     "by the http-server webserver (used during the test) can impact the final/deployed artifact in ./storybook-static"

mkdir -p ./tmp

[[ -d ./tmp/storybook-static-for-snapshot-regression ]] || cp -r ./storybook-static ./tmp/storybook-static-for-snapshot-regression

echo ""
echo "##[section]run visual regression tests..."

npm run test:visual:ci
