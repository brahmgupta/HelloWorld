#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

echo ""
echo "##[section]current node version"
node --version

echo ""
echo "##[section]install npm dependencies"
npm ci
