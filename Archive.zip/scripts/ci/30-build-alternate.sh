#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

rm -rf ./tmp # clear out any existing files

echo ""
echo "##[section]run alternate stencil js build (produces the agl-ds-alt version of the design library)..."

echo "##[section]produce alternate library version in ./tmp"
mkdir -p ./tmp

echo "##[section]copy ./src to tmp"
cp -r ./src ./tmp

echo "##[section]copy ./ssl to tmp (required for stencil.config.ts processing)"
cp -r ./ssl ./tmp

echo "##[section]copy ./scripts to tmp"
cp -r ./scripts ./tmp

echo "##[section]copy root files to tmp"
find ./ -maxdepth 1 -type f -exec cp {} ./tmp \;

cd tmp

    echo "##[section]create symlink node_modules to tmp"
    ln -s ../node_modules ./node_modules

    echo "##[section]rename agl-ds tags"
    npm run rename:component-prefixes

    echo ""
    echo "##[section]run stencil js build in tmp..."
    npm run build:stencil

    echo ""
    echo "##[section]package up the generated files..."
    npm pack

    NEW_DIST="../dist/alt"
    echo "##[section]unzip the package contents into the ${NEW_DIST} folder..."
    mkdir -p ${NEW_DIST}
    tar zxf aglenergy-design-system-*.tgz --directory ${NEW_DIST} --strip-components=1

cd ..

echo ""
echo "alternate package generation complete"
