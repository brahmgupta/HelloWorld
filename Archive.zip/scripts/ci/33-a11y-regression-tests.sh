#!/bin/bash
set -e # -e fail fast if any command fails
set -u # -u uset variables if any command fails

echo "##[section]copy ./storybook-static to ./tmp/storybook-static-for-snapshot-regression to ensure that no changes" \
     "by the http-server webserver (used during the test) can impact the final/deployed artifact in ./storybook-static"

mkdir -p ./tmp
[[ -d ./tmp/storybook-static-for-snapshot-regression ]] || cp -r ./storybook-static ./tmp/storybook-static-for-snapshot-regression

echo ""
echo "##[section]run a11y regression tests..."

echo "TODO enable a11y tests when stabelized"
# npm run test:a11y:ci
