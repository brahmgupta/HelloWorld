# Running the design system locally and making changes/contributions

## localhost development - making changes to the design library components

- install node 14.15.5 or greater (we recommend using node version manager to install and switch node versions)
- run `npm install` to install the required dependencies
- run `npm start` to start storybook in development mode with hot reloading of changes to the component code
- run `npm test:watch` to run the unit tests in watch mode.

## Component folder naming standards

- All core components live under `src\components\core\`. These include buttons, checkboxes etc
- All composite components live under `src\components\composite\`. These include components that are made up of other components and maybe somewhat more project specific (but still sharable)
- All layout components live under `src\layout\`.

## File naming standards

All components must adhere to the naming conventions:

- \$.component.scss
- \$.component.spec.ts
- \$.component.tsx
- \$.stories.js
- \$.types.js
- readme.md

WHERE \$ is the name of your component.

ALL component tags must begin with the namespace `agl-ds-`

## Creating new component

- Before you start work on a new component please discuss it in the design system daily standup, held at 09:15 each day (or send a representative from your team). This allows both the designers and developers from other teams to give input on the new component.
- Post the proposed public html for your new component to the #design-system-tech slack channel. Many teams will be consuming these components and once published they will be difficult to change without disruption - so getting a consensus on the public interface is important.
- Raising a PR with a completed component that has not been discussed will often lead to lengthy delays as the wider team will be looking at them for the first time and significant rework may be required.

## Running locally for development

Components are written in [stencil](https://stenciljs.com/), but showcased and rendered during development in [storybook](https://storybook.js.org/).

- To load the components in storybook with hot reloading as you make changes to the codebase, run `npm start`
- To load the index.html to test in browsers that fail to load storybook, run `npm start:stencil` and add your component markup to the [index.html](src/index.html) file. It's a little bit slower to recompile incremental builds as we include the `--es5` flag to support legacy browsers. This also supports hot reloading as you make changes to the codebase.

## Assets

- svg files placed under the ./src/assets folder are automatically optimized using [svgo](https://www.npmjs.com/package/svgo). Changes made to the svg files *should be* committed into the codebase.

Where required (for theming) svg's should leave the fill and stroke colours in the svg as set by the author of the file and then set the appropriate classes for either/both fill and stroke classes E.G
`<g stroke="#001cb0" stroke-width="1.5" fill="none">`
`<path d="M23,4H20V......." fill="#001cb0"></path>`
instead it should use classes such as
`<g stroke="#001cb0" class="primary-stroke" stroke-width="1.5" fill="none">`
`<path d="M23,4H20V......." fill="#001cb0" class="primary-fill"></path>`
See the [_svg.scss](src/global/published/_svg.scss) file for possible classes to use

## Theming

- The Design System currently support theming for Power Direct using the `agl-ds-theme-pd` component.  This component must wrap your SPA's root component E.G `<agl-ds-theme-pd><app-root /></agl-ds-theme-pd>`

- Any future requirements to add a theme should use what has been done for Power Direct as a template (with the new theme having it's own unique component name E.G `agl-ds-theme-newname`)

## Coding Standards

### JSX

- When used in HTML component attributes should use dash-case, when used in JSX should be camelCased. It is also of note that the shadowDom props that a Jest test expects ( as part of  'expect(page.root).toEqualHtml(...' ) are case insensitive ie styledas or StyledAs

### CSS

- Your CSS must adhere to the [Block Element Modifier (BEM) Standards](http://getbem.com/naming)
- If class names need to be applied conditionally, use the following syntax rather than building a list of class names in a function that returns a string:

```JSX
  <div class={{
      'foo__bar-title': true, // alway apply
      'foo__bar-title--hidden': this.isHidden, // apply when this.isHidden is true
      [`foo__bar-title--${this.state}`]: true // note the [] when the class name is also dynamic
    }}>
  </div>

  <div class="foo__bar-description"> // no conditional classes are required in this element so just use a normal string value
  </div>
```

### Slots

- Slot names should be lowercase and hyphen separated (e.g ```<slot name="primary-content">```).
- Document slot usage at the top of the component file so that it's included in the storybook presentation eg

```JSX
  /**
  @slot - The contents of this slot should ...
  */
  @Component({ ...
```

- When deciding whether to use an attribute or a slot for an externally provided value, the rule of thumb is to use an an attribute when only plain text is allowed and a slot when rich text is allowed. We want the components to be as restrictive as possible to keep control over the designs, but allow rich text when called for in the designs. This usually requires a discussion with the design team around the intended use of the component.

```Html
  <agl-ds-foo title="foo" description="bar"></agl-ds-foo>
```

vs

```Html
  <agl-ds-foo>
    <span slot="title">foo</span>
    <span slot="description">bar</span>
  </agl-ds-foo>
```

### TypeScript

**Enums vs Type Aliases**

- [String Unions](https://2ality.com/2020/02/enum-alternatives-typescript.html#unions-of-string-literal-types) must be used rather than Enums for component prop type-checking.

```typescript

// Use string unions ✅
type NoYesStrings = 'No' | 'Yes';

// Avoid enums ❌
enum NoYesEnum {
  No = 'No',
  Yes = 'Yes',
}

@Component({
...
})
export class BarComponent {
  @Prop() foo: NoYesEnum = 'Yes';
...
```

## Basic design rules for components

- They are to be width 100% with a max width (defined by UX). ie for buttons
- They will have a zero top margin and a bottom margin (defined by UX).
- Left and right margins should be zero as they are set by the parent/container component
- All components must include the agl-ds-component-reset mixin at the top of the scss file by default

## Modify existing component

- Why?
- Breaking change?
- Major/Minor?

## Accessibility

We are aiming for all components to meet (or exceed) WCAG 2 AA guidelines. To assist in meeting this requirement please ensure that each component passes the Storybook accessibility tests.

**Please note** that you will need to click on the `Tests completed` button at the bottom right of the accessibility tab to rerun the tests to check they have passed, as there is a bug in Storybook where they don't get run correctly the first time.

![Storybook rerun tests button](./.github/storybook-a11y.png)


Accessibility testing is also available for all storybook stories and is run in Chrome with a desktop viewport (This will be included as part of the CI pipeline and other viewports will be covered after the initial release in Mar 2021). This test is based on the axe engine provided by deque which is also the engine used by storybook and the lighthouse plugin in Chrome. https://www.deque.com/axe/

To run the tests:

```bash
  # Note: storybook must already be running via `npm start`
  npm run test:a11y
```

> To disabled certain 'accessibility' rules add the a11y details below for the Accordion component. The rule to disable is the id you will see in the command line violation results. Note this example is fictional as there are no contrast issues with the accordion.
> To interact with a component before the test is performed add the 'axetest' details given in the example below for the Accordion component.
>
> ```TypeScript
> Accordion.parameters = {
>   notes,
>   a11y: {
>    options: {
>      rules: {
>        'color-contrast': { enabled: false }
>      }
>    }
>  },
>  axetest: {
>   beforeAxeTestAsyncFunc: async (page) => {
>        await page.waitForSelector('#storyshots-hook', { visible: true });
>        await page.click('#storyshots-hook');
>        await page.waitForTimeout(500); // wait for the animation to finish
>    }
>  }
> };
> ```
> To run an a11y test on a single story uncomment the following line and include the name of the story
> ```
> // storyNameRegex: /accordion/i, // uncomment to run specific tests
>```
> from storyshots-a11y.js

## Focus ring

In order to reach a unified display of a focus ring around all focusable elements this library has overridden the default browser focus ring. The designed behaviour means that the focus ring will only be shown as the user "tabs" into a field. Any mouse based interaction removes the focus ring from the screen. To this end any consuming system of this library will need to factor in modifying custom code to accommodate non Design System focusable fields to match the current Design System behaviour.
The design system uses a mixin called hide-focus-ring-when-using-mouse and a js function called // hideFocusRingWhenUsingMouse which can be used where appropriate.
AEM makes use of the following code

```
*:focus {
   @include focus-ring();
}
body.agl-ds-alt-using-mouse * :focus {
   box-shadow: none !important;
}

(function (document, window, domIsReady, undefined) {
    domIsReady(function () {
        // Let the document know when the mouse is being used
        document.body.addEventListener('mousedown', function () {
            document.body.classList.add('agl-ds-alt-using-mouse');
        });
        // Re-enable focus styling when Tab is pressed
        document.body.addEventListener('keydown', function (event) {
            if (dispatchForCode(event) === 9) {
                document.body.classList.remove('agl-ds-alt-using-mouse');
            }
        });
        var dispatchForCode = function(event, callback) {
            var code;
            if (event.key !== undefined) {
                code = event.key;
            } else if (event.keyIdentifier !== undefined) {
                code = event.keyIdentifier;
            } else if (event.keyCode !== undefined) {
                code = event.keyCode;
            }
            callback(code);
        };
    });
})(document, window, domIsReady);
```

## Design Principle

As a basic accessibility design principle, we have agreed upon a standard whereby we will not support disabling fields, specifically buttons. From a11y perspective, we should avoid buttons/fields in this state as they are particularly difficult for people with cognizant disabilities to comprehend. It also makes it difficult for not sighted users to "know" that the button is present on the page, let alone understand what they must do it enable it, as screen readers can ignore them all together. Instead the button should remain clickable and display an error message if the criteria for clicking it has not been met.

## Testing

## Run All Tests

Running all specs file can be done by running either one of below:

```bash
  npm run test
  npm run test:watch
  npm run test:visual
```

## Debugging a test file

VS Code debugging on one file also available thru VS Code debug tab.

Ensure debug configuration selected is `"Spec Test Current File"`, and file tab is in focus before clicking play (debug) button.

![image](https://user-images.githubusercontent.com/37053272/83080727-5a75f180-a0c2-11ea-97cb-b43b9d4d86c7.png)

## Visual regression tests

Visual regression testing is available for all storybook stories and is run in Chrome with a desktop viewport (other viewports will be covered after the initial release in Mar 2021).

To run the tests:

```bash
  # Note: storybook must already be running via `npm start`
  npm run test:visual
```

If a visual difference is detected then the failure logs will include a link to a *diff* image. In the case of a CI/CD failure the *diff* image will be available as a build artifact.

The *diff* images contain the *baseline* copy on the left, the new version generated from your code on the right and the differences highlighted in red in the middle:

![Example diff image](.github/visual-regression-failure.png)

If the changes are actually correct then you need to update the *baseline* images and commit it to the codebase. To update the *baseline* images run:

```bash
  # Note: storybook must already be running via `npm start`
  npm run test:visual:approve
```

> To exclude a story from visual regression testing:
>
> ```TypeScript
> LoadingIndicator.parameters = {
>   notes,
>   storyshots: { disable: true } // the continuous animation in the loading indicator means that screenshot testing will be flakey - so we disable it
> };
> ```
>
> To interact with a component before the screenshot is taken. For example to expand an accordion:
>
> ```TypeScript
> Accordion.parameters = {
>   notes,
>   storyshots: {
>     visualRegression: {
>       screenshotHeight: 500,
>       beforeScreenshotAsyncFunc: async (page) => {
>         await page.waitForSelector('#storyshots-hook', { visible: > true });
>         await page.click('#storyshots-hook');
>         await page.waitForTimeout(500); // wait for the animation to > finish
>       }
>     }
>   }
> };
> ```
>
> To run a test on a single story uncomment the following line and include the name of the story
> ```
>//storyNameRegex: /modal/i, // uncomment to run specific tests
>```
> from visualRegression.storyshots.js
>

## Build & Publish

### Formatting

- `npm run format:check` - Uses the prettier formatter (with rules in `.prettierrc`) to validate the codebase (this is run in CI).
- `npm run format:fix` - Uses the prettier formatter to fix any formatting issues detected in the codebase (remember to commit the changes after running this.)

### Linting

- `npm run lint:sass` - Check that the scss files conform to the project standards.
- `npm run lint:sass:fix` - Uses the stylelint formatter to fix any formatting or rule violations detected in the codebase (remember to commit the changes after running this.)

## How to make a change to an existing component

- Raise PR

## Azure DevOps Pipelines

Running the build on the `master` branch will publish the package to GitHub packages.

## How to add a new component to the AglDsComponentLibraryModule (for consumption in Angular based applications)

1. Components that require reactive form integration

- Apart from the necessary code to be added to your component ( ie checked prop and corresponding checkChange event) you will need to add an entry in the angularValueAccessorBindings array in [stencil.config.ts](./stencil.config.ts)
- Add the component to the DECLARATIONS array in the [agl-ds-component-library-module.ts](./src/angular/agl-ds-component-library-module.ts) file

2. Components that DO NOT require reactive form integration

- Add the component to the DECLARATIONS array in the [agl-ds-component-library-module.ts](./src/angular/agl-ds-component-library-module.ts) file

## Development hint

To make the dev process easier do the following

- In the design system run `npm run build:stencil && npm pack`. This will pack the files into a tarball as part of the build process. This can then be imported into your angular application.
- In the angular app import the design system, for example:

  ```json
  "dependencies": {
      "@aglenergy/design-system": "file:../../../../strategic/AGL.DesignSystem/aglenergy-design-system-3.3.0.tgz",
      ...
  }
  ```

- Alternately, if you want to just test a design system build against your SPA you can copy the tarball to your SPA's root and run `npm install aglenergy-design-system-X.X.X.tgz`

## Design library NPM package release process

Releases of the design library npm package are currently done on an adhoc request basis by posting a message to the #design-system-tech slack channel. There are a group of core maintainers who will then release a new version. The manual steps they follow are:

1. Pull the latest `development` branch and read the latest `vnext` release notes in the [CHANGELOG.md](./CHANGELOG.md) file.

2. Decide on what the next version number should be according to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) rules.
    - **Double check that there were no accidental merges of change log entries further down in the changelog.md file (as this been known to happen), by checking the commits to the changelog.md since the previous release**
    - **Double check any breaking changes to see if they are necessary or could be avoided**

3. Update the version numbers to the new version number in:
    - [package.json](./package.json)
    - [package-lock.json](./package-lock.json)
    - [CHANGELOG.md](./CHANGELOG.md) - leave the boilerplate `vnext` section with empty breaking change/features/bug fixes sections to reduce merge conflicts with outstanding PRs

4. Push the changes to the `development` branch with the commit message "prepare the vX.X.X release"

5. Merge the `development` branch into the `master` branch and push.

6. Once the `master` build is [complete](https://dev.azure.com/aglenergydev/Maharaja/_build?definitionId=976&_a=summary), an automated message is sent to the #design-system-tech confirming that the npm package was deployed to the Akamai CDN. If the deployment succeeded then we also notify the #design-system and #design-system-tech slack channels with the new release details such as version number. Ideally this final manual step will be automated in the future.

## Troubleshooting issues

### Storybook story issues:

>**Issue**: Storybook knobs appears as raw html text, rather than the rendered html on the Storybook "Canvas" or "Docs" tab:
>
>![Storybook knobs without lit-html](./.github/knobs-without-lit-html.png)
>
> **Solution**: We use [lit-html](https://lit-html.polymer-project.org/) templates to convert our story source into html that can be rendered by Storybook. You need to wrap the text knob with the html() function and pass the text() function results into its array param:
>
>  ```html
>  <!-- broken -->
>  html`
>    <agl-ds-segmented-container>
>      <div slot="header">${text('Content', '<agl-ds-h3>This section displays the header contents </agl-ds-h3>')}</div>
>    </agl-ds-segmented-container>
>  `
>  <!-- fixed -->
>  html`
>    <agl-ds-segmented-container>
>      <div slot="header">${html([text('Content', '<agl-ds-h3>This section displays the header contents </agl-ds-h3>')])}</div>
>    </agl-ds-segmented-container>
>  `
>  ```

***

>**Issue**: Storybook component appears as raw html text, rather than the rendered component on the Storybook "Docs" tab:
>
>![Storybook without lit-html](./.github/docs-without-lit-html.png)
>
> **Solution** We use [lit-html](https://lit-html.polymer-project.org/) templates to convert our story source into html that can be rendered by Storybook. You need to mark the story as a lit-html template by prefixing the story string with `html` as per:
>
>  ```TypeScript
>  import { html } from 'lit-html'
>
>  export const StoryFoo = () => html`<div>I'm a story</div>`;
>  ```
