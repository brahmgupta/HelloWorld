// DIRECTIVES
export * from './directives/proxies';

// PACKAGE MODULE
export { AglDsComponentLibraryModule } from './agl-ds-component-library-module';
