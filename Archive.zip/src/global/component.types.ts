export type FontType = 'fontfamily01' | 'fontfamily02';

export type Appearance = 'default' | 'muted' | 'highlight' | 'inverse' | 'secondary-highlight';

export type TextAppearance = Appearance | 'error';

export type HeadingType = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

export type TitleType = 'title1' | 'title2' | 'title3' | 'title4' | 'title5' | 'title6';

export type FontSizes = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'display01' | 'display02' | 'inherit';

export type FontWeight = 'inherit' | 'semibold' | 'regular';

export type BottomMargin = 'none' | 'space00' | 'space01' | 'space02' | 'space03' | 'space04' | 'space05' | 'space06';

export type AriaAttribute = 'aria-expanded';

//This can be added to as required. We don't necessarily want to allow all attributes
export class AriaAttributes {
  public attribute: AriaAttribute;
  public value: string;
}
