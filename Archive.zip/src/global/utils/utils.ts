/**
 * Only import tree shakable npm modules into this common utils file - otherwise the entire package will be included in here and
 * will impact the load time of the design library *even* if a page only uses utils functions that do not use the imported package.
 *
 * If in doubt - compare the size of the utils.js file in the ./dist sub folders before and after making changes to imports in this utils.ts file (using `npm run build:stencil`)
 */

export function generateRandomNumber() {
  return Math.floor(Math.random() * 1000000000 + 1).toString();
}

export function generateRandomGuid(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, (c: string) => {
      const r = Math.floor(Math.random() * 16);
      const v = c === 'x' ? r : (r % 4) + 4;
      return v.toString(16);
    })
    .toUpperCase();
}

export function hideFocusRingWhenUsingMouse(inputObj: HTMLElement): void {
  let obj = null;
  if (inputObj.shadowRoot) {
    obj = inputObj.shadowRoot.querySelector('input');
  } else {
    obj = inputObj;
  }
  document.body.addEventListener('mousemove', function () {
    if (!(obj as HTMLElement).classList.contains('agl-ds-using-mouse')) {
      (obj as HTMLElement).classList.add('agl-ds-using-mouse');
    }
  });
  document.body.addEventListener('keydown', function (e: KeyboardEvent) {
    switch (e.key) {
      case 'Down':
      case 'Up':
      case 'Left':
      case 'Right':
      case 'ArrowUp':
      case 'ArrowDown':
      case 'ArrowRight':
      case 'ArrowLeft':
      case 'Tab':
      case 'Enter':
        (obj as HTMLElement).classList.remove('agl-ds-using-mouse');
        break;
      default:
        break;
    }
  });
}

export function getSiblings(el) {
  const siblings = [];
  siblings.push(el);
  while ((el = el.nextElementSibling)) {
    siblings.push(el);
  }
  return siblings;
}

export function checkSlottedContentForInvalidHTML(slot: HTMLElement, validTags: string[]): void {
  /* As part of the build process a script is applied to the Design Library (scripts\rename-component-prefixes.js) that modifies all agl-ds-xx tag name references to agl-ds-alt-xx.
    This is done to allow consuming systems such as AEM to use a different version of the Design system to that being used by a hosted SPA on the same page. Spas use the agl-ds-xx version
    while AEM for example uses the agl-ds-alt-xx version.
    Because AEM makes use of rich text editors in page construction the library can not successfully validate the slotted content. To that end the following variable is declared to solve this problem.
    The string value of dsVersion will have the '-alt' string added as part of the build script mentioned above. This can then be assessed to prevent validation in systems that use the 'alt' version.
  */

  const dsVersion = 'agl-ds-version';
  const isDSAltVersion = dsVersion.indexOf('-alt') > 0;
  if (isDSAltVersion) {
    return;
  }

  /*  There are 3 cases to check
   *    - default slot with only text allowed eg agl-ds-button/agl-ds-badge (need to pass the main tag name -agl-ds-button as a valid tag to pass the slot tag type check )
   *    - default slot with some tags allowed eg agl-ds-checkbox (need to pass the main tag name -agl-ds-checkbox as a valid tag to pass the slot tag type check )
   *    - named slot with some tags
   *     if the only valid content is text then pass the name of the slot as a validTag ie for agl-ds-badge
   */
  if (slot) {
    if (!validTags) {
      throw new Error('There were no valid tags passed');
    }
    let invalidTags = '';
    let validTagsString = ',';

    // check to make sure that the slot tag is valid
    // check slot.tagName for undefined causes IE issuse
    validTagsString += validTags.join(',');
    if (slot.tagName && validTagsString.toUpperCase().indexOf(',' + slot.tagName.toUpperCase()) < 0) {
      invalidTags += slot.tagName + ' :innerHTML(' + slot.innerHTML + ') , ';
    }
    const slottedContentChildren = slot.children;

    // check to make sure that the slotted children tags are valid
    // check element.tagName for undefined causes IE issuse
    if (slottedContentChildren) {
      if (slottedContentChildren?.length > 0) {
        Array.from(slottedContentChildren).forEach((element) => {
          if (element.tagName && validTagsString.toUpperCase().indexOf(',' + element.tagName.toUpperCase()) < 0) {
            invalidTags += element.tagName + ' :innerHTML(' + element.innerHTML + ') , ';
          }
        });
      }
    }

    if (invalidTags) {
      const slotName = slot?.slot ? `this slot (slot="${slot.slot}")` : 'the default slot';
      const componentName = slot?.localName ? ' of ' + slot.localName : '';
      console.error(
        `The following tag(s) (${invalidTags.substr(
          0,
          invalidTags.length - 2
        )}) are not considered valid HTML content for ${slotName}${componentName}`
      );
    }
  }
}

// This function is a temporary solution to deal with the pre chromium version of the Edge and will be removed once AGL update their SOE
export function resizeSVGsForEdge(
  svgSpan: HTMLSpanElement,
  mobileWidth?: string,
  mobileHeight?: string,
  tabletWidth?: string,
  tabletHeight?: string,
  desktopWidth?: string,
  desktopHeight?: string
) {
  if (browser === 'edge' || browser === 'ie11') {
    window.addEventListener(
      'resize',
      resizeSVG.bind(null, svgSpan, mobileWidth, mobileHeight, tabletWidth, tabletHeight, desktopWidth, desktopHeight)
    );
    resizeSVG(svgSpan, mobileWidth, mobileHeight, tabletWidth, tabletHeight, desktopWidth, desktopHeight);
  }
}

function resizeSVG(
  svgSpan: HTMLSpanElement,
  mobileWidth?: string,
  mobileHeight?: string,
  tabletWidth?: string,
  tabletHeight?: string,
  desktopWidth?: string,
  desktopHeight?: string
) {
  const mediaQueryMedium = window.matchMedia('(min-width: 720px)');
  const mediaQueryDesktop = window.matchMedia('(min-width: 922px)');
  if (mediaQueryDesktop.matches && tabletWidth) {
    svgSpan.getElementsByTagName('svg')[0].setAttribute('width', tabletWidth + 'px');
    svgSpan.getElementsByTagName('svg')[0].setAttribute('height', tabletHeight + 'px');
    return;
  }
  if (mediaQueryMedium.matches && desktopWidth) {
    svgSpan.getElementsByTagName('svg')[0].setAttribute('width', desktopWidth + 'px');
    svgSpan.getElementsByTagName('svg')[0].setAttribute('height', desktopHeight + 'px');
    return;
  }
  svgSpan.getElementsByTagName('svg')[0].setAttribute('width', mobileWidth + 'px');
  svgSpan.getElementsByTagName('svg')[0].setAttribute('height', mobileHeight + 'px');
}

const browser = (function (agent) {
  switch (true) {
    case agent.indexOf('edge') > -1:
      return 'edge';
    case agent.indexOf('edg') > -1:
      return 'edge-chromium';
    case agent.indexOf('trident') > -1:
      return 'ie11';
  }
})(window.navigator.userAgent.toLowerCase());
