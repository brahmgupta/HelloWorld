export type AddressType = 'postal' | 'poBox';

export type poBoxType =
  | 'CMA'
  | 'CPA'
  | 'CMB'
  | 'GPO BOX'
  | 'LOCKED BAG'
  | 'MS'
  | 'PO BOX'
  | 'POSTE RESTANTE'
  | 'PRIVATE BAG'
  | 'RMB'
  | 'RMS'
  | 'RMD';
