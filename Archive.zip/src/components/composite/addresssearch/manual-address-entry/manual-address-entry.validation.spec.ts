import { postCodeRegEx } from './manual-address-entry.validation';

const ausPostcodeRanges = [
  { region: 'ACT', lowerRange: 200, upperRange: 299 },
  { region: 'ACT', lowerRange: 2600, upperRange: 2618 },
  { region: 'ACT', lowerRange: 2900, upperRange: 2920 },
  { region: 'NSW', lowerRange: 1000, upperRange: 2599 },
  { region: 'NSW', lowerRange: 2620, upperRange: 2899 },
  { region: 'NSW', lowerRange: 2921, upperRange: 2999 },
  { region: 'NT', lowerRange: 800, upperRange: 999 },
  { region: 'QLD', lowerRange: 4000, upperRange: 4999 },
  { region: 'QLD', lowerRange: 9000, upperRange: 9999 },
  { region: 'SA', lowerRange: 5000, upperRange: 5999 },
  { region: 'TAS', lowerRange: 7000, upperRange: 7999 },
  { region: 'VIC', lowerRange: 3000, upperRange: 3999 },
  { region: 'VIC', lowerRange: 8000, upperRange: 8999 },
  { region: 'WA', lowerRange: 6000, upperRange: 6999 }
];

describe('Manual Address Entry Validation', () => {
  it('should validate post code ranges with postcode regex', async () => {
    ausPostcodeRanges.forEach((range) => {
      const regEx = postCodeRegEx[range.region.toLowerCase()];
      for (let i = range.lowerRange; i <= range.upperRange; i++) {
        const postCode = i < 1000 ? '0' + i : i.toString();
        expect(regEx.test(postCode)).toBeTruthy();
      }
    });
  });
});
