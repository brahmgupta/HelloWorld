import { text, object, boolean } from '@storybook/addon-knobs';
import notes from './readme.md';

export default {
  title: 'Composite/Manual Address Entry'
};

export const ManualAddressEntry = () => {
  const manualAddressEntryModal = document.createElement('agl-ds-manual-address-entry');

  manualAddressEntryModal.heading = text('heading', 'What address do you want connected?');

  manualAddressEntryModal.includePobox = boolean('Include PoBox', false);

  manualAddressEntryModal.defaultAddressDetail = object('Default Address Details', {
    streetNumber: '13123',
    streetName: 'sdfgdsfg',
    streetType: 'Road',
    suburb: 'sdfgsg',
    postcode: '2121',
    state: 'wa'
  });

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Open manual address entry';
  button.id = 'trigger';
  button.onclick = () => {
    manualAddressEntryModal.openModal();
  };
  const container = document.createElement('div');

  container.appendChild(manualAddressEntryModal);

  container.appendChild(button);

  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    manualAddressEntryModal.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
  }, 1000);

  return container;
};

ManualAddressEntry.storyName = 'manual address entry';
ManualAddressEntry.parameters = {
  notes,
  axetest: {
    beforeAxeTestAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  },
  storyshots: {
    visualRegression: {
      screenshotHeight: 750,
      beforeScreenshotAsyncFunc: async (page) => {
        await storyPageManipulation(page);
      }
    }
  }
};

const storyPageManipulation = async (page) => {
  await page.waitForSelector('#trigger', { visible: true });
  await page.waitForTimeout(1250); // allow time for the setTimeout's that attach events to the #trigger buttons in the stories
  await page.click('#trigger');
};
