# agl-ds-manual-address-entry



<!-- Auto Generated Below -->


## Properties

| Property               | Attribute           | Description                                                                                    | Type                 | Default                  |
| ---------------------- | ------------------- | ---------------------------------------------------------------------------------------------- | -------------------- | ------------------------ |
| `defaultAddressDetail` | --                  | Default form value as object                                                                   | `AddressDetailModel` | `{}`                     |
| `heading`              | `heading`           | Heading for the modal                                                                          | `string`             | `''`                     |
| `includePobox`         | `include-pobox`     | includePobox will give option to choose postal/pobox, which indicates a mailing address entry. | `boolean`            | `false`                  |
| `manualAddressId`      | `manual-address-id` | The manual address ID                                                                          | `string`             | `generateRandomNumber()` |


## Events

| Event            | Description                                   | Type                              |
| ---------------- | --------------------------------------------- | --------------------------------- |
| `addressConfirm` | Forwards address details when address confirm | `CustomEvent<AddressDetailModel>` |


## Methods

### `openModal(el: HTMLElement) => Promise<void>`

<span style="color:red">**[DEPRECATED]**</span> This will not be supported when the parameter is removed from the modal<br/><br/>Public method to open the modal

#### Returns

Type: `Promise<void>`



### `setTriggerButton(getTriggerButton: () => HTMLElement) => Promise<void>`

Public method to set the modal trigger element

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-address-search](../address-search)

### Depends on

- [agl-ds-modal](../../../core/modal/modal)
- [agl-ds-h2](../../../core/heading/h2)
- [agl-ds-radio-button-group](../../../core/radio-buttons/radio-button-group)
- [agl-ds-radio-button-set](../../../core/radio-buttons/radio-button-set)
- [agl-ds-radio-button](../../../core/radio-buttons/radio-button)
- [agl-ds-spacer](../../../core/spacer)
- [agl-ds-error-summary](../../error-summary)
- [agl-ds-textbox](../../../core/textbox)
- [agl-ds-autocomplete](../../autocomplete)
- [agl-ds-dropdownbox](../../../core/dropdownbox)
- [agl-ds-dropdown-option](../../../core/dropdownbox/dropdownoption)
- [agl-ds-button](../../../core/button)

### Graph
```mermaid
graph TD;
  agl-ds-manual-address-entry --> agl-ds-modal
  agl-ds-manual-address-entry --> agl-ds-h2
  agl-ds-manual-address-entry --> agl-ds-radio-button-group
  agl-ds-manual-address-entry --> agl-ds-radio-button-set
  agl-ds-manual-address-entry --> agl-ds-radio-button
  agl-ds-manual-address-entry --> agl-ds-spacer
  agl-ds-manual-address-entry --> agl-ds-error-summary
  agl-ds-manual-address-entry --> agl-ds-textbox
  agl-ds-manual-address-entry --> agl-ds-autocomplete
  agl-ds-manual-address-entry --> agl-ds-dropdownbox
  agl-ds-manual-address-entry --> agl-ds-dropdown-option
  agl-ds-manual-address-entry --> agl-ds-button
  agl-ds-modal --> agl-ds-icon
  agl-ds-radio-button-group --> agl-ds-form-field-label
  agl-ds-radio-button-group --> agl-ds-hint-validation-message
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-text
  agl-ds-radio-button --> agl-ds-icon
  agl-ds-error-summary --> agl-ds-notification
  agl-ds-error-summary --> agl-ds-spacer
  agl-ds-notification --> agl-ds-h4
  agl-ds-notification --> agl-ds-p
  agl-ds-notification --> agl-ds-link
  agl-ds-notification --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  agl-ds-textbox --> agl-ds-hint-validation-message
  agl-ds-autocomplete --> agl-ds-text
  agl-ds-autocomplete --> agl-ds-textbox
  agl-ds-autocomplete --> agl-ds-loading-indicator
  agl-ds-dropdownbox --> agl-ds-dropdown-option
  agl-ds-dropdownbox --> agl-ds-hint-validation-message
  agl-ds-address-search --> agl-ds-manual-address-entry
  style agl-ds-manual-address-entry fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
