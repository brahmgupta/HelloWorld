import { Component, ComponentInterface, Event, EventEmitter, Method, Prop, State, Watch, h } from '@stencil/core';
import { AddressDetailModel, StreetTypes } from '../address.model';

import { generateRandomNumber } from '../../../../global/utils/utils';
import leftArrow from '../../../../assets/agl_left_arrow.svg';
import { AddressType } from './manual-address-entry.types';
import { postCodeRegEx } from './manual-address-entry.validation';

//do in and out
@Component({
  tag: 'agl-ds-manual-address-entry',
  styleUrl: './manual-address-entry.scss',
  shadow: false,
  scoped: true
})
export class ManualAddressEntryComponent implements ComponentInterface {
  /**
   * The manual address ID
   */
  @Prop() manualAddressId: string = generateRandomNumber();

  /**
   *Heading for the modal
   */
  @Prop() heading: string = '';

  /**
   * includePobox will give option to choose postal/pobox, which indicates a mailing address entry.
   */
  @Prop() includePobox: boolean = false;

  /**
   * Default form value as object
   */
  @Prop() defaultAddressDetail: AddressDetailModel = {};

  @State() addressDetailState: AddressDetailModel = this.modifyAddressDetails(this.defaultAddressDetail, true);

  @State() addressTypeState: AddressType = 'postal';

  @State() invalidFields: string[] = [];

  @State() isFormInvalid: boolean = false;

  @State() firstInvalidInputId: string = '';

  /**
   * Forwards address details when address confirm
   */
  @Event() addressConfirm: EventEmitter<AddressDetailModel>;

  private modalContainer: HTMLAglDsModalElement;
  private postcodeDropdown: HTMLAglDsTextboxElement;
  private stateDropdown: HTMLAglDsDropdownboxElement;
  private errorNotification: HTMLAglDsErrorSummaryElement;
  private addressType: HTMLAglDsRadioButtonGroupElement;
  private streetNumber = this.manualAddressId + 'streetNumber';
  private streetName = this.manualAddressId + 'streetName';
  private streetType = this.manualAddressId + 'streetType';
  private suburb = this.manualAddressId + 'suburb';
  private state = this.manualAddressId + 'state';
  private postcode = this.manualAddressId + 'postcode';
  private poBoxNumber = this.manualAddressId + 'poBoxNumber';
  private poBoxType = this.manualAddressId + 'poBoxType';

  private requiredFields: string[] = [this.streetNumber, this.streetName, this.streetType, this.suburb, this.state, this.postcode];

  private modifyAddressDetails(addressDetails: AddressDetailModel | string[], addUniqueId: boolean) {
    //adds or subtracts the unique id for import/export
    const defaultAddressDetailArray = Object.keys(addressDetails);
    const defaultAddressDetail = {};
    defaultAddressDetailArray.map((item) => {
      if (addUniqueId) {
        defaultAddressDetail[this.manualAddressId + item] = addressDetails[item];
      } else {
        defaultAddressDetail[item.replace(this.manualAddressId, '')] = addressDetails[item];
      }
    });
    return defaultAddressDetail;
  }

  private handleFieldBlur(fieldName: string, value: string) {
    this.setValue(fieldName, value);
    this.validateField(fieldName, value);
    this.validateFormWhenCompleted(fieldName);
  }

  private setValue(fieldName: string, value: string) {
    const newValueObject = { ...this.addressDetailState };

    newValueObject[`${fieldName}`] = value;

    this.addressDetailState = newValueObject;
  }
  private contains(fieldName: string, name: string) {
    return fieldName.indexOf(name) > -1;
  }

  private validateField(fieldName: string, value: string) {
    const regex = {
      alphaNum: /^[0-9a-zA-Z][0-9a-zA-Z\s]*$/,
      streetName: /^[a-zA-Z][a-zA-Z \-']*$/,
      alpha: /^[a-zA-Z][a-zA-Z ]*$/
    };

    switch (true) {
      case this.contains(fieldName, 'streetName'):
      case this.contains(fieldName, 'streetType'):
      case this.contains(fieldName, 'suburb'):
        this.validateFieldWithRegex(fieldName, value, regex.alpha);
        break;
      case this.contains(fieldName, 'streetNumber'):
        this.validateFieldWithRegex(fieldName, value);
        break;
      case this.contains(fieldName, 'poBoxNumber'):
        this.validateFieldWithRegex(fieldName, value);
        break;
      case this.contains(fieldName, 'poBoxType'):
        this.validateFieldWithRegex(fieldName, value);
        break;
      case this.contains(fieldName, 'state'):
        this.validateStateField(value, postCodeRegEx);
        break;
      case this.contains(fieldName, 'postcode'):
        this.validatePostcodeField(value, postCodeRegEx);
        break;
      default:
        this.validateFieldWithRegex(fieldName, value);
        break;
    }
  }

  private validateFieldWithRegex(fieldName: string, value: string, regexRule?: RegExp) {
    if (regexRule) {
      if (value && regexRule.test(value)) {
        this.setFieldValid(fieldName);
      } else {
        this.setFieldInvalid(fieldName);
      }
    } else {
      if (value && value.trim()) {
        this.setFieldValid(fieldName);
      } else {
        this.setFieldInvalid(fieldName);
      }
    }
  }

  private validateStateField(value, postcodeRegex) {
    //if postcode is valid by default validation
    if (this.addressDetailState[this.postcode] && postcodeRegex.default.test(this.addressDetailState[this.postcode])) {
      //use state value to get regex to validate postcode
      if (value && postcodeRegex[`${value.toLowerCase()}`].test(this.addressDetailState[this.postcode])) {
        this.setFieldValid(this.state);
        this.setFieldValid(this.postcode);
      } else if (!value) {
        this.setFieldInvalid(this.state);
      } else {
        this.postcodeDropdown.validationText = 'State and postcode do not match';
        this.stateDropdown.validationText = 'State and postcode do not match';
        this.setFieldInvalid(this.state);
        this.setFieldInvalid(this.postcode);
      }
    } else {
      //postcode has no value or postcode is invalid, use default validation for state
      this.validateFieldWithRegex(this.state, value);
    }
  }

  private validatePostcodeField(value, postcodeRegex) {
    //if state is valid by default validation
    if (this.addressDetailState[this.state]) {
      //when postcode value passed in, validate with state based regex
      if (value && postcodeRegex[`${this.addressDetailState[this.state].toLowerCase()}`].test(value)) {
        this.setFieldValid(this.state);
        this.setFieldValid(this.postcode);
      } else if (!value) {
        this.setFieldInvalid(this.postcode);
      } else {
        this.postcodeDropdown.validationText = 'State and postcode do not match';
        this.stateDropdown.validationText = 'State and postcode do not match';
        this.setFieldInvalid(this.state);
        this.setFieldInvalid(this.postcode);
      }
    } else {
      //state has no value or state is invalid, use default validation for postcode
      this.validateFieldWithRegex(this.postcode, value, postcodeRegex.default);
    }
  }

  private isFieldValid(fieldName: string): boolean {
    return this.invalidFields.join().indexOf(fieldName) <= -1;
  }

  private setFieldValid(fieldName: string): void {
    if (this.isFieldValid(fieldName)) {
      return;
    }
    this.invalidFields = this.invalidFields.filter((item) => item !== fieldName);
  }

  private setFieldInvalid(fieldName: string): void {
    if (!this.isFieldValid(fieldName)) {
      return;
    }
    this.invalidFields = [...this.invalidFields, fieldName];
  }

  private validateFormWhenCompleted(fieldName: string) {
    if (!this.isFormInvalid) {
      return;
    }

    if (!this.isFieldValid(fieldName)) {
      return;
    }
    let isCompleted = true;

    this.requiredFields.forEach((fieldname) => {
      if (!this.addressDetailState[fieldname]) {
        isCompleted = false;
      }
    });

    if (isCompleted && this.validateForm()) {
      this.isFormInvalid = false;
    }
  }

  private validateForm() {
    let isValid = true;

    this.requiredFields.forEach((fieldName) => {
      const tmpFieldName = fieldName;
      this.validateField(tmpFieldName, this.addressDetailState[fieldName]);
      if (!this.isFieldValid(tmpFieldName)) {
        isValid = false;
      }
    });
    return isValid;
  }

  private updateRequiredFields() {
    if (this.addressTypeState === 'postal') {
      this.requiredFields = [this.streetNumber, this.streetName, this.streetType, this.suburb, this.state, this.postcode];
    } else {
      this.requiredFields = [this.poBoxType, this.poBoxNumber, this.suburb, this.state, this.postcode];
    }
  }

  private clearValueOnUnrequiredFields() {
    let unrequiredFields;
    this.addressTypeState === 'postal'
      ? (unrequiredFields = [this.poBoxType, this.poBoxNumber])
      : (unrequiredFields = [this.streetNumber, this.streetName, this.streetType]);

    unrequiredFields.forEach((fieldName) => {
      const newAddressModel = { ...this.addressDetailState };
      newAddressModel[`${fieldName}`] = null;
      this.addressDetailState = newAddressModel;
    });
  }

  private resetFormState() {
    this.addressDetailState = {};
    this.invalidFields = [];
    this.isFormInvalid = false;
    this.addressTypeState = this.includePobox ? 'poBox' : 'postal';
    this.firstInvalidInputId = '';
  }

  @Watch('addressTypeState')
  updateWhenAddressTypeChange() {
    this.updateRequiredFields();
    //reset invalid fields
    this.invalidFields = [];
  }

  @Watch('addressDetailState')
  updateRequiredfieldsWhenPoBoxTypeChange(oldValue: string, newValue: string) {
    if (oldValue && newValue && oldValue['poBoxType'] !== newValue['poBoxType']) {
      this.updateRequiredFields();
    }
  }

  @Watch('invalidFields')
  updateFirstInvalidInputId() {
    let hasFirstInvalidFieldFound = false;
    let firstInvalidField: string;
    this.requiredFields.forEach((requiredField) => {
      if (hasFirstInvalidFieldFound) return;
      if (!this.isFieldValid(requiredField)) {
        firstInvalidField = requiredField;
        hasFirstInvalidFieldFound = true;
      }
    });
    if (firstInvalidField === this.state || firstInvalidField === this.poBoxType) {
      this.firstInvalidInputId = `${firstInvalidField}_dropdown__button`;
    } else {
      this.firstInvalidInputId = `${firstInvalidField}_textBox`;
    }
  }

  /**
   * Public method to open the modal
   * @param {HTMLElement} el, the element need to be focused after modal close
   * @deprecated This will not be supported when the parameter is removed from the modal
   */
  @Method()
  async openModal(el: HTMLElement) {
    this.modalContainer.openModal(el);
    if (this.includePobox) {
      this.addressType.selectedValue = 'poBox';
    }
  }

  /**
   * Public method to set the modal trigger element
   * @param {Function} getTriggerButton, The anonymous function that returns the element that needs to be focused after modal close
   */
  @Method()
  async setTriggerButton(getTriggerButton: () => HTMLElement) {
    this.modalContainer.setTriggerButton(getTriggerButton);
  }

  componentWillLoad() {
    this.addressTypeState = this.includePobox ? 'poBox' : 'postal';
  }

  render() {
    return (
      <agl-ds-modal
        appearance="centerscreen"
        animationType="popup"
        disableScroll
        ref={(el) => (this.modalContainer = el)}
        onModalClosed={() => {
          this.resetFormState();
        }}
      >
        <div slot="header">
          <agl-ds-h2 bottomMargin="none" styledAs="title3">
            {this.heading}
          </agl-ds-h2>
        </div>
        <div slot="content">
          {this.includePobox && [
            <agl-ds-radio-button-group
              ref={(el) => (this.addressType = el)}
              groupName="addressType"
              onChange={(e) => {
                this.addressTypeState = (e.target as HTMLInputElement).value as AddressType;
                this.isFormInvalid = false;
              }}
              selectedValue={'poBox'}
            >
              <agl-ds-radio-button-set>
                <agl-ds-radio-button groupName="addressType" value="postal">
                  Postal address
                </agl-ds-radio-button>
                <agl-ds-radio-button groupName="addressType" value="poBox">
                  PO BOX address
                </agl-ds-radio-button>
              </agl-ds-radio-button-set>
            </agl-ds-radio-button-group>,
            <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
          ]}
          {this.isFormInvalid && (
            <agl-ds-error-summary
              ref={(el) => (this.errorNotification = el)}
              id="errorNotification"
              invalidFieldCount={this.invalidFields.length}
              firstInvalidInputId={this.firstInvalidInputId}
            ></agl-ds-error-summary>
          )}

          {/* Fields for postal address */}
          {this.addressTypeState === 'postal' && (
            <div>
              <div class="row">
                <div class="col-sm-12 col-md-6">
                  <agl-ds-textbox
                    label={'Unit number'}
                    hintText="If applicable"
                    maxLength={100}
                    value={this.addressDetailState.unitNumber}
                    onTextboxBlur={(e) => {
                      this.setValue('unitNumber', (e.detail.target as HTMLInputElement).value);
                    }}
                  ></agl-ds-textbox>
                </div>

                <div class="col-sm-12 col-md-6">
                  <agl-ds-textbox
                    id={this.streetNumber}
                    textBoxId={this.streetNumber + `_textBox`}
                    label="Street number"
                    maxLength={100}
                    validationText="Street number required"
                    onTextboxBlur={(e) => {
                      this.handleFieldBlur(this.streetNumber, (e.detail.target as HTMLInputElement).value);
                    }}
                    hasError={!this.isFieldValid(this.streetNumber)}
                    value={this.addressDetailState[this.streetNumber]}
                  ></agl-ds-textbox>
                </div>
              </div>

              <agl-ds-textbox
                id={this.streetName}
                label="Street name"
                textBoxId={this.streetName + '_textBox'}
                maxLength={100}
                inputType="text"
                validationText="Street name required"
                onTextboxBlur={(e) => {
                  this.handleFieldBlur(this.streetName, (e.detail.target as HTMLInputElement).value);
                }}
                hasError={!this.isFieldValid(this.streetName)}
                value={this.addressDetailState[this.streetName]}
              ></agl-ds-textbox>

              <agl-ds-autocomplete
                autoCompleteId={this.streetType}
                label="Street type"
                options={StreetTypes.map((type) => {
                  return { value: type, text: type };
                })}
                onAutocompleteOptionSelected={(e) => {
                  e.stopPropagation();
                  this.handleFieldBlur(this.streetType, e.detail.value);
                }}
                value={this.addressDetailState[this.streetType]}
                hasError={!this.isFieldValid(this.streetType)}
                validationText="Street type required (e.g. Road Avenue Blvd)"
                hintText="e.g. Road Avenue Blvd"
              ></agl-ds-autocomplete>
            </div>
          )}

          {/* fields for PO BOX */}
          {this.addressTypeState === 'poBox' && (
            <div class="row">
              <div class="col-sm-12 col-md-6">
                <agl-ds-dropdownbox
                  id={this.poBoxType}
                  selectId={this.poBoxType + '_dropdown'}
                  label="PO Box Type"
                  validationText="PO Box type required"
                  hintText="Select from list"
                  value={this.addressDetailState[this.poBoxType]}
                  onOptionSelected={(e) => {
                    this.handleFieldBlur(this.poBoxType, e.detail.value);
                  }}
                  onDropdownClosed={(e) => {
                    this.handleFieldBlur(this.poBoxType, e.detail);
                  }}
                  hasError={!this.isFieldValid(this.poBoxType)}
                >
                  <agl-ds-dropdown-option text="CMA" value="CMA"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="CPA" value="CPA"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="CMB" value="CMB"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="GPO BOX" value="GPO BOX"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="LOCKED BAG" value="LOCKED BAG"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="MS" value="MS"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="PO BOX" value="PO BOX"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="POSTE RESTANTE" value="POSTE RESTANTE"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="PRIVATE BAG" value="PRIVATE BAG"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="RMB" value="RMB"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="RMS" value="RMS"></agl-ds-dropdown-option>
                  <agl-ds-dropdown-option text="RMD" value="RMD"></agl-ds-dropdown-option>
                </agl-ds-dropdownbox>
              </div>

              <div class="col-sm-12 col-md-6">
                <agl-ds-textbox
                  id={this.poBoxNumber}
                  textBoxId={this.poBoxNumber + '_textBox'}
                  label="PO Box Number"
                  maxLength={100}
                  validationText="PO Box number required"
                  value={this.addressDetailState[this.poBoxNumber]}
                  onTextboxBlur={(e) => {
                    this.handleFieldBlur(this.poBoxNumber, (e.detail.target as HTMLInputElement).value);
                  }}
                  hasError={!this.isFieldValid(this.poBoxNumber)}
                ></agl-ds-textbox>
              </div>
            </div>
          )}

          <agl-ds-textbox
            id={this.suburb}
            textBoxId={this.suburb + '_textBox'}
            label="Suburb"
            maxLength={100}
            inputType="text"
            validationText="Suburb required"
            value={this.addressDetailState[this.suburb]}
            onTextboxBlur={(e) => {
              this.handleFieldBlur(this.suburb, (e.detail.target as HTMLInputElement).value);
            }}
            hasError={!this.isFieldValid(this.suburb)}
          ></agl-ds-textbox>

          <div class="row">
            <div class="col-sm-12 col-md-6">
              <agl-ds-dropdownbox
                ref={(el) => (this.stateDropdown = el)}
                id={this.state}
                selectId={this.state + '_dropdown'}
                label="State"
                validationText="State selection required"
                hintText="Select state"
                dropdownDirection="up"
                value={this.addressDetailState[this.state]}
                onDropdownClosed={(e) => {
                  this.handleFieldBlur(this.state, e.detail);
                }}
                onOptionSelected={(e) => {
                  this.handleFieldBlur(this.state, e.detail.value);
                }}
                hasError={!this.isFieldValid(this.state)}
              >
                <agl-ds-dropdown-option text="ACT" value="ACT"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="NSW" value="NSW"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="NT" value="NT"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="QLD" value="QLD"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="SA" value="SA"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="TAS" value="TAS"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="VIC" value="VIC"></agl-ds-dropdown-option>
                <agl-ds-dropdown-option text="WA" value="WA"></agl-ds-dropdown-option>
              </agl-ds-dropdownbox>
            </div>

            <div class="col-sm-12 col-md-6">
              <agl-ds-textbox
                ref={(el) => (this.postcodeDropdown = el)}
                id={this.postcode}
                textBoxId={this.postcode + '_textBox'}
                label="Postcode"
                maxLength={4}
                inputType="number"
                validationText="Postcode required (e.g. 3123)"
                hintText="e.g. 3123"
                value={this.addressDetailState[this.postcode]}
                onTextboxBlur={(e) => {
                  this.handleFieldBlur(this.postcode, (e.detail.target as HTMLInputElement).value);
                }}
                hasError={!this.isFieldValid(this.postcode)}
              ></agl-ds-textbox>
            </div>
          </div>
        </div>
        <div slot="footer">
          <div class="row">
            <div class="manual-address-entry__button col-sm-12 col-md-6">
              <agl-ds-button
                type="tertiary"
                iconPosition="left"
                onClick={() => {
                  this.modalContainer.closeModal();
                }}
                icon={leftArrow}
              >
                Return to address finder
              </agl-ds-button>
            </div>

            <div class="manual-address-entry__button col-sm-12 col-md-6">
              <agl-ds-button
                type="primary"
                onClick={() => {
                  this.isFormInvalid = !this.validateForm();
                  if (!this.isFormInvalid) {
                    this.clearValueOnUnrequiredFields();
                    this.addressConfirm.emit(this.modifyAddressDetails(this.addressDetailState, false));
                    this.modalContainer.closeModal();
                  } else {
                    setTimeout(() => this.errorNotification.setFocus(), 0);
                  }
                }}
              >
                Add address
              </agl-ds-button>
            </div>
          </div>
        </div>
      </agl-ds-modal>
    );
  }
}
