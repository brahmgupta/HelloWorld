jest.doMock('../../../../global/utils/utils', () => {
  return {
    generateRandomNumber: () => 52,
    hideFocusRingWhenUsingMouse: () => null,
    checkSlottedContentForInvalidHTML: () => null,
    getSiblings: () => null
  };
});

import { newSpecPage } from '@stencil/core/testing';
import { DropdownBoxComponent } from '../../../core/dropdownbox/dropdownbox.component';
import { DropdownOptionComponent } from '../../../core/dropdownbox/dropdownoption/dropdownoption.component';
import { HintValidationMessageComponent } from '../../../core/hint-validation-message/hint-validation-message.component';
import { ModalComponent } from '../../../core/modal/modal/modal.component';
import { RadioButtonComponent } from '../../../core/radio-buttons/radio-button/radio-button.component';
import { RadioButtonGroupComponent } from '../../../core/radio-buttons/radio-button-group/radio-button-group.component';
import { RadioButtonSetComponent } from '../../../core/radio-buttons/radio-button-set/radio-button-set.component';
import { TextBoxComponent } from '../../../core/textbox/textbox.component';
import { ManualAddressEntryComponent } from './manual-address-entry';

describe('Manual Address Entry Component', () => {
  //street number
  it('should not show error message on streetNumber textbox component when have letters in streetNumber', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNumberField = page.root.querySelector('#52streetNumber');
    const input = streetNumberField.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNumberField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should not show error message on streetNumber textbox component when have numbers in streetNumber', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNumberField = page.root.querySelector('#52streetNumber');
    const input = streetNumberField.querySelector('input');
    input.value = '123';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNumberField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should not show error message on streetNumber textbox component when have space in streetNumber', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNumberField = page.root.querySelector('#52streetNumber');
    const input = streetNumberField.querySelector('input');
    input.value = '10 A';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNumberField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should show error message on streetNumber textbox component when nothing in streetNumber', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNumberField = page.root.querySelector('#52streetNumber');
    const input = streetNumberField.querySelector('input');
    input.value = '';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNumberField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  it('should show error message on streetNumber textbox component when only whitespaces in streetNumber', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNumberField = page.root.querySelector('#52streetNumber');
    const input = streetNumberField.querySelector('input');
    input.value = '   ';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNumberField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  //street Name

  it('should not show error message on streetName textbox component when have letters in streetName', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNameField = page.root.querySelector('#52streetName');
    const input = streetNameField.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNameField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should not show error message on streetName textbox component when have space in streetName', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNameField = page.root.querySelector('#52streetName');
    const input = streetNameField.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNameField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should show error message on streetName textbox component when have @ in streetName', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNameField = page.root.querySelector('#52streetName');
    const input = streetNameField.querySelector('input');
    input.value = 'test@';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNameField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  it('should show error message on streetName textbox component when have numbers in streetName', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const streetNameField = page.root.querySelector('#52streetName');
    const input = streetNameField.querySelector('input');
    input.value = 'test1';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = streetNameField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  //suburb

  it('should not show error message on suburb textbox component when have letters in suburb', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const suburbField = page.root.querySelector('#52suburb');
    const input = suburbField.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = suburbField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should not show error message on suburb textbox component when have space in suburb', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const suburbField = page.root.querySelector('#52suburb');
    const input = suburbField.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = suburbField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeFalsy();
  });

  it('should show error message on suburb textbox component when have @ in suburb', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const suburbField = page.root.querySelector('#52suburb');
    const input = suburbField.querySelector('input');
    input.value = 'test@';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = suburbField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  it('should show error message on suburb textbox component when have numbers in suburb', async () => {
    const page = await newSpecPage({
      components: [ManualAddressEntryComponent, TextBoxComponent, HintValidationMessageComponent],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`
    });
    const suburbField = page.root.querySelector('#52suburb');
    const input = suburbField.querySelector('input');
    input.value = 'test1';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const errorMsg = suburbField.querySelector('agl-ds-hint-validation-message');
    expect(errorMsg.hasError).toBeTruthy();
  });

  //postcode
  it('should show error message on postcode textbox component when state and postcode not match when postcode text blur', async () => {
    const page = await newSpecPage({
      components: [
        ManualAddressEntryComponent,
        TextBoxComponent,
        HintValidationMessageComponent,
        RadioButtonGroupComponent,
        RadioButtonComponent,
        RadioButtonSetComponent,
        ModalComponent,
        DropdownBoxComponent,
        DropdownOptionComponent
      ],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`,
      supportsShadowDom: false
    });

    const stateDropdown = page.root.querySelector('#52state');

    const dropdownBtn = stateDropdown.querySelector('button');
    dropdownBtn.focus = jest.fn();
    const ul = stateDropdown.querySelector('ul');
    ul.focus = jest.fn();
    dropdownBtn.click();
    await page.waitForChanges();

    const option = stateDropdown.querySelector("[value='VIC']");
    option.dispatchEvent(new Event('mousedown'));
    await page.waitForChanges();

    const postcodeField = page.root.querySelector('#52postcode');
    const input = postcodeField.querySelector('input');
    input.value = '2000';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    expect((postcodeField as HTMLAglDsTextboxElement).hasError).toBeTruthy();
  });

  //state
  it('should show error message on postcode textbox component when state and postcode not match when postcode text blur', async () => {
    const page = await newSpecPage({
      components: [
        ManualAddressEntryComponent,
        TextBoxComponent,
        HintValidationMessageComponent,
        RadioButtonGroupComponent,
        RadioButtonComponent,
        RadioButtonSetComponent,
        ModalComponent,
        DropdownBoxComponent,
        DropdownOptionComponent
      ],
      html: `<agl-ds-manual-address-entry></agl-ds-manual-address-entry>`,
      supportsShadowDom: false
    });
    const postcodeField = page.root.querySelector('#52postcode');
    const input = postcodeField.querySelector('input');
    input.value = '2000';
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    const stateDropdown = page.root.querySelector('#52state');

    const dropdownBtn = stateDropdown.querySelector('button');

    dropdownBtn.focus = jest.fn();
    const ul = stateDropdown.querySelector('ul');
    ul.focus = jest.fn();
    dropdownBtn.click();
    await page.waitForChanges();

    const option = stateDropdown.querySelector("[value='VIC']");
    option.dispatchEvent(new Event('mousedown'));
    await page.waitForChanges();

    expect((stateDropdown as HTMLAglDsDropdownboxElement).hasError).toBeTruthy();
  });
});
