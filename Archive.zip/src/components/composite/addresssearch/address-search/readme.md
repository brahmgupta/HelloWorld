# agl-ds-address-search



<!-- Auto Generated Below -->


## Properties

| Property                           | Attribute                              | Description                                                                                                                                                                                                                                                                                                                                                                                                                           | Type                                               | Default                                   |
| ---------------------------------- | -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- | ----------------------------------------- |
| `addressInputValue`                | `address-input-value`                  | The address input value                                                                                                                                                                                                                                                                                                                                                                                                               | `AddressDetailModel \| string`                     | `''`                                      |
| `baseUrl`                          | `base-url`                             | Address search api baseUrl                                                                                                                                                                                                                                                                                                                                                                                                            | `string`                                           | `''`                                      |
| `debounceTime`                     | `debounce-time`                        | The debounce time while user type in address                                                                                                                                                                                                                                                                                                                                                                                          | `number`                                           | `600`                                     |
| `hasError`                         | `has-error`                            | Flag to show error state                                                                                                                                                                                                                                                                                                                                                                                                              | `boolean`                                          | `false`                                   |
| `hintText`                         | `hint-text`                            | Hint text will be shown underneath the textbox but will be hidden if there is an error                                                                                                                                                                                                                                                                                                                                                | `string`                                           | `''`                                      |
| `isMailingAddress`                 | `is-mailing-address`                   | Address search isMailingAddress flag. If true, will include poBox and unserviceable addresses                                                                                                                                                                                                                                                                                                                                         | `boolean`                                          | `false`                                   |
| `label`                            | `label`                                | The label text for the input, will be hidden if type is experiential                                                                                                                                                                                                                                                                                                                                                                  | `string`                                           | `''`                                      |
| `manualAddressHeading`             | `manual-address-heading`               | Manual address modal heading                                                                                                                                                                                                                                                                                                                                                                                                          | `string`                                           | `''`                                      |
| `manualAddressOptionHighlightText` | `manual-address-option-highlight-text` | Highlight text that shows on the option that triggers manual address entry                                                                                                                                                                                                                                                                                                                                                            | `string`                                           | `'Enter it manually'`                     |
| `manualAddressOptionText`          | `manual-address-option-text`           | Text that shows on the option that triggers manual address entry                                                                                                                                                                                                                                                                                                                                                                      | `string`                                           | `"Can't find address? Enter it manually"` |
| `placeholder`                      | `placeholder`                          | The placeholder property for the input, only used if type is experiential                                                                                                                                                                                                                                                                                                                                                             | `string`                                           | `''`                                      |
| `showSpinner`                      | `show-spinner`                         | Flag to show spinner                                                                                                                                                                                                                                                                                                                                                                                                                  | `boolean`                                          | `false`                                   |
| `showValidIcon`                    | `show-valid-icon`                      | Shows the valid icon when it equals true and validSelectionMode is set to external or onSelect                                                                                                                                                                                                                                                                                                                                        | `boolean`                                          | `undefined`                               |
| `subscriptionKey`                  | `subscription-key`                     | Address search api subscriptionKey                                                                                                                                                                                                                                                                                                                                                                                                    | `string`                                           | `''`                                      |
| `type`                             | `type`                                 | Type for the control, either default, default-inverse or experiential                                                                                                                                                                                                                                                                                                                                                                 | `"default" \| "default-inverse" \| "experiential"` | `'default'`                               |
| `validSelectionMode`               | `valid-selection-mode`                 | Shows the valid icon when validSelectionMode is set to external or onSelect and showValidIcon equals true. validSelectionMode should be used when an api call regulates the visibility of the icon ie when an address is searched for by the user and the address is servicable. onSelect should be used with a static list of options (eg street Name) where any selection is valid If set to false, valid state will never display. | `"external" \| "off" \| "onSelect"`                | `'off'`                                   |
| `validText`                        | `valid-text`                           | Text to show when valid. Will override the hint text if present at the bottom of the component.                                                                                                                                                                                                                                                                                                                                       | `string`                                           | `''`                                      |
| `validationText`                   | `validation-text`                      | Validation text to show when the has error flag is true                                                                                                                                                                                                                                                                                                                                                                               | `string`                                           | `''`                                      |


## Events

| Event                        | Description                                                            | Type                              |
| ---------------------------- | ---------------------------------------------------------------------- | --------------------------------- |
| `addressSearchBlur`          | Fires when text input loses focus                                      | `CustomEvent<FocusEvent>`         |
| `addressSearchInput`         | Fires when user starts typing in the textbox for address search        | `CustomEvent<InputEvent>`         |
| `addressSelected`            | Fires when address option selected. AddressDetailModel will be emitted | `CustomEvent<AddressDetailModel>` |
| `manualAddressOptionClicked` | Fires when manual address option is selected                           | `CustomEvent<void>`               |


## Methods

### `setTextBoxValue(textValue: string) => Promise<void>`

Sets the textbox component element

#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [agl-ds-autocomplete](../../autocomplete)
- [agl-ds-manual-address-entry](../manual-address-entry)

### Graph
```mermaid
graph TD;
  agl-ds-address-search --> agl-ds-autocomplete
  agl-ds-address-search --> agl-ds-manual-address-entry
  agl-ds-autocomplete --> agl-ds-text
  agl-ds-autocomplete --> agl-ds-textbox
  agl-ds-autocomplete --> agl-ds-loading-indicator
  agl-ds-textbox --> agl-ds-hint-validation-message
  agl-ds-manual-address-entry --> agl-ds-modal
  agl-ds-manual-address-entry --> agl-ds-h2
  agl-ds-manual-address-entry --> agl-ds-radio-button-group
  agl-ds-manual-address-entry --> agl-ds-radio-button-set
  agl-ds-manual-address-entry --> agl-ds-radio-button
  agl-ds-manual-address-entry --> agl-ds-spacer
  agl-ds-manual-address-entry --> agl-ds-error-summary
  agl-ds-manual-address-entry --> agl-ds-textbox
  agl-ds-manual-address-entry --> agl-ds-autocomplete
  agl-ds-manual-address-entry --> agl-ds-dropdownbox
  agl-ds-manual-address-entry --> agl-ds-dropdown-option
  agl-ds-manual-address-entry --> agl-ds-button
  agl-ds-modal --> agl-ds-icon
  agl-ds-radio-button-group --> agl-ds-form-field-label
  agl-ds-radio-button-group --> agl-ds-hint-validation-message
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-text
  agl-ds-radio-button --> agl-ds-icon
  agl-ds-error-summary --> agl-ds-notification
  agl-ds-error-summary --> agl-ds-spacer
  agl-ds-notification --> agl-ds-h4
  agl-ds-notification --> agl-ds-p
  agl-ds-notification --> agl-ds-link
  agl-ds-notification --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  agl-ds-dropdownbox --> agl-ds-dropdown-option
  agl-ds-dropdownbox --> agl-ds-hint-validation-message
  style agl-ds-address-search fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
