import { Component, ComponentInterface, Event, EventEmitter, Listen, Method, Prop, State, Watch, h } from '@stencil/core';
import { AutocompleteState, validSelectionMode } from '../../autocomplete/autocomplete.types';

import { AddressDetailModel } from '../address.model';
import { AutoCompleteOption } from '../../autocomplete/autocompleteResult';
import { TextboxType } from '../../../core/textbox/textbox.types';
import { AddressSearchService } from './address-search.service';

@Component({
  tag: 'agl-ds-address-search',
  shadow: false //needs to be false for events to get the correct target in children components
})
export class AddressSearchComponent implements ComponentInterface {
  /**
   * Address search api baseUrl
   */
  @Prop() baseUrl: string = '';

  /**
   * Address search api subscriptionKey
   */
  @Prop() subscriptionKey: string = '';

  /**
   * Address search isMailingAddress flag. If true, will include poBox and unserviceable addresses
   */
  @Prop() isMailingAddress: boolean = false;
  /**
   * The label text for the input, will be hidden if type is experiential
   */
  @Prop() label: string = '';

  /**
   * Type for the control, either default, default-inverse or experiential
   */
  @Prop() type: TextboxType = 'default';

  /**
   * The placeholder property for the input, only used if type is experiential
   */
  @Prop() placeholder: string = '';

  /**
   * The address input value
   */
  @Prop() addressInputValue: string | AddressDetailModel = '';

  /**
   * The debounce time while user type in address
   */
  @Prop() debounceTime: number = 600;

  /**
   * Manual address modal heading
   */
  @Prop() manualAddressHeading: string = '';

  /**
   * Validation text to show when the has error flag is true
   */
  @Prop() validationText: string = '';

  /**
   * Text to show when valid. Will override the hint text if present at the bottom of the component.
   */
  @Prop() validText: string = '';

  /**
   * Shows the valid icon when it equals true and validSelectionMode is set to external or onSelect
   */
  @Prop() showValidIcon: boolean;

  /**
   * Shows the valid icon when validSelectionMode is set to external or onSelect and showValidIcon
   * equals true. validSelectionMode should be used when an api call regulates the visibility of the
   * icon ie when an address is searched for by the user and the address is servicable. onSelect should
   * be used with a static list of options (eg street Name) where any selection is valid
   * If set to false, valid state will never display.
   */
  @Prop() validSelectionMode: validSelectionMode = 'off';

  /**
   * Hint text will be shown underneath the textbox but will be hidden if there is an error
   */
  @Prop() hintText: string = '';

  /**
   * Flag to show error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Flag to show spinner
   */
  @Prop() showSpinner: boolean = false;

  /**
   * Text that shows on the option that triggers manual address entry
   */
  @Prop() manualAddressOptionText: string = "Can't find address? Enter it manually";

  /**
   * Highlight text that shows on the option that triggers manual address entry
   */
  @Prop() manualAddressOptionHighlightText: string = 'Enter it manually';

  /**
   * Address options that shows in the suggestion list
   */
  @State() options: AutoCompleteOption[] = [];

  /**
   * Address search state, idle/displayResults/loading/resultSelected
   */
  @State() autoCompleteState: AutocompleteState = 'idle';

  /**
   * Display address string, will be set after manual address is confirmed
   */
  @State() addressString: string;

  /**
   * Fires when address option selected. AddressDetailModel will be emitted
   */
  @Event() addressSelected: EventEmitter<AddressDetailModel>;

  /**
   * Fires when manual address option is selected
   */
  @Event() manualAddressOptionClicked: EventEmitter<void>;

  /**
   * Fires when user starts typing in the textbox for address search
   */
  @Event() addressSearchInput: EventEmitter<InputEvent>;

  /**
   * Fires when text input loses focus
   */
  @Event() addressSearchBlur: EventEmitter<FocusEvent>;

  /**
   * Sets the textbox component element
   */
  @Method()
  async setTextBoxValue(textValue: string): Promise<void> {
    await this.autocompleteComp.setTextBoxValue(textValue);
  }

  private addressSearchService: AddressSearchService;

  private manualAddressComp: HTMLAglDsManualAddressEntryElement;

  private autocompleteComp: HTMLAglDsAutocompleteElement;

  componentWillLoad() {
    this.addressSearchService = new AddressSearchService(this.baseUrl, this.subscriptionKey, this.isMailingAddress);
    if (this.addressInputValue) {
      this.setAddressValue(this.addressInputValue);
    }
  }

  componentDidLoad() {
    this.manualAddressComp.setTriggerButton(() => {
      return this.autocompleteComp.querySelector('agl-ds-textbox');
    });
  }

  private async handleAddressSearch(query: string) {
    const manualAddressOption = {
      value: 'manualAddressOption',
      text: this.manualAddressOptionText,
      doNotComplete: true,
      highlightText: this.manualAddressOptionHighlightText
    };
    if (query.length >= 7) {
      this.autoCompleteState = 'loading';
      try {
        const addressDataModal = await this.addressSearchService.getAddressList(query);
        this.options = [
          ...addressDataModal.data.map((x) => {
            return { value: x.id, text: x.address };
          }),
          manualAddressOption
        ];
      } catch (e) {
        this.options = [manualAddressOption];
      }

      this.autoCompleteState = 'displayResults';
    } else {
      this.options = [];
      this.autoCompleteState = 'idle';
    }
  }

  private async handleClick(): Promise<void> {
    const element = await this.autocompleteComp.getTextBoxElement();
    await element.selectInput();
  }

  private debounce(callback, wait) {
    let timeout;
    return (...args) => {
      const context = this;
      clearTimeout(timeout);
      timeout = setTimeout(() => callback.apply(context, args), wait);
    };
  }

  /**
   * Sets the component value based off a previously stored address details model
   */
  private setAddressString(addressDetailModel: AddressDetailModel) {
    if (addressDetailModel.poBoxType) {
      const poBoxNumber =
        addressDetailModel.poBoxNumber !== null && addressDetailModel.poBoxNumber !== undefined ? addressDetailModel.poBoxNumber : '';
      this.addressString = `${addressDetailModel.poBoxType} ${poBoxNumber}, ${addressDetailModel.suburb} ${addressDetailModel.state} ${addressDetailModel.postcode}`.trimLeft();
    } else {
      const unitNumber =
        addressDetailModel.unitNumber !== null && addressDetailModel.unitNumber !== undefined ? addressDetailModel.unitNumber : '';
      this.addressString = `${unitNumber} ${addressDetailModel.streetNumber} ${addressDetailModel.streetName} ${addressDetailModel.streetType}, ${addressDetailModel.suburb} ${addressDetailModel.state} ${addressDetailModel.postcode}`.trimLeft();
    }
  }
  /**
   * Set the display value of the address search component based on a custom string or an address details model
   * @param value The address value to dsiplay as either a string or addressDetailModel
   */
  private setAddressValue(value: string | AddressDetailModel) {
    if (typeof value === 'string') {
      this.addressString = value;
    } else {
      this.setAddressString(value);
    }
  }

  @Watch('addressInputValue')
  valueWatchHandler(newValue: string | AddressDetailModel) {
    this.setAddressValue(newValue);
  }

  @Listen('autocompleteOptionSelected')
  async handleOptionSelected(event: CustomEvent<AutoCompleteOption>) {
    if (event.detail.value === 'manualAddressOption') {
      this.manualAddressOptionClicked.emit();
      this.manualAddressComp.openModal(this.autocompleteComp.querySelector('input'));
      this.autoCompleteState = 'resultSelected';
      return;
    }

    this.autoCompleteState = 'loading';
    const response = await this.addressSearchService.getAddressDetails(event.detail.value);
    this.addressSelected.emit({
      ...response.data.address,
      latitude: response.data.geoLocation ? response.data.geoLocation.latitude : '',
      longitude: response.data.geoLocation ? response.data.geoLocation.longitude : '',
      poBoxNumber: response.data.postOfficeBox ? response.data.postOfficeBox.postOfficeBoxNumber : '',
      poBoxType: response.data.postOfficeBox ? response.data.postOfficeBox.postOfficeBoxType : null
    });
    this.autoCompleteState = 'resultSelected';
  }

  render() {
    return (
      <div>
        <agl-ds-autocomplete
          value={this.addressString}
          label={this.label}
          type={this.type}
          placeholder={this.placeholder}
          options={this.options}
          parentState={this.showSpinner ? 'loading' : this.autoCompleteState}
          mode="controlled"
          hintText={this.hintText}
          validationText={this.validationText}
          validText={this.validText}
          showValidIcon={this.showValidIcon}
          validSelectionMode={this.validSelectionMode}
          hasError={this.hasError}
          ref={(el) => {
            this.autocompleteComp = el;
          }}
          onAutocompleteInput={this.debounce((e: CustomEvent) => {
            this.addressSearchInput.emit(e.detail as InputEvent);
            this.handleAddressSearch((e.detail.target as HTMLInputElement).value);
          }, this.debounceTime)}
          onClick={() => {
            this.handleClick();
          }}
          onAutocompleteBlur={() => {
            this.addressSearchBlur.emit();
          }}
        ></agl-ds-autocomplete>
        <agl-ds-manual-address-entry
          heading={this.manualAddressHeading}
          ref={(el) => {
            this.manualAddressComp = el;
          }}
          includePobox={this.isMailingAddress}
          onAddressConfirm={(e) => {
            this.addressSelected.emit(e.detail);
            this.setAddressString(e.detail as AddressDetailModel);
          }}
        ></agl-ds-manual-address-entry>
      </div>
    );
  }
}
