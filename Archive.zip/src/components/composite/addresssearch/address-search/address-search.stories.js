import { select, text, boolean, number } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/AddressSearch'
};

export const Default = () =>
  html`<agl-ds-address-search
    label="${text('label', 'Connection address')}"
    placeholder="${text('placeholder', 'e.g. 123 Queen Street, Melbourne')}"
    address-input-value="${text('addressInputValue', '')}"
    debouce-time="${number('debounce time', 600)}"
    type="${select('type', ['default', 'default-inverse', 'experiential'], 'default')}"
    base-url="${text('baseUrl', 'https://qtruat-api.platform.agl.com.au/shared')}"
    subscription-key="${text('subscriptionKey', '')}"
    is-mailing-address="${boolean('isMailingAddress', false)}"
    has-error="${boolean('has Error', false)}"
    show-spinner="${boolean('show Spinner', false)}"
    validation-text="${text('validation Text', 'There is an error')}"
    manual-address-heading="${text('manualAddressHeading', 'What address do you want to connect?')}"
    hint-text="${text('hintText', 'e.g. 123 Queen Street, Melbourne')}"
    manual-address-option-text="${text('manual Address Option Text', "Can't find address? Enter it manually")}"
    manual-address-option-highlight-text="${text('manual Address Option HighlightText', 'Enter it manually')}"
    show-valid-icon="${boolean('show valid icon', false)}"
    valid-selection-mode="${select('valid selection mode', ['off', 'onSelect', 'external'], 'off')}"
  ></agl-ds-address-search>`;

Default.storyName = 'default';
Default.parameters = {
  notes,
  // these rules are excluded as the story is not a real world example of how the elements are consumed
  a11y: {
    options: {
      rules: {
        'label-title-only': { enabled: false }
      }
    }
  }
};
