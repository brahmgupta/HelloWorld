import { h } from '@stencil/core';
import { newSpecPage } from '@stencil/core/testing';
import { TextBoxComponent } from '../../../core/textbox/textbox.component';
import { ManualAddressEntryComponent } from '../manual-address-entry/manual-address-entry';
import { RadioButtonGroupComponent } from '../../../core/radio-buttons/radio-button-group/radio-button-group.component';
import { RadioButtonSetComponent } from '../../../core/radio-buttons/radio-button-set/radio-button-set.component';
import { ModalComponent } from '../../../core/modal/modal/modal.component';
import { Autocomplete } from '../../autocomplete/autocomplete.component';
import { AddressDetailModel } from '../address.model';
import { RadioButtonComponent } from '../../../core/radio-buttons/radio-button/radio-button.component';
import { AddressSearchService } from './address-search.service';
import { AddressSearchComponent } from './address-search';

jest.useFakeTimers();

describe('address search component', () => {
  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllTimers();
  });

  it('should render default address search', async () => {
    const page = await newSpecPage({
      components: [AddressSearchComponent, AddressSearchComponent, ManualAddressEntryComponent, ModalComponent],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });
    await page.waitForChanges();
    expect(page.root).not.toBeNull();
  });

  it('should render suggestion list when the input has more than 7 characters', async () => {
    const page = await newSpecPage({
      components: [AddressSearchComponent, Autocomplete, TextBoxComponent, ManualAddressEntryComponent, ModalComponent],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });

    jest.spyOn(AddressSearchService.prototype, 'getAddressList').mockImplementation(async () => {
      return { data: [{ id: '1', address: 'test' }] };
    });

    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    input.select = jest.fn();
    input.value = 'testtest';
    input.dispatchEvent(new Event('input'));
    jest.runAllTimers();
    await page.waitForChanges();

    expect(autoComplete.querySelectorAll('li').length).toEqual(2);
  });

  it('should not show suggestion list when the input has less than 7 characters', async () => {
    const page = await newSpecPage({
      components: [AddressSearchComponent, Autocomplete, TextBoxComponent, ManualAddressEntryComponent, ModalComponent],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });

    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    input.select = jest.fn();
    input.value = 'testte';
    input.dispatchEvent(new Event('input'));
    jest.runAllTimers();
    await page.waitForChanges();

    expect(autoComplete.querySelectorAll('ul').length).toEqual(0);
  });

  it('should call addressSelected when address selected from the list', async () => {
    const page = await newSpecPage({
      components: [AddressSearchComponent, Autocomplete, TextBoxComponent, ManualAddressEntryComponent, ModalComponent],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });

    jest.spyOn(AddressSearchService.prototype, 'getAddressList').mockImplementation(async () => {
      return { data: [{ id: '1', address: '699 bourke street, docklands' }] };
    });

    jest.spyOn(AddressSearchService.prototype, 'getAddressDetails').mockImplementation(async () => {
      return {
        data: {
          address: {
            floorNumber: '',
            unitNumber: '',
            streetNumber: '699',
            street: 'Bourke Street',
            streetName: 'Bourke',
            streetType: 'Street',
            streetTypeSuffix: '',
            suburb: 'DOCKLANDS',
            postcode: '3008',
            state: 'VIC',
            deliveryPointIdentifier: '76347199'
          },
          geoLocation: {
            latitude: '-37.81815783',
            longitude: '144.95345766'
          }
        }
      };
    });

    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    input.select = jest.fn();
    input.value = '699 bourke street';

    input.dispatchEvent(new Event('input'));
    jest.runAllTimers();
    await page.waitForChanges();

    input.focus = jest.fn();

    const selectedSpy = jest.fn();
    page.win.addEventListener('addressSelected', selectedSpy);

    autoComplete.querySelectorAll('li')[0].click();

    await page.waitForChanges();

    expect(selectedSpy).toHaveBeenCalled();
  });

  it('should render manual address entry when manual address entry option is clicked', async () => {
    const page = await newSpecPage({
      components: [AddressSearchComponent, Autocomplete, TextBoxComponent, ManualAddressEntryComponent, ModalComponent],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });

    jest.spyOn(AddressSearchService.prototype, 'getAddressList').mockImplementation(async () => {
      return { data: [{ id: '1', address: 'test' }] };
    });

    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    input.select = jest.fn();
    input.value = 'testtest';
    input.dispatchEvent(new Event('input'));
    jest.runAllTimers();
    await page.waitForChanges();

    input.focus = jest.fn();
    autoComplete.querySelectorAll('li')[1].click();
    await page.waitForChanges();

    expect(page.root.querySelectorAll('agl-ds-manual-address-entry').length).toEqual(1);
  });

  it('should render manual address entry with radio button options postal/pobox when isMailingAddress set to true', async () => {
    const page = await newSpecPage({
      components: [
        AddressSearchComponent,
        Autocomplete,
        TextBoxComponent,
        ManualAddressEntryComponent,
        RadioButtonGroupComponent,
        RadioButtonSetComponent,
        RadioButtonComponent,
        ModalComponent
      ],
      html: `<agl-ds-address-search label='Connection address'></agl-ds-address-search>`
    });
    await page.waitForChanges();

    jest.spyOn(AddressSearchService.prototype, 'getAddressList').mockImplementation(async () => {
      return { data: [{ id: '1', address: 'test' }] };
    });

    page.root.isMailingAddress = true;
    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    input.select = jest.fn();
    input.value = 'testtest';
    input.dispatchEvent(new Event('input'));
    jest.runAllTimers();
    await page.waitForChanges();

    input.focus = jest.fn();
    autoComplete.querySelectorAll('li')[1].click();
    await page.waitForChanges();

    expect(page.root.querySelectorAll('agl-ds-radio-button-group').length).toEqual(1);
  });

  it('should set the original text to be displayed based on the `addressInputValue` parameter when a string is given', async () => {
    const page = await newSpecPage({
      components: [
        AddressSearchComponent,
        Autocomplete,
        TextBoxComponent,
        ManualAddressEntryComponent,
        RadioButtonGroupComponent,
        RadioButtonSetComponent,
        ModalComponent
      ],
      html: `<agl-ds-address-search address-input-value='123 test street bayside 3124' label='Connection address'></agl-ds-address-search>`
    });
    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    expect(input.value).toEqual('123 test street bayside 3124');
  });

  it('should set the original text to be displayed based on the `addressInputValue` parameter when an existing address search model is given', async () => {
    const testAddress: AddressDetailModel = {
      unitNumber: '',
      streetNumber: '31',
      streetName: 'Burwood',
      streetType: 'Close',
      suburb: 'ANDERGROVE',
      postcode: '4740',
      state: 'QLD',
      deliveryPointIdentifier: '46383836',
      latitude: '-21.10001253',
      longitude: '149.17993520',
      poBoxNumber: '',
      poBoxType: null
    };
    const page = await newSpecPage({
      components: [AddressSearchComponent, Autocomplete, TextBoxComponent, ManualAddressEntryComponent, ModalComponent],
      template: () => <agl-ds-address-search addressInputValue={testAddress}></agl-ds-address-search>
    });

    const autoComplete = page.root.querySelectorAll('agl-ds-autocomplete')[0];
    const input = autoComplete.querySelector('input');
    expect(input.value).toEqual('31 Burwood Close, ANDERGROVE QLD 4740');
  });
});
