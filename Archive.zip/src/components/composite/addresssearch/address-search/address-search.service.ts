import { QasResponse, DataModel } from '../address.model';
import { generateRandomGuid } from '../../../../global/utils/utils';

export class AddressSearchService {
  private baseUrl: string;
  private httpHeaders;
  private isMailingAddress: boolean;

  constructor(baseUrl, subscriptionKey, isMailingAddress) {
    this.baseUrl = baseUrl;
    this.httpHeaders = {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Ocp-Apim-Subscription-Key': subscriptionKey,
      'Correlation-Id': generateRandomGuid(),
      'Api-Version': 'v2'
    };
    this.isMailingAddress = isMailingAddress;
  }

  /**
   * Returns an Promise for the HTTP GET request for the JSON resource.
   * Get the data modal for the address searching.
   * @return {DataModel} The Promise for the HTTP request.
   */
  public async getAddressList(query: string): Promise<DataModel> {
    const urlParams =
      this.baseUrl +
      `/addresses/search/suggest?query=${query}&maxResults=10` +
      (this.isMailingAddress ? '&excludeUnserviceable=false&excludePostOfficeBox=false' : '');

    try {
      const response = await fetch(urlParams, {
        method: 'GET',
        headers: this.httpHeaders
      });
      handleErrors(response);
      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(e);
    }
  }

  /**
   * Returns an promise for the HTTP GET request for the JSON resource.
   * Get the addressDetails for address selected from the list.
   * @return {QasResponse} The promise for the HTTP request.
   */
  public async getAddressDetails(id: string): Promise<QasResponse> {
    const urlParams = this.baseUrl + `/addresses/search/select?Id=${id}`;

    try {
      const response = await fetch(urlParams, {
        method: 'GET',
        headers: this.httpHeaders
      });
      handleErrors(response);
      const data = await response.json();
      return data;
    } catch (e) {
      throw new Error(e);
    }
  }
}

function handleErrors(response: Response): void | Response {
  if (!response.ok) {
    throw new Error(response.status.toString());
  }
  return response;
}
