import { poBoxType } from './manual-address-entry/manual-address-entry.types';

export class DataModel {
  public data: AddressModel[];
}

export class AddressModel {
  public id: string;
  public address: string;
}

export class AddressDetailModel {
  public addressId?: string;
  public addressMode?: string;
  public addressType?: string;
  public careOf?: string;
  public deliveryPointIdentifier?: string;
  public floor?: string;
  public houserNumber?: string;
  public latitude?: string;
  public longitude?: string;
  public poBoxNumber?: string;
  public poBoxType?: poBoxType;
  public postcode?: string;
  public state?: string;
  public streetNumber?: string;
  public streetName?: string;
  public streetType?: string;
  public suburb?: string;
  public unitNumber?: string;
  public validatedByQAS?: string | boolean;
  public fullAddress?: string;
}

export interface GeoLocation {
  latitude: string;
  longitude: string;
}

export interface QasResponse {
  data: {
    address: AddressDetailModel;
    geoLocation?: GeoLocation;
    postOfficeBox?: PostOfficeBox;
  };
}

export interface PostOfficeBox {
  postOfficeBoxNumber: string;
  postOfficeBoxType: poBoxType;
}

export class AddressSearchDataResponse {
  public data: AddressSearchDataAddressDetailResponse;
}

export class AddressSearchDataAddressDetailResponse {
  public address: AddressDetailModel;
}

// tslint:disable-next-line: variable-name
export const StreetTypes = [
  'Access',
  'Alley',
  'Alleyway',
  'Amble',
  'Anchorage',
  'Approach',
  'Arcade',
  'Artery',
  'Avenue',
  'Basin',
  'Beach',
  'Bend',
  'Block',
  'Boulevard',
  'Brace',
  'Brae',
  'Break',
  'Bridge',
  'Broadway',
  'Brow',
  'Bypass',
  'Byway',
  'Causeway',
  'Centre',
  'Centreway',
  'Chase',
  'Circle',
  'Circlet',
  'Circuit',
  'Circus',
  'Close',
  'Colonnade',
  'Common',
  'Concourse',
  'Copse',
  'Corner',
  'Corso',
  'Court',
  'Courtyard',
  'Cove',
  'Crescent',
  'Crest',
  'Cross',
  'Crossing',
  'Crossroad',
  'Crossway',
  'Cruiseway',
  'Cul-De-Sac',
  'Cutting',
  'Dale',
  'Dell',
  'Deviation',
  'Dip',
  'Distributor',
  'Drive',
  'Driveway',
  'Edge',
  'Elbow',
  'End',
  'Entrance',
  'Esplanade',
  'Estate',
  'Expressway',
  'Extension',
  'Fairway',
  'Fire Track',
  'Firetrail',
  'Flat',
  'Follow',
  'Footway',
  'Foreshore',
  'Formation',
  'Freeway',
  'Front',
  'Frontage',
  'Gap',
  'Gardens',
  'Gates',
  'Glade',
  'Glen',
  'Grange',
  'Green',
  'Ground',
  'Grove',
  'Gully',
  'Heights',
  'Highroad',
  'Highway',
  'Hill',
  'Interchange',
  'Intersection',
  'Junction',
  'Key',
  'Landing',
  'Lane',
  'Laneway',
  'Lees',
  'Line',
  'Link',
  'Little',
  'Lookout',
  'Loop',
  'Lower',
  'Mall',
  'Meander',
  'Mew',
  'Mews',
  'Motorway',
  'Mount',
  'Nook',
  'Outlook',
  'Parade',
  'Park',
  'Parklands',
  'Parkway',
  'Part',
  'Pass',
  'Path',
  'Pathway',
  'Piazza',
  'Place',
  'Plateau',
  'Plaza',
  'Pocket',
  'Point',
  'Port',
  'Promenade',
  'Quad',
  'Quadrangle',
  'Quadrant',
  'Quays',
  'Ramble',
  'Ramp',
  'Range',
  'Reach',
  'Reserve',
  'Rest',
  'Retreat',
  'Ride',
  'Ridge',
  'Ridgeway',
  'Right Of Way',
  'Ring',
  'Rise',
  'River',
  'Riverway',
  'Riviera',
  'Road',
  'Roads',
  'Roadside',
  'Roadway',
  'Ronde',
  'Rosebowl',
  'Rotary',
  'Round',
  'Route',
  'Row',
  'Rue',
  'Run',
  'Service Way',
  'Siding',
  'Slope',
  'Sound',
  'Spur',
  'Square',
  'Stairs',
  'State Highway',
  'Steps',
  'Strand',
  'Street',
  'Strip',
  'Subway',
  'Tarn',
  'Terrace',
  'Thoroughfare',
  'Tollway',
  'Top',
  'Tor',
  'Towers',
  'Track',
  'Trail',
  'Trailer',
  'Triangle',
  'Trunkway',
  'Turn',
  'Underpass',
  'Upper',
  'Vale',
  'Viaduct',
  'View',
  'Villas',
  'Vista',
  'Wade',
  'Walk',
  'Walkway',
  'Way',
  'Wharf',
  'Wynd',
  'Yard'
];
