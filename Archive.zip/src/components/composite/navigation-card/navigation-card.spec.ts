import { newSpecPage } from '@stencil/core/testing';
import { NavigationCardComponent } from './navigation-card';

describe('navigation-card', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [NavigationCardComponent],
      html: `<agl-ds-navigation-card heading="Dummy heading" description="Dummy description." image-path="../../../assets/man-with-mobile.svg" url="http://www.agl.com.au"></agl-ds-navigation-card>
      `
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-navigation-card description="Dummy description." heading="Dummy heading" image-path="../../../assets/man-with-mobile.svg" url="http://www.agl.com.au">
      <mock:shadow-root>
        <a class="navigation-card" href="http://www.agl.com.au">
          <div class="navigation-card__image">
            <img aria-hidden="true" src="../../../assets/man-with-mobile.svg">
          </div>
          <div class="navigation-card__details-container">
          <agl-ds-h2 appearance="highlight" styledas="title5" bottommargin="space02" >
              Dummy heading
            </agl-ds-h2>
            <agl-ds-p  bottom-margin="none" styledas="sm">
              Dummy description.
            </agl-ds-p>
          </div>
          <div class="navigation-card__arrow">
            <agl-ds-icon icon="svg contents from: src/assets/agl_ficon_dig_chevron_right.svg" size="sm"></agl-ds-icon>
          </div>
        </a>
      </mock:shadow-root>
    </agl-ds-navigation-card>
    `);
  });
});
