import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Navigation Card'
};

export const NavigationCard = () => html`
  <agl-ds-navigation-card
    heading="${text('Heading text', "I'm a new customer")}"
    description="${text('Description text', 'Join AGL and enjoy exclusive offers as a new customer.')}"
    image-path="${select('path for image', ['../../assets/man-with-mobile.svg', ''], '../../assets/man-with-mobile.svg')}"
    url="http://www.agl.com.au"
  >
  </agl-ds-navigation-card>
`;

NavigationCard.storyName = 'navigation card';
NavigationCard.parameters = { notes };
