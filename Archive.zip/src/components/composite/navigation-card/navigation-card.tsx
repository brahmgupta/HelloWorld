import { Component, Host, h, Prop, ComponentInterface } from '@stencil/core';
import chevronRightIcon from '../../../assets/agl_ficon_dig_chevron_right.svg';
import { hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';

@Component({
  tag: 'agl-ds-navigation-card',
  styleUrl: 'navigation-card.scss',
  shadow: true
})
export class NavigationCardComponent implements ComponentInterface {
  /**
   * The heading for the navigation card
   */
  @Prop() heading: string = '';

  /**
   * The description for the navigation card
   */
  @Prop() description: string = '';

  /**
   * The image path for the navigation card
   */
  @Prop() imagePath: string = '';

  /**
   * The destination url for the navigation card click
   */
  @Prop() url: string = '';

  async componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);
  }

  private inputElement: HTMLAnchorElement;

  render() {
    const imageSection =
      this.imagePath !== '' ? (
        <div class="navigation-card__image">
          <img aria-hidden="true" src={this.imagePath}></img>
        </div>
      ) : (
        ''
      );

    return (
      <Host>
        <a class="navigation-card" href={this.url} ref={(el) => (this.inputElement = el)}>
          {imageSection}
          <div class="navigation-card__details-container">
            <agl-ds-h2 styledAs="title5" appearance="highlight" bottomMargin="space02">
              {this.heading}
            </agl-ds-h2>
            <agl-ds-p styledAs="sm" bottom-margin="none">
              {this.description}
            </agl-ds-p>
          </div>
          <div class="navigation-card__arrow">
            <agl-ds-icon icon={chevronRightIcon} size="sm"></agl-ds-icon>
          </div>
        </a>
      </Host>
    );
  }
}
