# agl-ds-navigation-card



<!-- Auto Generated Below -->


## Properties

| Property      | Attribute     | Description                                       | Type     | Default |
| ------------- | ------------- | ------------------------------------------------- | -------- | ------- |
| `description` | `description` | The description for the navigation card           | `string` | `''`    |
| `heading`     | `heading`     | The heading for the navigation card               | `string` | `''`    |
| `imagePath`   | `image-path`  | The image path for the navigation card            | `string` | `''`    |
| `url`         | `url`         | The destination url for the navigation card click | `string` | `''`    |


## Dependencies

### Depends on

- [agl-ds-h2](../../core/heading/h2)
- [agl-ds-p](../../core/paragraph)
- [agl-ds-icon](../../core/icon)

### Graph
```mermaid
graph TD;
  agl-ds-navigation-card --> agl-ds-h2
  agl-ds-navigation-card --> agl-ds-p
  agl-ds-navigation-card --> agl-ds-icon
  style agl-ds-navigation-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
