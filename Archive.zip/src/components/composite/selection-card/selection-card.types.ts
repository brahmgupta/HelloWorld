import { CheckboxChangeEventDetail } from '../../core/checkboxes/checkbox/checkbox.types';

export type SelectionCardType = 'basic' | 'agl_icon_dig_elec' | 'agl_icon_dig_gas';

export interface SelectionCardChangeEventDetail extends CheckboxChangeEventDetail {
  groupName: string;
}
