import { newSpecPage } from '@stencil/core/testing';
import { CheckboxComponent } from '../../../core/checkboxes/checkbox/checkbox.component';
import { SelectionCardComponent } from '../selection-card.component';
import { SelectionCardGroupComponent } from './selection-card-group.component';
import * as utils from './../../../../global/utils/utils';

describe('selection-card-group', () => {
  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllTimers();
  });
  it('should render selection card group component with slot content', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [SelectionCardGroupComponent, SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card-group
      id="group-id"
      group-name="group-1"
      styled-as="title3"
      heading="Add Carbon Neutral (electricity)"
      sub-heading="Sub heading as an attribute"
      validation-text="This is validation error text"
    >
      <agl-ds-selection-card heading="Heading without icon" type="agl_icon_dig_elec" value="elec" group-name="group-1">
        <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
        <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>
      <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas" group-name="group-1">
      </agl-ds-selection-card>
    </agl-ds-selection-card-group>`,
      supportsShadowDom: true
    });
    expect(page.root)
      .toEqualHtml(`<agl-ds-selection-card-group group-name="group-1" heading="Add Carbon Neutral (electricity)" id="group-id" styled-as="title3" sub-heading="Sub heading as an attribute" validation-text="This is validation error text">
          <mock:shadow-root>
            <agl-ds-form-field-label heading="Add Carbon Neutral (electricity)" styledas="title3">
              <span slot="sub-heading">
                Sub heading as an attribute
              </span>
              <slot></slot>
            </agl-ds-form-field-label>
            <div>
              <agl-ds-hint-validation-message asdescribedbyid="111" class="default-selection-card-validation-message">
                <div slot="validation-text">
                  This is validation error text
                </div>
              </agl-ds-hint-validation-message>
            </div>
          </mock:shadow-root>
          <agl-ds-selection-card group-name="group-1" heading="Heading without icon" type="agl_icon_dig_elec" value="elec">
            <mock:shadow-root>
              <div class="icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_elec_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="elec">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Heading without icon
                        </span>
                        <agl-ds-spacer size="space01"></agl-ds-spacer>
                        <span class="selection-card__subtext-container">
                          <slot></slot>
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
            <agl-ds-text bottom-margin="none" font-weight="semibold" styled-as="lg">
              $1.00
            </agl-ds-text>
            <agl-ds-text bottom-margin="none" styled-as="xs">
              a&nbsp;week (GST&nbsp;Incl.)
            </agl-ds-text>
          </agl-ds-selection-card>
          <agl-ds-selection-card group-name="group-1" heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas">
            <mock:shadow-root>
              <div class="icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_gas_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="gas">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Add Carbon Neutral (electricity)
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
          </agl-ds-selection-card>
        </agl-ds-selection-card-group>`);
  });

  it('should select selection card based on given selected value', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [SelectionCardGroupComponent, SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card-group
      id="group-id"
      selected-value="['elec']"
      group-name="group-1"
      styled-as="title3"
      heading="Add Carbon Neutral (electricity)"
      sub-heading="Sub heading as an attribute"
      validation-text="This is validation error text"
    >
      <agl-ds-selection-card heading="Heading without icon" type="agl_icon_dig_elec" value="elec" group-name="group-1">
        <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
        <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>
      <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas" group-name="group-1">
      </agl-ds-selection-card>
    </agl-ds-selection-card-group>`
    });
    expect(page.root)
      .toEqualHtml(`<agl-ds-selection-card-group group-name="group-1" heading="Add Carbon Neutral (electricity)" id="group-id" selected-value="['elec']" styled-as="title3" sub-heading="Sub heading as an attribute" validation-text="This is validation error text">
          <mock:shadow-root>
            <agl-ds-form-field-label heading="Add Carbon Neutral (electricity)" styledas="title3">
              <span slot="sub-heading">
                Sub heading as an attribute
              </span>
              <slot></slot>
            </agl-ds-form-field-label>
            <div>
              <agl-ds-hint-validation-message asdescribedbyid="111" class="default-selection-card-validation-message">
                <div slot="validation-text">
                  This is validation error text
                </div>
              </agl-ds-hint-validation-message>
            </div>
          </mock:shadow-root>
          <agl-ds-selection-card group-name="group-1" heading="Heading without icon" type="agl_icon_dig_elec" value="elec">
            <mock:shadow-root>
              <div class="checked icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_elec_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox checked icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" checked="" id="111" tabindex="0" type="checkbox" value="elec">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Heading without icon
                        </span>
                        <agl-ds-spacer size="space01"></agl-ds-spacer>
                        <span class="selection-card__subtext-container">
                          <slot></slot>
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
            <agl-ds-text bottom-margin="none" font-weight="semibold" styled-as="lg">
              $1.00
            </agl-ds-text>
            <agl-ds-text bottom-margin="none" styled-as="xs">
              a&nbsp;week (GST&nbsp;Incl.)
            </agl-ds-text>
          </agl-ds-selection-card>
          <agl-ds-selection-card group-name="group-1" heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas">
            <mock:shadow-root>
              <div class="icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_gas_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="gas">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Add Carbon Neutral (electricity)
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
          </agl-ds-selection-card>
        </agl-ds-selection-card-group>`);
    expect(page.root.selectedValue).toEqual(['elec']);
  });

  it('should display validation error on haserror set', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [SelectionCardGroupComponent, SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card-group
      id="group-id"
      group-name="group-1"
      styled-as="title3"
      has-error="true"
      heading="Add Carbon Neutral (electricity)"
      sub-heading="Sub heading as an attribute"
      validation-text="This is validation error text"
    >
      <agl-ds-selection-card heading="Heading without icon" type="agl_icon_dig_elec" value="elec" group-name="group-1">
        <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
        <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>
      <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas" group-name="group-1">
      </agl-ds-selection-card>
    </agl-ds-selection-card-group>`,
      supportsShadowDom: true
    });
    expect(page.root)
      .toEqualHtml(`<agl-ds-selection-card-group group-name="group-1"  has-error="true" heading="Add Carbon Neutral (electricity)" id="group-id" styled-as="title3" sub-heading="Sub heading as an attribute" validation-text="This is validation error text">
          <mock:shadow-root>
            <agl-ds-form-field-label heading="Add Carbon Neutral (electricity)" styledas="title3">
              <span slot="sub-heading">
                Sub heading as an attribute
              </span>
              <slot></slot>
            </agl-ds-form-field-label>
            <div>
              <agl-ds-hint-validation-message asdescribedbyid="111" class="default-selection-card-validation-message"  has-error="">
                <div slot="validation-text">
                  This is validation error text
                </div>
              </agl-ds-hint-validation-message>
            </div>
          </mock:shadow-root>
          <agl-ds-selection-card group-name="group-1" heading="Heading without icon" type="agl_icon_dig_elec" value="elec">
            <mock:shadow-root>
              <div class="error icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_elec_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox error icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="elec">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Heading without icon
                        </span>
                        <agl-ds-spacer size="space01"></agl-ds-spacer>
                        <span class="selection-card__subtext-container">
                          <slot></slot>
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
            <agl-ds-text bottom-margin="none" font-weight="semibold" styled-as="lg">
              $1.00
            </agl-ds-text>
            <agl-ds-text bottom-margin="none" styled-as="xs">
              a&nbsp;week (GST&nbsp;Incl.)
            </agl-ds-text>
          </agl-ds-selection-card>
          <agl-ds-selection-card group-name="group-1" heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas">
            <mock:shadow-root>
              <div class="error icon selection-card">
                <span aria-hidden="true" class="large-svg">
                  svg contents from: src/assets/agl_icon_dig_gas_32px.svg
                </span>
                <agl-ds-checkbox class="selection-card__checkbox">
                  <div class="checkbox error icon selection-card__checkbox">
                    <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="gas">
                    <label htmlfor="111" id="label111">
                      <span class="selection-card__container">
                        <span class="selection-card__text-container">
                          Add Carbon Neutral (electricity)
                        </span>
                      </span>
                    </label>
                  </div>
                </agl-ds-checkbox>
              </div>
            </mock:shadow-root>
          </agl-ds-selection-card>
        </agl-ds-selection-card-group>`);
  });

  it('should console.error when invalid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SelectionCardGroupComponent, SelectionCardComponent, CheckboxComponent],
      html: `
      <agl-ds-selection-card-group
      id="group-id"
      group-name="group-1"
      styled-as="title3"
      heading="Add Carbon Neutral (electricity)"
      sub-heading="Sub heading as an attribute"
      validation-text="This is validation error text"
    >
      <agl-ds-p styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-p>
      <agl-ds-p styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-p>
    </agl-ds-selection-card-group>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalled();
  });
  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SelectionCardGroupComponent, SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card-group
      id="group-id"
      group-name="group-1"
      styled-as="title3"
      has-error="true"
      heading="Add Carbon Neutral (electricity)"
      sub-heading="Sub heading as an attribute"
    >
      <agl-ds-selection-card heading="Heading without icon" type="agl_icon_dig_elec" value="elec" group-name="group-1">
        <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
        <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>
      <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas" group-name="group-1">
      </agl-ds-selection-card>
    </agl-ds-selection-card-group>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });
});
