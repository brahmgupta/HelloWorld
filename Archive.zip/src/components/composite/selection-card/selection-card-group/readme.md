# agl-ds-selection-card-group



<!-- Auto Generated Below -->


## Properties

| Property           | Attribute            | Description                                                                                                                                                                                                                                                      | Type                   | Default                  |
| ------------------ | -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ------------------------ |
| `groupName`        | `group-name`         | Group name for the selection group                                                                                                                                                                                                                               | `string`               | `undefined`              |
| `hasError`         | `has-error`          | Shows the selection cards in the group in an error state                                                                                                                                                                                                         | `boolean`              | `false`                  |
| `heading`          | `heading`            | The legend/heading for the selection card group                                                                                                                                                                                                                  | `string`               | `undefined`              |
| `selectedValue`    | `selected-value`     | Sets the default value of the selection group                                                                                                                                                                                                                    | `string \| string[]`   | `undefined`              |
| `selectionGroupId` | `selection-group-id` | Unique ID for the selection group                                                                                                                                                                                                                                | `string`               | `generateRandomNumber()` |
| `styledAs`         | `styled-as`          | Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present.                                                                                         | `"title3" \| "title5"` | `'title5'`               |
| `subHeading`       | `sub-heading`        | The sub heading for the selection card group. There is also a slot which can be used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading | `string`               | `undefined`              |
| `validationText`   | `validation-text`    | The validation/ error text for the selection card group                                                                                                                                                                                                          | `string`               | `null`                   |


## Events

| Event         | Description                   | Type               |
| ------------- | ----------------------------- | ------------------ |
| `valueChange` | Selection value changed event | `CustomEvent<any>` |


## Slots

| Slot            | Description                                                                                                                                                 |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"default"`     | The content placed in this slot must be a agl-ds-selection-card.<br>The selection-card-group is to be used as a wrapper around a selection-card.            |
| `"sub-heading"` | Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading |


## Dependencies

### Depends on

- [agl-ds-form-field-label](../../../core/form-field-label)
- [agl-ds-hint-validation-message](../../../core/hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-selection-card-group --> agl-ds-form-field-label
  agl-ds-selection-card-group --> agl-ds-hint-validation-message
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-text
  style agl-ds-selection-card-group fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
