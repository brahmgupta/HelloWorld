import { Component, h, Host, Prop, Element, Watch, Listen, EventEmitter, Event, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, getSiblings } from '../../../../global/utils/utils';
import { FormFieldTitleType } from '../../../core/form-field-label/form-field-label.types';
import { SelectionCardChangeEventDetail } from '../selection-card.types';
/**
 * @slot sub-heading - Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading
 * @slot default - The content placed in this slot must be a agl-ds-selection-card.<br>The selection-card-group is to be used as a wrapper around a selection-card.
 */

@Component({
  tag: 'agl-ds-selection-card-group',
  styleUrl: 'selection-card-group.component.scss',
  shadow: true
})
export class SelectionCardGroupComponent implements ComponentInterface {
  @Element() host: HTMLAglDsSelectionCardGroupElement;

  /**
   *  Unique ID for the selection group
   */
  @Prop() selectionGroupId: string = generateRandomNumber();

  /**
   * The legend/heading for the selection card group
   */
  @Prop() heading: string;

  /**
   * The sub heading for the selection card group. There is also a slot which can be used for the inclusion of Phrasing content
   * (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading
   */
  @Prop() subHeading: string;

  /**
   * Group name for the selection group
   */
  @Prop() groupName: string;

  /**
   * The validation/ error text for the selection card group
   */
  @Prop() validationText: string = null;

  /**
   * Shows the selection cards in the group in an error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Sets the default value of the selection group
   */
  @Prop({ mutable: true }) selectedValue: string[] | string;

  /**
   * Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present.
   */
  @Prop() styledAs: FormFieldTitleType = 'title5';

  /**
   * Selection value changed event
   */
  @Event({ bubbles: false }) valueChange: EventEmitter;
  private _selectionCards: HTMLAglDsSelectionCardElement[];
  @Listen('selectionCardChange')
  dsCheckedChangeHandler(event: CustomEvent) {
    const eventDetail: SelectionCardChangeEventDetail = event.detail;
    // check to make sure that its the correct event that is being listened to
    if (eventDetail.groupName === this.groupName) {
      this.selectedValue = this.selectedValue || [];
      this.selectedValue = eventDetail.checked
        ? this.selectedValue.concat(eventDetail.value)
        : (this.selectedValue as string[]).filter((value) => value != eventDetail.value); //needs to be set for ngmodel and formcontrolname
      this.valueChange.emit(this.selectedValue); // emit the value for the valuechange event
    }
  }

  @Watch('selectedValue')
  selectedValueChanged(newValue: string[] | string) {
    if (typeof newValue === 'string') {
      if (newValue.length > 0) {
        this.selectedValue = JSON.parse(newValue.replace(/'/g, '"'));
        this._selectionCards.forEach((selectionCard) => {
          selectionCard.checked = !!(this.selectedValue as string[]).find((i) => i === selectionCard.value);
        });
      }
    }
  }

  @Watch('hasError')
  addError(hasError: boolean) {
    [...this._selectionCards].forEach((card) => (card.hasError = hasError));
  }

  componentDidLoad() {
    this.addError(this.hasError);
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-selection-card-group', 'agl-ds-selection-card']);
    this._selectionCards = this.host.querySelector('agl-ds-selection-card')
      ? [...getSiblings(this.host.querySelector('agl-ds-selection-card'))]
      : [];
    this.selectedValueChanged(this.selectedValue);
  }

  private renderSubHeading() {
    if (this.subHeading?.length > 0 || this.host.querySelector('[slot="sub-heading"]')?.innerHTML.length > 0) {
      return <span slot="sub-heading">{this.subHeading ? this.subHeading : <slot name="sub-heading" />}</span>;
    }
    return '';
  }

  render() {
    return (
      <Host>
        <agl-ds-form-field-label heading={this.heading} styledAs={this.styledAs}>
          {this.renderSubHeading()}
          <slot />
        </agl-ds-form-field-label>
        {this.validationText && (
          <div>
            <agl-ds-hint-validation-message
              class="default-selection-card-validation-message"
              asDescribedbyId={this.selectionGroupId}
              has-error={this.hasError}
            >
              <div slot="validation-text">{this.validationText}</div>
            </agl-ds-hint-validation-message>
          </div>
        )}
      </Host>
    );
  }
}
