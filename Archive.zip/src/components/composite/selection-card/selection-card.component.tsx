import { Element, Component, Host, h, Prop, EventEmitter, Event, Watch } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, resizeSVGsForEdge } from '../../../global/utils/utils';
import { CheckboxChangeEventDetail } from '../../core/checkboxes/checkbox/checkbox.types';
import elecIcon from '../../../assets/agl_icon_dig_elec_32px.svg';
import gasIcon from '../../../assets/agl_icon_dig_gas_32px.svg';
import { SelectionCardChangeEventDetail, SelectionCardType } from './selection-card.types';
/**
 * @slot - default slot content appears to the right of the card next to the checkbox
 */
@Component({
  tag: 'agl-ds-selection-card',
  styleUrl: 'selection-card.component.scss',
  shadow: true
})
export class SelectionCardComponent {
  private aglDsCheckbox: HTMLAglDsCheckboxElement;
  private isIconType: boolean;
  private hasSlot: boolean;
  private svgSpan: HTMLSpanElement;
  @Element() host: HTMLAglDsSelectionCardElement;
  /**
   * internalised Unique ID for the binding Accordion button to its panel
   */
  private uniqueID: string = generateRandomNumber();

  /**
   * The heading for the selection card
   */
  @Prop() heading: string = '';

  /**
   * The checked value for the selection card
   */
  @Prop({ mutable: true }) checked: boolean = false;

  /**
   * The error for the selection card
   */
  @Prop() hasError: boolean = false;

  /**
   * The Suppress Margin value for the card
   */
  @Prop() suppressMargin: boolean = false;

  /**
   * The value for the selection card
   */
  @Prop() value: string = '';

  /**
   * The Group Name for the selection card
   */
  @Prop() groupName: string = '';

  /**
   * The type of selection card to be displayed
   */
  @Prop({ reflect: true }) type: SelectionCardType = 'basic';

  /**
   * SelectionCard changed event
   */
  @Event() selectionCardChange: EventEmitter<SelectionCardChangeEventDetail>;

  /**
   * @deprecated checkboxChange changed event for backward compatibility,
   * Use selectionCardChange going forward
   */
  @Event() checkboxChange: EventEmitter<CheckboxChangeEventDetail>;

  private onCheckboxStateChange(details: CheckboxChangeEventDetail): void {
    this.checked = details.checked;
    this.selectionCardChange.emit({ value: this.value, checked: this.checked, groupName: this.groupName });
    this.checkboxChange.emit({ value: this.value, checked: this.checked });
  }

  componentDidLoad() {
    const checkbox = this.host.shadowRoot?.querySelector('agl-ds-checkbox');
    if (this.isIconType) {
      resizeSVGsForEdge(this.svgSpan, '32', '32', '48', '48');
    }
    this.aglDsCheckbox = checkbox?.querySelector('.checkbox');
    this.addCheckedToCheckbox(this.checked);
    this.addErrorToCheckbox(this.hasError);
    this.updateClass('icon', this.isIconType);
    this.updateClass('selection-card__checkbox', true);
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-selection-card', 'agl-ds-text', 'span']);
    this.isIconType = this.type.indexOf('icon') >= 0;
    this.hasSlot = this.host.children?.length > 0;
  }

  @Watch('checked')
  addCheckedToCheckbox(checked: boolean) {
    checked ? this.updateClass('checked') : this.updateClass('checked', false);
  }

  @Watch('hasError')
  addErrorToCheckbox(hasError: boolean) {
    hasError ? this.updateClass('error') : this.updateClass('error', false);
  }

  private updateClass(className: string, add: boolean = true) {
    add ? this.aglDsCheckbox?.classList.add(className) : this.aglDsCheckbox?.classList.remove(className);
  }

  private getIcon(): string {
    switch (this.type) {
      case 'agl_icon_dig_elec':
        return elecIcon;
      case 'agl_icon_dig_gas':
        return gasIcon;
      default:
        throw new Error(this.type + ' is not a valid selecton card type');
    }
  }

  render() {
    return (
      <Host>
        <div
          class={{
            'selection-card': true,
            checked: this.checked,
            icon: this.isIconType,
            error: this.hasError,
            'suppress-margin': this.suppressMargin
          }}
        >
          {this.isIconType ? (
            <span class="large-svg" ref={(el) => (this.svgSpan = el)} aria-hidden="true" innerHTML={this.getIcon()} />
          ) : null}
          <agl-ds-checkbox
            class="selection-card__checkbox"
            checkboxId={this.uniqueID}
            checked={this.checked}
            value={this.value}
            onCheckedChange={(event: CustomEvent<CheckboxChangeEventDetail>) => this.onCheckboxStateChange(event.detail)}
          >
            <span class="selection-card__container">
              <span class="selection-card__text-container">{this.heading}</span>
              {this.hasSlot ? <agl-ds-spacer size="space01"></agl-ds-spacer> : ''}
              {this.hasSlot ? (
                <span class="selection-card__subtext-container">
                  <slot />
                </span>
              ) : (
                ''
              )}
            </span>
          </agl-ds-checkbox>
        </div>
      </Host>
    );
  }
}
