import { boolean, select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Selection Card'
};

export const SelectionCard = () => html`
  <agl-ds-selection-card
    heading="${text('Heading text', 'Add Carbon Neutral (electricity)')}"
    checked="${boolean('Option checked (only first)', true)}"
    suppress-margin="${boolean('Suppress margin bottom (only first)', false)}"
    type="agl_icon_dig_elec"
    value="some value"
  >
    ${html([
      text(
        'slot content (first)',
        `<agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
       <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>`
      )
    ])}
  </agl-ds-selection-card>
  <agl-ds-selection-card heading="Add Carbon Neutral" checked="false" value="carbon">
    ${html([
      text(
        'slot content (second)',
        `<agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
       <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>`
      )
    ])}
  </agl-ds-selection-card>
  <agl-ds-selection-card
    heading="Add Carbon Neutral (electricity)"
    has-error="${boolean('Toggle Error (third option) ', true)}"
    checked="false"
    type="agl_icon_dig_elec"
    value="gas"
  >
  </agl-ds-selection-card>
  <agl-ds-selection-card heading="Heading without icon" value="gas"> </agl-ds-selection-card>
`;

SelectionCard.storyName = 'selection card';
SelectionCard.parameters = { notes };

export const SelectionCardGroup = () => html`
  <agl-ds-selection-card-group
    id="group-id"
    selected-value="${select('default selected', ['["elec"]', '["elec", "gas"]', '[]'], '["elec"]')}"
    group-name="group-1"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    heading="${text('Heading text', 'Add Carbon Neutral (electricity)')}"
    sub-heading="${text('Sub heading text', 'Sub heading as an attribute')}"
    validation-text="${text('Validation text', 'This is validation error text')}"
  >
    <agl-ds-selection-card heading="Heading without icon" type="agl_icon_dig_elec" value="elec" group-name="group-1">
      <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
      <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
    </agl-ds-selection-card>
    <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" type="agl_icon_dig_gas" value="gas" group-name="group-1">
    </agl-ds-selection-card>
  </agl-ds-selection-card-group>
  <br />
  <label><input type="checkbox" onClick="document.getElementById('group-id').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br /><br />
  <label>Group value: <span id="groupValue"></span></label>
  <br /><br/ >
  <button onClick="document.getElementById('groupValue').innerHTML = String(document.getElementById('group-id').selectedValue)">
    Show current group value
  </button>
`;

SelectionCardGroup.storyName = 'selection group';
SelectionCardGroup.parameters = { notes };
