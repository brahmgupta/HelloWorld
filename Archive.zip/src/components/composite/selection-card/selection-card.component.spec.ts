import { newSpecPage } from '@stencil/core/testing';
import * as utils from '../../../global/utils/utils';
import { CheckboxComponent } from '../../core/checkboxes/checkbox/checkbox.component';
import { SelectionCardComponent } from './selection-card.component';

describe('selection-card', () => {
  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllTimers();
  });
  it('should render selection card component with slot content', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [SelectionCardComponent],
      html: `<agl-ds-selection-card heading="Dummy heading" checked=false>
      <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
      <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>`
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-selection-card checked="false" heading="Dummy heading" type="basic">
    <mock:shadow-root>
        <div class="selection-card">
           <agl-ds-checkbox checkboxid="111" class="selection-card__checkbox" value="">
            <span class="selection-card__container">
              <span class="selection-card__text-container">
                Dummy heading
              </span>
              <agl-ds-spacer size="space01"></agl-ds-spacer>
              <span class="selection-card__subtext-container">
                <slot></slot>
              </span>
            </span>
          </agl-ds-checkbox>
         </div>
       </mock:shadow-root>
       <agl-ds-text bottom-margin="none" font-weight="semibold" styled-as="lg">
       $1.00
       </agl-ds-text>
       <agl-ds-text bottom-margin="none" styled-as="xs">
       a&nbsp;week (GST&nbsp;Incl.)
       </agl-ds-text>
    </agl-ds-selection-card> 
    `);
  });

  it('should render selection card component without slot content', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');

    const page = await newSpecPage({
      components: [SelectionCardComponent],
      html: `<agl-ds-selection-card heading="Heading without icon" value="gas"></agl-ds-selection-card>`
    });

    expect(page.root).toEqualHtml(`<agl-ds-selection-card heading="Heading without icon" type="basic" value="gas">
    <mock:shadow-root>
      <div class="selection-card">
        <agl-ds-checkbox checkboxid="111" class="selection-card__checkbox" value="gas">
          <span class="selection-card__container">
            <span class="selection-card__text-container">
              Heading without icon
            </span>
          </span>
        </agl-ds-checkbox>
       </div>
       </mock:shadow-root>
     </agl-ds-selection-card>`);
  });

  it('should select the card if checked is set to true', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');

    const page = await newSpecPage({
      components: [SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card heading="Heading without icon" checked="true" value="gas"></agl-ds-selection-card>`,
      supportsShadowDom: true
    });

    expect(page.root).toEqualHtml(`<agl-ds-selection-card checked="true" heading="Heading without icon" type="basic" value="gas">
    <mock:shadow-root>
      <div class="checked selection-card">
        <agl-ds-checkbox class="selection-card__checkbox">
          <div class="checkbox checked selection-card__checkbox">
            <input aria-describedby="" aria-invalid="false" checked="" id="111" tabindex="0" type="checkbox" value="gas">
            <label htmlfor="111" id="label111">
              <span class="selection-card__container">
                <span class="selection-card__text-container">
                  Heading without icon
                </span>
              </span>
            </label>
          </div>
        </agl-ds-checkbox>
       </div>
       </mock:shadow-root>
     </agl-ds-selection-card>`);

    const checkboxInput = page.root.shadowRoot.querySelector('agl-ds-checkbox').querySelector('input');
    expect(checkboxInput.checked).toBeTruthy();
  });

  it('should show error if hasError is set to true', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');

    const page = await newSpecPage({
      components: [SelectionCardComponent, CheckboxComponent],
      html: `<agl-ds-selection-card heading="Heading without icon" has-error="true" value="gas"></agl-ds-selection-card>`
    });

    expect(page.root).toEqualHtml(`<agl-ds-selection-card has-error="true" heading="Heading without icon" type="basic" value="gas">
    <mock:shadow-root>
      <div class="error selection-card">
      <agl-ds-checkbox class="selection-card__checkbox">
        <div class="checkbox error selection-card__checkbox">
          <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="gas">
          <label htmlfor="111" id="label111">
            <span class="selection-card__container">
              <span class="selection-card__text-container">
                Heading without icon
              </span>
            </span>
          </label>
        </div>
      </agl-ds-checkbox>
    </div>
       </mock:shadow-root>
     </agl-ds-selection-card>`);
  });

  it('should display icon if icon type is provided', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');

    const page = await newSpecPage({
      components: [SelectionCardComponent],
      html: `<agl-ds-selection-card heading="Heading with icon" type="agl_icon_dig_elec" value="gas"></agl-ds-selection-card>`
    });

    expect(page.root).toEqualHtml(`<agl-ds-selection-card heading="Heading with icon" type="agl_icon_dig_elec" value="gas">
    <mock:shadow-root>
      <div class="icon selection-card">
        <span aria-hidden="true" class="large-svg">
          svg contents from: src/assets/agl_icon_dig_elec_32px.svg
        </span>
        <agl-ds-checkbox checkboxid="111" class="selection-card__checkbox" value="gas">
          <span class="selection-card__container">
            <span class="selection-card__text-container">
              Heading with icon
            </span>
          </span>
        </agl-ds-checkbox>
       </div>
       </mock:shadow-root>
     </agl-ds-selection-card>`);
  });

  it('should console.error when invalid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SelectionCardComponent],
      html: `
      <agl-ds-selection-card heading="Dummy heading" checked=false>
      <agl-ds-p styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-p>
      <agl-ds-p styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-p>
      </agl-ds-selection-card>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalled();
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SelectionCardComponent],
      html: `
      <agl-ds-selection-card heading="Dummy heading" checked=false>
      <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
      <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
      </agl-ds-selection-card>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should add "checked" class to checkbox-component', async () => {
    const page = await newSpecPage({
      components: [SelectionCardComponent, CheckboxComponent],
      html: `
      <agl-ds-selection-card heading="Dummy heading" checked=true>
      </agl-ds-selection-card>
      `,
      supportsShadowDom: true
    });
    const selectionCardChangeSpy = jest.fn();
    page.doc.addEventListener('selectionCardChange', selectionCardChangeSpy);
    const checkbox = page.root.shadowRoot.querySelector('agl-ds-checkbox').querySelector('.checkbox');
    expect(checkbox.className).toContain('checked');
  });

  it('should add "error" class to checkbox-component', async () => {
    const page = await newSpecPage({
      components: [SelectionCardComponent, CheckboxComponent],
      html: `
      <agl-ds-selection-card heading="Dummy heading" has-error=true>
      </agl-ds-selection-card>
      `,
      supportsShadowDom: true
    });
    const selectionCardChangeSpy = jest.fn();
    page.doc.addEventListener('selectionCardChange', selectionCardChangeSpy);
    const checkbox = page.root.shadowRoot.querySelector('agl-ds-checkbox').querySelector('.checkbox');
    expect(checkbox.className).toContain('error');
  });
});
