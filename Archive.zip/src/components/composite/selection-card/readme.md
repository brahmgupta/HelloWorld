# agl-ds-selection



<!-- Auto Generated Below -->


## Properties

| Property         | Attribute         | Description                                | Type                                                   | Default   |
| ---------------- | ----------------- | ------------------------------------------ | ------------------------------------------------------ | --------- |
| `checked`        | `checked`         | The checked value for the selection card   | `boolean`                                              | `false`   |
| `groupName`      | `group-name`      | The Group Name for the selection card      | `string`                                               | `''`      |
| `hasError`       | `has-error`       | The error for the selection card           | `boolean`                                              | `false`   |
| `heading`        | `heading`         | The heading for the selection card         | `string`                                               | `''`      |
| `suppressMargin` | `suppress-margin` | The Suppress Margin value for the card     | `boolean`                                              | `false`   |
| `type`           | `type`            | The type of selection card to be displayed | `"agl_icon_dig_elec" \| "agl_icon_dig_gas" \| "basic"` | `'basic'` |
| `value`          | `value`           | The value for the selection card           | `string`                                               | `''`      |


## Events

| Event                 | Description                                                                                                                                              | Type                                          |
| --------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------- |
| `checkboxChange`      | <span style="color:red">**[DEPRECATED]**</span> checkboxChange changed event for backward compatibility, Use selectionCardChange going forward<br/><br/> | `CustomEvent<CheckboxChangeEventDetail>`      |
| `selectionCardChange` | SelectionCard changed event                                                                                                                              | `CustomEvent<SelectionCardChangeEventDetail>` |


## Slots

| Slot | Description                                                                |
| ---- | -------------------------------------------------------------------------- |
|      | default slot content appears to the right of the card next to the checkbox |


## Dependencies

### Depends on

- [agl-ds-checkbox](../../core/checkboxes/checkbox)
- [agl-ds-spacer](../../core/spacer)

### Graph
```mermaid
graph TD;
  agl-ds-selection-card --> agl-ds-checkbox
  agl-ds-selection-card --> agl-ds-spacer
  agl-ds-checkbox --> agl-ds-hint-validation-message
  style agl-ds-selection-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
