# agl-ds-autocomplete



<!-- Auto Generated Below -->


## Properties

| Property                | Attribute                  | Description                                                                                                                                                                                                                                                                                                                                                                                                                            | Type                                                          | Default                  |
| ----------------------- | -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- | ------------------------ |
| `autoCompleteId`        | `auto-complete-id`         | The autocomplete ID                                                                                                                                                                                                                                                                                                                                                                                                                    | `string`                                                      | `generateRandomNumber()` |
| `dropdownDirection`     | `dropdown-direction`       | The dropdown direction. Set to up when the autocomplete is at the bottom of the page.                                                                                                                                                                                                                                                                                                                                                  | `string`                                                      | `'down'`                 |
| `hasError`              | `has-error`                | Flag to show error state                                                                                                                                                                                                                                                                                                                                                                                                               | `boolean`                                                     | `false`                  |
| `hintText`              | `hint-text`                | Hint text will be shown underneath the textbox but will be hidden if there is an error                                                                                                                                                                                                                                                                                                                                                 | `string`                                                      | `undefined`              |
| `label`                 | `label`                    | The label text for the input, will be hidden if type is experiential                                                                                                                                                                                                                                                                                                                                                                   | `string`                                                      | `''`                     |
| `maxLength`             | `max-length`               | The maxlength property of the input: note max length does nothing when inputType is number as it technically not valid [link to mozilla docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/Input#attr-maxlength)                                                                                                                                                                                                          | `number`                                                      | `undefined`              |
| `minCharactersToSearch` | `min-characters-to-search` | How many characters to type before the autocomplete starts triggering                                                                                                                                                                                                                                                                                                                                                                  | `number`                                                      | `1`                      |
| `mode`                  | `mode`                     | Mode for the autocomplete uncontrolled will internally filter the options for the autocomplete, controlled will let the consumer pass in the current state and results to display                                                                                                                                                                                                                                                      | `"controlled" \| "uncontrolled"`                              | `'uncontrolled'`         |
| `options`               | --                         | Autocomplete options which can be passed in using TSX or JS e.g. document.getElementByTagName('agl-ds-autocomplete').options = [] Use either this or optionsString                                                                                                                                                                                                                                                                     | `AutoCompleteOption[]`                                        | `undefined`              |
| `optionsString`         | `options-string`           | Autocomplete options which can be passed in using a JSON string                                                                                                                                                                                                                                                                                                                                                                        | `string`                                                      | `undefined`              |
| `parentState`           | `parent-state`             | Sets the state of the autocomplete in controlled mode                                                                                                                                                                                                                                                                                                                                                                                  | `"displayResults" \| "idle" \| "loading" \| "resultSelected"` | `undefined`              |
| `placeholder`           | `placeholder`              | The placeholder property for the input, only used if type is experiential                                                                                                                                                                                                                                                                                                                                                              | `string`                                                      | `undefined`              |
| `showValidIcon`         | `show-valid-icon`          | Shows the valid icon when it equals true and validSelectionMode is set to external or onSelect                                                                                                                                                                                                                                                                                                                                         | `boolean`                                                     | `undefined`              |
| `type`                  | `type`                     | Type for the control, either default, default-inverse or experiential                                                                                                                                                                                                                                                                                                                                                                  | `"default" \| "default-inverse" \| "experiential"`            | `'default'`              |
| `validSelectionMode`    | `valid-selection-mode`     | Shows the valid icon when validSelectionMode is set to external or onSelect and showValidIcon equals true. validSelectionMode should be used when an api call regulates the visibility of the icon ie when an address is searched for by the user and the address is serviceable. onSelect should be used with a static list of options (eg street Name) where any selection is valid If set to false, valid state will never display. | `"external" \| "off" \| "onSelect"`                           | `'off'`                  |
| `validText`             | `valid-text`               | Text to show when valid. Will override the hint text if present at the bottom of the component.                                                                                                                                                                                                                                                                                                                                        | `string`                                                      | `''`                     |
| `validationText`        | `validation-text`          | Validation text to show when the has error flag is true                                                                                                                                                                                                                                                                                                                                                                                | `string`                                                      | `undefined`              |
| `value`                 | `value`                    | The value for the input                                                                                                                                                                                                                                                                                                                                                                                                                | `string`                                                      | `undefined`              |


## Events

| Event                        | Description                                                                                                                         | Type                              |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- | --------------------------------- |
| `autocompleteBlur`           | Fires when a blur event happens on either the textbox or the dropdown and the next target is not either the textbox or the dropdown | `CustomEvent<FocusEvent>`         |
| `autocompleteInput`          | Forwards the input event of the textbox input                                                                                       | `CustomEvent<InputEvent>`         |
| `autocompleteOptionSelected` | Fires when an option is selected from the dropdown                                                                                  | `CustomEvent<AutoCompleteOption>` |


## Methods

### `getTextBoxElement() => Promise<HTMLAglDsTextboxElement>`

Gets the textbox component element

#### Returns

Type: `Promise<HTMLAglDsTextboxElement>`



### `setTextBoxValue(textValue: string) => Promise<void>`

Sets the textbox component element

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-address-search](../addresssearch/address-search)
 - [agl-ds-manual-address-entry](../addresssearch/manual-address-entry)

### Depends on

- [agl-ds-text](../../core/text)
- [agl-ds-textbox](../../core/textbox)
- [agl-ds-loading-indicator](../../core/loading-indicator)

### Graph
```mermaid
graph TD;
  agl-ds-autocomplete --> agl-ds-text
  agl-ds-autocomplete --> agl-ds-textbox
  agl-ds-autocomplete --> agl-ds-loading-indicator
  agl-ds-textbox --> agl-ds-hint-validation-message
  agl-ds-address-search --> agl-ds-autocomplete
  agl-ds-manual-address-entry --> agl-ds-autocomplete
  style agl-ds-autocomplete fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
