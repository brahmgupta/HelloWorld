export interface AutoCompleteOption {
  value: string;
  text: string;
  doNotComplete?: boolean;
  highlightText?: string;
}
