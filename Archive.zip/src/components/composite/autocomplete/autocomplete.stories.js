import { select, text, boolean, number } from '@storybook/addon-knobs';
import notes from './readme.md';

export default {
  title: 'Composite/Autocomplete'
};

export const Default = () => {
  const autocomplete = document.createElement('agl-ds-autocomplete');
  autocomplete.options = [
    { value: 'Random1', text: 'Random 1' },
    { value: 'Random2', text: 'Random 2' },
    { value: 'test', text: 'test' },
    { value: 'test1', text: 'test1' },
    { value: 'testing123', text: 'testing123' },
    {
      value: 'testingautocomplete',
      text: 'testing this entry will not be prefilled',
      doNotComplete: true,
      highlightText: 'this entry will not be prefilled'
    },
    { value: 'teaser', text: 'teaser' },
    { value: 'teaser1', text: 'teaser 1' },
    { value: 'teaser2', text: 'teaser 2' },
    { value: 'teaser3', text: 'teaser 3' },
    { value: 'teaser4', text: 'teaser 4' },
    { value: 'Random3', text: 'Random 3' },
    { value: 'Random4', text: 'Random 4' },
    { value: 'Random5', text: 'Random 5' }
  ];
  autocomplete.setAttribute('label', text('label', 'type test'));
  autocomplete.setAttribute('type', select('type', ['default', 'default-inverse'], 'default'));
  autocomplete.setAttribute('has-error', boolean('has error', false));
  autocomplete.setAttribute('max-length', number('max length', 100));
  autocomplete.setAttribute('validation-text', text('validation text', 'validation text'));
  autocomplete.setAttribute('hint-text', text('hint text', 'hint text'));
  autocomplete.setAttribute('dropdown-direction', 'down');
  autocomplete.setAttribute('show-valid-icon', boolean('show valid icon', false));
  autocomplete.setAttribute('valid-selection-mode', select('valid selection mode', ['off', 'onSelect', 'external'], 'off'));
  return autocomplete;
};

Default.storyName = 'default';
Default.parameters = { notes };

export const Experiential = () => {
  const autocomplete = document.createElement('agl-ds-autocomplete');
  autocomplete.options = [
    { value: 'test', text: 'test' },
    { value: 'test1', text: 'test1' },
    { value: 'testing123', text: 'testing123' },
    { value: 'testingautocomplete', text: 'testingautocomplete' }
  ];
  autocomplete.setAttribute('placeholder', 'Type "test"');
  autocomplete.setAttribute('type', 'experiential');
  autocomplete.setAttribute('has-error', boolean('has error', false));
  autocomplete.setAttribute('max-length', number('max length', 100));
  autocomplete.setAttribute('validation-text', text('validation text', 'validation text'));
  autocomplete.setAttribute('hint-text', text('hint text', 'hint text'));
  autocomplete.setAttribute('show-valid-icon', boolean('show valid icon', false));
  autocomplete.setAttribute('valid-selection-mode', select('valid selection mode', ['off', 'onSelect', 'external'], 'off'));
  return autocomplete;
};

Experiential.storyName = 'experiential';
Experiential.parameters = { notes };

export const Controlled = () => {
  const autocomplete = document.createElement('agl-ds-autocomplete');
  autocomplete.setAttribute('mode', 'controlled');
  autocomplete.setAttribute('placeholder', 'Enter at least 3 characters');
  autocomplete.setAttribute('label', 'Enter at least 3 characters');
  autocomplete.setAttribute('type', select('type', ['default', 'default-inverse', 'experiential'], 'default'));
  autocomplete.setAttribute('show-valid-icon', boolean('show valid icon', false));
  autocomplete.setAttribute('valid-selection-mode', select('valid selection mode', ['off', 'onSelect', 'external'], 'off'));

  autocomplete.addEventListener('autocompleteInput', (e) => {
    autocomplete.parentState = 'loading';
    if (e.detail.target.value.length > 3) {
      setTimeout(() => {
        autocomplete.options = [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' },
          { value: 'testing123', text: 'testing123' },
          { value: 'testingautocomplete', text: 'testingautocomplete' }
        ];
        autocomplete.parentState = 'displayResults';
      }, 500);
    }
  });

  autocomplete.addEventListener('autcompleteOptionSelected', (e) => {
    autocomplete.parentState = 'resultSelected';
  });

  return autocomplete;
};

Controlled.storyName = 'controlled';
