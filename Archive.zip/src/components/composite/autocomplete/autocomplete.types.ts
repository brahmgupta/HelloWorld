export type AutocompleteState = 'idle' | 'displayResults' | 'loading' | 'resultSelected';

export type AutocompleteMode = 'controlled' | 'uncontrolled';

export type validSelectionMode = 'off' | 'onSelect' | 'external';
