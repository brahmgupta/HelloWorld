import { Component, ComponentInterface, h, Prop, State, Listen, Watch, EventEmitter, Event, Method, Host, Element } from '@stencil/core';
import { TextboxType } from '../../core/textbox/textbox.types';
import { generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import { AutoCompleteOption } from './autocompleteResult';
import { AutocompleteState, AutocompleteMode, validSelectionMode } from './autocomplete.types';

/** Known issues TODO
 *  Screen reader incorrectly reads out the details of the input box again when the manual address modal is opened
 *  Once the modal is opened shift tab ( ie reverse order) will miss the footer buttons
 **/

@Component({
  tag: 'agl-ds-autocomplete',
  styleUrl: './autocomplete.component.scss'
})
export class Autocomplete implements ComponentInterface {
  @Element() host: HTMLAglDsAutocompleteElement;
  /**
   * The autocomplete ID
   */
  @Prop() autoCompleteId: string = generateRandomNumber();

  /**
   * The label text for the input, will be hidden if type is experiential
   */
  @Prop() label: string = '';

  /**
   * The value for the input
   */
  @Prop() value: string;

  /**
   * The placeholder property for the input, only used if type is experiential
   */
  @Prop() placeholder: string;

  /**
   * The maxlength property of the input: note max length does nothing when inputType is number as it technically not valid [link to mozilla docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/Input#attr-maxlength)
   */
  @Prop() maxLength?: number;

  /**
   * Flag to show error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Validation text to show when the has error flag is true
   */
  @Prop() validationText: string;

  /**
   * Text to show when valid. Will override the hint text if present at the bottom of the component.
   */
  @Prop() validText: string = '';

  /**
   * Shows the valid icon when it equals true and validSelectionMode is set to external or onSelect
   */
  @Prop() showValidIcon: boolean;

  /**
   * Shows the valid icon when validSelectionMode is set to external or onSelect and showValidIcon
   * equals true. validSelectionMode should be used when an api call regulates the visibility of the
   * icon ie when an address is searched for by the user and the address is serviceable. onSelect should
   * be used with a static list of options (eg street Name) where any selection is valid
   * If set to false, valid state will never display.
   */
  @Prop() validSelectionMode: validSelectionMode = 'off';

  /**
   * Hint text will be shown underneath the textbox but will be hidden if there is an error
   */
  @Prop() hintText: string;

  /**
   * Type for the control, either default, default-inverse or experiential
   */
  @Prop() type: TextboxType = 'default';

  /**
   * The dropdown direction. Set to up when the autocomplete is at the bottom of the page.
   */
  @Prop() dropdownDirection: string = 'down';

  /**
   * How many characters to type before the autocomplete starts triggering
   */
  @Prop() minCharactersToSearch: number = 1;

  /**
   * Mode for the autocomplete uncontrolled will internally filter the options for the autocomplete, controlled will let the consumer pass in the current state and results to display
   */
  @Prop() mode: AutocompleteMode = 'uncontrolled';

  /**
   * Sets the state of the autocomplete in controlled mode
   */
  @Prop() parentState: AutocompleteState;

  /**
   * Autocomplete options which can be passed in using TSX or JS e.g. document.getElementByTagName('agl-ds-autocomplete').options = []
   * Use either this or optionsString
   */
  @Prop() options: AutoCompleteOption[];

  /**
   * Autocomplete options which can be passed in using a JSON string
   */
  @Prop() optionsString: string;

  @State() filteredResults: AutoCompleteOption[] = [];
  @State() currentState: AutocompleteState = 'idle';
  @State() inputValue: string;
  @State() selectedIndex: number = -1;
  @State() dropdownOptions: AutoCompleteOption[] = [];
  @State() hasSelection: boolean = false;

  private textboxComponent: HTMLAglDsTextboxElement;
  private inputElement: HTMLInputElement;
  private optionElements: HTMLLIElement[] = [];
  private ul: HTMLDivElement;

  @Watch('value')
  valueWatchHandler(newValue: string) {
    this.inputValue = newValue;
  }

  @Watch('optionsString')
  optionsStringWatchHandler(newValue: string) {
    this.dropdownOptions = JSON.parse(newValue);
    if (this.mode === 'controlled') {
      this.filteredResults = this.dropdownOptions;
    }
  }

  @Watch('options')
  optionsWatchHandler(newValue: AutoCompleteOption[]) {
    this.dropdownOptions = newValue;
    if (this.mode === 'controlled') {
      this.filteredResults = this.dropdownOptions;
    }
  }

  @Watch('parentState')
  parentStateWatchHandler(newValue: AutocompleteState) {
    this.currentState = newValue;
  }

  @Watch('currentState')
  currentStateWatchHandler(newValue: AutocompleteState) {
    if (newValue === 'displayResults') {
      this.setInputElementAttribute('aria-expanded', 'true');
      hideFocusRingWhenUsingMouse(this.ul);
    } else {
      this.setInputElementAttribute('aria-expanded', 'false');
      this.setInputElementAttribute('aria-activedescendant', '');
    }
  }

  /**
   * Fires when an option is selected from the dropdown
   */
  @Event() autocompleteOptionSelected: EventEmitter<AutoCompleteOption>;

  /**
   * Fires when a blur event happens on either the textbox or the dropdown and the next target is not either the textbox or the dropdown
   */
  @Event() autocompleteBlur: EventEmitter<FocusEvent>;

  /**
   * Forwards the input event of the textbox input
   */
  @Event() autocompleteInput: EventEmitter<InputEvent>;

  /**
   * Gets the textbox component element
   */
  @Method()
  async getTextBoxElement(): Promise<HTMLAglDsTextboxElement> {
    return this.textboxComponent;
  }

  /**
   * Sets the textbox component element
   */
  @Method()
  async setTextBoxValue(textValue: string): Promise<void> {
    await this.textboxComponent.setInput(textValue);
  }

  @Listen('textboxInput')
  textboxInputHandler(event: CustomEvent<InputEvent>) {
    const eventTarget = event.detail.target as HTMLInputElement;
    const value = eventTarget.value;
    if (this.mode === 'uncontrolled') {
      this.filteredResults = this.dropdownOptions.filter(
        (x) => value.length >= this.minCharactersToSearch && x.text.toLowerCase().startsWith(value.toLowerCase())
      );
      this.currentState = 'displayResults';
    }
    this.autocompleteInput.emit(event.detail);
  }

  @Listen('textboxFocus')
  textboxFocusHandler() {
    this.selectedIndex = 0;
    this.inputElement.setAttribute('aria-activedescendant', '');
    if (this.filteredResults && this.filteredResults.length && this.currentState !== 'resultSelected') {
      this.currentState = 'displayResults';
    }
  }

  private textboxBlurHandler(event: FocusEvent) {
    if (this.currentState === 'loading') {
      return;
    }
    const nextTarget = event.relatedTarget || document.activeElement;
    if (
      !nextTarget ||
      (this.optionElements.indexOf(nextTarget as HTMLLIElement) === -1 &&
        this.optionElements.indexOf((nextTarget as HTMLElement).parentElement as HTMLLIElement) === -1)
    ) {
      this.currentState = this.currentState === 'resultSelected' ? 'resultSelected' : 'idle';
      this.autocompleteBlur.emit(event);
    }
  }

  @Listen('textboxKeydown')
  textboxKeydownHandler(event: CustomEvent<KeyboardEvent>) {
    this.hasSelection = false;
    if (event.detail.key === 'ArrowDown' || event.detail.key === 'Down') {
      const validListItems = this.optionElements.filter((x) => !!x);
      if (validListItems.length) {
        const firstOption = this.optionElements.find((o) => o.id === `${this.autoCompleteId}__option-0`);
        if (firstOption) {
          firstOption.focus();
          this.selectedIndex = 0;
          this.setInputElementAttribute('aria-activedescendant', `${this.autoCompleteId}__option-0`);
        }
      }
    } else if (event.detail.key === 'Escape' || event.detail.key === 'Esc') {
      this.currentState = 'idle';
    }
  }

  private isValidDisplayHelper(selectionMode: validSelectionMode, showIcon: boolean): boolean {
    if (showIcon) {
      if (selectionMode === 'onSelect' && this.hasSelection) {
        return true;
      }

      if (selectionMode === 'external') {
        return true;
      }
    }

    return false;
  }

  private setInputElementAttribute(attributeName: string, value: string) {
    if (this.inputElement) {
      this.inputElement.setAttribute(attributeName, value);
    }
  }

  private focusOnNextOption() {
    const validListItems = this.optionElements.filter((x) => !!x);
    if (this.selectedIndex !== validListItems.length - 1) {
      this.selectedIndex++;
      validListItems[this.selectedIndex].focus();
      this.setInputElementAttribute('aria-activedescendant', `${this.autoCompleteId}__option-${this.selectedIndex}`);
    }
  }

  private focusOnPreviousOption() {
    const validListItems = this.optionElements.filter((x) => !!x);
    if (this.selectedIndex === 0) {
      this.inputElement.focus();
    } else {
      this.selectedIndex--;
      validListItems[this.selectedIndex].focus();
      this.setInputElementAttribute('aria-activedescendant', `${this.autoCompleteId}__option-${this.selectedIndex}`);
    }
  }

  private onOptionSelected(x: AutoCompleteOption): void {
    this.hasSelection = true;
    if (!x.doNotComplete) {
      this.inputValue = x.text;
    }
    this.inputElement.focus();
    this.currentState = 'resultSelected';
    this.autocompleteOptionSelected.emit(x);
  }

  private onOptionKeyDown(e: KeyboardEvent): void {
    switch (e.key) {
      case 'Down':
      case 'ArrowDown':
        this.focusOnNextOption();
        break;
      case 'Up':
      case 'ArrowUp':
        this.focusOnPreviousOption();
        break;
      case 'Esc':
      case 'Escape':
        this.currentState = 'idle';
        break;
      case 'Enter':
      case ' ':
        (e.target as HTMLLIElement).click();
        break;
      default:
        break;
    }
  }

  private onOptionBlur(event: FocusEvent) {
    if (this.currentState === 'loading') {
      return;
    }

    const nextTarget = event.relatedTarget || document.activeElement;
    if (
      !nextTarget ||
      (this.optionElements.indexOf(nextTarget as HTMLLIElement) === -1 &&
        this.optionElements.indexOf((nextTarget as HTMLElement).parentElement as HTMLLIElement) === -1)
    ) {
      this.currentState = this.currentState === 'resultSelected' ? 'resultSelected' : 'idle';
      this.autocompleteBlur.emit(event);
    }
  }

  componentWillLoad() {
    this.dropdownOptions = this.optionsString ? JSON.parse(this.optionsString) : this.options;
    this.currentState = this.parentState ? this.parentState : this.currentState;
    if (this.mode === 'controlled') {
      this.filteredResults = this.dropdownOptions;
    }
    this.inputValue = this.value;
  }

  componentDidRender() {
    this.optionElements = Array.from(this.host.querySelectorAll('li'));
  }

  async componentDidLoad() {
    this.inputElement = await this.textboxComponent.getInputElement();
    this.setInputElementAttribute('aria-expanded', 'false');
    this.setInputElementAttribute('aria-owns', `${this.autoCompleteId}_list`);
    this.setInputElementAttribute('aria-autocomplete', 'list');
    this.setInputElementAttribute('role', 'combobox');
  }

  private renderHighlightedText(option: AutoCompleteOption) {
    const index = option.text.indexOf(option.highlightText);
    const firstSection = option.text.substr(0, index);
    const highlight = option.highlightText;
    const lastSection = option.text.substring(index + option.highlightText.length, option.text.length);
    return [
      <span class="agl-ds-autocomplete__dropdown-item-text--no-overflow">{firstSection}</span>,
      <agl-ds-text appearance="highlight" fontWeight="semibold">
        {highlight}
      </agl-ds-text>,
      <span class="agl-ds-autocomplete__dropdown-item-text">{lastSection}</span>
    ];
  }

  render() {
    this.optionElements.splice(0, this.optionElements.length);
    return (
      <Host>
        <div class="agl-ds-autocomplete" ref={(el) => (this.ul = el)}>
          <agl-ds-textbox
            textBoxId={`${this.autoCompleteId}_textBox`}
            label={this.label}
            value={this.inputValue}
            hasError={this.hasError}
            type={this.type}
            maxLength={this.maxLength}
            placeholder={this.placeholder}
            hintText={this.hintText}
            isInputValid={this.isValidDisplayHelper(this.validSelectionMode, this.showValidIcon)}
            validationText={this.validationText}
            validText={this.validText}
            browserAutocomplete={false}
            onTextboxBlur={(e) => this.textboxBlurHandler(e.detail)}
            ref={(el) => (this.textboxComponent = el)}
            aria-autocomplete="list"
          />
          {this.currentState === 'loading' && [
            <span
              class={{
                'loading-overlay': true,
                ['loading-overlay--inverse']: this.type === 'default-inverse',
                ['loading-overlay--experiential']: this.type === 'experiential'
              }}
            ></span>,
            <agl-ds-loading-indicator
              size="sm"
              class={{
                ['loading-indicator']: true,
                ['loading-indicator--experiential']: this.type === 'experiential'
              }}
            />
          ]}
          {this.currentState === 'displayResults' && (
            <ul
              class={{
                ['agl-ds-autocomplete__dropdown']: true,
                ['agl-ds-autocomplete__dropdown--experiential']: this.type === 'experiential',
                ['agl-ds-autocomplete__dropdown--up']: this.dropdownDirection === 'up'
              }}
              role="listbox"
              id={`${this.autoCompleteId}_list`}
            >
              {this.filteredResults.map((x, index) => (
                <li
                  key={x.text}
                  id={`${this.autoCompleteId}__option-${index}`}
                  tabIndex={-1}
                  class="agl-ds-autocomplete__dropdown-item"
                  role="option"
                  onClick={() => this.onOptionSelected(x)}
                  onKeyDown={(e) => this.onOptionKeyDown(e)}
                  onBlur={(e) => this.onOptionBlur(e)}
                  aria-selected={`${this.selectedIndex === index}`}
                  aria-posinset={index + 1}
                  aria-setsize={this.filteredResults.length}
                >
                  {!x.highlightText ? <span class="agl-ds-autocomplete__dropdown-item-text">{x.text}</span> : this.renderHighlightedText(x)}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Host>
    );
  }
}
