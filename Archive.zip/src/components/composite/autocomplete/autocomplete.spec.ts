import { newSpecPage } from '@stencil/core/testing';
import { TextBoxComponent } from '../../core/textbox/textbox.component';
import { Autocomplete } from './autocomplete.component';
import * as utils from './../../../global/utils/utils';

describe('autocomplete component', () => {
  it('should render the default autocomplete', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid"></agl-ds-autocomplete>`
    });
    expect(page.root).not.toBeNull();
  });

  it('should show results when in controlled mode and state is displayResults', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled"></agl-ds-autocomplete>`
    });

    page.root.options = [
      { value: 'test', text: 'test' },
      { value: 'test1', text: 'test1' },
      { value: 'testing123', text: 'testing123' },
      { value: 'testingautocomplete', text: 'testingautocomplete', doNotComplete: true, highlightText: 'autocomplet' }
    ];

    page.root.setAttribute('parent-state', 'displayResults');
    await page.waitForChanges();
    const list = page.root.querySelector('ul');
    expect(list).not.toBeNull();
    expect(list.querySelectorAll('li').length).toBe(4);
  });

  it('should show loading indicator when in controlled mode and state is loading', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled"></agl-ds-autocomplete>`
    });

    page.root.setAttribute('parent-state', 'loading');
    await page.waitForChanges();
    const loader = page.root.querySelector('agl-ds-loading-indicator');
    expect(loader.tagName.toLowerCase()).toBe('agl-ds-loading-indicator');
  });

  it('should fire autocompleteOptionSelectedEvent event when an option is selected', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' },
          { value: 'testing123', text: 'testing123' },
          { value: 'testingautocomplete', text: 'testingautocomplete', doNotComplete: true, highlightText: 'autocomplet' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });
    const textbox = page.root.querySelectorAll('input')[0];
    textbox.focus = jest.fn();
    const selectSpy = jest.fn();
    page.win.addEventListener('autocompleteOptionSelected', selectSpy);

    const firstOption = page.root.querySelector('li');
    firstOption.click();
    await page.waitForChanges();
    expect(selectSpy).toHaveBeenCalled();
  });

  it('should fire autocompleteInput when the textboxInput fires', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled"></agl-ds-autocomplete>`
    });

    const inputSpy = jest.fn();
    page.win.addEventListener('autocompleteInput', inputSpy);

    const input = page.root.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('input'));
    expect(inputSpy).toHaveBeenCalled();
  });

  it('should filter and show results when in uncontrolled mode', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="uncontrolled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' },
          { value: 'testing123', text: 'testing123' },
          { value: 'testingautocomplete', text: 'testingautocomplete', doNotComplete: true, highlightText: 'autocomplet' }
        ]
      )}'></agl-ds-autocomplete>`
    });

    const input = page.root.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('input'));
    await page.waitForChanges();
    let listOptions = page.root.querySelectorAll('li');
    expect(listOptions.length).toBe(4);

    input.value = 'testing';
    input.dispatchEvent(new Event('input'));
    await page.waitForChanges();
    listOptions = page.root.querySelectorAll('li');
    expect(listOptions.length).toBe(2);
  });

  it('should return the textbox element when getTextBoxElement is called', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled"></agl-ds-autocomplete>`
    });

    const textbox = page.root.querySelector('agl-ds-textbox');
    const result = await page.root.getTextBoxElement();
    expect(result).toBe(textbox);
  });

  it('should move to the first option in the list if input down arrow key is pressed', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });
    const firstListItem = page.root.querySelectorAll('li')[0];
    const focusSpy = jest.fn();
    firstListItem.focus = focusSpy;
    const input = page.root.querySelector('input');
    input.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'ArrowDown'
      })
    );
    await page.waitForChanges();
    expect(focusSpy).toHaveBeenCalled();
  });

  it('should move to the textbox when first list option up arrow key is pressed', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });
    const textbox = page.root.querySelectorAll('input')[0];
    const firstListItem = page.root.querySelectorAll('li')[0];
    const focusSpy = jest.fn();
    textbox.focus = focusSpy;
    firstListItem.focus = jest.fn();
    textbox.dispatchEvent(new Event('focus'));
    textbox.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'ArrowDown'
      })
    );
    firstListItem.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'ArrowUp'
      })
    );
    await page.waitForChanges();
    expect(focusSpy).toHaveBeenCalled();
  });

  it('should move to the next list option up arrow key is pressed', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });
    const textbox = page.root.querySelectorAll('input')[0];
    const firstListItem = page.root.querySelectorAll('li')[0];
    const secondListItem = page.root.querySelectorAll('li')[1];
    const focusSpy = jest.fn();
    textbox.focus = jest.fn();
    firstListItem.focus = jest.fn();
    secondListItem.focus = focusSpy;
    textbox.dispatchEvent(new Event('focus'));
    textbox.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'ArrowDown'
      })
    );
    firstListItem.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'ArrowDown'
      })
    );
    await page.waitForChanges();
    expect(focusSpy).toHaveBeenCalled();
  });

  it('should close the dropdown when esc is pressed', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });

    const firstListItem = page.root.querySelectorAll('li')[0];
    firstListItem.focus = jest.fn();
    firstListItem.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'Esc'
      })
    );
    await page.waitForChanges();
    expect(page.root.querySelectorAll('ul').length).toBe(0);
  });

  it('should select an option when enter is pressed', async () => {
    jest.spyOn(utils, 'hideFocusRingWhenUsingMouse').mockImplementation();
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" options-string='${JSON.stringify(
        [
          { value: 'test', text: 'test' },
          { value: 'test1', text: 'test1' }
        ]
      )}' parent-state="displayResults"></agl-ds-autocomplete>`
    });
    const selectedSpy = jest.fn();
    page.win.addEventListener('autocompleteOptionSelected', selectedSpy);
    const textbox = page.root.querySelectorAll('input')[0];
    const focusSpy = jest.fn();
    textbox.focus = focusSpy;
    const firstListItem = page.root.querySelectorAll('li')[0];
    firstListItem.focus = jest.fn();
    firstListItem.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'Enter'
      })
    );
    await page.waitForChanges();
    expect(focusSpy).toHaveBeenCalled();
    expect(selectedSpy).toHaveBeenCalled();
  });

  it('should show svg when isValid is true and select mode is `onSelect`', async () => {
    const page = await newSpecPage({
      components: [Autocomplete, TextBoxComponent],
      html: `<agl-ds-autocomplete type="default" label="test" has-error="false" autocomplete-id="testid" mode="controlled" show-valid-icon="true" valid-selection-mode="external"></agl-ds-autocomplete>`
    });

    page.root.options = [
      { value: 'test', text: 'test' },
      { value: 'test1', text: 'test1' },
      { value: 'testing123', text: 'testing123' },
      { value: 'testingautocomplete', text: 'testingautocomplete', doNotComplete: true, highlightText: 'autocomplet' }
    ];

    const svg = page.root.querySelector('svg');
    expect(svg).not.toBeNull();
  });
});
