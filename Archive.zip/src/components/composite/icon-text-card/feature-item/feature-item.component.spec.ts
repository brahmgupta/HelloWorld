import { newSpecPage } from '@stencil/core/testing';
import { FeatureItemComponent } from '../feature-item/feature-item.component';

describe('Feature item component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [FeatureItemComponent],
      html: `<agl-ds-feature-item icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            </agl-ds-feature-item>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-feature-item icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
          <mock:shadow-root>
          <div class="icon-text icon-text-feature-item">
              <div class="icon-text-feature-item__icon">
                  <agl-ds-icon iconpath="https://via.placeholder.com/240x360/0bf/fff?text=A" size="xs"></agl-ds-icon>
              </div>
              <div class="icon-text-feature-item__content">
                <div class="icon-text-feature-item__content--description">
                  <slot name="description"></slot>
                </div>
              </div>
            </div>
          </mock:shadow-root>
        </agl-ds-feature-item>
    `);
  });
});
