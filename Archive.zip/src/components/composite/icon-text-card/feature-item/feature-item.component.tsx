import { Component, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { IconTextCard } from '../icon-text-card.component';

/**
 *@slot title - The content placed in this slot is the text for the title
 *@slot description - The content placed in this slot is authorable via AEM RTE, it could be semantic P tag . If used in SPA it should be agl-ds-p
 */

@Component({
  tag: 'agl-ds-feature-item',
  styleUrl: './../icon-text-card.component.scss',
  shadow: true
})
export class FeatureItemComponent implements ComponentInterface {
  @Element() host: HTMLAglDsFeatureItemElement;
  /**
   * The icon path for the component
   */
  @Prop() iconPath: string = '';

  render() {
    return <IconTextCard host={this.host} iconPath={this.iconPath} iconSize="xs" cardType="feature-item" />;
  }
}
