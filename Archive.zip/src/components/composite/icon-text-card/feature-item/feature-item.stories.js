import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Icon Text Card/Feature Item'
};

export const FeatureItem = () => html`
  <agl-ds-feature-item icon-path="${text('Feature item icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
    <span slot="description">${text('Feature item description', '19Mbps evening speed (7pm-11pm)')}</span>
  </agl-ds-feature-item>
`;

FeatureItem.storyName = 'feature item';
FeatureItem.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('agl-ds-feature-item p:first-of-type {margin-top: 0; font-size: 14px;}');
style.sheet.insertRule('agl-ds-feature-item p:last-of-type {margin-bottom: 0; font-size: 14px;}');
