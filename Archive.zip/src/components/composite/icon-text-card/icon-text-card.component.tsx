import { FunctionalComponent, h, Host } from '@stencil/core';
import { IconSize } from '../../core/icon/icon.types';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { IconCardType } from './icon-text-card.types';

/**
 *@slot title - The content placed in this slot is the text for the title
 *@slot description - The content placed in this slot is authorable via AEM RTE, it could be semantic P tag . If used in SPA it should be agl-ds-p
 */

interface IconTextCardProps {
  host: HTMLAglDsFeatureCardElement | HTMLAglDsFeatureItemElement | HTMLAglDsPrefooterElement;
  iconPath: string;
  iconSize: IconSize;
  cardType: IconCardType;
}

export const IconTextCard: FunctionalComponent<IconTextCardProps> = ({ host, iconPath, iconSize, cardType }) => {
  if (cardType !== 'feature-item') {
    checkSlottedContentForInvalidHTML(host.querySelector('[slot="title"]'), ['agl-ds-text', 'span']);
  }

  if (cardType === 'feature-card') {
    return (
      <Host>
        <div class={{ ['icon-text icon-text-' + cardType]: true }}>
          <div class={{ ['icon-text-' + cardType + '__icon']: true }}>
            <agl-ds-icon iconPath={iconPath} size={iconSize}></agl-ds-icon>
          </div>

          <div class={{ ['icon-text-' + cardType + '__content']: true }}>
            <agl-ds-p bottom-margin="none">
              <agl-ds-text fontWeight="semibold">
                <slot name="title" />
              </agl-ds-text>
            </agl-ds-p>

            <div class={{ ['icon-text-' + cardType + '__content--description']: true }}>
              <slot name="description" />
            </div>
          </div>
        </div>
      </Host>
    );
  }

  if (cardType === 'feature-item') {
    return (
      <Host>
        <div class={{ ['icon-text icon-text-' + cardType]: true }}>
          <div class={{ ['icon-text-' + cardType + '__icon']: true }}>
            <agl-ds-icon iconPath={iconPath} size={iconSize}></agl-ds-icon>
          </div>

          <div class={{ ['icon-text-' + cardType + '__content']: true }}>
            <div class={{ ['icon-text-' + cardType + '__content--description']: true }}>
              <slot name="description" />
            </div>
          </div>
        </div>
      </Host>
    );
  }

  if (cardType === 'prefooter') {
    return (
      <Host>
        <div class={{ ['icon-text icon-text-' + cardType]: true }}>
          <div class={{ ['icon-text-' + cardType + '__icon']: true }}>
            <agl-ds-icon iconPath={iconPath} size={iconSize}></agl-ds-icon>
          </div>

          <div class={{ ['icon-text-' + cardType + '__content']: true }}>
            <agl-ds-p styledAs="lg">
              <agl-ds-text fontWeight="semibold">
                <slot name="title" />
              </agl-ds-text>
            </agl-ds-p>

            <div class={{ ['icon-text-' + cardType + '__content--description']: true }}>
              <slot name="description" />
            </div>
          </div>
        </div>
      </Host>
    );
  }

  if (cardType === 'promo-card') {
    return (
      <Host>
        <agl-ds-card appearance="filled" corner="rounded">
          <div class={{ ['icon-text icon-text-' + cardType]: true }}>
            <div class={{ ['icon-text-' + cardType + '__icon']: true }}>
              <agl-ds-icon iconPath={iconPath} size={iconSize}></agl-ds-icon>
            </div>

            <div class={{ ['icon-text-' + cardType + '__content']: true }}>
              <agl-ds-p styledAs="sm" bottom-margin="none">
                <agl-ds-text fontWeight="semibold">
                  <slot name="title" />
                </agl-ds-text>
              </agl-ds-p>

              <div class={{ ['icon-text-' + cardType + '__content--description']: true }}>
                <slot name="description" />
              </div>
            </div>
          </div>
        </agl-ds-card>
      </Host>
    );
  }
};
