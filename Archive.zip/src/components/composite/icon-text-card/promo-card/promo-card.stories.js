import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Icon Text Card/Promo'
};

export const PromoCard = () => html`
  <agl-ds-promo-card icon-path="${text('Promo icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
    <span slot="title">${text('Promo title', 'No lock in contracts')}</span>
    <span slot="description">${text('Promo description', 'For all your essential services - electricity, gas & NBN')}</span>
  </agl-ds-promo-card>
`;

PromoCard.storyName = 'promo card';
PromoCard.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('agl-ds-promo-card p:first-of-type {margin-top: 0; font-size: 14px;}');
style.sheet.insertRule('agl-ds-promo-card p:last-of-type {margin-bottom: 0; font-size: 14px;}');
