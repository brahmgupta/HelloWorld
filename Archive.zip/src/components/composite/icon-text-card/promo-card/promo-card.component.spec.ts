import { newSpecPage } from '@stencil/core/testing';
import { PromoCardComponent } from '../promo-card/promo-card.component';

describe('Promo card component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [PromoCardComponent],
      html: `<agl-ds-promo-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            </agl-ds-promo-card>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-promo-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
          <mock:shadow-root>
          <agl-ds-card appearance="filled" corner="rounded">
            <div class="icon-text icon-text-promo-card">
              <div class="icon-text-promo-card__icon">
                  <agl-ds-icon iconpath="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm"></agl-ds-icon>
              </div>
              <div class="icon-text-promo-card__content">
                <agl-ds-p styledas="sm" bottom-margin="none">
                  <agl-ds-text fontweight="semibold">
                    <slot name="title"></slot>
                  </agl-ds-text>
                </agl-ds-p>
                <div class="icon-text-promo-card__content--description">
                  <slot name="description"></slot>
                </div>
              </div>
            </div>
          </agl-ds-card>
          </mock:shadow-root>
        </agl-ds-promo-card>
    `);
  });
});
