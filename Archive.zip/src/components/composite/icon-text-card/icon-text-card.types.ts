export type IconCardType = 'feature-card' | 'prefooter' | 'promo-card' | 'feature-item';
