import { newSpecPage } from '@stencil/core/testing';
import { PrefooterComponent } from '../prefooter/prefooter.component';

describe('Prefooter component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [PrefooterComponent],
      html: `<agl-ds-prefooter icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            </agl-ds-prefooter>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-prefooter icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
          <mock:shadow-root>
          <div class="icon-text icon-text-prefooter">
            <div class="icon-text-prefooter__icon">
                <agl-ds-icon iconpath="https://via.placeholder.com/240x360/0bf/fff?text=A" size="lg"></agl-ds-icon>
            </div>
            <div class="icon-text-prefooter__content">
              <agl-ds-p styledas="lg">
                <agl-ds-text fontweight="semibold">
                  <slot name="title"></slot>
                </agl-ds-text>
              </agl-ds-p>
              <div class="icon-text-prefooter__content--description">
                <slot name="description"></slot>
              </div>
            </div>
          </div>
          </mock:shadow-root>
        </agl-ds-prefooter>
    `);
  });
});
