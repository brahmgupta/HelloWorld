# agl-ds-prefooter


<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description                     | Type     | Default |
| ---------- | ----------- | ------------------------------- | -------- | ------- |
| `iconPath` | `icon-path` | The icon path for the component | `string` | `''`    |


## Slots

| Slot            | Description                                                                                                                  |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `"description"` | The content placed in this slot is authorable via AEM RTE, it could be semantic P tag . If used in SPA it should be agl-ds-p |
| `"title"`       | The content placed in this slot is the text for the title                                                                    |


## Dependencies

### Depends on

- [agl-ds-icon](../../../core/icon)
- [agl-ds-p](../../../core/paragraph)
- [agl-ds-text](../../../core/text)
- [agl-ds-card](../../../core/card)

### Graph
```mermaid
graph TD;
  agl-ds-prefooter --> agl-ds-icon
  agl-ds-prefooter --> agl-ds-p
  agl-ds-prefooter --> agl-ds-text
  agl-ds-prefooter --> agl-ds-card
  style agl-ds-prefooter fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
