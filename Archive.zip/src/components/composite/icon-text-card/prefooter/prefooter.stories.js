import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Icon Text Card/Pre Footer'
};

export const Prefooter = () => html`
  <agl-ds-prefooter icon-path="${text('Prefooter icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
    <span slot="title">${text('Prefooter Title', 'No lock in contracts')}</span>
    <span slot="description">${text('Prefooter Description', 'For electricity, gas & NBN')}</span>
  </agl-ds-prefooter>
`;

Prefooter.storyName = 'prefooter';
Prefooter.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('agl-ds-prefooter p:first-of-type {margin-top: 0; font-size: 18px;}');
style.sheet.insertRule('agl-ds-prefooter p:last-of-type {margin-bottom: 0; font-size: 18px;}');
