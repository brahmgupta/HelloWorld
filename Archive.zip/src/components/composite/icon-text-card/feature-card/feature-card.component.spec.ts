import { newSpecPage } from '@stencil/core/testing';
import { FeatureCardComponent } from '../feature-card/feature-card.component';

describe('Feature card component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [FeatureCardComponent],
      html: `<agl-ds-feature-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            </agl-ds-feature-card>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-feature-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
          <mock:shadow-root>
          <div class="icon-text icon-text-feature-card">
            <div class="icon-text-feature-card__icon">
                <agl-ds-icon iconpath="https://via.placeholder.com/240x360/0bf/fff?text=A" size="md"></agl-ds-icon>
            </div>
            <div class="icon-text-feature-card__content">
              <agl-ds-p  bottom-margin="none">
                <agl-ds-text fontweight="semibold">
                  <slot name="title"></slot>
                </agl-ds-text>
              </agl-ds-p>
              <div class="icon-text-feature-card__content--description">
                <slot name="description"></slot>
              </div>
            </div>
          </div>
          </mock:shadow-root>
        </agl-ds-feature-card>
    `);
  });

  it('should console.error when an invalid html tag is passed in via the title slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FeatureCardComponent],
      html: `
        <agl-ds-feature-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
         <span slot="title"><p>dummy text</p></span>
        </agl-ds-feature-card>
            `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should not console.error when valid html tags are passed in via the title slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FeatureCardComponent],
      html: `
        <agl-ds-feature-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
         <span slot="title"><agl-ds-text>dummy text</agl-ds-text><span>dummy text</span></span>
        </agl-ds-feature-card>
            `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });
});
