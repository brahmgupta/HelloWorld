import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Icon Text Card/Feature'
};

export const FeatureCard = () => html`
  <agl-ds-feature-card icon-path="${text('Feature icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
    <span slot="title">${text('Feature title', 'No lock in contracts')}</span>
    <span slot="description">${text('Feature description', 'For all your essential services - electricity, gas  & NBN')}</span>
  </agl-ds-feature-card>
`;

FeatureCard.storyName = 'feature card';
FeatureCard.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('agl-ds-feature-card p:first-of-type {margin-top: 0;}');
style.sheet.insertRule('agl-ds-feature-card p:last-of-type {margin-bottom: 0;}');
