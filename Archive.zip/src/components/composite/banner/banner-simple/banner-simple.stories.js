import { text, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/banner/Banner Simple'
};

export const BannerSimple = () => html`
  <div class="storybook-background">
    <agl-ds-banner-simple
      image-path="${text('Image URL', 'https://agl-design-system.azurewebsites.net/assets/pot-plants.svg')}"
      banner-text="${text('Text', 'Hi Alex, confirm your solar and battery quote')}"
      banner-height="${select('Banner height', ['sm', 'lg'], 'lg')}"
    >
    </agl-ds-banner-simple>
  </div>
`;

BannerSimple.parameters = { notes };

export const BannerSimpleWithHeaderAndFooter = () => html`
  <div class="storybook-background2">
    <agl-ds-banner-simple image-path="${text('Image URL', 'https://agl-design-system.azurewebsites.net/assets/pot-plants.svg')}">
      <div slot="content">
        <div class="storybook__content-container">
          <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="muted">
            Step 2 • Add broadband
          </agl-ds-h1>
          <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">
            Get $10 off your bill every month when you bundle your broadband
          </agl-ds-h2>
          <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">
            Terms and conditions apply
          </agl-ds-p>
        </div>
      </div>
    </agl-ds-banner-simple>
  </div>
`;

BannerSimpleWithHeaderAndFooter.storyName = 'Banner Simple with header and footer';
BannerSimpleWithHeaderAndFooter.parameters = { notes };

export const BannerSimpleToBeUsedWithComponentAbove = () => html`
  <div class="storybook-background2">
    <agl-ds-banner-simple
      image-path="${text('Image URL', 'https://agl-design-system.azurewebsites.net/assets/pot-plants.svg')}"
      with-top-component="true"
    >
      <div slot="content">
        <div class="storybook__content-container">
          <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">
            Get $10 off your bill every month when you bundle your broadband
          </agl-ds-h2>
          <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">
            Terms and conditions apply
          </agl-ds-p>
        </div>
      </div>
    </agl-ds-banner-simple>
  </div>
`;

BannerSimpleToBeUsedWithComponentAbove.storyName = 'Banner Simple to be used with component above';
BannerSimpleToBeUsedWithComponentAbove.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.storybook-background {background-color: var(--c-primary-01, #001cb0); display: inline-block; width: 100%;}');
style.sheet.insertRule('.storybook-background2 {background-color: #F9F9FB; display: inline-block; width: 100%;}');
style.sheet.insertRule('body.sb-show-main {margin: 0 !important;}');
style.sheet.insertRule('@media screen and (min-width: 992px) {.storybook__content-container {width: 80%;}}');
style.sheet.insertRule('.storybook__content-container {width: 100%; }');
style.sheet.insertRule('.storybook__content-p1 {margin-bottom: 8px;}');
style.sheet.insertRule('.storybook__content-heading {margin-bottom: 8px;}');
