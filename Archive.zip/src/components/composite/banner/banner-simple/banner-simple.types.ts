export type BannerHeight = 'sm' | 'lg';
