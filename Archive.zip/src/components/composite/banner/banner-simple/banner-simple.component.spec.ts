import { newSpecPage } from '@stencil/core/testing';
import { BannerSimpleComponent } from './banner-simple.component';

describe('Banner Simple component', () => {
  const bannerhtmlStart = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg">`;
  const bannerhtmlStartWithText = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg" banner-text="Hi Alex, confirm your solar and battery quote">`;
  const bannerSmallhtmlStartWithText = `<agl-ds-banner-simple  banner-height="sm" image-path="../../assets/pot-plants.svg" banner-text="Hi Alex, confirm your solar and battery quote">`;
  const bannerhtmlStartWithTextAndSuppresedPadding = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg" with-top-component banner-text="Hi Alex, confirm your solar and battery quote">`;
  const bannerhtmlStartWithoutImage = `<agl-ds-banner-simple>`;
  const bannerhtmlContent = `<div slot="content"><span class="banner-simple__text">Hi Alex, confirm your solar and battery quote</span></div>`;
  const bannerhtmlEnd = `</agl-ds-banner-simple>`;

  const bannerhtmlExpected = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg">
                    <mock:shadow-root>
                      <div class="banner-height--lg banner-simple">
                        <div class="banner-simple__container">
                          <div class="banner-simple__content">
                            <slot name="content"></slot>
                          </div>
                        </div>
                        <div class="banner-simple__image-container">
                        <agl-ds-illustration imagepath="../../assets/pot-plants.svg" size="md" bottommargin="none"></agl-ds-illustration>
                        </div>
                      </div>
                    </mock:shadow-root>
                    <div slot="content">
                      <span class="banner-simple__text">Hi Alex, confirm your solar and battery quote</span>
                    </div>
                  </agl-ds-banner-simple>`;

  const bannerSmallhtmlExpected = `<agl-ds-banner-simple banner-height="sm" banner-text="Hi Alex, confirm your solar and battery quote" image-path="../../assets/pot-plants.svg">
                  <mock:shadow-root>
                    <div class="banner-height--sm banner-simple">
                      <div class="banner-simple__container">
                        <div class="banner-simple__text-wrapper">
                          <agl-ds-h1 appearance="inverse" styledas="title2" bottommargin="none">
                            <span class="banner-simple__text">
                              Hi Alex, confirm your solar and battery quote
                            </span>
                          </agl-ds-h1>
                        </div>
                        <div class="banner-simple__content">
                          <slot name="content"></slot>
                        </div>
                      </div>
                      <div class="banner-simple__image-container">
                        <agl-ds-illustration imagepath="../../assets/pot-plants.svg" size="xs" bottommargin="none"></agl-ds-illustration>
                      </div>
                    </div>
                  </mock:shadow-root>
                </agl-ds-banner-simple>`;

  const bannerhtmlExpectedWithText = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg" banner-text="Hi Alex, confirm your solar and battery quote">
                  <mock:shadow-root>
                    <div class="banner-height--lg banner-simple">
                      <div class="banner-simple__container">
                        <div class="banner-simple__text-wrapper">
                          <agl-ds-h1 appearance="inverse" styledas="title2" bottommargin="none">
                            <span class="banner-simple__text">Hi Alex, confirm your solar and battery quote</span>
                          </agl-ds-h1>
                        </div>
                        <div class="banner-simple__content">
                          <slot name="content"></slot>
                        </div>
                      </div>
                      <div class="banner-simple__image-container">
                        <agl-ds-illustration imagepath="../../assets/pot-plants.svg" size="md" bottommargin="none"></agl-ds-illustration>
                      </div>
                    </div>
                  </mock:shadow-root>
                </agl-ds-banner-simple>`;

  const bannerhtmlExpectedWithTextAndSuppressedPadding = `<agl-ds-banner-simple image-path="../../assets/pot-plants.svg" with-top-component banner-text="Hi Alex, confirm your solar and battery quote">
                <mock:shadow-root>
                  <div class="banner-height--lg banner-simple">
                    <div class="banner-simple__container suppress-top-padding">
                      <div class="banner-simple__text-wrapper">
                        <agl-ds-h1 appearance="inverse" styledas="title2" bottommargin="none">
                          <span class="banner-simple__text">Hi Alex, confirm your solar and battery quote</span>
                        </agl-ds-h1>
                      </div>
                      <div class="banner-simple__content">
                        <slot name="content"></slot>
                      </div>
                    </div>
                    <div class="banner-simple__image-container">

                      <agl-ds-illustration imagepath="../../assets/pot-plants.svg" size="sm" bottommargin="none"></agl-ds-illustration>
                    </div>
                  </div>
                </mock:shadow-root>
              </agl-ds-banner-simple>`;

  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [BannerSimpleComponent],
      html: bannerhtmlStart + bannerhtmlContent + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpected);
    const text = page.root.querySelector('.banner-simple__text');
    expect(text).toBeDefined();
    const image = page.root.querySelector('.banner-simple__image');
    expect(image).toBeDefined();
    const height = page.root.querySelector('.banner-height--lg');
    expect(height).toBeDefined();
  });

  it('should render the component without the image', async () => {
    const page = await newSpecPage({
      components: [BannerSimpleComponent],
      html: bannerhtmlStartWithoutImage + bannerhtmlEnd
    });
    const image = page.root.querySelector('.banner-simple__image');
    expect(image).toBeNull();
  });

  it('should render the component with text', async () => {
    const page = await newSpecPage({
      components: [BannerSimpleComponent],
      html: bannerhtmlStartWithText + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpectedWithText);
    const text = page.root.querySelector('.banner-simple__text');
    expect(text).toBeDefined();
    const image = page.root.querySelector('.banner-simple__image');
    expect(image).toBeDefined();
  });

  it('should render the small version of the component with text', async () => {
    const page = await newSpecPage({
      components: [BannerSimpleComponent],
      html: bannerSmallhtmlStartWithText + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerSmallhtmlExpected);
    const text = page.root.querySelector('.banner-height--sm');
    expect(text).toBeDefined();
  });

  it('should render the component with text and suppressed padding', async () => {
    const page = await newSpecPage({
      components: [BannerSimpleComponent],
      html: bannerhtmlStartWithTextAndSuppresedPadding + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpectedWithTextAndSuppressedPadding);
    const text = page.root.querySelector('.banner-simple__text');
    expect(text).toBeDefined();
    const image = page.root.querySelector('.banner-simple__image');
    expect(image).toBeDefined();
    const suppressPadding = page.root.querySelector('.suppress-top-padding');
    expect(suppressPadding).toBeDefined();
  });
});
