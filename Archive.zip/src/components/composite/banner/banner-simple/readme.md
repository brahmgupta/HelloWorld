# agl-ds-banner-simple



<!-- Auto Generated Below -->


## Properties

| Property           | Attribute            | Description                                                                                                                                                                 | Type           | Default     |
| ------------------ | -------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- | ----------- |
| `bannerHeight`     | `banner-height`      | The height of the banner                                                                                                                                                    | `"lg" \| "sm"` | `'lg'`      |
| `bannerText`       | `banner-text`        | The text to be displayed on the banner                                                                                                                                      | `string`       | `undefined` |
| `imagePath`        | `image-path`         | The path of the image to be displayed on the banner                                                                                                                         | `string`       | `undefined` |
| `withTopComponent` | `with-top-component` | Version of banner which has a component above it. This is only intended to be used when another component needs to be placed above the banner such as a progress indicator. | `boolean`      | `false`     |


## Slots

| Slot        | Description                                                                                  |
| ----------- | -------------------------------------------------------------------------------------------- |
| `"content"` | either the slot content or the prop bannerText will be placed in the left side of the banner |


## Dependencies

### Depends on

- [agl-ds-h1](../../../core/heading/h1)
- [agl-ds-illustration](../../../core/illustration)

### Graph
```mermaid
graph TD;
  agl-ds-banner-simple --> agl-ds-h1
  agl-ds-banner-simple --> agl-ds-illustration
  style agl-ds-banner-simple fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
