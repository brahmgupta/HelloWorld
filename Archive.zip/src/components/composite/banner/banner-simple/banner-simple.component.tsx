import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { IllustrationSize } from '../../../core/illustration/illustration.types';
import { BannerHeight } from './banner-simple.types';

/**
 * @slot content - either the slot content or the prop bannerText will be placed in the left side of the banner
 */
@Component({
  tag: 'agl-ds-banner-simple',
  styleUrl: 'banner-simple.component.scss',
  shadow: true
})
export class BannerSimpleComponent implements ComponentInterface {
  /**
   * The path of the image to be displayed on the banner
   */
  @Prop() imagePath: string;

  /**
   * The text to be displayed on the banner
   */
  @Prop() bannerText: string;

  /**
   * The height of the banner
   */
  @Prop() bannerHeight: BannerHeight = 'lg';

  /**
   * Version of banner which has a component above it. This is only intended to be used when another component needs to be placed above the banner such as a progress indicator.
   */
  @Prop() withTopComponent: boolean = false;

  render() {
    let imageSize: IllustrationSize = 'md';
    if (this.bannerHeight === 'sm') {
      imageSize = 'xs';
    }

    if (this.withTopComponent) {
      this.bannerHeight === 'lg';
      imageSize = 'sm';
    }

    return (
      <Host>
        <div class={{ 'banner-simple': true, ['banner-height--' + this.bannerHeight]: true }}>
          <div
            class={{
              ['banner-simple__container']: true,
              'suppress-top-padding': this.withTopComponent
            }}
          >
            {this.bannerText && (
              <div class="banner-simple__text-wrapper">
                <agl-ds-h1 appearance="inverse" styledAs="title2" bottomMargin="none">
                  <span class="banner-simple__text">{this.bannerText}</span>
                </agl-ds-h1>
              </div>
            )}
            <div class="banner-simple__content">
              <slot name="content" />
            </div>
          </div>
          {this.imagePath && (
            <div class="banner-simple__image-container">
              <agl-ds-illustration imagePath={this.imagePath} size={imageSize} bottomMargin="none"></agl-ds-illustration>
            </div>
          )}
        </div>
      </Host>
    );
  }
}
