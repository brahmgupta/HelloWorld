import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/banner/Guided Banner'
};

export const GuidedBanner = () => html`
  <div class="storybook-background">
    <agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
      <span slot="primary-heading">${text('Primary heading', `Let's get started. `)}</span>
      <span slot="secondary-heading">${text('Secondary heading', 'Do you have a current AGL electricity or gas account?')}</span>
      <span slot="description">${text('Description', 'Typically takes about 3 mins to complete the virtual power plant signup.')}</span>
    </agl-ds-guided-banner>
  </div>
`;

GuidedBanner.parameters = { notes };

export const GuidedBannerWithBackButton = () => html`
  <div class="storybook-background">
    <agl-ds-guided-banner image-path="../../assets/pot-plants.svg" has-back-button="true">
      <span slot="primary-heading">${text('Primary heading', `Let's get started. `)}</span>
      <span slot="secondary-heading">${text('Secondary heading', 'Do you have a current AGL electricity or gas account?')}</span>
      <span slot="description">${text('Description', 'Typically takes about 3 mins to complete the virtual power plant signup.')}</span>
    </agl-ds-guided-banner>
  </div>
`;

GuidedBannerWithBackButton.storyName = 'Guided Banner with Back Button';
GuidedBannerWithBackButton.parameters = { notes };

//Added styles to give background colour in storybook to show correct fonts
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.storybook-background {background-color: var(--c-primary-01, #001cb0); display: inline-block;}');
// style.sheet.insertRule('.storybook-stepper { color:red; height:50px;}');

//to do add the stepper back in when we have the real component
{
  /* <div slot="stepper">
<div class="storybook-stepper"><agl-ds-stepper>stepper goes here if required<agl-ds-stepper></div>
</div> */
}
