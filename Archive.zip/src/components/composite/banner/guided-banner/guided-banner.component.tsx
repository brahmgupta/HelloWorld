import { Component, h, Host, Prop, Event, EventEmitter, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber } from '../../../../global/utils/utils';
import leftArrowIcon from '../../../../assets/left-arrow.svg';

@Component({
  tag: 'agl-ds-guided-banner',
  styleUrl: 'guided-banner.component.scss',
  shadow: true
})
export class GuidedBannerComponent implements ComponentInterface {
  @Element() host: HTMLAglDsGuidedBannerElement;
  /**
   * The id of the back button
   */
  @Prop() backButtonId: string = generateRandomNumber();

  /**
   * The path of the image to be displayed on the banner
   */
  @Prop() imagePath: string;

  /**
   * Toggle Back button display
   */
  @Prop() hasBackButton: boolean = false;

  /**
   * When the back button clicked, emit value
   */
  @Event() backButtonClick: EventEmitter<string>;

  /**
   * Handle click of Back Button
   */
  private handleBackButtonClick = () => {
    this.backButtonClick.emit(this.backButtonId);
  };

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="primary-heading"]'), ['agl-ds-text', 'span', 'slot']);
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="secondary-heading"]'), ['agl-ds-text', 'span']);
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="description"]'), ['agl-ds-text', 'agl-ds-link', 'span']);
  }

  render() {
    return (
      <Host>
        <div
          class={{
            'guided-banner-container': true,
            'guided-banner-container__has-back-button': this.hasBackButton
          }}
        >
          <div>
            <div class="guided-banner-container__heading-wrapper">
              <agl-ds-h1 appearance="inverse" bottom-margin="none" styledAs="title2">
                <span class="guided-banner-container__primary-heading">
                  <slot name="primary-heading" />
                </span>
              </agl-ds-h1>
            </div>
            <div class="guided-banner-container__heading-wrapper ">
              <agl-ds-h2 appearance="inverse" bottom-margin="none" font="fontfamily02" styledAs="title4">
                <slot name="secondary-heading" />
              </agl-ds-h2>
            </div>
            <agl-ds-p appearance="inverse" styledAs="md">
              <slot name="description" />
            </agl-ds-p>
            <slot name="stepper" />
          </div>
          {this.imagePath ? <img aria-hidden="true" src={this.imagePath} class="guided-banner-container__image" /> : ''}

          {this.hasBackButton && (
            <div class="guided-banner-container__back-button">
              <agl-ds-button
                type="tertiary"
                icon={leftArrowIcon}
                iconPosition="left"
                mode="reverse"
                srContext="back"
                onClick={() => this.handleBackButtonClick()}
              >
                Back
              </agl-ds-button>
            </div>
          )}
        </div>
      </Host>
    );
  }
}
