# agl-ds-guided-banner



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute         | Description                                         | Type      | Default                  |
| --------------- | ----------------- | --------------------------------------------------- | --------- | ------------------------ |
| `backButtonId`  | `back-button-id`  | The id of the back button                           | `string`  | `generateRandomNumber()` |
| `hasBackButton` | `has-back-button` | Toggle Back button display                          | `boolean` | `false`                  |
| `imagePath`     | `image-path`      | The path of the image to be displayed on the banner | `string`  | `undefined`              |


## Events

| Event             | Description                              | Type                  |
| ----------------- | ---------------------------------------- | --------------------- |
| `backButtonClick` | When the back button clicked, emit value | `CustomEvent<string>` |


## Dependencies

### Depends on

- [agl-ds-h1](../../../core/heading/h1)
- [agl-ds-h2](../../../core/heading/h2)
- [agl-ds-p](../../../core/paragraph)
- [agl-ds-button](../../../core/button)

### Graph
```mermaid
graph TD;
  agl-ds-guided-banner --> agl-ds-h1
  agl-ds-guided-banner --> agl-ds-h2
  agl-ds-guided-banner --> agl-ds-p
  agl-ds-guided-banner --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  style agl-ds-guided-banner fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
