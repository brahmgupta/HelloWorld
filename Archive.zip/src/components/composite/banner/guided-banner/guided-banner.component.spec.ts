import { newSpecPage } from '@stencil/core/testing';
import { GuidedBannerComponent } from './guided-banner.component';

describe('Guided Banner component', () => {
  const bannerhtmlStartWithBackButtonLink = `<agl-ds-guided-banner has-back-button="true" image-path="../../assets/pot-plants.svg">`;

  const bannerhtmlStartWithoutBackLink = `<agl-ds-guided-banner image-path="../../assets/pot-plants.svg">`;

  const headingStrongHtml = `<span slot="primary-heading">Dummy header strong</span>`;

  const headingHtml = `<span slot="secondary-heading">Dummy header</span>`;

  const descriptionHtml = `<span slot="description">Dummy description</span>`;

  const bannerhtmlEnd = `</agl-ds-guided-banner>`;

  const bannerhtmlExpectedWithBackButton = `<agl-ds-guided-banner image-path="../../assets/pot-plants.svg" has-back-button="true">
  <mock:shadow-root>
    <div class="guided-banner-container guided-banner-container__has-back-button">
      <div>
        <div class="guided-banner-container__heading-wrapper">
          <agl-ds-h1 appearance="inverse" bottom-margin="none" styledAs="title2">
            <span class="guided-banner-container__primary-heading">
              <slot name="primary-heading" />
            </span>
          </agl-ds-h1>
        </div>
        <div class="guided-banner-container__heading-wrapper ">
          <agl-ds-h2 appearance="inverse" bottom-margin="none" font="fontfamily02" styledAs="title4">
            <slot name="secondary-heading" />
          </agl-ds-h2>
        </div>
        <agl-ds-p appearance="inverse" styledAs="md">
          <slot name="description" />
        </agl-ds-p>
        <slot name="stepper" />
      </div>
      <img aria-hidden="true" class="guided-banner-container__image" src="../../assets/pot-plants.svg">
      <div class="guided-banner-container__back-button">
        <agl-ds-button icon="svg contents from: src/assets/left-arrow.svg" iconposition="left" mode="reverse" srcontext="back" type="tertiary">
          Back
        </agl-ds-button>
      </div>
    </div>
  </mock:shadow-root>
  <span slot="primary-heading">
    Dummy header strong
  </span>
  <span slot="secondary-heading">
    Dummy header
  </span>
  <span slot="description">
    Dummy description
  </span>
</agl-ds-guided-banner>`;

  const bannerhtmlExpectedWithoutBackButton = `<agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
                    <mock:shadow-root>
                      <div class="guided-banner-container">
                        <div>
                          <div class="guided-banner-container__heading-wrapper">
                            <agl-ds-h1 appearance="inverse" bottom-margin="none" styledAs="title2">
                              <span class="guided-banner-container__primary-heading">
                                <slot name="primary-heading" />
                              </span>
                            </agl-ds-h1>
                          </div>
                          <div class="guided-banner-container__heading-wrapper ">
                            <agl-ds-h2 appearance="inverse" bottom-margin="none" font="fontfamily02" styledAs="title4">
                              <slot name="secondary-heading" />
                            </agl-ds-h2>
                          </div>
                          <agl-ds-p appearance="inverse" styledAs="md">
                            <slot name="description" />
                          </agl-ds-p>
                          <slot name="stepper" />
                        </div>
                        <img aria-hidden="true" class="guided-banner-container__image" src="../../assets/pot-plants.svg">
                      </div>
                    </mock:shadow-root>
                    <span slot="primary-heading">
                      Dummy header strong
                    </span>
                    <span slot="secondary-heading">
                      Dummy header
                    </span>
                    <span slot="description">
                      Dummy description
                    </span>
                  </agl-ds-guided-banner>`;

  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + headingStrongHtml + headingHtml + descriptionHtml + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpectedWithBackButton);
    const slot = page.root.querySelector('[slot="primary-heading"]');
    expect(slot).toBeDefined();
  });

  it('should render the back button', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + headingStrongHtml + headingHtml + descriptionHtml + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpectedWithBackButton);
    const backButton = page.root.querySelector('.guided-banner-container__back-link');
    expect(backButton).toBeDefined();
  });

  it('should not render the back button', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithoutBackLink + headingStrongHtml + headingHtml + descriptionHtml + bannerhtmlEnd
    });
    expect(page.root).toEqualHtml(bannerhtmlExpectedWithoutBackButton);
    const backButton = page.root.querySelector('.guided-banner-container__back-link');
    expect(backButton).toBeNull();
  });

  it('should render the component without the strong header', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + headingHtml + bannerhtmlEnd
    });
    const slot = page.root.querySelector('[slot="primary-heading"]');
    expect(slot).toBeNull();
  });

  it('should render the component without the header', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + bannerhtmlEnd
    });
    const slot = page.root.querySelector('[slot="primary-heading"]');
    expect(slot).toBeNull();
  });

  it('should render the component without the description', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + bannerhtmlEnd
    });
    const slot = page.root.querySelector('[slot="primary-heading"]');
    expect(slot).toBeNull();
  });

  it('should display back button', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + bannerhtmlEnd,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-button');
    expect(element).toBeTruthy();
  });

  it('should not display back button', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithoutBackLink + bannerhtmlEnd,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-button');
    expect(element).toBeNull();
  });

  it('should dispatch "backbuttonClick" event', async () => {
    const page = await newSpecPage({
      components: [GuidedBannerComponent],
      html: bannerhtmlStartWithBackButtonLink + bannerhtmlEnd,
      supportsShadowDom: false
    });

    const buttonClickSpy = jest.fn();
    page.win.addEventListener('backButtonClick', buttonClickSpy);

    const element = page.doc.querySelector('agl-ds-button');
    element.dispatchEvent(new Event('click'));

    await page.waitForChanges();
    expect(buttonClickSpy).toHaveBeenCalled();
  });

  it('should not console.error when valid html tags are passed in via the all 3 slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedBannerComponent],
      html: `
      <div class="storybook-background">
      <agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
        <span slot="primary-heading"><agl-ds-text>dummy text</agl-ds-text><span>dummy text</span></span>
        <span slot="secondary-heading"><agl-ds-text>dummy text</agl-ds-text><span>dummy text</span></span>
        <span slot="description"><agl-ds-text>dummy text</agl-ds-text><span>dummy text</span></span>
        </agl-ds-guided-banner>
    </div>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the primary-heading slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedBannerComponent],
      html: `
      <div class="storybook-background">
      <agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
        <span slot="primary-heading"><p>dummy text</p></span>
        </agl-ds-guided-banner>
    </div>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should console.error when an invalid html tag is passed in via the secondary-heading slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedBannerComponent],
      html: `
      <div class="storybook-background">
      <agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
        <span slot="secondary-heading"><p>dummy text</p></span>
        </agl-ds-guided-banner>
    </div>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should console.error when an invalid html tag is passed in via the description slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedBannerComponent],
      html: `
      <div class="storybook-background">
      <agl-ds-guided-banner image-path="../../assets/pot-plants.svg">
        <span slot="description"><p>dummy text</p></span>
        </agl-ds-guided-banner>
    </div>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
