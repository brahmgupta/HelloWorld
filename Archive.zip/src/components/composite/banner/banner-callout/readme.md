# agl-ds-banner-callout



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute    | Description                                                 | Type                      | Default     |
| ------------ | ------------ | ----------------------------------------------------------- | ------------------------- | ----------- |
| `appearance` | `appearance` | Set the appearance of the banner-callout component          | `"default" \| "elevated"` | `'default'` |
| `imagePath`  | `image-path` | The path of the image to be displayed on the banner-callout | `string`                  | `undefined` |


## Slots

| Slot        | Description                                                                                                                                                                                                                                                    |
| ----------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"content"` | The content placed in this slot is authorable via AEM RTE, it could be semantic H (2-6) tag for title, followed by P tag for description, with optional Call to Action link-button. If used in SPA it should be agl-ds-h(2-6), agl-ds-p, agl-ds-button href="" |


## Dependencies

### Depends on

- [agl-ds-card](../../../core/card)

### Graph
```mermaid
graph TD;
  agl-ds-banner-callout --> agl-ds-card
  style agl-ds-banner-callout fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
