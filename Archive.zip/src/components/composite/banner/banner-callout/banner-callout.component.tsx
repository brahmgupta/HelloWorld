import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { BannerCalloutAppearance } from './banner-callout.types';

/**
 *@slot content - The content placed in this slot is authorable via AEM RTE, it could be semantic H (2-6) tag for title, followed by P tag for description, with optional Call to Action link-button. If used in SPA it should be agl-ds-h(2-6), agl-ds-p, agl-ds-button href=""
 */

@Component({
  tag: 'agl-ds-banner-callout',
  styleUrl: 'banner-callout.component.scss',
  shadow: true
})
export class BannerCalloutComponent implements ComponentInterface {
  /**
   * The path of the image to be displayed on the banner-callout
   */
  @Prop() imagePath: string;

  /**
   * Set the appearance of the banner-callout component
   */
  @Prop() appearance?: BannerCalloutAppearance = 'default';

  render() {
    if (this.appearance === 'elevated') {
      return (
        <Host>
          <agl-ds-card appearance="elevated">
            <div class={{ 'banner-callout': true }}>
              <div class="banner-callout__image">
                <img aria-hidden="true" src={this.imagePath} />
              </div>
              <div class="banner-callout__content">
                <slot name="content" />
              </div>
            </div>
          </agl-ds-card>
        </Host>
      );
    }

    return (
      <Host>
        <div class={{ 'banner-callout': true }}>
          <div class="banner-callout__image">
            <img aria-hidden="true" src={this.imagePath} />
          </div>
          <div class="banner-callout__content">
            <slot name="content" />
          </div>
        </div>
      </Host>
    );
  }
}
