import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/banner/Banner Callout'
};

export const BannerCallout = () => html`
  <agl-ds-banner-callout
    appearance="${select('appearance', ['default', 'elevated'], 'default')}"
    image-path="${text('Image URL', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}"
  >
    <span slot="content">
      <agl-ds-h3 styled-as="title2" font="fontfamily02" bottom-margin="none">
        ${text('Title', 'Already have an electricity or gas account with AGL?')}
      </agl-ds-h3>
      <agl-ds-p styled-as="lg">
        ${text(
          'Description',
          'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. '
        )}
      </agl-ds-p>
    </span>
  </agl-ds-banner-callout>
`;

BannerCallout.parameters = { notes };
