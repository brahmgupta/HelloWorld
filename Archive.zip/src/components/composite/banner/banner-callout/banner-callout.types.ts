export type BannerCalloutAppearance = 'default' | 'elevated';
