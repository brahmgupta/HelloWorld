import { newSpecPage } from '@stencil/core/testing';
import { BannerCalloutComponent } from './banner-callout.component';

describe('Banner Callout Component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [BannerCalloutComponent],
      html: `<agl-ds-banner-callout image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"></agl-ds-banner-callout>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-banner-callout image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" >
			<mock:shadow-root>
				<div class="banner-callout">
                  <div class="banner-callout__image">
                    <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
                  </div>
                  <div class="banner-callout__content">
                    <slot name="content"></slot>
                  </div>
                </div>
			</mock:shadow-root>
		</agl-ds-banner-callout>`
    );
  });

  describe('pass details to display the banner callout with correct attributes', () => {
    it('should present a banner callout with "Elevated" appearance', async () => {
      const page = await newSpecPage({
        components: [BannerCalloutComponent],
        html: `<agl-ds-banner-callout appearance="elevated" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"></agl-ds-banner-callout>`
      });
      expect(page.root).toEqualHtml(
        `<agl-ds-banner-callout appearance="elevated" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" >
          <mock:shadow-root>
          <agl-ds-card appearance="elevated">
              <div class="banner-callout">
                <div class="banner-callout__image">
                    <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
                </div>
                <div class="banner-callout__content">
                  <slot name="content"></slot>
                </div>
              </div>
          </agl-ds-card>
          </mock:shadow-root>
      </agl-ds-banner-callout>`
      );
    });
  });
});
