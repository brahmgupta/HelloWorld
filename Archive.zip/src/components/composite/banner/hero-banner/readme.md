# agl-ds-hero-banner



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                                                | Type                | Default     |
| --------------- | ---------------- | -------------------------------------------------------------------------- | ------------------- | ----------- |
| `bannerTitle`   | `banner-title`   | The card title (h1) to be displayed on the banner                          | `string`            | `undefined` |
| `imagePath`     | `image-path`     | The path of the image to be displayed on the banner                        | `string`            | `undefined` |
| `imagePosition` | `image-position` | The position of the image to be displayed on the banner, defaults to Right | `"left" \| "right"` | `'right'`   |


## Slots

| Slot               | Description                                                                                                                                                             |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"call-to-action"` | The content placed in this slot is authorable via AEM RTE, it should be an agl-ds-button                                                                                |
| `"description"`    | The content placed in this slot is authorable via AEM RTE, it should be semantic P, OL, UL, A tag for description. If used in SPA it should be agl-ds-h(2-6) & agl-ds-p |


## Dependencies

### Depends on

- [agl-ds-h1](../../../core/heading/h1)

### Graph
```mermaid
graph TD;
  agl-ds-hero-banner --> agl-ds-h1
  style agl-ds-hero-banner fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
