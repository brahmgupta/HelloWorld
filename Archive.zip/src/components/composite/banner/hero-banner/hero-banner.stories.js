import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/banner/Hero Banner'
};

export const HeroBanner = () => html`
  <agl-ds-hero-banner
    banner-title="${text('Title', 'AGL NBN')}"
    image-path="${text('Image URL', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}"
    image-position="${select('Image position', ['right', 'left'], 'right')}"
  >
    <span slot="description">
      <agl-ds-p styled-as="xl" font="fontfamily02" appearance="inverse">
        ${text('Sub title', 'Unlimited data plans from $55 a month.')}
      </agl-ds-p>
      <agl-ds-p styled-as="sm" appearance="inverse">
        ${text(
          'Description',
          'Unlimited data plans from $55 a month.Here’s some supporting copy, just in case you didn’t get the gist from the above.'
        )}
      </agl-ds-p>
    </span>
    <span slot="call-to-action">
      <agl-ds-button type="primary" mode="reverse" href="https://www.agl.com.au">
        ${text('Call to action text', 'See our plans')}
      </agl-ds-button>
    </span>
  </agl-ds-hero-banner>
`;

HeroBanner.parameters = { notes };
