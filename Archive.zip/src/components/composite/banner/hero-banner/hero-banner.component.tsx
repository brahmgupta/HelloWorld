import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { ImagePositions } from './hero-banner.types';

/**
 *@slot description - The content placed in this slot is authorable via AEM RTE, it should be semantic P, OL, UL, A tag for description. If used in SPA it should be agl-ds-h(2-6) & agl-ds-p
 *@slot call-to-action - The content placed in this slot is authorable via AEM RTE, it should be an agl-ds-button
 */

@Component({
  tag: 'agl-ds-hero-banner',
  styleUrl: 'hero-banner.component.scss',
  shadow: true
})
export class HeroBannerComponent implements ComponentInterface {
  /**
   * The card title (h1) to be displayed on the banner
   */
  @Prop() bannerTitle: string;

  /**
   * The path of the image to be displayed on the banner
   */
  @Prop() imagePath: string;

  /**
   * The position of the image to be displayed on the banner, defaults to Right
   */
  @Prop() imagePosition: ImagePositions = 'right';

  render() {
    if (!(['left', 'right'] as ImagePositions[]).includes(this.imagePosition)) {
      throw new Error(this.imagePosition + ' is not a valid image position');
    }

    return (
      <Host>
        <div class={{ 'hero-banner': true, ['hero-banner--' + this.imagePosition]: true }}>
          <div class="hero-banner__content">
            {this.bannerTitle ? (
              <agl-ds-h1 styledAs="title6" appearance="inverse" bottomMargin="none">
                {this.bannerTitle}
              </agl-ds-h1>
            ) : (
              ''
            )}
            <slot name="description" />
            <slot name="call-to-action" />
          </div>
          <div class="hero-banner__image">
            <img aria-hidden="true" src={this.imagePath} />
          </div>
        </div>
      </Host>
    );
  }
}
