export type ImagePositions = 'left' | 'right';
