import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { HeroBannerComponent } from './hero-banner.component';

describe('Hero Banner Component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [HeroBannerComponent],
      html: `<agl-ds-hero-banner banner-title="Testing Title"
					image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
					image-position="right"></agl-ds-hero-banner>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-hero-banner banner-title="Testing Title"
				image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				image-position="right">
			<mock:shadow-root>
				<div class="hero-banner hero-banner--right">
				<div class="hero-banner__content">
					<agl-ds-h1 styledas="title6"  appearance="inverse" bottommargin="none">Testing Title</agl-ds-h1>
					<slot name="description"></slot>
					<slot name="call-to-action"></slot>
					</div>
					<div class="hero-banner__image">
						<img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
					</div>
				</div>
			</mock:shadow-root>
		</agl-ds-hero-banner>`
    );
  });

  describe('pass details to display the hero banner with correct attributes', () => {
    let page: SpecPage;
    let element;

    it('should present a hero banner with image positioned on the left', async () => {
      page = await newSpecPage({
        components: [HeroBannerComponent],
        html: `<agl-ds-hero-banner banner-title="Testing Title"
						image-path="../https://via.placeholder.com/240x360/0bf/fff?text=A"
						image-position="left"></agl-ds-hero-banner>`,
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('.hero-banner');
      const heroBanner = element.classList.contains('hero-banner--left');
      expect(heroBanner).toBeTruthy();
    });
  });
});
