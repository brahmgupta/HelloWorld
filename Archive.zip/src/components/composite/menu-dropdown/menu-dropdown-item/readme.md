# agl-ds-menu-item



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                                                                                                       | Type         | Default     |
| -------------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | ------------ | ----------- |
| `action`       | --              | The action of menu item                                                                                                                           | `() => void` | `undefined` |
| `hasPopup`     | `has-popup`     | Indicates has popup after clicking menu item                                                                                                      | `boolean`    | `false`     |
| `hoveredIndex` | `hovered-index` | The hovered index of the menu item for display, passed in from parent                                                                             | `number`     | `-1`        |
| `icon`         | `icon`          | The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps) If both iconPath and icon are set, icon will be preferred over iconPath | `string`     | `undefined` |
| `iconPath`     | `icon-path`     | The path of an icon to be displayed along with text                                                                                               | `string`     | `undefined` |
| `index`        | `index`         | The index of the menu item of the list                                                                                                            | `number`     | `undefined` |
| `menuId`       | `menu-id`       | The menuId from parent                                                                                                                            | `string`     | `''`        |
| `setSize`      | `set-size`      | The length of menu item elements                                                                                                                  | `number`     | `undefined` |
| `text`         | `text`          | The text of the menu item                                                                                                                         | `string`     | `''`        |


## Events

| Event              | Description                      | Type                  |
| ------------------ | -------------------------------- | --------------------- |
| `menuItemHovered`  | Fires when menu item is hovered  | `CustomEvent<number>` |
| `menuItemSelected` | Fires when menu item is selected | `CustomEvent<number>` |


## Methods

### `setFocus() => Promise<void>`

Sets focus to the button

#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [agl-ds-icon](../../../core/icon)
- [agl-ds-text](../../../core/text)

### Graph
```mermaid
graph TD;
  agl-ds-menu-dropdown-item --> agl-ds-icon
  agl-ds-menu-dropdown-item --> agl-ds-text
  style agl-ds-menu-dropdown-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
