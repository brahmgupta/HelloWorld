import { Component, Host, h, Prop, ComponentInterface, Method, Event, EventEmitter, Watch } from '@stencil/core';
import { hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';

@Component({
  tag: 'agl-ds-menu-dropdown-item',
  styleUrl: 'menu-dropdown-item.scss',
  shadow: true
})
export class MenuDropdownItemComponent implements ComponentInterface {
  /**
   * The menuId from parent
   */
  @Prop() menuId: string = '';

  /**
   * The text of the menu item
   */
  @Prop() text: string = '';

  /**
   * The index of the menu item of the list
   */
  @Prop() index: number;

  /**
   * Indicates has popup after clicking menu item
   */
  @Prop() hasPopup: boolean = false;

  /**
   * The hovered index of the menu item for display, passed in from parent
   */
  @Prop() hoveredIndex: number = -1;

  /**
   * The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps)
   * If both iconPath and icon are set, icon will be preferred over iconPath
   */
  @Prop() icon: string;

  /**
   * The path of an icon to be displayed along with text
   */
  @Prop() iconPath: string;

  /**
   *  The length of menu item elements
   */
  @Prop() setSize: number;

  /**
   *  The action of menu item
   */
  @Prop() action: () => void;

  /**
   * Sets focus to the button
   */
  @Method()
  async setFocus() {
    this.menuItem.focus();
  }

  /** Fires when menu item is selected */
  @Event() menuItemSelected: EventEmitter<number>;

  /** Fires when menu item is hovered */
  @Event() menuItemHovered: EventEmitter<number>;

  /** Sets menu-item in focus when hovered index is matching its current index */
  @Watch('hoveredIndex')
  handleHoveredIndexUpdated() {
    if (this.hoveredIndex === this.index) {
      this.menuItem.focus();
    }
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.menuItem);
  }

  /**
   * Emits the index number of the selected menu item to its parent
   * It will also attempt to run the function that was passed in on the action property
   */
  private handleMenuItemClick() {
    if (typeof this.action === 'function') {
      try {
        this.action();
      } catch (error) {
        console.error(error);
      }
    }
    this.menuItemSelected.emit(this.index);
  }

  private handleMenuItemHover() {
    this.menuItemHovered.emit(this.index);
  }

  private menuItem: HTMLLIElement;

  render() {
    return (
      <Host>
        <li
          ref={(el) => (this.menuItem = el)}
          aria-labelledby={`${this.menuId}-menuitem--${this.index}`}
          aria-haspopup={`${this.hasPopup}`}
          aria-posinset={this.index + 1}
          aria-setsize={this.setSize}
          role="menuitem"
          onClick={() => this.handleMenuItemClick()}
          onMouseDown={() => this.handleMenuItemClick()}
          onMouseOver={() => this.handleMenuItemHover()}
          class={{
            'agl-ds-menu-dropdown-item': true,
            'agl-ds-menu-dropdown-item--hovered': this.hoveredIndex === this.index
          }}
          tabindex={0}
        >
          {!!this.icon || !!this.iconPath ? (
            <agl-ds-icon class="agl-ds-menu-dropdown-item__icon" icon={this.icon} icon-path={this.iconPath} size="xs"></agl-ds-icon>
          ) : null}
          <agl-ds-text
            id={`${this.menuId}__menuitem--${this.index}`}
            class="agl-ds-menu-dropdown-item__label"
            appearance={this.hoveredIndex === this.index ? 'highlight' : 'default'}
            styledAs="sm"
          >
            <slot />
          </agl-ds-text>
        </li>
      </Host>
    );
  }
}
