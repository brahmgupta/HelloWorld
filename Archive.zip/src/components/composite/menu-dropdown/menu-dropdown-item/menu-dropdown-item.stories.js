import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Menu dropdown/Menu dropdown item'
};

export const MenuItem = () => html`<agl-ds-h1 styled-as="title2">Menu item - Single</agl-ds-h1>
  <agl-ds-menu-dropdown-item icon-path="${text('Icon path', '/assets/agl_icon_carbon_neutral_on_32px.svg')}" id="menu-single" index="0"
    >${text('label', 'Item 1')}</agl-ds-menu-dropdown-item
  ><br /><br /><br />

  <agl-ds-h1 styled-as="title2">Menu item - Collection</agl-ds-h1>
  <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_elec_32px.svg" menu-id="menu-coll" index="0"
    >Menu Item 1 with quite long description text, so it pushes into different lines</agl-ds-menu-dropdown-item
  >
  <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_gas_32px.svg" menu-id="menu-coll" index="1"
    >Menu Item 2</agl-ds-menu-dropdown-item
  >
  <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_pencil_32px.svg" menu-id="menu-coll" index="2"
    >Menu Item 3</agl-ds-menu-dropdown-item
  >
  <agl-ds-menu-dropdown-item menu-id="menu-coll" index="3">Menu Item 4 without an icon</agl-ds-menu-dropdown-item>
  <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_home_32px.svg" menu-id="menu-coll" index="4"
    >Menu Item 5</agl-ds-menu-dropdown-item
  >

  <script>
    // Attaching function for non-angular environment
    // For angular application, use (action) instead
    var componentInstance = document.querySelector('#menu-single');
    componentInstance.action = () => alert('Action alert on menu-single');
  </script>`;

MenuItem.storyName = 'Menu dropdown item';
MenuItem.parameters = {
  notes,
  // these rules are excluded as the story is not a real world example of how the menu items are consumed
  a11y: {
    options: {
      rules: {
        'aria-required-parent': { enabled: false },
        'aria-valid-attr-value': { enabled: false }
      }
    }
  }
};
