import { newSpecPage } from '@stencil/core/testing';
import { MenuDropdownItemComponent } from './menu-dropdown-item';

describe('menu-dropdown', () => {
  const menuDropdownItemHtml = `<agl-ds-menu-dropdown-item icon-path="/icon.svg" menu-id="menu" index="0">Menu Item 1</agl-ds-menu-dropdown-item>`;
  const menuDropdownItemHtmlExpected = `<agl-ds-menu-dropdown-item icon-path="/icon.svg" index="0" menu-id="menu">
  <mock:shadow-root>
    <li aria-haspopup="false" aria-labelledby="menu-menuitem--0" aria-posinset="1" class="agl-ds-menu-dropdown-item" role="menuitem" tabindex="0">
      <agl-ds-icon class="agl-ds-menu-dropdown-item__icon" icon-path="/icon.svg" size="xs"></agl-ds-icon>
      <agl-ds-text appearance="default" class="agl-ds-menu-dropdown-item__label" id="menu__menuitem--0" styledas="sm">
        <slot></slot>
      </agl-ds-text>
    </li>
  </mock:shadow-root>
  Menu Item 1
</agl-ds-menu-dropdown-item>`;

  const menuDropdownItemNoIconHtml = `<agl-ds-menu-dropdown-item menu-id="menu" index="0">Menu Item 2</agl-ds-menu-dropdown-item>`;
  const menuDropdownItemNoIconHtmlExpected = `<agl-ds-menu-dropdown-item index="0" menu-id="menu">
  <mock:shadow-root>
    <li aria-haspopup="false" aria-labelledby="menu-menuitem--0" aria-posinset="1" class="agl-ds-menu-dropdown-item" role="menuitem" tabindex="0">
      <agl-ds-text appearance="default" class="agl-ds-menu-dropdown-item__label" id="menu__menuitem--0" styledas="sm">
        <slot></slot>
      </agl-ds-text>
    </li>
  </mock:shadow-root>
  Menu Item 2
</agl-ds-menu-dropdown-item>`;

  it('should render menu-dropdown-item component', async () => {
    const page = await newSpecPage({
      components: [MenuDropdownItemComponent],
      html: menuDropdownItemHtml
    });
    expect(page.root).toEqualHtml(menuDropdownItemHtmlExpected);
  });

  it('should render menu-dropdown-item component without an icon', async () => {
    const page = await newSpecPage({
      components: [MenuDropdownItemComponent],
      html: menuDropdownItemNoIconHtml
    });
    expect(page.root).toEqualHtml(menuDropdownItemNoIconHtmlExpected);
  });
});
