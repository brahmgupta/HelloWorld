import { Component, ComponentInterface, Element, h, Host, Prop, Watch } from '@stencil/core';

@Component({
  tag: 'agl-ds-menu-dropdown-trigger',
  shadow: true
})
export class MenuDropdownTriggerComponent implements ComponentInterface {
  @Element() host: HTMLAglDsMenuDropdownTriggerElement;

  /**
   * The state of menu lists are being displayed
   */
  @Prop() menuOpen: boolean = false;

  /**
   * Override toggle to pass rotate state to its slotted child component
   */
  @Prop() iconRotation: boolean = false;

  /**
   * This will pass the open/close state to its slotted component
   */
  @Watch('menuOpen')
  updateSlottedElementState() {
    // loop through slotted component children and pass 'active' property

    // specific treatment for agl-ds-button as trigger element
    Array.from<HTMLAglDsButtonElement>(this.host.querySelectorAll('agl-ds-button')).forEach((item: HTMLAglDsButtonElement) => {
      this.updateExpandedAttributeTriggerButton(item);

      this.iconRotation ? item.rotateButtonIcon() : null; // sets icon rotation state on agl-ds-button
      item.setButtonState(this.menuOpen); // sets active state on agl-ds-button
    });
  }

  componentDidLoad() {
    Array.from<HTMLAglDsButtonElement>(this.host.querySelectorAll('agl-ds-button')).forEach((item: HTMLAglDsButtonElement) => {
      this.updateExpandedAttributeTriggerButton(item);
    });
  }

  /**
   * Specific treatment for expanded/collapse attribute of trigger type button
   * @param buttonElement DSL Button Element
   */
  private updateExpandedAttributeTriggerButton(buttonElement: HTMLAglDsButtonElement) {
    this.menuOpen
      ? buttonElement.shadowRoot.querySelector('button').setAttribute('aria-expanded', 'true')
      : buttonElement.shadowRoot.querySelector('button').setAttribute('aria-expanded', 'false');
  }

  render() {
    return (
      <Host slot="trigger">
        <slot />
      </Host>
    );
  }
}
