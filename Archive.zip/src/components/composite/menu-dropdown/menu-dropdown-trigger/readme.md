# agl-ds-menu-trigger



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                         | Type      | Default |
| -------------- | --------------- | ------------------------------------------------------------------- | --------- | ------- |
| `iconRotation` | `icon-rotation` | Override toggle to pass rotate state to its slotted child component | `boolean` | `false` |
| `menuOpen`     | `menu-open`     | The state of menu lists are being displayed                         | `boolean` | `false` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
