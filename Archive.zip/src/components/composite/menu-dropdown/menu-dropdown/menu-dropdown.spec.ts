import { newSpecPage } from '@stencil/core/testing';
import { MenuDropdownComponent } from './menu-dropdown';

describe('menu-dropdown', () => {
  const menuDropdownHtml = `<agl-ds-menu-dropdown menu-id="menu-test">
    <agl-ds-menu-dropdown-trigger>
      <agl-ds-button>Click Me</agl-ds-button>
    </agl-ds-menu-dropdown-trigger>
    <agl-ds-menu-dropdown-item>Menu Item 1</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item>Menu Item 2</agl-ds-menu-dropdown-item>
  </agl-ds-menu-dropdown>`;

  const menuDropdownRightLargeHtml = `<agl-ds-menu-dropdown menu-id="menu-test" position="right" size="lg">
    <agl-ds-menu-dropdown-trigger>
      <agl-ds-button>Click Me</agl-ds-button>
    </agl-ds-menu-dropdown-trigger>
    <agl-ds-menu-dropdown-item>Menu Item</agl-ds-menu-dropdown-item>
  </agl-ds-menu-dropdown>`;

  const menuDropdownExpectedHtml = `<agl-ds-menu-dropdown menu-id="menu-test">
      <mock:shadow-root>
        <div class="agl-ds-menu-dropdown agl-ds-menu-dropdown--left">
          <div class="agl-ds-menu-dropdown__trigger">
            <slot name="trigger"></slot>
          </div>
          <div class="agl-ds-menu-dropdown__anchor agl-ds-menu-dropdown__anchor--left">
            <agl-ds-card appearance="flat" class="agl-ds-menu-dropdown__content agl-ds-menu-dropdown__content--sm" corner="rounded">
              <ul aria-labelledby="menu-test" class="agl-ds-menu-dropdown__content-area" id="menu-test__menu" role="menu" tabindex="-1">
                <slot></slot>
              </ul>
            </agl-ds-card>
          </div>
          <div class="agl-ds-menu-dropdown__backdrop"></div>
        </div>
      </mock:shadow-root>
      <agl-ds-menu-dropdown-trigger>
        <agl-ds-button>
          Click Me
        </agl-ds-button>
      </agl-ds-menu-dropdown-trigger>
      <agl-ds-menu-dropdown-item>
        Menu Item 1
      </agl-ds-menu-dropdown-item>
      <agl-ds-menu-dropdown-item>
        Menu Item 2
      </agl-ds-menu-dropdown-item>
    </agl-ds-menu-dropdown>`;

  const menuDropdownRightLargeHtmlExpected = `<agl-ds-menu-dropdown menu-id="menu-test" position="right" size="lg">
    <mock:shadow-root>
    <div class="agl-ds-menu-dropdown agl-ds-menu-dropdown--right">
      <div class="agl-ds-menu-dropdown__trigger">
        <slot name="trigger"></slot>
      </div>
      <div class="agl-ds-menu-dropdown__anchor agl-ds-menu-dropdown__anchor--right">
        <agl-ds-card appearance="flat" class="agl-ds-menu-dropdown__content agl-ds-menu-dropdown__content--lg" corner="rounded">
          <ul aria-labelledby="menu-test" class="agl-ds-menu-dropdown__content-area" id="menu-test__menu" role="menu" tabindex="-1">
            <slot></slot>
          </ul>
        </agl-ds-card>
      </div>
      <div class="agl-ds-menu-dropdown__backdrop"></div>
    </div>
  </mock:shadow-root>
  <agl-ds-menu-dropdown-trigger>
    <agl-ds-button>
      Click Me
    </agl-ds-button>
  </agl-ds-menu-dropdown-trigger>
  <agl-ds-menu-dropdown-item>
    Menu Item
  </agl-ds-menu-dropdown-item>
</agl-ds-menu-dropdown>`;

  it('should render menu-dropdown component', async () => {
    const page = await newSpecPage({
      components: [MenuDropdownComponent],
      html: menuDropdownHtml
    });
    expect(page.root).toEqualHtml(menuDropdownExpectedHtml);
  });

  it('should render menu-dropdown component with "right" position and "large" dropdown area', async () => {
    const page = await newSpecPage({
      components: [MenuDropdownComponent],
      html: menuDropdownRightLargeHtml
    });
    expect(page.root).toEqualHtml(menuDropdownRightLargeHtmlExpected);
  });
});
