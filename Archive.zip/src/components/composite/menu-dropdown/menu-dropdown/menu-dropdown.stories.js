import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Menu dropdown/Menu dropdown'
};

const commonStoryshots = {
  axetest: {
    beforeAxeTestAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  },
  visualRegression: {
    screenshotHeight: 750,
    beforeScreenshotAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  }
};

const storyPageManipulation = async (page) => {
  await page.waitForSelector('#trigger', { visible: true });
  await page.waitForTimeout(0); // allow time for the setTimeout's that attach events to the #trigger buttons in the stories
  await page.click('#trigger');
};

const paragraphContent =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras non nisl imperdiet, scelerisque nisl eu, tristique erat. Cras ac rutrum tellus. Suspendisse accumsan non risus a luctus. Morbi ac pharetra ligula, id tempus felis. Duis sit amet libero at mauris luctus vehicula. Donec id mattis leo, a commodo justo. Mauris.';

export const Menu = () => html`
  <agl-ds-p>${paragraphContent}</agl-ds-p>

  <agl-ds-card corner="rounded">
    <agl-ds-p bottom-margin="none">${paragraphContent}</agl-ds-p>
    <agl-ds-menu-dropdown position="${select('Position', ['left', 'right'], 'right')}" size="${select('Size', ['sm', 'md'], 'sm')}">
      <agl-ds-menu-dropdown-trigger>
        <agl-ds-button id="trigger">Click Me</agl-ds-button>
      </agl-ds-menu-dropdown-trigger>
      <agl-ds-menu-dropdown-item>Make payment</agl-ds-menu-dropdown-item>
      <agl-ds-menu-dropdown-item>Download bill</agl-ds-menu-dropdown-item>
    </agl-ds-menu-dropdown>
  </agl-ds-card>

  <agl-ds-p></agl-ds-p>
  <agl-ds-p>${paragraphContent}</agl-ds-p>
`;

Menu.storyName = 'Menu dropdown inside a card component';
Menu.parameters = { notes, storyshots: commonStoryshots };

export const MenuAlongWithParagraph = () => html`
  <agl-ds-p>${paragraphContent}</agl-ds-p>

  <agl-ds-menu-dropdown position="${select('Position', ['left', 'right'], 'left')}" size="${select('Size', ['sm', 'md'], 'sm')}">
    <agl-ds-menu-dropdown-trigger>
      <agl-ds-button id="trigger" type="secondary">Click Me</agl-ds-button>
    </agl-ds-menu-dropdown-trigger>
    <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_elec_32px.svg" id="menu-item-c1">Menu Item 1</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_gas_32px.svg" id="menu-item-c2">Menu Item 2</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_battery_32px.svg" id="menu-item-c3">Menu Item 3</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_rent_32px.svg" id="menu-item-c4">Menu Item 4</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item id="menu-item-c5">Menu Item 5 no-icon</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item icon-path="/assets/agl_icon_dig_modem_32px.svg" id="menu-item-c6">Menu Item 6</agl-ds-menu-dropdown-item>
    <agl-ds-menu-dropdown-item id="menu-item-c7" (menuItemSelected)="someFunction()">Menu Item 7 Angular</agl-ds-menu-dropdown-item>
  </agl-ds-menu-dropdown>

  <agl-ds-p></agl-ds-p>
  <agl-ds-p>${paragraphContent}</agl-ds-p>

  <script>
    // Attaching function for non-Angular environment
    // For Angular application, use (action) instead
    const select = (target) => document.querySelector(target);
    const menuItem1 = select('#menu-item-c1');
    const menuItem2 = select('#menu-item-c2');
    const menuItem3 = select('#menu-item-c3');
    const menuItem4 = select('#menu-item-c4');
    const menuItem5 = select('#menu-item-c5');
    const menuItem6 = select('#menu-item-c6');
    menuItem1.action = () => alert('Menu Item 1 Clicked');
    menuItem2.action = () => alert('Menu Item 2 Clicked');
    menuItem3.action = () => alert('Menu Item 3 Clicked');
    menuItem4.action = () => alert('Menu Item 4 Clicked');
    menuItem5.action = () => alert('Menu Item 5 no-icon Clicked');
    menuItem6.action = () => alert('Menu Item 6 Clicked');

    function someFunction() {
      alert('Menu Item 7 Clicked');
    }
  </script>
`;
MenuAlongWithParagraph.storyName = 'Menu dropdown along with paragraphs';
MenuAlongWithParagraph.parameters = { notes, storyshots: commonStoryshots };
