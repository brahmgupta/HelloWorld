import { Component, Element, Host, h, Prop, ComponentInterface, State, Watch, Listen } from '@stencil/core';
import { generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';
import { MenuDropdownPosition, MenuDropdownSize } from './menu-dropdown.types';

@Component({
  tag: 'agl-ds-menu-dropdown',
  styleUrl: 'menu-dropdown.scss',
  shadow: true
})
export class MenuDropdownComponent implements ComponentInterface {
  @Element() host: HTMLAglDsMenuDropdownElement;

  /**
   * Unique ID for the label of the menu
   */
  @Prop() menuId: string = generateRandomNumber();

  /**
   * The position of the dropdown area relative to the trigger
   */
  @Prop() position: MenuDropdownPosition = 'left';

  /**
   * The size of the dropdown area
   */
  @Prop() size: MenuDropdownSize = 'sm';

  /**
   * The state of menu lists that are being displayed
   */
  @State() menuOpen: boolean = false;

  /**
   * The menu trigger button focused state
   */
  @State() isTriggerFocused: boolean = false;

  /**
   * The index of the selected menu item
   */
  @State() selectedIndex: number = -1;

  /**
   * The index of the hovered menu item
   */
  @State() hoveredIndex: number = -1;

  /**
   * Refers to the ul item
   */
  private listboxNode: HTMLUListElement;

  /**
   * Refers to the trigger container element
   */
  private triggerElement: HTMLDivElement;

  /**
   * The menu items for the menu where user can choose from
   */
  private items: HTMLAglDsMenuDropdownItemElement[] = [];

  private keyCodes = {
    13: 'enter',
    27: 'escape',
    32: 'space',
    38: 'up',
    40: 'down'
  };

  /**
   * This method waits the animation function be called
   * and returns targeted element when it is ready
   *
   * @param el Targeted HTML element
   * @returns Targeted element itself in Promise
   */
  private onElementReady(el: HTMLElement): Promise<HTMLElement> {
    return new Promise((resolve) => {
      const waitForElement = () => {
        if (el.offsetParent) {
          resolve(el);
        } else {
          window.requestAnimationFrame(waitForElement);
        }
      };
      waitForElement();
    });
  }

  /** Focusing on the trigger - this will resets selected & hover index */
  private focusOnTriggerElement() {
    this.triggerElement.focus();
    this.isTriggerFocused = true;
    this.selectedIndex = -1;
    this.hoveredIndex = -1;
  }

  /** Action when the list container is in focus */
  private handleListNodeFocus(): void {
    this.onElementReady(this.listboxNode).then((el) => el.focus());
  }

  /** Action on list container lost focus */
  private handleListNodeBlur() {
    this.menuOpen = false;
    this.focusOnTriggerElement();
  }

  /** Action on trigger area click */
  private handleTriggerClick(): void {
    this.menuOpen = !this.menuOpen;
    if (this.menuOpen) {
      this.handleListNodeFocus();
    }
  }

  /** Action on trigger area lost focus */
  private handleTriggerBlur() {
    this.isTriggerFocused = false;
  }

  private handleListNodeKeyDown(event: KeyboardEvent) {
    switch (this.keyCodes[event.keyCode]) {
      case 'up':
        this.handleUpArrow(event);
        break;
      case 'down':
        this.handleDownArrow(event);
        break;
      case 'enter':
        this.handleEnter(event);
        break;
      case 'escape':
        this.handleListNodeBlur();
        break;
      default:
        break;
    }
  }

  private handleTriggerKeyDown(event: KeyboardEvent) {
    switch (this.keyCodes[event.keyCode]) {
      case 'up':
        this.handleTriggerClick();
        this.handleUpArrow(event);
        break;
      case 'down':
        this.handleTriggerClick();
        this.handleDownArrow(event);
        break;
      case 'escape':
        this.handleTriggerBlur();
        break;
      default:
        break;
    }
  }

  private handleDownArrow(event: KeyboardEvent) {
    event.preventDefault();

    const { menuOpen, items, hoveredIndex } = this;
    const isNotAtBottom = hoveredIndex !== items.length - 1;
    const allowMoveDown = isNotAtBottom && menuOpen;
    if (allowMoveDown) {
      this.handleMenuItemFocus(hoveredIndex + 1);
    }
  }

  private handleUpArrow(event: KeyboardEvent) {
    event.preventDefault();
    const { menuOpen, hoveredIndex } = this;
    const isNotAtTop = hoveredIndex > 0;
    const allowMoveUp = isNotAtTop && menuOpen;
    if (allowMoveUp) {
      this.handleMenuItemFocus(hoveredIndex - 1);
    }
  }

  private handleEnter(event: KeyboardEvent) {
    event.preventDefault();
    const hasHoveredMenuItem = this.hoveredIndex >= 0;
    if (hasHoveredMenuItem) {
      this.handleMenuItemEntered(this.hoveredIndex);
    }
  }

  private handleMenuItemFocus(index: number) {
    this.hoveredIndex = index;
    this.selectedIndex = index;
  }

  private handleMenuItemEntered(index: number) {
    this.selectedIndex = index;
    this.hoveredIndex = index;

    Array.from<HTMLAglDsMenuDropdownItemElement>(this.host.querySelectorAll('agl-ds-menu-dropdown-item')).forEach(
      (item: HTMLAglDsMenuDropdownItemElement, itemIndex: number) => {
        if (!!item && itemIndex === index) {
          // converts keyboard key-enter event into a click then passing it down to its menu-item child
          item.shadowRoot.querySelector('li').dispatchEvent(new Event('click'));
        }
      }
    );
  }

  @Watch('hoveredIndex')
  updateHoveredMenuItem(hoveredIndex: number) {
    Array.from<HTMLAglDsMenuDropdownItemElement>(this.host.querySelectorAll('agl-ds-menu-dropdown-item')).forEach(
      (item: HTMLAglDsMenuDropdownItemElement, index: number) => {
        item.hoveredIndex = hoveredIndex;
        item.index = index;
      }
    );
  }

  @Watch('menuOpen')
  updateStateToChild() {
    const parentStateMenuOpen = this.menuOpen;
    Array.from<HTMLAglDsMenuDropdownTriggerElement>(this.host.querySelectorAll('agl-ds-menu-dropdown-trigger[slot="trigger"]')).forEach(
      (item: HTMLAglDsMenuDropdownTriggerElement) => {
        item.menuOpen = parentStateMenuOpen;
      }
    );
  }

  @Listen('menuItemSelected')
  handleMenuItemSelected(event: CustomEvent) {
    this.menuOpen = false;
    if ((event.detail as number) > -1) {
      this.selectedIndex = -1;
      this.hoveredIndex = -1;
    }

    this.focusOnTriggerElement();
  }

  @Listen('menuItemHovered')
  handleMenuItemHovered(event: CustomEvent) {
    if (this.hoveredIndex != (event.detail as number)) {
      this.hoveredIndex = event.detail as number;
      this.selectedIndex = event.detail as number;
    }
  }

  componentWillLoad() {
    Array.from<HTMLAglDsMenuDropdownItemElement>(this.host.querySelectorAll('agl-ds-menu-dropdown-item')).forEach(
      (item: HTMLAglDsMenuDropdownItemElement, index: number) => {
        item.hoveredIndex = -1;
        item.index = index;
        item.setSize = this.items.length;
        item.menuId = this.menuId;
      }
    );
    this.items = Array.from<HTMLAglDsMenuDropdownItemElement>(this.host.querySelectorAll('agl-ds-menu-dropdown-item'));
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.triggerElement);
  }

  render() {
    return (
      <Host>
        <div class={{ 'agl-ds-menu-dropdown': true, ['agl-ds-menu-dropdown--' + this.position]: true }}>
          <div
            class="agl-ds-menu-dropdown__trigger"
            ref={(el) => (this.triggerElement = el)}
            onClick={() => this.handleTriggerClick()}
            onKeyDown={(event) => this.handleTriggerKeyDown(event)}
          >
            <slot name="trigger"></slot>
          </div>
          <div class={{ 'agl-ds-menu-dropdown__anchor': true, ['agl-ds-menu-dropdown__anchor--' + this.position]: true }}>
            <agl-ds-card
              corner="rounded"
              appearance={this.menuOpen ? 'elevated' : 'flat'}
              class={{
                'agl-ds-menu-dropdown__content': true,
                'agl-ds-menu-dropdown__content--show': this.menuOpen,
                ['agl-ds-menu-dropdown__content--' + this.size]: true
              }}
            >
              <ul
                id={`${this.menuId}__menu`}
                tabIndex={-1}
                role="menu"
                aria-labelledby={`${this.menuId}`}
                class="agl-ds-menu-dropdown__content-area"
                ref={(el) => (this.listboxNode = el)}
                onKeyDown={(event) => this.handleListNodeKeyDown(event)}
              >
                <slot />
              </ul>
            </agl-ds-card>
          </div>
          <div
            class={{ 'agl-ds-menu-dropdown__backdrop': true, 'agl-ds-menu-dropdown__backdrop--show': this.menuOpen }}
            onClick={() => this.handleTriggerClick()}
          ></div>
        </div>
      </Host>
    );
  }
}
