# agl-ds-menu-dropdown



<!-- Auto Generated Below -->


## Properties

| Property   | Attribute  | Description                                               | Type                | Default                  |
| ---------- | ---------- | --------------------------------------------------------- | ------------------- | ------------------------ |
| `menuId`   | `menu-id`  | Unique ID for the label of the menu                       | `string`            | `generateRandomNumber()` |
| `position` | `position` | The position of the dropdown area relative to the trigger | `"left" \| "right"` | `'left'`                 |
| `size`     | `size`     | The size of the dropdown area                             | `"md" \| "sm"`      | `'sm'`                   |


## Dependencies

### Depends on

- [agl-ds-card](../../../core/card)

### Graph
```mermaid
graph TD;
  agl-ds-menu-dropdown --> agl-ds-card
  style agl-ds-menu-dropdown fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
