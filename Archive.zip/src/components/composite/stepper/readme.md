# agl-ds-stepper



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [agl-ds-p](../../core/paragraph)
- [agl-ds-text](../../core/text)

### Graph
```mermaid
graph TD;
  agl-ds-stepper --> agl-ds-p
  agl-ds-stepper --> agl-ds-text
  style agl-ds-stepper fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
