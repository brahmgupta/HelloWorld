import { StepperMobileModel } from './stepper.model';

export class StepperService {
  constructor(private innerDivElement: HTMLOListElement) {}

  public getStepperMobileDataModel(): StepperMobileModel {
    const stepElements: Element[] = (this.innerDivElement.children[0] as HTMLSlotElement).assignedElements();
    let stepperModel: StepperMobileModel = undefined;
    let activeStepIndex: number;
    if (stepElements?.length > 0) {
      stepperModel = new StepperMobileModel();
      stepElements.forEach((ele: HTMLElement, index: number) => {
        if (ele?.attributes?.getNamedItem('status')?.value?.toLowerCase() === 'active') {
          activeStepIndex = index;
          return;
        }
      });
      stepperModel.activeStepNumber = activeStepIndex + 1;
      stepperModel.activeStepName = stepElements[activeStepIndex].attributes.getNamedItem('description')?.value;
      stepperModel.stepCount = stepElements?.length;

      if (stepperModel?.activeStepNumber && stepperModel?.activeStepNumber !== stepElements?.length) {
        stepperModel.nextStepName = stepElements[activeStepIndex + 1]?.attributes?.getNamedItem('description')?.value;
      }
    }
    return stepperModel;
  }
}
