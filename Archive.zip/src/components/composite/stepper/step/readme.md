# agl-ds-step



<!-- Auto Generated Below -->


## Properties

| Property      | Attribute     | Description                                                                                                                 | Type                                                 | Default     |
| ------------- | ------------- | --------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- | ----------- |
| `description` | `description` | The description of the step                                                                                                 | `string`                                             | `undefined` |
| `status`      | `status`      | The status of the step                                                                                                      | `"Active" \| "Completed" \| "Error" \| "Incomplete"` | `undefined` |
| `stepId`      | `step-id`     | The id to uniquely identify each step, this can be used in the click event handler to determine which step has been clicked | `string`                                             | `undefined` |
| `stepNumber`  | `step-number` | The number of the step to be shown in the circle                                                                            | `number`                                             | `undefined` |


## Events

| Event          | Description                                                  | Type                  |
| -------------- | ------------------------------------------------------------ | --------------------- |
| `stepSelected` | The event fired when the step of completed status is clicked | `CustomEvent<string>` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
