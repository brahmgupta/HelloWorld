import { Component, ComponentInterface, Event, EventEmitter, Prop, h } from '@stencil/core';

import { StepStatus } from '../stepper.model';
import completedIcon from '../../../../assets/agl_ds_stepper_completed.svg';
import errorIcon from '../../../../assets/agl_ds_stepper_step_error.svg';
import { hideFocusRingWhenUsingMouse, resizeSVGsForEdge } from '../../../../global/utils/utils';

@Component({
  tag: 'agl-ds-step',
  styleUrl: 'step.component.scss',
  shadow: true
})
export class StepComponent implements ComponentInterface {
  private errorSpan: HTMLSpanElement;
  private completedSpan: HTMLSpanElement;
  /**
   * The id to uniquely identify each step, this can be used in the click event handler to determine which step has been clicked
   */
  @Prop() stepId: string;
  /**
   * The number of the step to be shown in the circle
   */
  @Prop() stepNumber: number;
  /**
   * The description of the step
   */
  @Prop({ reflect: true }) description: string;
  /**
   * The status of the step
   */
  @Prop({ reflect: true }) status: StepStatus;
  /**
   * The event fired when the step of completed status is clicked
   */
  @Event() stepSelected: EventEmitter<string>;

  private liElement: HTMLLIElement;
  private isStepComplete: boolean = false;
  private isStepInError: boolean = false; //TODO Allow the error state to be clickable as well as complete

  private getCompleteIcon() {
    if (this.status.toLowerCase() !== 'completed') {
      return this.stepNumber;
    } else {
      return <span ref={(el) => (this.completedSpan = el)} innerHTML={completedIcon} class="step__icon" aria-hidden="true"></span>;
    }
  }

  private getErrorIcon() {
    return <span ref={(el) => (this.errorSpan = el)} innerHTML={errorIcon} class="step--error" aria-hidden="true"></span>;
  }
  private stepClick = () => {
    this.stepSelected.emit(this.stepId);
  };

  componentWillLoad() {
    this.isStepComplete = this.status.toLowerCase() === 'completed';
    this.isStepInError = this.status.toLowerCase() === 'error';
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.liElement);
    resizeSVGsForEdge(this.completedSpan, '10', '10', '10', '10');
    resizeSVGsForEdge(this.errorSpan, '24', '24', '24', '24');
  }

  render() {
    return (
      <li
        role="listitem"
        class={{ ['step']: true, ['has-icon']: true, [this.status.toLowerCase()]: true }}
        tabindex="0"
        onClick={this.isStepComplete && this.stepClick}
        ref={(l) => (this.liElement = l)}
      >
        <span class="sr-only">
          {this.status.toLowerCase() + ' step ' + (this.isStepComplete || this.isStepInError ? this.stepNumber : '')}
        </span>
        {this.status.toLowerCase() !== 'error' && (
          <span class={{ ['step__circle']: true, [this.status.toLowerCase()]: true }}>{this.getCompleteIcon()}</span>
        )}
        {this.status.toLowerCase() === 'error' && this.getErrorIcon()}
        &nbsp;&nbsp;{this.description}
      </li>
    );
  }
}
