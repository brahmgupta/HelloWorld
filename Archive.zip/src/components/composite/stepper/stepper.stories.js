import { html } from 'lit-html';
import stepperNotes from './readme.md';
import notes from './step/readme.md';

const allNotes = `${stepperNotes}\n\n${notes}`;

export default {
  title: 'Composite/Stepper'
};

export const Stepper = () => {
  return html` <p>
      <button>Focusable element before</button>
    </p>
    <div style="display: flex">
      <agl-ds-stepper>
        <agl-ds-step step-id="step1" step-number="1" description="Mobile setup" status="completed"></agl-ds-step>
        <agl-ds-step step-id="step2" step-number="2" description="Energy setup" status="error"></agl-ds-step>
        <agl-ds-step step-id="step3" step-number="3" description="Internet setup" status="active"></agl-ds-step>
        <agl-ds-step step-id="step4" step-number="4" description="Personal details" status="Incomplete"></agl-ds-step>
        <agl-ds-step step-id="step5" step-number="5" description="Billing details" status="Incomplete"></agl-ds-step>
        <agl-ds-step step-id="step6" step-number="6" description="Review and submit" status="Incomplete"></agl-ds-step>
        <agl-ds-step step-id="step7" step-number="7" description="Completed" status="Incomplete"></agl-ds-step>
        <agl-ds-step step-id="step8" step-number="8" description="Completed" status="Incomplete"></agl-ds-step>
        <agl-ds-step step-id="step9" step-number="9" description="Completed" status="Incomplete"></agl-ds-step>
      </agl-ds-stepper>
    </div>
    <p>
      <button>Focusable element after</button>
    </p>`;
};

Stepper.parameters = { notes: allNotes };

const getStepElement = (stepId, stepNumber, description, status) => {
  const stepElement = document.createElement('agl-ds-step');

  stepElement.addEventListener('stepSelected', (e) => {
    console.log(`step clicked - value = ` + e.detail);
  });

  stepElement.setAttribute('step-id', stepId);
  stepElement.setAttribute('step-number', stepNumber);
  stepElement.setAttribute('description', description);
  stepElement.setAttribute('status', status);
  return stepElement;
};

export const StepperWithClickEvent = () => {
  const stepperElement = document.createElement('agl-ds-stepper');
  stepperElement.appendChild(getStepElement('step1', 1, 'Step 1', 'completed'));
  stepperElement.appendChild(getStepElement('step2', 2, 'Step 2', 'completed'));
  stepperElement.appendChild(getStepElement('step3', 3, 'Step 3', 'Active'));
  stepperElement.appendChild(getStepElement('step4', 3, 'Step 4', 'Incomplete'));
  return stepperElement;
};

StepperWithClickEvent.parameters = { notes: allNotes };
