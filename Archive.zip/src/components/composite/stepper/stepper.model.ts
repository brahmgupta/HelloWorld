export class StepperMobileModel {
  activeStepNumber?: number;
  activeStepName?: string;
  stepCount?: number;
  nextStepName?: string;
}

export type StepStatus = 'Incomplete' | 'Active' | 'Completed' | 'Error';
