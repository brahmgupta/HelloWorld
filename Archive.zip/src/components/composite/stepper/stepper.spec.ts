import { newSpecPage } from '@stencil/core/testing';
import { StepComponent } from './step/step.component';
import { StepperComponent } from './stepper.component';
import { StepperService } from './stepper.service';

describe('Stepper component', () => {
  it('should render my component', async () => {
    jest.spyOn(StepperService.prototype, 'getStepperMobileDataModel').mockImplementation(() => {
      return { activeStepNumber: 2, stepCount: 9, nextStepName: 'Personal details', activeStepName: 'Internet setup' };
    });

    jest.spyOn(StepperComponent.prototype as any, 'preparePagePosition').mockImplementation(() => {
      return null;
    });
    const page = await newSpecPage({
      components: [StepperComponent, StepComponent],
      html: `
      <agl-ds-stepper>
        <agl-ds-step step-id="step1" step-number="1" description="Mobile setup" status="completed"></agl-ds-step>
        <agl-ds-step step-id="step2" step-number="2" description="Energy setup" status="error"></agl-ds-step>
        <agl-ds-step step-id="step3" step-number="3" description="Internet setup" status="active"></agl-ds-step>
        <agl-ds-step step-id="step4" step-number="4" description="Personal details" status="Incomplete"></agl-ds-step>
        </agl-ds-stepper>
      `
    });

    expect(page.root).toEqualHtml(`
    <agl-ds-stepper>
      <mock:shadow-root>
        <div aria-label="progress" class="visible-lg-only" role="group">
          <div class="container-large">
            <button aria-hidden="true" class="container-large__left-arrow" tabindex="-1">
              <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M15,12c0,0.3-0.1,0.5-0.3,0.7l-4,4c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l3.3-3.3L9.3,8.7c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l4,4C14.9,11.5,15,11.7,15,12z"></path>
              </svg>
            </button>
            <div class="container-large__outer">
              <span class="sr-only" id="currentStep">
                active step 3 Internet setup
              </span>
              <ol aria-labelledby="currentStep" class="container-large__inner" role="list">
                <slot></slot>
              </ol>
            </div>
            <button aria-hidden="true" class="container-large__right-arrow" tabindex="-1">
              <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M15,12c0,0.3-0.1,0.5-0.3,0.7l-4,4c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l3.3-3.3L9.3,8.7c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l4,4C14.9,11.5,15,11.7,15,12z"></path>
              </svg>
            </button>
          </div>
        </div>
        <div aria-label="progress" class="hidden-lg" role="group">
          <span class="sr-only">
            Progress summary
          </span>
          <ol class="container-small-medium">
            <li class="container-small-medium__count">
              <agl-ds-p bottommargin="none" styledas="md">
                Step
                <agl-ds-text fontweight="semibold">
                  2
                </agl-ds-text>
                of
                <agl-ds-text fontweight="semibold">
                  9
                </agl-ds-text>
                <span class="sr-only">
                  Active step Internet setup
                </span>
              </agl-ds-p>
            </li>
            <li class="container-small-medium__next">
              <agl-ds-p bottommargin="none" styledas="md">
                Next step:
                <agl-ds-text fontweight="semibold">
                  Personal details
                </agl-ds-text>
              </agl-ds-p>
            </li>
          </ol>
        </div>
      </mock:shadow-root>
      <agl-ds-step description="Mobile setup" status="completed" step-id="step1" step-number="1">
        <mock:shadow-root>
          <li class="completed has-icon step" role="listitem" tabindex="0">
            <span class="sr-only">
              completed step 1
            </span>
            <span class="completed step__circle">
              <span aria-hidden="true" class="step__icon">
                svg contents from: src/assets/agl_ds_stepper_completed.svg
              </span>
            </span>
            Mobile setup
          </li>
        </mock:shadow-root>
      </agl-ds-step>
      <agl-ds-step description="Energy setup" status="error" step-id="step2" step-number="2">
        <mock:shadow-root>
          <li class="error has-icon step" role="listitem" tabindex="0">
            <span class="sr-only">
              error step 2
            </span>
            <span aria-hidden="true" class="step--error">
              svg contents from: src/assets/agl_ds_stepper_step_error.svg
            </span>
            Energy setup
          </li>
        </mock:shadow-root>
      </agl-ds-step>
      <agl-ds-step description="Internet setup" status="active" step-id="step3" step-number="3">
        <mock:shadow-root>
          <li class="active has-icon step" role="listitem" tabindex="0">
            <span class="sr-only">
              active step
            </span>
            <span class="active step__circle">
              3
            </span>
            Internet setup
          </li>
        </mock:shadow-root>
      </agl-ds-step>
      <agl-ds-step description="Personal details" status="Incomplete" step-id="step4" step-number="4">
        <mock:shadow-root>
          <li class="has-icon incomplete step" role="listitem" tabindex="0">
            <span class="sr-only">
              incomplete step
            </span>
            <span class="incomplete step__circle">
              4
            </span>
            Personal details
          </li>
        </mock:shadow-root>
      </agl-ds-step>
    </agl-ds-stepper>
    `);
  });
});
