import { Component, ComponentInterface, h, Host, Element } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { StepperService } from './stepper.service';

@Component({
  tag: 'agl-ds-stepper',
  styleUrl: 'stepper.component.scss',
  shadow: true
})
export class StepperComponent implements ComponentInterface {
  @Element() host: HTMLAglDsStepperElement;
  private stepperService: StepperService;
  private outerDivElement: HTMLDivElement;
  private innerOlElement: HTMLOListElement;
  private leftArrowButtonElement: HTMLButtonElement;
  private rightArrowButtonElement: HTMLButtonElement;
  private currentStep: HTMLSpanElement;
  private currentStepMobile: HTMLSpanElement;

  private activeStepNumberDsTextElement: HTMLAglDsTextElement;
  private totalStepNumberDsTextElement: HTMLAglDsTextElement;
  private nextStepNumberDsTextElement: HTMLAglDsTextElement;
  private nextStepContainerElement: HTMLLIElement;

  private pagePosition: { pageLeftPosition?: string; pageLastStepElement?: Element }[] = [];
  private currentPageIndex: number = 0;

  private onResize() {
    this.prepareMobileLayout();
    this.preparePagePosition();
  }

  private preparePagePosition(): void {
    const outerDivOffsetRight = this?.outerDivElement?.offsetWidth;
    const stepElements: Element[] = (this?.innerOlElement?.children[0] as HTMLSlotElement).assignedElements();
    let pageWidth: number = 0;
    this.pagePosition = [];

    if (stepElements?.length > 0) {
      stepElements.forEach((ele: HTMLElement, index: number) => {
        const eleClientRec = ele?.getBoundingClientRect();
        const eleLeft = eleClientRec?.left - this.outerDivElement?.offsetLeft;
        if (index === 0) {
          this.pagePosition.push({ pageLeftPosition: eleLeft + 'px' });
        }
        pageWidth += eleClientRec.width;

        if (pageWidth >= outerDivOffsetRight) {
          // once the page end is reached, setting the last step element of the page
          // this last step element will have gradient style applied
          this.pagePosition[this.pagePosition?.length - 1].pageLastStepElement = ele?.firstElementChild;
          this.pagePosition.push({ pageLeftPosition: '-' + eleLeft + 'px' });
          pageWidth = eleClientRec?.width;
        }
      });
      this.innerOlElement.style.left = this.pagePosition[0]?.pageLeftPosition;
      this.displayArrows();
    }
  }

  private prepareMobileLayout(): void {
    this.stepperService = new StepperService(this.innerOlElement);
    const stepperMobileModel = this.stepperService.getStepperMobileDataModel();
    if (stepperMobileModel) {
      this.activeStepNumberDsTextElement.innerHTML = stepperMobileModel?.activeStepNumber?.toString();
      this.totalStepNumberDsTextElement.innerHTML = stepperMobileModel?.stepCount?.toString();

      if (stepperMobileModel.nextStepName) {
        this.nextStepNumberDsTextElement.innerHTML = stepperMobileModel?.nextStepName;
      } else {
        this.nextStepContainerElement.style.display = 'none';
      }
    }
    this.currentStepMobile.innerText = 'Active step ' + stepperMobileModel.activeStepName;
    const activeStep = Array.from(this.host.children).find((el) => el.shadowRoot.querySelector('.active'));
    this.currentStep.innerText = (activeStep as HTMLElement)?.shadowRoot.querySelector('li').innerText;
  }

  private moveStepperToLeft(): void {
    if (this.currentPageIndex > 0) {
      this.currentPageIndex--;
    }
    this.navigateStepperDirection();
  }

  private moveStepperToRight(): void {
    if (this.currentPageIndex < this?.pagePosition.length - 1) {
      this.currentPageIndex++;
    }
    this.navigateStepperDirection();
  }

  private navigateStepperDirection(): void {
    const nextPageDetails = this.pagePosition[this.currentPageIndex];
    this.displayArrows();
    //  for some reason left transition isn't applied when the below statement is executed without set timeout
    // hence we have the set timeout wrapping this left assignment statement
    setTimeout(() => {
      this.innerOlElement.style.left = nextPageDetails.pageLeftPosition;
    }, 0);
  }

  private displayArrows() {
    const displayLeftArrow = this?.currentPageIndex > 0;
    const displayRightArrow = this?.pagePosition?.length - this?.currentPageIndex > 1;

    this.leftArrowButtonElement.style.display = !displayLeftArrow ? 'none' : 'inline-block';
    this.rightArrowButtonElement.style.display = !displayRightArrow ? 'none' : 'inline-block';
  }
  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-stepper', 'agl-ds-step']);
  }

  componentDidLoad() {
    this.prepareMobileLayout();
    this.preparePagePosition();
    window.addEventListener('resize', this.onResize.bind(this));
  }

  render() {
    return (
      <Host>
        <div class="visible-lg-only" role="group" aria-label="progress">
          <div class="container-large">
            <button
              ref={(el) => (this.leftArrowButtonElement = el)}
              onClick={() => this.moveStepperToLeft()}
              class="container-large__left-arrow"
              tabindex="-1"
              aria-hidden="true"
            >
              <svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M15,12c0,0.3-0.1,0.5-0.3,0.7l-4,4c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l3.3-3.3L9.3,8.7c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l4,4C14.9,11.5,15,11.7,15,12z"></path>
              </svg>
            </button>
            <div class="container-large__outer" ref={(el) => (this.outerDivElement = el)}>
              <span id="currentStep" class="sr-only" ref={(el) => (this.currentStep = el)}></span>
              <ol role="list" class="container-large__inner" ref={(el) => (this.innerOlElement = el)} aria-labelledby="currentStep">
                <slot />
              </ol>
            </div>
            <button
              ref={(el) => (this.rightArrowButtonElement = el)}
              onClick={() => this.moveStepperToRight()}
              class="container-large__right-arrow"
              tabindex="-1"
              aria-hidden="true"
            >
              <svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M15,12c0,0.3-0.1,0.5-0.3,0.7l-4,4c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l3.3-3.3L9.3,8.7c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l4,4C14.9,11.5,15,11.7,15,12z"></path>
              </svg>
            </button>
          </div>
        </div>

        <div class="hidden-lg" aria-label="progress" role="group">
          <span class="sr-only">Progress summary</span>
          <ol class="container-small-medium">
            <li class="container-small-medium__count">
              <agl-ds-p bottomMargin="none" styledAs="md">
                Step <agl-ds-text fontWeight="semibold" ref={(el) => (this.activeStepNumberDsTextElement = el)}></agl-ds-text> of{' '}
                <agl-ds-text ref={(el) => (this.totalStepNumberDsTextElement = el)} fontWeight="semibold"></agl-ds-text>
                <span class="sr-only" ref={(el) => (this.currentStepMobile = el)}></span>
              </agl-ds-p>
            </li>
            <li class="container-small-medium__next" ref={(el) => (this.nextStepContainerElement = el)}>
              <agl-ds-p styledAs="md" bottomMargin="none">
                Next step: <agl-ds-text fontWeight="semibold" ref={(el) => (this.nextStepNumberDsTextElement = el)}></agl-ds-text>
              </agl-ds-p>
            </li>
          </ol>
        </div>
      </Host>
    );
  }
}
