import { Component, ComponentInterface, Element, Event, EventEmitter, h, Host, Prop } from '@stencil/core';

/**
 *@slot tile-heading - The content placed in will appear in the upper half of the tile if the content is also filled, else appear in the tile by itself
 *@slot tile-content - The content placed in will appear in the lower half of the tile if the heading is also filled, else appear in the tile by itself
 */

@Component({
  tag: 'agl-ds-tile',
  styleUrl: 'tile.component.scss',
  shadow: true
})
export class TileComponent implements ComponentInterface {
  private hasHeadingSlot: boolean;
  private hasContentSlot: boolean;

  /**
   *this component as HTML Element
   */
  @Element() hostElement: HTMLAglDsTileElement;

  /**
   * Will show an "active" blue border if true around the tile
   */
  @Prop() active: boolean = false;

  /**
   * Will show a box shadow on hover if true
   */
  @Prop() hoverable: boolean = true;

  /**
   * Name for the tile, used to identify it in onclick events
   */
  @Prop() tileId: string = 'tile';

  /**
   * Provide screen reader users with additional context or to convey information not available in HTML alone
   */
  @Prop() srContext?: string = '';

  /**
   * Theme colour to apply to the top edge of the tile
   */
  @Prop() theme: string = 'none';

  /**
   * Emits an event containing the `name` property when tile is clicked
   */
  @Event() tileClicked: EventEmitter<string>;

  private handleClick() {
    this.tileClicked.emit(this.tileId);
  }

  componentWillLoad() {
    this.hasHeadingSlot = !!this.hostElement.querySelector('[slot="tile-heading"]');
    this.hasContentSlot = !!this.hostElement.querySelector('[slot="tile-content"]');
  }

  render() {
    return (
      <Host onClick={() => this.handleClick()}>
        <div class={{ tile: true, 'tile--active': this.active, 'tile--hoverable': this.hoverable, ['tile__theme--' + this.theme]: true }}>
          <agl-ds-segmented-container>
            {this.hasHeadingSlot && (
              <div slot="section-1">
                <slot name="tile-heading"></slot>
              </div>
            )}
            {this.hasContentSlot && (
              <div slot="section-2">
                <slot name="tile-content"></slot>
              </div>
            )}
          </agl-ds-segmented-container>
        </div>
      </Host>
    );
  }
}
