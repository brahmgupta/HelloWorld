# agl-ds-tile



<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                                                                                              | Type      | Default  |
| ----------- | ------------ | -------------------------------------------------------------------------------------------------------- | --------- | -------- |
| `active`    | `active`     | Will show an "active" blue border if true around the tile                                                | `boolean` | `false`  |
| `hoverable` | `hoverable`  | Will show a box shadow on hover if true                                                                  | `boolean` | `true`   |
| `srContext` | `sr-context` | Provide screen reader users with additional context or to convey information not available in HTML alone | `string`  | `''`     |
| `theme`     | `theme`      | Theme colour to apply to the top edge of the tile                                                        | `string`  | `'none'` |
| `tileId`    | `tile-id`    | Name for the tile, used to identify it in onclick events                                                 | `string`  | `'tile'` |


## Events

| Event         | Description                                                        | Type                  |
| ------------- | ------------------------------------------------------------------ | --------------------- |
| `tileClicked` | Emits an event containing the `name` property when tile is clicked | `CustomEvent<string>` |


## Slots

| Slot             | Description                                                                                                                      |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `"tile-content"` | The content placed in will appear in the lower half of the tile if the heading is also filled, else appear in the tile by itself |
| `"tile-heading"` | The content placed in will appear in the upper half of the tile if the content is also filled, else appear in the tile by itself |


## Dependencies

### Depends on

- [agl-ds-segmented-container](../../layout/segmented-container)

### Graph
```mermaid
graph TD;
  agl-ds-tile --> agl-ds-segmented-container
  style agl-ds-tile fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
