import { newSpecPage } from '@stencil/core/testing';
import { TileComponent } from './tile.component';

describe('tile component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [TileComponent],
      html: `<agl-ds-tile theme="primary02"></agl-ds-tile>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-tile theme="primary02">
        <mock:shadow-root>
          <div class="tile tile--hoverable tile__theme--primary02">
            <agl-ds-segmented-container></agl-ds-segmented-container>
          </div>
        </mock:shadow-root>
      </agl-ds-tile>`
    );
  });
  it('should render with the correct class applied for the active attribute', async () => {
    const page = await newSpecPage({
      components: [TileComponent],
      html: `<agl-ds-tile theme="primary01-tint-60" active="true"></agl-ds-tile>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-tile active="true" theme="primary01-tint-60">
        <mock:shadow-root>
          <div class="tile tile--active tile--hoverable tile__theme--primary01-tint-60">
            <agl-ds-segmented-container></agl-ds-segmented-container>
          </div>
        </mock:shadow-root>
      </agl-ds-tile>`
    );
    const activeClass = page.root.shadowRoot.querySelector(`div.tile--active`);
    expect(activeClass).toBeTruthy();
  });
});
