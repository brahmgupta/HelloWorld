import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import TileNotes from './readme.md';

export default {
  title: 'Composite/Tile'
};

export const Tile = () => {
  const optionTheme = select(
    'Theme',
    [
      'none',
      'primary01',
      'primary02',
      'secondary01',
      'secondary02',
      'secondary03',
      'secondary04',
      'tertiary01',
      'tertiary02',
      'tertiary03',
      'tertiary04'
    ],
    'secondary01'
  );
  const optionTint = select('Tint', ['', '-tint-80', '-tint-60'], '');
  const optionActive = select('active', [true, false], false);
  const optionHoverable = select('hoverable', [true, false], false);

  return html`
    <div style="display:flex; flex-wrap:wrap;">
      <div style="margin:16px; width:300px; height:194px;">
        <agl-ds-spacer orientation="vertical"></agl-ds-spacer>
        <agl-ds-text styled-as="lg">heading + content fields</agl-ds-text>
        <agl-ds-tile
          id="hac"
          theme="${optionTheme}${optionTint} "
          active="${optionActive}"
          hoverable="${optionHoverable}"
          tileId="heading and content tile"
        >
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">Heading</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Edit</agl-ds-link>
          </div>
          <div slot="tile-content" style="height:96px; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">Some great content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">Some smaller but still great content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </div>

      <div style="margin:16px; width:300px; height:194px;">
        <agl-ds-spacer orientation="vertical"></agl-ds-spacer>
        <agl-ds-text styled-as="lg">empty</agl-ds-text>
        <agl-ds-tile
          id="empty"
          theme="${optionTheme}${optionTint} "
          active="${optionActive}"
          hoverable="${optionHoverable}"
          tileId="empty only"
        ></agl-ds-tile>
      </div>

      <div style="margin:16px; width:300px; height:200px;">
        <agl-ds-spacer orientation="vertical"></agl-ds-spacer>
        <agl-ds-text styled-as="lg">heading slot only</agl-ds-text>
        <agl-ds-tile
          id="ho"
          theme="${optionTheme}${optionTint} "
          active="${optionActive}"
          hoverable="${optionHoverable}"
          tileId="heading only"
        >
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">A lonely heading</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Edit</agl-ds-link>
          </div>
        </agl-ds-tile>
      </div>

      <div style="margin:16px; width:300px; height:194px;">
        <agl-ds-spacer orientation="vertical"></agl-ds-spacer>
        <agl-ds-text styled-as="lg">content slot only</agl-ds-text>
        <agl-ds-tile
          id="co"
          theme="${optionTheme}${optionTint} "
          active="${optionActive}"
          hoverable="${optionHoverable}"
          tileId="content only"
        >
          <div slot="tile-content" style="height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">Some lonely content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">Some smaller but still lonely content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </div>
    </div>

    <script>
      // Attaching listeners for click events
      // In Angular application, use (tileClicked) instead
      (() => {
        let tiles = [
          document.querySelector('#hac'),
          document.querySelector('#empty'),
          document.querySelector('#ho'),
          document.querySelector('#co')
        ];
        tiles.forEach((tile) => tile.addEventListener('tileClicked', ({ detail }) => alert(detail + ' clicked!')));
      })();
    </script>
  `;
};

Tile.parameters = { notes: TileNotes };
Tile.storyname = 'Tile';
