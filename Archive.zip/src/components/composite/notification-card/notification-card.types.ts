export type NotificationType = 'information' | 'warning' | 'error';
