import { text, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Notification Card'
};

export const NotificationCardWithImage = () => html`
  <div>
    <agl-ds-notification
      type="${select('Type', ['information', 'warning', 'error'], 'information')}"
      image-path="${select(
        'Image Path',
        ['../../assets/pot-plants-2.svg', '../../assets/pot-plants.svg'],
        '../../assets/pot-plants-2.svg'
      )}"
      heading="${text('Heading', `Ok, we can help you find out. Leave your details and we’ll contact you.`)}"
      message="${text('Message', `Complete the form and we’ll supply instructions and the form you’ll need to pass on to the home owner `)}"
      button-text="${text('Button Text', 'Button text')}"
      button-type="${select('Button type', ['primary', 'secondary', 'tertiary'], 'secondary')}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-icon="${select('Show Icon', [true, false], true)}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
      <slot>
        <agl-ds-p>${text('Slot content', 'For all your essential services - electricity, gas & NBN')}</agl-ds-p>
      </slot>
    </agl-ds-notification>
  </div>
`;

NotificationCardWithImage.parameters = { notes };

export const NotificationCardWithButton = () => html`
  <div>
    <agl-ds-notification
      type="warning"
      heading="${text('Heading', `Ok, we can help you find out. Leave your details and we’ll contact you.`)}"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      button-text="${text('Button text', 'Button text')}"
      button-type="${select('Button type', ['primary', 'secondary', 'tertiary'], 'secondary')}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
  <div style="padding-top: 10px;">
    <agl-ds-notification
      type="information"
      heading="${text('Heading', `Ok, we can help you find out. Leave your details and we’ll contact you.`)}"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      button-text="${text('Button text', 'Button text')}"
      button-type="${select('Button type', ['primary', 'secondary', 'tertiary'], 'secondary')}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
`;

NotificationCardWithButton.parameters = { notes };

export const NotificationCardWithHeader = () => html`
  <div>
    <agl-ds-notification
      type="warning"
      heading="${text('Heading', `Ok, we can help you find out. Leave your details and we’ll contact you.`)}"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
  <div style="padding-top: 10px;">
    <agl-ds-notification
      type="information"
      heading="${text('Heading', `Ok, we can help you find out. Leave your details and we’ll contact you.`)}"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
`;

NotificationCardWithHeader.parameters = { notes };

export const NotificationCardWithLink = () => html`
  <div>
    <agl-ds-notification
      type="warning"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
  <div style="padding-top: 10px;">
    <agl-ds-notification
      type="information"
      message="${text('Message', `A simple message telling me what’s going down on screen. `)}"
      link-text="${text('Link text', `Example Link`)}"
      link-open-new-window="${select('Link Open in new window', [true, false], true)}"
      link-href="${text('Link href', 'https://www.agl.com.au')}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
`;

NotificationCardWithLink.storyName = 'Notification Card with Link';
NotificationCardWithLink.parameters = { notes };

export const NotificationCardBasic = () => html`
  <div>
    <agl-ds-notification
      type="warning"
      message="${text('Message', `A simple message telling me what’s going down on screen.`)}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
  <div style="padding-top: 10px;">
    <agl-ds-notification
      type="information"
      message="${text('Message', `A simple message telling me what’s going down on screen.`)}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
  <div style="padding-top: 10px;">
    <agl-ds-notification
      type="error"
      message="${text('Message', `A simple message telling me what’s going down on screen.`)}"
      show-close-icon="${select('Show Close Icon', [true, false], false)}"
    >
    </agl-ds-notification>
  </div>
`;

NotificationCardBasic.parameters = { notes };
