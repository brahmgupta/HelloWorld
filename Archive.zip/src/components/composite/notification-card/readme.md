# agl-ds-notification



<!-- Auto Generated Below -->


## Properties

| Property            | Attribute              | Description                                             | Type                                     | Default         |
| ------------------- | ---------------------- | ------------------------------------------------------- | ---------------------------------------- | --------------- |
| `buttonText`        | `button-text`          | The text for action button                              | `string`                                 | `undefined`     |
| `buttonType`        | `button-type`          | The type for action button                              | `"primary" \| "secondary" \| "tertiary"` | `'secondary'`   |
| `heading`           | `heading`              | The heading for the navigation card                     | `string`                                 | `''`            |
| `imagePath`         | `image-path`           | The path of the image to be displayed on the banner     | `string`                                 | `undefined`     |
| `linkHref`          | `link-href`            | The destination url for the notification link click     | `string`                                 | `''`            |
| `linkOpenNewWindow` | `link-open-new-window` | Determines if the destination is opened in a new window | `boolean`                                | `true`          |
| `linkText`          | `link-text`            | The text for link                                       | `string`                                 | `undefined`     |
| `message`           | `message`              | The message for the navigation card                     | `string`                                 | `''`            |
| `showCloseIcon`     | `show-close-icon`      | Determines if the close icon needs to be displayed      | `boolean`                                | `false`         |
| `showIcon`          | `show-icon`            | Determines if the icon needs to be displayed            | `boolean`                                | `true`          |
| `type`              | `type`                 | The type of  Notification                               | `"error" \| "information" \| "warning"`  | `'information'` |


## Events

| Event            | Description                      | Type                |
| ---------------- | -------------------------------- | ------------------- |
| `buttonClick`    | Action Button Click event        | `CustomEvent<any>`  |
| `closeIconClick` | Fires when close Icon is clicked | `CustomEvent<void>` |


## Slots

| Slot               | Description                                                                                                             |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------- |
| `"call-to-action"` | (optional) The content placed in this slot should be agl-ds-button, and or agl-ds-link                                  |
| `"default"`        | The content placed in this slot is intended to replace the message and link properties and will appear just below them. |
| `"message"`        | (optional) The content placed in this slot is authorable via AEM RTE, it could be any semantic HMTL tag                 |


## Dependencies

### Used by

 - [agl-ds-error-summary](../error-summary)

### Depends on

- [agl-ds-h4](../../core/heading/h4)
- [agl-ds-p](../../core/paragraph)
- [agl-ds-link](../../core/link)
- [agl-ds-button](../../core/button)

### Graph
```mermaid
graph TD;
  agl-ds-notification --> agl-ds-h4
  agl-ds-notification --> agl-ds-p
  agl-ds-notification --> agl-ds-link
  agl-ds-notification --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  agl-ds-error-summary --> agl-ds-notification
  style agl-ds-notification fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
