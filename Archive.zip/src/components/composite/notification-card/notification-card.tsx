import { Component, h, Host, Prop, Element, Event, EventEmitter, ComponentInterface } from '@stencil/core';
import { ButtonType } from '../../core/button/button.types';
import warningIcon from '../../../assets/notification_alert.svg';
import informationIcon from '../../../assets/notification_information.svg';
import errorIcon from '../../../assets/notification_error.svg';
import iconClose from '../../../assets/icon-close.svg';
import { resizeSVGsForEdge } from '../../../global/utils/utils';
import { NotificationType } from './notification-card.types';

/**
 *@slot default - The content placed in this slot is intended to replace the message and link properties and will appear just below them.
 *@slot message - (optional) The content placed in this slot is authorable via AEM RTE, it could be any semantic HMTL tag
 *@slot call-to-action - (optional) The content placed in this slot should be agl-ds-button, and or agl-ds-link
 */
@Component({
  tag: 'agl-ds-notification',
  styleUrl: 'notification-card.scss',
  shadow: true
})
export class NotificationCardComponent implements ComponentInterface {
  private hasMessageSlot: boolean;
  private hasCtaSlot: boolean;
  private svgSpan: HTMLSpanElement;

  /**
   *this component as HTML Element
   */
  @Element() hostElement: HTMLAglDsNotificationElement;

  /**
   * The type of  Notification
   */
  @Prop() type: NotificationType = 'information';

  /**
   * The path of the image to be displayed on the banner
   */
  @Prop() imagePath: string;

  /**
   * The heading for the navigation card
   */
  @Prop() heading: string = '';

  /**
   * The message for the navigation card
   */
  @Prop() message: string = '';

  /**
   * The text for action button
   */
  @Prop() buttonText: string;

  /**
   * The type for action button
   */
  @Prop() buttonType: ButtonType = 'secondary';

  /**
   * Action Button Click event
   */

  // TODO change the name of buttonClick from generic name to something more specific
  // This may cause issues in a consuming SPA because of the generic name
  @Event({ bubbles: true, composed: true }) buttonClick: EventEmitter;

  /**
   * The text for link
   */
  @Prop() linkText: string;

  /**
   * The destination url for the notification link click
   */
  @Prop() linkHref: string = '';

  /**
   * Determines if the destination is opened in a new window
   */
  @Prop() linkOpenNewWindow: boolean = true;

  /**
   * Determines if the icon needs to be displayed
   */
  @Prop() showIcon: boolean = true;

  /**
   * Determines if the close icon needs to be displayed
   */
  @Prop() showCloseIcon: boolean = false;

  /**
   * Fires when close Icon is clicked
   */
  @Event() closeIconClick: EventEmitter<void>;

  componentWillLoad() {
    this.hasMessageSlot = !!this.hostElement.querySelector('[slot="message"]');
    this.hasCtaSlot = !!this.hostElement.querySelector('[slot="call-to-action"]');
  }

  componentDidLoad() {
    resizeSVGsForEdge(this.svgSpan, '24', '24', '32', '32');
  }

  /**
   * Get icon based on Notification type
   */
  private getNotificationIcon = (): string => {
    switch (this.type) {
      case 'warning':
        return warningIcon;
      case 'error':
        return errorIcon;
      case 'information':
        return informationIcon;
      default:
        return null;
    }
  };

  /**
   * Handle click event of button
   */
  private handleButtonClick = (): void => {
    if (this.buttonClick) {
      this.buttonClick.emit();
    }
  };

  /**
   * Handle click event of close icon
   */
  private handleCloseButtonClick = (): void => {
    if (this.closeIconClick) {
      this.closeIconClick.emit();
    }
  };

  render() {
    if (!(['error', 'information', 'warning'] as NotificationType[]).includes(this.type)) {
      throw new Error(this.type + ' is not a valid NotificationType');
    }

    return (
      <Host>
        <div
          class={{
            'notification-container': true,
            ['notification-container--' + this.type]: true,
            'notification-container--with-heading': !!this.heading
          }}
        >
          {this.showIcon && this.getNotificationIcon() && (
            <div class={{ 'notification-container__icon': true }}>
              <span ref={(el) => (this.svgSpan = el)} aria-hidden="true" innerHTML={this.getNotificationIcon()}></span>
            </div>
          )}
          <div class={{ 'notification-container__content': true }}>
            {!!this.heading && (
              <div class={{ 'notification-container__heading': true }}>
                <agl-ds-h4>{this.heading}</agl-ds-h4>
              </div>
            )}

            <div
              class={{
                'notification-container--warning--message': this.type === 'warning' && !this.heading,
                'notification-container--error--message': this.type === 'error' && !this.heading
              }}
            >
              {(!!this.message || !!this.linkText) && (
                <agl-ds-p bottom-margin="none">
                  {this.message}&nbsp;
                  {!!this.linkText && (
                    <agl-ds-link srContext={this.heading + this.message} href={this.linkHref} openNewWindow={this.linkOpenNewWindow}>
                      {this.linkText}
                    </agl-ds-link>
                  )}
                </agl-ds-p>
              )}
              <slot />
              {this.hasMessageSlot && <slot name="message" />}
            </div>

            {!!this.buttonText && (
              <div class={{ 'notification-container__button': true }}>
                <agl-ds-button onClick={this.handleButtonClick} type={this.buttonType}>
                  {this.buttonText}
                </agl-ds-button>
              </div>
            )}

            {this.hasCtaSlot && <slot name="call-to-action" />}
          </div>
          {!!this.imagePath && (
            <div class={{ 'notification-container__image': true }}>
              <img aria-hidden="true" src={this.imagePath} />
            </div>
          )}
          {this.showCloseIcon && (
            <button
              class={{
                'notification-container__close-button': true
              }}
              aria-label="close the notification"
              onClick={() => {
                this.handleCloseButtonClick();
              }}
            >
              <img aria-hidden="true" src={iconClose} />
            </button>
          )}
        </div>
      </Host>
    );
  }
}
