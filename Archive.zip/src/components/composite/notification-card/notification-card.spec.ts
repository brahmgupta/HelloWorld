import { newSpecPage } from '@stencil/core/testing';
import { NotificationCardComponent } from './notification-card';

describe('Notification Card Component', () => {
  describe('With given props', () => {
    const notificationExpectedhtml = `
    <agl-ds-notification button-text="Button text"
        button-type="primary"
        heading="Heading text"
        image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
        link-href="https://www.agl.com.au"
        link-open-new-window="true"
        link-text="Example Link"
        message="Message text"
        type="warning">
        <mock:shadow-root>
      <div class="notification-container notification-container--warning notification-container--with-heading">
        <div class="notification-container__icon">
          <span aria-hidden="true">
            svg contents from: src/assets/notification_alert.svg
          </span>
        </div>
        <div class="notification-container__content">
          <div class="notification-container__heading">
            <agl-ds-h4>
              Heading text
            </agl-ds-h4>
          </div>
          <div>
            <agl-ds-p bottom-margin="none">
              Message text
              <agl-ds-link href="https://www.agl.com.au" openNewWindow=""  srcontext="Heading textMessage text">
                Example Link
              </agl-ds-link>
            </agl-ds-p>
            <slot></slot>
          </div>
          <div class="notification-container__button">
            <agl-ds-button type="primary">
              Button text
            </agl-ds-button>
          </div>
        </div>
        <div class="notification-container__image">
          <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
        </div>
      </div>
    </mock:shadow-root>
    </agl-ds-notification>`;

    it('should render my component', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
                type="warning"
                heading="Heading text"
                message="Message text"
                button-text="Button text"
                button-type="primary"
                link-text="Example Link"
                link-open-new-window="true"
                link-href="https://www.agl.com.au"
                >
            </agl-ds-notification>`
      });

      expect(page.root).toEqualHtml(notificationExpectedhtml);
    });
  });

  describe('Icon', () => {
    it('should render information type component without Icon', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="information"
                message="Message text" show-icon="false" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('.notification-container__icon');

      expect(element).toBeNull();
    });

    it('should render information type component with Icon', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="information"
                  message="Message text" show-icon="true">
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('.notification-container__icon');

      expect(element).toBeTruthy();
    });

    it('should render warning type component with Icon', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
                message="Message text" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('.notification-container__icon');
      expect(element).toBeTruthy();

      const image = element.querySelector('span');
      expect(image).toBeTruthy();
      expect(image.getAttribute('aria-hidden')).toEqual('true');
    });
  });

  describe('Header', () => {
    it('should render the component without header', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text"
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-h4');

      expect(element).toBeNull();
    });

    it('should render the component with Header', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text"
                heading="Heading text">
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-h4');

      expect(element).toBeTruthy();
    });
  });

  describe('Message and Link', () => {
    it('should render the component without Link', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-link');

      expect(element).toBeNull();
    });

    it('should render the component with Link', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="warning"
                  message="Message text"
                  link-text="Example Link"
                  link-open-new-window="true"
                  link-href="https://www.agl.com.au" >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-link');

      expect(element).toBeTruthy();
      expect(element.getAttribute('href')).toEqual('https://www.agl.com.au');
    });

    it('should suppress margin of message', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-p');

      expect(element).toBeTruthy();
      expect(element.getAttribute('bottom-margin')).toEqual('none');
    });
  });

  describe('Button', () => {
    it('should render the component without Button', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-button');

      expect(element).toBeNull();
    });

    it('should render the component with Primary Button', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="warning"
                  message="Message text"
                  button-text="Button text"
                  button-type="primary" >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('agl-ds-button');

      expect(element).toBeTruthy();
      expect(element.getAttribute('type')).toEqual('primary');
    });

    it('should dispatch "buttonClick" event', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="warning"
                  message="Message text"
                  button-text="Button text"
                  button-type="primary" >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const buttonClickSpy = jest.fn();
      page.win.addEventListener('buttonClick', buttonClickSpy);

      const element = page.doc.querySelector('agl-ds-button');
      element.dispatchEvent(new Event('click'));

      await page.waitForChanges();
      expect(buttonClickSpy).toHaveBeenCalled();
    });
  });

  describe('Image', () => {
    it('should render the component without Image', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text" >
                </agl-ds-notificationtype=>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('.notification-container__image');

      expect(element).toBeNull();
    });

    it('should render the component with Image', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
                  type="warning" >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('.notification-container__image');
      expect(element).toBeTruthy();

      const image = element.querySelector('img');
      expect(image).toBeTruthy();
      expect(image.getAttribute('aria-hidden')).toEqual('true');
      expect(image.getAttribute('src')).toEqual('https://via.placeholder.com/240x360/0bf/fff?text=A');
    });
  });

  describe('Close Icon', () => {
    it('should render the component without Close Icon', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                type="warning"
                message="Message text" >
              </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('button');

      expect(element).toBeNull();
    });

    it('should render the component with Close Icon', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="warning"
                  message="Message text"
                  show-close-icon >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const element = page.doc.querySelector('button');

      expect(element).toBeTruthy();
      expect(element.getAttribute('class')).toEqual('notification-container__close-button');
    });

    it('should dispatch "closeIconClick" event', async () => {
      const page = await newSpecPage({
        components: [NotificationCardComponent],
        html: `<agl-ds-notification
                  type="warning"
                  message="Message text"
                  show-close-icon >
                </agl-ds-notification>`,
        supportsShadowDom: false
      });

      const closeIconClickSpy = jest.fn();
      page.win.addEventListener('closeIconClick', closeIconClickSpy);

      const element = page.doc.querySelector('button');
      element.dispatchEvent(new Event('click'));

      await page.waitForChanges();
      expect(closeIconClickSpy).toHaveBeenCalled();
    });
  });
});
