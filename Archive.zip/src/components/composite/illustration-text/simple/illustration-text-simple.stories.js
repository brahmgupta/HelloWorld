import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Illustration Text'
};

export const IllustrationTextSimple = () => html`
  <agl-ds-illustration-text-simple
    illustration-path="${text('illustration path', './../../../../assets/girl-with-tick.svg')}"
    illustration-position="${select('illustration position', ['top', 'right'], 'top')}"
    size="${select('Size', ['xs', 'sm', 'md', 'lg', 'xl'], 'sm')}"
  >
    <span slot="title">
      <agl-ds-h1 styled-as="title4">${text('Title', 'This quote has expired')}</agl-ds-h1>
    </span>
    <span slot="content-line-1">${text('content-line-1', 'Sorry, your quote (ref. number 30108765) is no longer valid.')}</span>
    <span slot="content-line-2">
      ${text(
        'content-line-2',
        'To discuss your options, get in touch from 9:00am - 5:30pm AEST weekdays.  Shannon Smith, Email ssmith@agl.com.au, Phone (03) 8633 6221'
      )}
    </span>
  </agl-ds-illustration-text-simple>
`;

IllustrationTextSimple.storyName = 'illustration text simple';
IllustrationTextSimple.parameters = { notes };
