import { newSpecPage } from '@stencil/core/testing';
import { IllustrationComponent } from '../../../core/illustration/illustration.component';
import { IllustrationTextSimpleComponent } from './illustration-text-simple.component';

describe('Illustration Text Simple component', () => {
  it('should render the component with the image on top', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="sm">
        <span slot="title">
          Title
        </span>
        <span slot="content-line-1">
          content-line-1
        </span>
        <span slot="content-line-2">
          content-line-2
        </span>
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-illustration-text-simple illustration-path="./../../../../assets/girl-with-tick.svg" illustration-size="sm">
      <mock:shadow-root>
        <div class="wrapper">
          <div>
            <agl-ds-illustration imagepath="./../../../../assets/girl-with-tick.svg" size="lg" bottom-margin="none"></agl-ds-illustration>
          </div>
          <div class="wrapper__text">
            <div>
              <slot name="title"></slot>
            </div>
            <agl-ds-p>
              <slot name="content-line-1"></slot>
            </agl-ds-p>
            <agl-ds-p>
              <slot name="content-line-2"></slot>
            </agl-ds-p>
          </div>
        </div>
      </mock:shadow-root>
      <span slot="title">
        Title
      </span>
      <span slot="content-line-1">
        content-line-1
      </span>
      <span slot="content-line-2">
        content-line-2
      </span>
    </agl-ds-illustration-text-simple>
    `);
  });

  it('should render the component with the image on the right', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-position="right"
        illustration-size="sm">
        <span slot="title">
          Title
        </span>
        <span slot="content-line-1">
          content-line-1
        </span>
        <span slot="content-line-2">
          content-line-2
        </span>
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-illustration-text-simple illustration-path="./../../../../assets/girl-with-tick.svg" illustration-position="right" illustration-size="sm">
      <mock:shadow-root>
        <div class="wrapper align-image-right">
          <div class="wrapper__illustration">
            <agl-ds-illustration imagepath="./../../../../assets/girl-with-tick.svg" size="lg" bottom-margin="none"></agl-ds-illustration>
          </div>
          <div class="align-text-left wrapper__text">
            <div>
              <slot name="title"></slot>
            </div>
            <agl-ds-p>
              <slot name="content-line-1"></slot>
            </agl-ds-p>
            <agl-ds-p>
              <slot name="content-line-2"></slot>
            </agl-ds-p>
          </div>
        </div>
      </mock:shadow-root>
      <span slot="title">
        Title
      </span>
      <span slot="content-line-1">
        content-line-1
      </span>
      <span slot="content-line-2">
        content-line-2
      </span>
    </agl-ds-illustration-text-simple>
    `);
  });

  it('should render the component without the content-line-1 if its not passed', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="sm">
        <span slot="title">
          Title
        </span>
        <span slot="content-line-2">
          content-line-2
        </span>
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-illustration-text-simple illustration-path="./../../../../assets/girl-with-tick.svg" illustration-size="sm">
      <mock:shadow-root>
        <div class="wrapper">
          <div>
            <agl-ds-illustration imagepath="./../../../../assets/girl-with-tick.svg" size="lg" bottom-margin="none"></agl-ds-illustration>
          </div>
          <div class="wrapper__text">
            <div>
              <slot name="title"></slot>
            </div>
            <agl-ds-p>
              <slot name="content-line-1"></slot>
            </agl-ds-p>
            <agl-ds-p>
              <slot name="content-line-2"></slot>
            </agl-ds-p>
          </div>
        </div>
      </mock:shadow-root>
      <span slot="title">
        Title
      </span>
      <span slot="content-line-2">
        content-line-2
      </span>
    </agl-ds-illustration-text-simple>
    `);
  });

  it('should render the component without the content-line-2 if its not passed', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="sm">
        <span slot="title">
          Title
        </span>
        <span slot="content-line-1">
          content-line-1
        </span>
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-illustration-text-simple illustration-path="./../../../../assets/girl-with-tick.svg" illustration-size="sm">
      <mock:shadow-root>
        <div class="wrapper">
          <div>
            <agl-ds-illustration imagepath="./../../../../assets/girl-with-tick.svg" size="lg" bottom-margin="none"></agl-ds-illustration>
          </div>
          <div class="wrapper__text">
            <div>
              <slot name="title"></slot>
            </div>
            <agl-ds-p>
              <slot name="content-line-1"></slot>
            </agl-ds-p>
            <agl-ds-p>
              <slot name="content-line-2"></slot>
            </agl-ds-p>
          </div>
        </div>
      </mock:shadow-root>
      <span slot="title">
        Title
      </span>
      <span slot="content-line-1">
        content-line-1
      </span>
    </agl-ds-illustration-text-simple>
    `);
  });

  it('should render the component with a xs image', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent, IllustrationComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="xs">
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-illustration-text-simple[illustration-size="xs"]');

    expect(element).toBeTruthy();
  });

  it('should render the component with a sm image', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent, IllustrationComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="sm">
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-illustration-text-simple[illustration-size="sm"]');

    expect(element).toBeTruthy();
  });

  it('should render the component with a md image', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent, IllustrationComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="md">
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-illustration-text-simple[illustration-size="md"]');

    expect(element).toBeTruthy();
  });

  it('should render the component with a lg image', async () => {
    const page = await newSpecPage({
      components: [IllustrationTextSimpleComponent, IllustrationComponent],
      html: `
      <agl-ds-illustration-text-simple
        illustration-path="./../../../../assets/girl-with-tick.svg"
        illustration-size="lg">
      </agl-ds-illustration-text-simple>
      `,
      supportsShadowDom: false
    });

    const element = page.doc.querySelector('agl-ds-illustration-text-simple[illustration-size="lg"]');

    expect(element).toBeTruthy();
  });
});
