export type IllustrationPosition = 'top' | 'right';
