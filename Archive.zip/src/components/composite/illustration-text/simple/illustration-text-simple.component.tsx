import { Component, ComponentInterface, h, Prop } from '@stencil/core';
import { IllustrationSize } from '../../../core/illustration/illustration.types';
import { IllustrationPosition } from './illustration-text-simple.types';

/**
 * @slot title - The title to be displayed.
 * @slot content-line-1 - A slot to include the first line of the description.
 * @slot content-line-2 - A slot to include the second line of the description.
 */

@Component({
  tag: 'agl-ds-illustration-text-simple',
  styleUrl: 'illustration-text-simple.component.scss',
  shadow: true
})
export class IllustrationTextSimpleComponent implements ComponentInterface {
  /**
   * The illustration path for the component
   */
  @Prop() illustrationPath: string = '';

  /**
   * The size of the illustration
   */
  @Prop() size: IllustrationSize = 'lg';

  /**
   * The position of the illustration to be displayed
   */
  @Prop() illustrationPosition: IllustrationPosition = 'top';

  render() {
    return (
      <div class={{ wrapper: true, 'align-image-right': this.illustrationPosition === 'right' }}>
        <div class={{ wrapper__illustration: this.illustrationPosition === 'right' }}>
          <agl-ds-illustration imagePath={this.illustrationPath} size={this.size} bottom-margin="none"></agl-ds-illustration>
        </div>
        <div class={{ wrapper__text: true, 'align-text-left': this.illustrationPosition === 'right' }}>
          <div>
            <slot name="title" />
          </div>
          <agl-ds-p>
            <slot name="content-line-1" />
          </agl-ds-p>
          <agl-ds-p>
            <slot name="content-line-2" />
          </agl-ds-p>
        </div>
      </div>
    );
  }
}
