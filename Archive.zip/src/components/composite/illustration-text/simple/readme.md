# agl-ds-illustration-text-simple



<!-- Auto Generated Below -->


## Properties

| Property               | Attribute               | Description                                      | Type                                   | Default |
| ---------------------- | ----------------------- | ------------------------------------------------ | -------------------------------------- | ------- |
| `illustrationPath`     | `illustration-path`     | The illustration path for the component          | `string`                               | `''`    |
| `illustrationPosition` | `illustration-position` | The position of the illustration to be displayed | `"right" \| "top"`                     | `'top'` |
| `size`                 | `size`                  | The size of the illustration                     | `"lg" \| "md" \| "sm" \| "xl" \| "xs"` | `'lg'`  |


## Slots

| Slot               | Description                                           |
| ------------------ | ----------------------------------------------------- |
| `"content-line-1"` | A slot to include the first line of the description.  |
| `"content-line-2"` | A slot to include the second line of the description. |
| `"title"`          | The title to be displayed.                            |


## Dependencies

### Depends on

- [agl-ds-illustration](../../../core/illustration)
- [agl-ds-p](../../../core/paragraph)

### Graph
```mermaid
graph TD;
  agl-ds-illustration-text-simple --> agl-ds-illustration
  agl-ds-illustration-text-simple --> agl-ds-p
  style agl-ds-illustration-text-simple fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
