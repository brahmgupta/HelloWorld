import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Error summary'
};

export const Default = () => html`
  <agl-ds-error-summary id="errorSummary" invalid-field-count="${text('invalidFieldCount', '1')}" first-invalid-input-id="myInput1">
  </agl-ds-error-summary>

  <label>
    <input
      type="checkbox"
      id="chk1"
      onClick="document.getElementById('errorSummary').setAttribute('invalid-field-count', (document.getElementById('chk1').checked? '2':'1') );"
    />
    Toggle invalid field count from 1 to 2
  </label>
  <br />
  <label>
    <input
      type="checkbox"
      id="chk2"
      onClick="document.getElementById('errorSummary').setAttribute('first-invalid-input-id', (document.getElementById('chk2').checked? 'myInput2':'myInput1') );"
    />
    Toggle invalid field target for the "Go To error" link from myInput1 to myInput2 (defined further down the page)
  </label>
  <div style="height: 2000px"></div>
  <label>
    <input id="myInput1" type="text" value="myInput1" />
  </label>
  <div style="height: 2000px"></div>
  <label>
    <agl-ds-checkbox checked="false" type="validation" validation-text="Please accept the terms and conditions" checkbox-id="myInput2">
      check box label
    </agl-ds-checkbox>
  </label>
`;

Default.storyName = 'Error summary';
Default.parameters = { notes };
