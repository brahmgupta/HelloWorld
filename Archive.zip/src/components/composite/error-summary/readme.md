# agl-ds-app-error-summary



<!-- Auto Generated Below -->


## Properties

| Property              | Attribute                | Description                                                         | Type     | Default     |
| --------------------- | ------------------------ | ------------------------------------------------------------------- | -------- | ----------- |
| `firstInvalidInputId` | `first-invalid-input-id` | The id of the first input to receive focus on the click of the link | `string` | `undefined` |
| `invalidFieldCount`   | `invalid-field-count`    | The count of errors to be displayed in the message                  | `number` | `0`         |


## Methods

### `setFocus() => Promise<void>`

Sets focus to the Error summary

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-manual-address-entry](../addresssearch/manual-address-entry)

### Depends on

- [agl-ds-notification](../notification-card)
- [agl-ds-spacer](../../core/spacer)

### Graph
```mermaid
graph TD;
  agl-ds-error-summary --> agl-ds-notification
  agl-ds-error-summary --> agl-ds-spacer
  agl-ds-notification --> agl-ds-h4
  agl-ds-notification --> agl-ds-p
  agl-ds-notification --> agl-ds-link
  agl-ds-notification --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  agl-ds-manual-address-entry --> agl-ds-error-summary
  style agl-ds-error-summary fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
