import { newSpecPage } from '@stencil/core/testing';
import { ErrorSummaryComponent } from './error-summary.component';

describe('Error Summary Component', () => {
  it('should render my component with the correct message and link text for invalid-field-count = 1', async () => {
    const page = await newSpecPage({
      components: [ErrorSummaryComponent],
      html: ` <agl-ds-error-summary
                invalid-field-count= "1"
                first-invalid-input-id="myInput1">
              </agl-ds-error-summary>`,
      supportsShadowDom: false
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-error-summary first-invalid-input-id="myInput1" invalid-field-count="1">
        <host>
          <div class="notification-card">
            <agl-ds-notification linkhref="#myInput1" linktext="Go to error" message="There’s a problem. Fix the issue below to continue." type="error"></agl-ds-notification>
          </div>
          <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
        </host>
      </agl-ds-error-summary>
      `
    );
  });

  it('should render my component with the correct message and link text for invalid-field-count = 2', async () => {
    const page = await newSpecPage({
      components: [ErrorSummaryComponent],
      html: ` <agl-ds-error-summary
                invalid-field-count= "2"
                first-invalid-input-id="myInput1">
              </agl-ds-error-summary>`,
      supportsShadowDom: false
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-error-summary first-invalid-input-id="myInput1" invalid-field-count="2">
        <host>
          <div class="notification-card">
            <agl-ds-notification linkhref="#myInput1" linktext="Go to first error" message="There’s a problem. Fix the 2 issues below to continue." type="error"></agl-ds-notification>
          </div>
          <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
        </host>
      </agl-ds-error-summary>
      `
    );
  });
});
