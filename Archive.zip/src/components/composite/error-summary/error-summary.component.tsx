import { Component, ComponentInterface, h, Method, Prop, Watch } from '@stencil/core';

@Component({
  tag: 'agl-ds-error-summary',
  styleUrl: 'error-summary.component.scss',
  shadow: true
})
export class ErrorSummaryComponent implements ComponentInterface {
  private message: string = 'There’s a problem. Fix the $$invalidFieldCount issues below to continue.';
  private errorLinkText: string = 'Go to first error';
  private tmpMessage: string = '';
  private tmpErrorLinkText: string = '';
  private notificationCard: HTMLAglDsNotificationElement;

  /**
   * The count of errors to be displayed in the message
   */
  @Prop() invalidFieldCount: number = 0;
  /**
   * The id of the first input to receive focus on the click of the link
   */
  @Prop() firstInvalidInputId: string;

  @Watch('invalidFieldCount')
  updateInvalidFieldCount() {
    this.tmpMessage = this.message;
    this.tmpErrorLinkText = this.errorLinkText;
    if (this.invalidFieldCount === 1) {
      this.tmpMessage = this.tmpMessage.replace('$$invalidFieldCount issues', 'issue');
      this.tmpErrorLinkText = this.errorLinkText.replace('first ', '');
    } else {
      this.tmpMessage = this.tmpMessage.replace('$$invalidFieldCount', this.invalidFieldCount.toString());
    }
  }

  componentWillLoad() {
    this.updateInvalidFieldCount();
  }

  /**
   * Sets focus to the Error summary
   */
  @Method()
  async setFocus() {
    setTimeout(() => this.notificationCard.shadowRoot.querySelector('agl-ds-link').shadowRoot.querySelector('a').focus());
  }

  render() {
    return (
      <host>
        <div class="notification-card">
          <agl-ds-notification
            ref={(el) => (this.notificationCard = el)}
            type="error"
            message={this.tmpMessage}
            linkText={this.tmpErrorLinkText}
            linkHref={`#${this.firstInvalidInputId}`}
            linkOpenNewWindow={false}
          ></agl-ds-notification>
        </div>
        <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
      </host>
    );
  }
}
