import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { TriptychComponent } from './triptych.component';

describe('Triptych component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [TriptychComponent],
      html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
            </agl-ds-triptych>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-triptych href="https://agl-design-system.azurewebsites.net/" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
          <mock:shadow-root>
          <agl-ds-card appearance="elevated" hoverable="">
            <div class="image-text-card-triptych">
              <div class="image-text-card-triptych__image">
                <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
              </div>
              <div class="image-text-card-triptych__content">
                <div class="title-container">
                  <div class="title-container__title">
                    <a href="https://agl-design-system.azurewebsites.net/">
                      <slot name="title"></slot>
                    </a>
                  </div>
                  <div class="title-container__chevron">
                    <agl-ds-icon icon="svg contents from: src/assets/agl_ficon_dig_chevron_right.svg" size="xs"></agl-ds-icon>
                  </div>
                </div>
                <div class="image-text-card-triptych__description">
                  <slot name="description"></slot>
                </div>
                <slot name="call-to-action"></slot>
              </div>
            </div>
          </agl-ds-card>
          </mock:shadow-root>
        </agl-ds-triptych>
    `);
  });

  describe('pass details to display the triptych with correct attributes', () => {
    let page: SpecPage;
    let hyperlink;

    it('should present a triptych with hyperlink enabled.', async () => {
      page = await newSpecPage({
        components: [TriptychComponent],
        html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
        </agl-ds-triptych>`,
        supportsShadowDom: false
      });
      hyperlink = await page.doc.querySelector('.title-container__title a');
      expect(hyperlink).toBeTruthy();
    });
  });

  it('should console.error when an invalid html tag is passed in via the title slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TriptychComponent],
      html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
      <p slot="title">dummy text</p>
      </agl-ds-triptych>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should not throw an error when an invalid html tag is passed in via the title slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TriptychComponent],
      html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
      <agl-ds-h2 slot="title">dummy text</agl-ds-h2>
      </agl-ds-triptych>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the description slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TriptychComponent],
      html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
      <p slot="description">dummy text</p>
      </agl-ds-triptych>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should not throw an error when an invalid html tag is passed in via the description slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TriptychComponent],
      html: `<agl-ds-triptych image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
      <agl-ds-p slot="description"><agl-ds-text>dummy text<agl-ds-text><agl-ds-p>dummy text<agl-ds-p><agl-ds-link>dummy text<agl-ds-link></agl-ds-p>
      </agl-ds-triptych>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });
});
