import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Image Text Card/Triptych'
};

export const Triptych = () => html`
  <agl-ds-triptych
    image-path="${text('Image path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}"
    href="${text('Hyperlink', 'https://agl-design-system.azurewebsites.net/')}"
  >
    <agl-ds-h3 styled-as="title5" appearance="highlight" class="hydrated" slot="title">
      ${text('Title', 'No lock in contracts')}
    </agl-ds-h3>
    <agl-ds-p styled-as="lg" font="fontfamily02" appearance="muted" slot="description">
      ${text(
        'Description',
        'With AGL Energy Insights, estimate which type of appliances are costing you the most at home. Use energy smarter and reduce your bill.'
      )}
    </agl-ds-p>
  </agl-ds-triptych>
`;

Triptych.storyName = 'triptych';
Triptych.parameters = { notes };
