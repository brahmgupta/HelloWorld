# agl-ds-triptych

<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                                                                          | Type                        | Default      |
| --------------- | ---------------- | ---------------------------------------------------------------------------------------------------- | --------------------------- | ------------ |
| `href`          | `href`           | The hyperlink value of the component                                                                 | `string`                    | `''`         |
| `imagePath`     | `image-path`     | The image path for the component                                                                     | `string`                    | `''`         |
| `imagePosition` | `image-position` | The position of the image Options are `left` and `right` Default sets to `left` here.                | `"left" \| "right"`         | `'left'`     |
| `variant`       | `variant`        | The variant of the Component Options are `triptych` and `spotlight` Default sets to `triptych` here. | `"spotlight" \| "triptych"` | `'triptych'` |


## Slots

| Slot            | Description                                                             |
| --------------- | ----------------------------------------------------------------------- |
| `"description"` | A slot to include the description.                                      |
| `"title"`       | The hyperlink title should provide separately to have HREF lable on it. |


## Dependencies

### Depends on

- [agl-ds-card](../../../core/card)
- [agl-ds-icon](../../../core/icon)

### Graph
```mermaid
graph TD;
  agl-ds-triptych --> agl-ds-card
  agl-ds-triptych --> agl-ds-icon
  style agl-ds-triptych fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
