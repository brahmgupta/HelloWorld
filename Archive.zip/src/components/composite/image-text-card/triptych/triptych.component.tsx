import { Component, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { ImageTextCard } from '../image-text-card.component';
import { Variants, ImagePositions } from '../image-text-card.types';

/**
 * @slot title - The hyperlink title should provide separately to have HREF lable on it.
 * @slot description - A slot to include the description.
 *
 */

@Component({
  tag: 'agl-ds-triptych',
  styleUrl: './../image-text-card.component.scss',
  shadow: true
})
export class TriptychComponent implements ComponentInterface {
  @Element() host: HTMLAglDsTriptychElement;
  /**
   * The image path for the component
   */
  @Prop() imagePath: string = '';

  /**
   * The variant of the Component
   * Options are `triptych` and `spotlight`
   * Default sets to `triptych` here.
   */
  @Prop() variant: Variants = 'triptych';

  /**
   * The hyperlink value of the component
   */
  @Prop() href: string = '';

  /**
   * The position of the image
   * Options are `left` and `right`
   * Default sets to `left` here.
   */
  @Prop() imagePosition: ImagePositions = 'left';

  render() {
    return (
      <ImageTextCard
        host={this.host}
        imagePath={this.imagePath}
        variant={this.variant}
        href={this.href}
        imagePosition={this.imagePosition}
        appearance="elevated"
      />
    );
  }
}
