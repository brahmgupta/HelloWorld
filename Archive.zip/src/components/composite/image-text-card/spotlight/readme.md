# agl-ds-spotlight


<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                                                     | Type                        | Default       |
| ----------------- | ------------------- | ----------------------------------------------------------------------------------------------- | --------------------------- | ------------- |
| `appearance`      | `appearance`        | Set the appearance of the spotlight component. Default to `"flat"`                              | `"elevated" \| "flat"`      | `'flat'`      |
| `hideImageMobile` | `hide-image-mobile` | Hides the image on mobile viewports                                                             | `boolean`                   | `true`        |
| `href`            | `href`              | The hyperlink value for the component                                                           | `string`                    | `''`          |
| `imagePath`       | `image-path`        | The image path for the component                                                                | `string`                    | `''`          |
| `imagePosition`   | `image-position`    | The position of the Image Options are `left` and `right` Default sets to `left`                 | `"left" \| "right"`         | `'left'`      |
| `variant`         | `variant`           | The variant of the Component Options are `triptych` and `spotlight` Default sets to `spotlight` | `"spotlight" \| "triptych"` | `'spotlight'` |


## Slots

| Slot               | Description                                                                                                      |
| ------------------ | ---------------------------------------------------------------------------------------------------------------- |
| `"call-to-action"` | The details of the call to action button. AEM need to be configure the button type/mode so, this is a open slot. |
| `"description"`    | A slot to include the description.                                                                               |


## Dependencies

### Depends on

- [agl-ds-card](../../../core/card)
- [agl-ds-icon](../../../core/icon)

### Graph
```mermaid
graph TD;
  agl-ds-spotlight --> agl-ds-card
  agl-ds-spotlight --> agl-ds-icon
  style agl-ds-spotlight fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
