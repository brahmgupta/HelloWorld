import { select, text, boolean } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Image Text Card/Spotlight'
};

export const Spotlight = () => html`
  <agl-ds-spotlight
    image-path="${text('Image path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}"
    image-position="${select('Image position', ['right', 'left'], 'left')}"
    appearance="${select('Appearance', ['elevated', 'flat'], 'flat')}"
    hide-image-mobile="${boolean('Hide image on mobile', true)}"
  >
    <span slot="title">
      <agl-ds-h3 styled-as="title1" appearance="default" class="hydrated">${text('Title', '')} </agl-ds-h3>
    </span>
    <span slot="description">
      <agl-ds-p styled-as="xl" font="fontfamily02" appearance="default">
        ${text(
          'Description',
          'Shine a light on your energy usage with the AGL Energy app. Track usage, get bill estimates, enter meter readings, pay bills and manage your account on the go.'
        )}
      </agl-ds-p>
    </span>
    <span slot="call-to-action">
      <agl-ds-button type="secondary" href="https://www.agl.com.au" open-new-window="false">
        ${text('Call to Action text', 'See our plans')}
      </agl-ds-button>
    </span>
  </agl-ds-spotlight>
`;

Spotlight.storyName = 'spotlight';
Spotlight.parameters = { notes };
