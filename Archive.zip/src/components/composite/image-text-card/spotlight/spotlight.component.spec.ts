import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { SpotlightComponent } from './spotlight.component';

describe('Spotlight component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [SpotlightComponent],
      html: `<agl-ds-spotlight image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" appearance="flat" hideImageMobile="true"></agl-ds-spotlight>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-spotlight image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" appearance="flat" hideImageMobile="true">
          <mock:shadow-root>
            <agl-ds-card appearance="flat" corner="rounded">
              <div class="image-text-card image-text-card-spotlight image-text-card-spotlight--left">
                <div class="image-text-card-spotlight__image image-text-card-spotlight__image-hide-mobile">
                  <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
                </div>
                <div class="image-text-card-spotlight__content">
                  <slot name="description"></slot>
                  <slot name="call-to-action"></slot>
                </div>
              </div>
              </agl-ds-card>
          </mock:shadow-root>
        </agl-ds-spotlight>
    `);
  });

  describe('pass details to display the spotlight with image position left', () => {
    let page: SpecPage;
    let imagePosition;

    it('should present a spotlight with image position left.', async () => {
      page = await newSpecPage({
        components: [SpotlightComponent],
        html: `<agl-ds-spotlight image-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
        </agl-ds-spotlight>`,
        supportsShadowDom: false
      });
      imagePosition = await page.doc.querySelector('.image-text-card-spotlight--left');
      expect(imagePosition).toBeTruthy();
    });
  });

  describe('pass details to display the spotlight with image position right', () => {
    let page: SpecPage;
    let imagePosition;

    it('should present a spotlight with image position right.', async () => {
      page = await newSpecPage({
        components: [SpotlightComponent],
        html: `<agl-ds-spotlight image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" image-position="right">
        </agl-ds-spotlight>`,
        supportsShadowDom: false
      });
      imagePosition = await page.doc.querySelector('.image-text-card-spotlight--right');
      expect(imagePosition).toBeTruthy();
    });
  });
});
