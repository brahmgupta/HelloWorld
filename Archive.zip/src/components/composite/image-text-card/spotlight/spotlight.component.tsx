import { Component, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { CardAppearance } from '../../../core/card/card.types';
import { ImageTextCard } from '../image-text-card.component';
import { Variants, ImagePositions, SpotlightAppearance } from '../image-text-card.types';

/**
 * @slot description - A slot to include the description.
 * @slot call-to-action - The details of the call to action button. AEM need to be configure the button type/mode so, this is a open slot.
 */

@Component({
  tag: 'agl-ds-spotlight',
  styleUrl: './../image-text-card.component.scss',
  shadow: true
})
export class SpotlightComponent implements ComponentInterface {
  @Element() host: HTMLAglDsSpotlightElement;
  /**
   * The image path for the component
   */
  @Prop() imagePath: string = '';

  /**
   * The variant of the Component
   * Options are `triptych` and `spotlight`
   * Default sets to `spotlight`
   */
  @Prop() variant: Variants = 'spotlight';

  /**
   * The hyperlink value for the component
   */
  @Prop() href: string = '';

  /**
   * The position of the Image
   * Options are `left` and `right`
   * Default sets to `left`
   */
  @Prop() imagePosition: ImagePositions = 'left';

  /**
   * Set the appearance of the spotlight component. Default to `"flat"`
   */
  @Prop() appearance: SpotlightAppearance = 'flat';

  /**
   * Hides the image on mobile viewports
   */
  @Prop() hideImageMobile: boolean = true;

  render() {
    const mappedAppearance: CardAppearance =
      ([
        { key: 'flat', value: 'flat' },
        { key: 'elevated', value: 'elevated' }
      ] as {
        key: SpotlightAppearance;
        value: CardAppearance;
      }[]).find((a) => a.key === this.appearance)?.value || 'flat';

    return (
      <ImageTextCard
        host={this.host}
        imagePath={this.imagePath}
        variant="spotlight"
        href={this.href}
        imagePosition={this.imagePosition}
        appearance={mappedAppearance}
        hideImageMobile={this.hideImageMobile}
      />
    );
  }
}
