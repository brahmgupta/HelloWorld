import { FunctionalComponent, h, Host } from '@stencil/core';
import { CardAppearance } from '../../core/card/card.types';
import iconChevron from '../../../assets/agl_ficon_dig_chevron_right.svg';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { Variants, ImagePositions } from './image-text-card.types';

interface ImageTextCardProps {
  host: HTMLAglDsTriptychElement;
  imagePath: string;
  variant: Variants;
  href: string;
  imagePosition: ImagePositions;
  appearance: CardAppearance;
  hideImageMobile?: boolean;
}

export const ImageTextCard: FunctionalComponent<ImageTextCardProps> = ({
  host,
  imagePath,
  variant,
  href,
  imagePosition,
  appearance,
  hideImageMobile
}) => {
  if (variant === 'triptych') {
    checkSlottedContentForInvalidHTML(host.querySelector('[slot="title"]'), [
      'agl-ds-text',
      'agl-ds-h2',
      'agl-ds-h3',
      'agl-ds-h4',
      'agl-ds-h5',
      'agl-ds-h6'
    ]);
    checkSlottedContentForInvalidHTML(host.querySelector('[slot="description"]'), ['agl-ds-text', 'agl-ds-p', 'agl-ds-link']);
    return (
      <Host>
        <agl-ds-card appearance={appearance} hoverable={href !== '' ? true : false}>
          <div
            class={{
              ['image-text-card-' + variant]: true
            }}
          >
            <div class={{ ['image-text-card-' + variant + '__image']: true }}>
              <img aria-hidden="true" src={imagePath} />
            </div>
            <div class={{ ['image-text-card-' + variant + '__content']: true }}>
              <div class={{ 'title-container': true }}>
                <div class={{ 'title-container__title': true }}>
                  <a href={href}>
                    <slot name="title" />
                  </a>
                </div>
                <div class={{ 'title-container__chevron': true }}>
                  <agl-ds-icon icon={iconChevron} size="xs"></agl-ds-icon>
                </div>
              </div>
              <div class={{ ['image-text-card-' + variant + '__description']: true }}>
                <slot name="description" />
              </div>
              <slot name="call-to-action" />
            </div>
          </div>
        </agl-ds-card>
      </Host>
    );
  }
  return (
    <Host>
      <agl-ds-card appearance={appearance} corner="rounded">
        <div
          class={{
            'image-text-card': true,
            ['image-text-card-' + variant]: true,
            ['image-text-card-' + variant + '--' + imagePosition]: true
          }}
        >
          <div
            class={{ ['image-text-card-' + variant + '__image']: true, 'image-text-card-spotlight__image-hide-mobile': hideImageMobile }}
          >
            <img aria-hidden="true" src={imagePath} />
          </div>
          <div class={{ ['image-text-card-' + variant + '__content']: true }}>
            <slot name="description" />
            <slot name="call-to-action" />
          </div>
        </div>
      </agl-ds-card>
    </Host>
  );
};
