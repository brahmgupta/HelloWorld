export type Variants = 'spotlight' | 'triptych';

export type ImagePositions = 'left' | 'right';

export type SpotlightAppearance = 'flat' | 'elevated';
