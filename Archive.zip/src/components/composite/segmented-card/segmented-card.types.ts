export type HeaderType = 'default' | 'with-content' | 'with-space';
