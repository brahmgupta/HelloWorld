import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Composite/Segmented Card'
};

export const SegmentedCard = () => html`
  <agl-ds-segmented-card
    theme="${select(
      'Theme',
      [
        'primary01',
        'primary02',
        'secondary01',
        'secondary02',
        'secondary03',
        'secondary04',
        'tertiary01',
        'tertiary02',
        'tertiary03',
        'tertiary04'
      ],
      'primary01'
    )}${select('Tint', ['', '-tint-80', '-tint-60'], '')} "
    header-type="${select('Header type', ['default', 'with-content', 'with-space'], 'default')}"
    header-content="${text('Header content', '1st MONTH FREE')}"
  >
    <div slot="card-heading">
      <agl-ds-h2 styled-as="title5" appearance="default" bottom-margin="none">${text('Card heading', 'NBN 25')}</agl-ds-h2>
      <div class="segmented-card-heading">
        <agl-ds-p bottom-margin="none">
          <agl-ds-text styled-as="display01">
            <span>${text('Card title - lg', '$50')}</span>
          </agl-ds-text>
          <agl-ds-text styled-as="xl">
            <span>${text('Card title - sm', 'per month')}</span>
          </agl-ds-text>
        </agl-ds-p>
      </div>
      <agl-ds-p styled-as="md" bottom-margin="none"> ${text('Card description', 'Minimum cost $55 or $145 with modem')} </agl-ds-p>
    </div>
    <div slot="card-promo">
      <agl-ds-promo-card icon-path="${text('Promo icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="title">${text('Promo title', 'Save $10 off your monthly bill')}</span>
        <span slot="description">
          <p>${text('Promo description', 'when bundled with an energy plan')}</p>
        </span>
      </agl-ds-promo-card>
    </div>
    <div slot="card-image">
      <img aria-hidden="true" src="${text('Image path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}" />
    </div>
    <div slot="selling-point">
      <agl-ds-p styled-as="xl" bottom-margin="none">
        ${text('Selling point description', 'Best for basic internet browsing and HD video')}
      </agl-ds-p>
    </div>
    <div slot="feature-list">
      <agl-ds-h3 styled-as="title6" appearance="default">Feature List heading (optional)</agl-ds-h3>
      <agl-ds-feature-item icon-path="${text('Feature item 1 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p> ${text('Feature item 1 description 1', '19Mbps evening speed (7pm-11pm)')} </agl-ds-p>
        </span>
      </agl-ds-feature-item>
      <agl-ds-feature-item icon-path="${text('Feature item 2 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p bottom-margin="none">${text('Feature item 1 description 2', 'Unlimited Data')}</agl-ds-p>
        </span>
      </agl-ds-feature-item>
    </div>
    <div slot="benefit-list">
      <agl-ds-h3 styled-as="title6" appearance="default">Benefit List heading (optional)</agl-ds-h3>
      <agl-ds-feature-item icon-path="${text('Benefit item 1 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p>${text('Benefit item 1 description', "Rates won't go up for 2 years")}</agl-ds-p>
        </span>
      </agl-ds-feature-item>
      <agl-ds-feature-item icon-path="${text('Benefit item 2 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p bottom-margin="none">${text('Benefit item 2 description', 'No lock-in contract')}</agl-ds-p>
        </span>
      </agl-ds-feature-item>
    </div>
    <div slot="other-list">
      <agl-ds-h3 styled-as="title6" appearance="default">Other List heading (optional)</agl-ds-h3>
      <agl-ds-feature-item icon-path="${text('Other item 1 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p>
            ${text('Other item 1 description', 'BYO modem or receive an AGL modem for $0 when you stay connected with us for 12 months')}
          </agl-ds-p>
        </span>
      </agl-ds-feature-item>
      <agl-ds-feature-item icon-path="${text('Other item 2 icon path', 'https://via.placeholder.com/240x360/0bf/fff?text=A')}">
        <span slot="description">
          <agl-ds-p bottom-margin="none">
            ${text(
              'Other item 2 description',
              'Add a Home Phone plan for $10/mth (you’ll need an AGL modem). – Not available Fixed Wireless connections.'
            )}
          </agl-ds-p>
        </span>
      </agl-ds-feature-item>
    </div>
    <div slot="support-information">
      <agl-ds-h3 styled-as="title6" appearance="default">Support Information heading (optional)</agl-ds-h3>
      <agl-ds-p styled-as="md" bottom-margin="none">
        ${text(
          'Support information description',
          'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat'
        )}
      </agl-ds-p>
    </div>
    <div slot="calls-to-action">
      <div class="cta-section">
        <agl-ds-button
          type="${select('CTA button type', ['primary', 'secondary', 'tertiary'], 'primary')}"
          href="https://www.agl.com.au"
          rel="relative"
          open-new-window="${select('CTA open in new window', ['true', 'false'], 'false')}"
        >
          ${text('CTA button text', 'Choose this plan')}
        </agl-ds-button>
      </div>
      <div class="cta-section">
        <agl-ds-link
          styled-as="md"
          appearance="default"
          open-new-window="${select('CTA link 1 open in new window', [true, false], true)}"
          href="${text('CTA link 1 href', 'https://www.agl.com.au')}"
          sr-context="${text('CTA link 1 sr-context', 'sr-context to further inform the user')}"
        >
          ${text('CTA link 1 text', 'Key fact sheet')}
        </agl-ds-link>
      </div>
      <div class="cta-section">
        <agl-ds-link
          styled-as="md"
          appearance="default"
          open-new-window="${select('CTA link 2 open in new window', [true, false], true)}"
          href="${text('CTA link 2 href', 'https://www.agl.com.au')}"
          sr-context="${text('CTA link 2 sr-context', 'sr-context to further inform the user')}"
        >
          ${text('CTA link 2 text', 'Critical information summary')}
        </agl-ds-link>
      </div>
    </div>
  </agl-ds-segmented-card>
`;

SegmentedCard.parameters = { notes };
SegmentedCard.storyname = 'Segmented card';

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.cta-section {margin-bottom: 24px;}');
style.sheet.insertRule('agl-ds-segmented-card img {width:100%; object-fit:cover; height:auto; max-height:205px;}');
