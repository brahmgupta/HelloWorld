import { Component, Host, Element, Prop, h, ComponentInterface } from '@stencil/core';
import { generateRandomNumber } from '../../../global/utils/utils';
import { HeaderType } from './segmented-card.types';

/**
 *@slot card-heading - The content placed in this slot is authorable via AEM RTE, it could be semantic H (2-3) tag for title, followed by 2 P tags for title & description. If used in SPA it should be agl-ds-h(2-3) and 2 agl-ds-p tags  bottom-margin="none"
 *@slot card-promo - The content placed in this slot should be agl-ds-promo-card
 *@slot card-image - The content placed in this slot is authorable via AEM RTE, should be an IMG tag. If used in a SPA, it should be agl-ds-illustration
 *@slot selling-point - The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p styledAs="xl" bottom-margin="none"
 *@slot feature-list - The content placed in this slot is authorable via AEM RTE, should be semantic H (3-4) tag for title (optional), followed by a number of agl-ds-feature-item. If used in a SPA, it should be agl-ds-h(3-4), followed by a number of agl-ds-feature-item
 *@slot benefit-list - The content placed in this slot is authorable via AEM RTE, should be semantic H (3-4) tag for title (optional), followed by a number of agl-ds-feature-item. If used in a SPA, it should be agl-ds-h(3-4), followed by a number of agl-ds-feature-item
 *@slot feature-list - The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"
 *@slot other-list - The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"
 *@slot support-information - The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"
 *@slot calls-to-action - The content placed in this slot should be agl-ds-button, and or agl-ds-link
 */

@Component({
  tag: 'agl-ds-segmented-card',
  styleUrl: 'segmented-card.component.scss',
  shadow: true
})
export class SegmentedCardComponent implements ComponentInterface {
  /**
   * internalised Unique ID for the binding Accordion button to its panel
   */
  private uniqueID: string = generateRandomNumber();
  private hasCardHeadingSlot: boolean;
  private hasPromoSlot: boolean;
  private hasImageSlot: boolean;
  private hasSellingPointSlot: boolean;
  private hasFeatureListSlot: boolean;
  private hasBenefitListSlot: boolean;
  private hasOtherListSlot: boolean;
  private hasSupportInformationSlot: boolean;
  private hasCallsToActionSlot: boolean;

  /**
   *this component as HTML Element
   */
  @Element() hostElement: HTMLAglDsSegmentedCardElement;

  /**
   * Theme colour to apply to the Product Card
   */
  @Prop() theme: string;

  /**
   * Header type.
   * default: coloured strip
   * with-content: text content
   * with-space: coloured strip with padding on top, which is used to align with other with-content cards
   */
  @Prop() headerType: HeaderType = 'default';

  /**
   * Header content (optional)
   */
  @Prop() headerContent?: string;

  componentWillLoad() {
    this.hasCardHeadingSlot = !!this.hostElement.querySelector('[slot="card-heading"]');
    this.hasPromoSlot = !!this.hostElement.querySelector('[slot="card-promo"]');
    this.hasImageSlot = !!this.hostElement.querySelector('[slot="card-image"]');
    this.hasSellingPointSlot = !!this.hostElement.querySelector('[slot="selling-point"]');
    this.hasFeatureListSlot = !!this.hostElement.querySelector('[slot="feature-list"]');
    this.hasBenefitListSlot = !!this.hostElement.querySelector('[slot="benefit-list"]');
    this.hasOtherListSlot = !!this.hostElement.querySelector('[slot="other-list"]');
    this.hasSupportInformationSlot = !!this.hostElement.querySelector('[slot="support-information"]');
    this.hasCallsToActionSlot = !!this.hostElement.querySelector('[slot="calls-to-action"]');
  }

  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    return (
      <Host>
        {this.headerType === 'with-space' && <div class="segmented-card__top-space" />}
        {this.headerType === 'with-content' && (
          <div class={{ 'segmented-card__header': true, ['segmented-card__header-theme--' + this.theme]: true }}>
            <agl-ds-text styled-as="lg" appearance="inverse" fontWeight="semibold">
              {this.headerContent}
            </agl-ds-text>
          </div>
        )}
        <agl-ds-card appearance="elevated">
          <div
            id={'segmented-card-' + this.uniqueID}
            class={{
              'segmented-card': true,
              'segmented-card__no-border-top': this.headerType === 'with-content',
              ['segmented-card__theme--' + this.theme]: true
            }}
          >
            {this.hasCardHeadingSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--card-heading': true }}>
                <slot name="card-heading" />
              </section>
            )}
            {this.hasPromoSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--promo': true }}>
                <slot name="card-promo" />
              </section>
            )}
            {this.hasImageSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--image': true }}>
                <div class="segmented-card__image--section">
                  <slot name="card-image" />
                </div>
              </section>
            )}
            {this.hasSellingPointSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--selling-point': true }}>
                <slot name="selling-point" />
              </section>
            )}
            {this.hasFeatureListSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--feature-list': true }}>
                <slot name="feature-list" />
              </section>
            )}
            {this.hasBenefitListSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--benefit-list': true }}>
                <slot name="benefit-list" />
              </section>
            )}
            {this.hasOtherListSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--other-list': true }}>
                <slot name="other-list" />
              </section>
            )}
            {this.hasSupportInformationSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--support-information': true }}>
                <slot name="support-information" />
              </section>
            )}
            {this.hasCallsToActionSlot && (
              <section class={{ 'segmented-card__section': true, 'segmented-card__section--calls-to-action': true }}>
                <slot name="calls-to-action" />
              </section>
            )}
          </div>
        </agl-ds-card>
      </Host>
    );
  }
}
