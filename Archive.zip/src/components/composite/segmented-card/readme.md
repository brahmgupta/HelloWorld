# agl-ds-segmented-card



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                                                                                                                                          | Type                                          | Default     |
| --------------- | ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------- | ----------- |
| `headerContent` | `header-content` | Header content (optional)                                                                                                                                            | `string`                                      | `undefined` |
| `headerType`    | `header-type`    | Header type. default: coloured strip with-content: text content with-space: coloured strip with padding on top, which is used to align with other with-content cards | `"default" \| "with-content" \| "with-space"` | `'default'` |
| `theme`         | `theme`          | Theme colour to apply to the Product Card                                                                                                                            | `string`                                      | `undefined` |


## Slots

| Slot                    | Description                                                                                                                                                                                                                                            |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `"benefit-list"`        | The content placed in this slot is authorable via AEM RTE, should be semantic H (3-4) tag for title (optional), followed by a number of agl-ds-feature-item. If used in a SPA, it should be agl-ds-h(3-4), followed by a number of agl-ds-feature-item |
| `"calls-to-action"`     | The content placed in this slot should be agl-ds-button, and or agl-ds-link                                                                                                                                                                            |
| `"card-heading"`        | The content placed in this slot is authorable via AEM RTE, it could be semantic H (2-3) tag for title, followed by 2 P tags for title & description. If used in SPA it should be agl-ds-h(2-3) and 2 agl-ds-p tags  bottom-margin="none"               |
| `"card-image"`          | The content placed in this slot is authorable via AEM RTE, should be an IMG tag. If used in a SPA, it should be agl-ds-illustration                                                                                                                    |
| `"card-promo"`          | The content placed in this slot should be agl-ds-promo-card                                                                                                                                                                                            |
| `"feature-list"`        | The content placed in this slot is authorable via AEM RTE, should be semantic H (3-4) tag for title (optional), followed by a number of agl-ds-feature-item. If used in a SPA, it should be agl-ds-h(3-4), followed by a number of agl-ds-feature-item |
| `"feature-list"`        | The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"                                                                                                               |
| `"other-list"`          | The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"                                                                                                               |
| `"selling-point"`       | The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p styledAs="xl" bottom-margin="none"                                                                                                 |
| `"support-information"` | The content placed in this slot is authorable via AEM RTE, should be p tag. If used in a SPA, it should be agl-ds-p bottom-margin="none"                                                                                                               |


## Dependencies

### Depends on

- [agl-ds-text](../../core/text)
- [agl-ds-card](../../core/card)

### Graph
```mermaid
graph TD;
  agl-ds-segmented-card --> agl-ds-text
  agl-ds-segmented-card --> agl-ds-card
  style agl-ds-segmented-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
