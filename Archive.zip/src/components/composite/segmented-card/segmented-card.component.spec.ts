jest.mock('../../../global/utils/utils', () => ({
  generateRandomNumber: () => 52
}));

import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { SegmentedCardComponent } from './segmented-card.component';

describe('segmented-card component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [SegmentedCardComponent],
      html: `<agl-ds-segmented-card theme="primary01-tint-60"></agl-ds-segmented-card>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-segmented-card theme="primary01-tint-60">
			<mock:shadow-root>
              <agl-ds-card appearance="elevated">
                  <div class="segmented-card segmented-card__theme--primary01-tint-60"  id="segmented-card-52">
                      
                  </div>
              </agl-ds-card>
            </mock:shadow-root>
		</agl-ds-segmented-card>`
    );
  });

  describe('pass details to display the segmented-card with correct attributes', () => {
    let page: SpecPage;
    let element;

    it('should present a segmented-card with correct ID', async () => {
      page = await newSpecPage({
        components: [SegmentedCardComponent],
        html: '<agl-ds-segmented-card></agl-ds-segmented-card> ',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('.segmented-card');
      expect(element.id).toEqual('segmented-card-52');
    });
  });
});
