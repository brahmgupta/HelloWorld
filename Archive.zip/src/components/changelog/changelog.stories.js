import * as cl from './../../../CHANGELOG.md';
import * as packageJson from './../../../package.json';

const allNotes = `${cl.default}`;

export default {
  title: 'Change log docs'
};

export const ChangeLog = () => `Click on the "Docs" tab above to see the changelog for version ${packageJson.default.version}.`;

ChangeLog.storyName = 'Change log';
ChangeLog.parameters = {
  notes: allNotes,
  storyshots: { disable: true } // no need to test this component
};
