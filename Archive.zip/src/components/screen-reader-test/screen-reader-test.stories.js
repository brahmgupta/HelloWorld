import { html } from 'lit-html';
import { script } from './script.js';

export default {
  title: 'Screen reader test page',
  parameters: {
    paddings: { disable: true }
  }
};

export const Default = () => {
  //apply the modal
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    document.getElementById('manualAddressEntry')?.setTriggerButton(() => {
      return document.querySelector('#modalTrigger');
    });
  }, 1000);
  return html`

  <agl-ds-screen-reader-test>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="top" id="xx">
      <div slot="banner"><agl-ds-banner-simple banner-text="Screen reader test page"></agl-ds-banner-simple></div>
      <div slot="stepper">
        <agl-ds-stepper>
          <agl-ds-step step-id="step1" step-number="1" description="Mobile setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step2" step-number="2" description="Energy setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step3" step-number="3" description="Internet setup" status="active"></agl-ds-step>
          <agl-ds-step step-id="step4" step-number="4" description="Personal details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step5" step-number="5" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step6" step-number="6" description="Review and submit" status="error"></agl-ds-step>
          <agl-ds-step step-id="step7" step-number="7" description="Completed" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step8" step-number="8" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step9" step-number="9" description="Billing details" status="Incomplete"></agl-ds-step>

        </agl-ds-stepper>
      </div>
      <div slot="error-summary">
        <agl-ds-error-summary class="hide-error-summary" id="errorSummary" invalid-field-count="1" first-invalid-input-id="checkboxInError"></agl-ds-error-summary>
      </div>
      <div slot="content">
        <div class="left-content">

          <agl-ds-h2>Composite components</agl-ds-h2>

          <agl-ds-h3>Address Search</agl-ds-h3>
          <agl-ds-address-search
            label="Connection address"
            placeholder="e.g. 123 Queen Street, Melbourne"
            debouce-time=" 600"
            base-url="https://qtruat-api.platform.agl.com.au/shared"
            subscription-key=""
            is-mailing-address="false"
            show-spinner="false"
            validation-text="There is an error"
            manual-address-heading="What address do you want to connect?"
            hint-text="e.g. 123 Queen Street, Melbourne"
            manual-address-option-text="Can't find address? Enter it manually"
            manual-address-option-highlight-text="Enter it manually"
          ></agl-ds-address-search>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>


          <agl-ds-h3>Manual address entry</agl-ds-h3>
          <agl-ds-button type="primary"  id="modalTrigger"  sr-context="This is the extra information that can be added to assist the reader"
            onClick="document.getElementById('manualAddressEntry').openModal()"
            >Show manual address</agl-ds-button>
            <agl-ds-p>This component fails accessibility due to a conflict of ids in the manual address part of the address search.</agl-ds-p>
            <agl-ds-manual-address-entry id="manualAddressEntry"
              heading="What address do you want connected?"
              include-po-box="true"></agl-ds-manual-address-entry>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Auto complete</agl-ds-h3>
          <agl-ds-autocomplete
            label="type test"
            has-error="false"
            validation-text="validation text"
            hint-text="hint text"
            options-string='[
                              {
                                "value": "test",
                                "text": "test"
                              },
                              {
                                "value": "test1",
                                "text": "test1"
                              },
                              {
                                "value": "testing123",
                                "text": "testing123"
                              },
                              {
                                "value": "testingautocomplete",
                                "text": "testing this entry will not be prefilled",
                                "doNotComplete": true,
                                "highlightText": "this entry will not be prefilled"
                              }
                            ]'
          ></agl-ds-autocomplete>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Banner callout</agl-ds-h3>
          <agl-ds-banner-callout appearance="default" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            <span slot="content">
              <agl-ds-h3 styled-as="title2" font="fontfamily02" bottom-margin="none">
                Already have an electricity or gas account with AGL?
              </agl-ds-h3>
              <agl-ds-p styled-as="lg">
                Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil
                impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Et harum quidem
                rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus
                id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.
              </agl-ds-p>
            </span>
          </agl-ds-banner-callout>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Banner simple</agl-ds-h3>
          <agl-ds-p>This component has been included as part of the "Core components in the simple container" story</agl-ds-p>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Guided banner</agl-ds-h3>
          <div class="storybook-background">
            <agl-ds-guided-banner image-path="../../assets/pot-plants.svg" has-back-button="true">
            <span slot="primary-heading">Let's get started.</span>
            <span slot="secondary-heading">Do you have a current AGL electricity or gas account?</span>
            <span slot="description">Typically takes about 3 mins to complete the virtual power plant signup.</span>
          </agl-ds-guided-banner>
        </div>

        <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
        <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

        <agl-ds-h3>Hero banner</agl-ds-h3>
            <agl-ds-hero-banner
            banner-title="AGL NBN"
            image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
            image-position="right"
          >
          <span slot="description">
            <agl-ds-p styled-as="xl" font="fontfamily02" appearance="inverse">Unlimited data plans from $55 a month.</agl-ds-p>
            <agl-ds-p styled-as="sm" appearance="inverse">
                Unlimited data plans from $55 a month.Here’s some supporting copy, just in case you didn’t get the gist from the above.
            </agl-ds-p>
          </span>
          <span slot="call-to-action">
            <agl-ds-button type="primary" mode="reverse" href="https://www.agl.com.au">See our plans</agl-ds-button>
          </span>
          </agl-ds-hero-banner>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Error summary</agl-ds-h3>
          <agl-ds-p>This component is typically not displayed on page load. To display the component click on the button below to simulate an error on page submission.</agl-ds-p>
           <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
          <agl-ds-button onclick="showErrorSummary()">
                Submit
              </agl-ds-button>
          <agl-ds-p>Note Clicking on the "Go to error" link in the component will bring the user back down to the checkbox below</agl-ds-p>
          <agl-ds-checkbox
            id="checkboxInError"
            hint-text="This is the hint text"
            validation-text="this is the validation text">Checkbox used for the error summary validation
          </agl-ds-checkbox>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Feature card</agl-ds-h3>
          <agl-ds-feature-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            <span slot="title">No lock in contracts</span>
            <span slot="description">For all your essential services - electricity, gas  & NBN</span>
          </agl-ds-feature-card>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Feature item</agl-ds-h3>
          <agl-ds-feature-item icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            <span slot="description">19Mbps evening speed (7pm-11pm)</span>
          </agl-ds-feature-item>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Prefooter</agl-ds-h3>
          <agl-ds-prefooter icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            <span slot="title">No lock in contracts</span>
            <span slot="description">For electricity, gas & NBN</span>
          </agl-ds-prefooter>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Promo card</agl-ds-h3>
          <agl-ds-promo-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
            <span slot="title">No lock in contracts</span>
            <span slot="description">For all your essential services - electricity, gas & NBN</span>
          </agl-ds-promo-card>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Illustration text</agl-ds-h3>
          <agl-ds-illustration-text-simple
            illustration-path="./../../../../assets/girl-with-tick.svg"
            illustration-position="top"
            size="sm"
          >
            <span slot="title">
              <agl-ds-h4 styled-as="title4">This quote has expired</agl-ds-h4>
            </span>
            <span slot="content-line-1">Sorry, your quote (ref. number 30108765) is no longer valid.</span>
            <span slot="content-line-2">
                To discuss your options, get in touch from 9:00am - 5:30pm AEST weekdays.  Shannon Smith, Email ssmith@agl.com.au, Phone (03) 8633 6221
            </span>
          </agl-ds-illustration-text-simple>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Spotlight</agl-ds-h3>
          <agl-ds-spotlight
          image-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
          image-position="left"
          appearance="flat"
          hide-image-mobile="true"
          >
            <span slot="title">
              <agl-ds-h3 styled-as="title1" appearance="default" class="hydrated">AGL Energy</agl-ds-h3>
            </span>
            <span slot="description">
              <agl-ds-p styled-as="xl" font="fontfamily02" appearance="default">
                Shine a light on your energy usage with the AGL Energy app. Track usage, get bill estimates, enter meter readings, pay bills and manage your account on the go.
              </agl-ds-p>
            </span>
            <span slot="call-to-action">
              <agl-ds-button type="secondary" href="https://www.agl.com.au" open-new-window="false">
                See our plans
              </agl-ds-button>
            </span>
          </agl-ds-spotlight>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Tryptich</agl-ds-h3>
          <agl-ds-triptych     image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" href="https://agl-design-system.azurewebsites.net/">
            <agl-ds-h3 styled-as="title5" appearance="highlight" class="hydrated" slot="title">
              No lock in contracts
            </agl-ds-h3>
            <agl-ds-p styled-as="lg" font="fontfamily02" appearance="muted" slot="description">
              With AGL Energy Insights, estimate which type of appliances are costing you the most at home. Use energy smarter and reduce your bill.
            </agl-ds-p>
          </agl-ds-triptych>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Navigation card</agl-ds-h3>
          <agl-ds-navigation-card
              heading="I'm a new customer"
              description="Join AGL and enjoy exclusive offers as a new customer.
              image-path="../../assets/man-with-mobile.svg"
              url="http://www.agl.com.au"
          >
          </agl-ds-navigation-card>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Notification card</agl-ds-h3>
          <agl-ds-notification
            type="warning"
            image-path="../../assets/pot-plants-2.svg"
            heading="Ok, we can help you find out. Leave your details and we’ll contact you."
            message="Complete the form and we’ll supply instructions and the form you’ll need to pass on to the home owner "
            button-text="Button text"
            button-type="secondary"
            link-text="Example Link"
            link-open-new-window="true"
            link-href="https://www.agl.com.au"
            show-icon="true"
          >
            <slot>
              <agl-ds-p>For all your essential services - electricity, gas & NBN</agl-ds-p>
            </slot>
          </agl-ds-notification>
          <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

          <agl-ds-notification
            type="error"
            heading="Ok, we can help you find out. Leave your details and we’ll contact you."
            message="A simple message telling me what’s going down on screen"
          >
            <slot>
              <agl-ds-p>For all your essential services - electricity, gas & NBN</agl-ds-p>
            </slot>
          </agl-ds-notification>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Segmented card</agl-ds-h3>
          <agl-ds-segmented-card>
          <div slot="card-heading">
            <agl-ds-h2 styled-as="title5" appearance="default" bottom-margin="none">NBN 25</agl-ds-h2>
            <div class="segmented-card-heading">
              <agl-ds-p bottom-margin="none">
                <agl-ds-text styled-as="display01">
                  <span>$50</span>
                </agl-ds-text>
                <agl-ds-text styled-as="xl">
                  <span>per month</span>
                </agl-ds-text>
              </agl-ds-p>
            </div>
            <agl-ds-p styled-as="md" bottom-margin="none">Minimum cost $55 or $145 with modem </agl-ds-p>
          </div>
          <div slot="card-promo">
            <agl-ds-promo-card icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">
              <span slot="title">Save $10 off your monthly bill</span>
              <span slot="description">
                <p>when bundled with an energy plan</p>
              </span>
            </agl-ds-promo-card>
          </div>
          <div slot="card-image">
            <img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A" />
          </div>
          <div slot="calls-to-action">
            <div class="cta-section">
              <agl-ds-button type="primary" href="https://www.agl.com.au" rel="relative">
                Choose this plan
              </agl-ds-button>
            </div>
          </div>
        </agl-ds-segmented-card>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Selection card</agl-ds-h3>
          <agl-ds-selection-card heading="Add Carbon Neutral (electricity)" checked="Option checked'" value="some value">
            <agl-ds-text styled-as="lg" font-weight="semibold" bottom-margin="none">$1.00</agl-ds-text>
            <agl-ds-text styled-as="xs" bottom-margin="none">a&nbsp;week (GST&nbsp;Incl.)</agl-ds-text>
          </agl-ds-selection-card>
          <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
          <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

          <agl-ds-h3>Tiles</agl-ds-h3>
      <agl-ds-list>
      <agl-ds-list-item>
        <agl-ds-tile id="tl1" theme="primary01" active="false" hoverable="true" name="heading and content tile">
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">Heading</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Edit</agl-ds-link>
          </div>
          <div slot="tile-content" style="height:96px; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">Some great content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">Some smaller but still great content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </agl-ds-list-item>
      <agl-ds-list-item>
        <agl-ds-tile id="tl2" theme="secondary01" active="false" hoverable="true" name="heading and content tile">
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">Heading</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Edit</agl-ds-link>
          </div>
          <div slot="tile-content" style="height:96px; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">Some great content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">Some smaller but still great content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </agl-ds-list-item>
      <agl-ds-list-item>
        <agl-ds-tile id="tl3" theme="tertiary01" active="false" hoverable="true" name="heading and content tile">
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">Heading</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Edit</agl-ds-link>
          </div>
          <div slot="tile-content" style="height:96px; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">Some great content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">Some smaller but still great content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </agl-ds-list-item>
    </agl-ds-list>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

        </div>
      </div>
      <div slot="sidebar">
        <div>
          sidebar content<br /><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua.<br />
        </div>
      </div>
    </agl-ds-fulfilment-container>
    ${script(`function showErrorSummary() {
      document.getElementById('errorSummary').classList.remove('hide-error-summary');
      document.body.scrollTop = 0; // For Safari
      document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
      document.getElementById('errorSummary').setFocus();
      document.getElementById('checkboxInError').hasError = true;
      }`)}

`;
};
Default.storyName = 'Composite components in the fulfillment container';

Default.parameters = {
  notes: `Notes: This page is a work in progress <br>
          TODO: maybe put role=banner for the all the banners and role="alert" for errors`,
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false },
        'heading-order': { enabled: false }
      }
    }
  }
};

export const Core = () => {
  //apply the modal
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    document.getElementById('modal')?.setTriggerButton(() => {
      return document.querySelector('#modalTrigger');
    });
  }, 1000);
  return html`
  <agl-ds-screen-reader-test>
  <agl-ds-simple-container>
    <div slot="banner" class="banner">
      <agl-ds-banner-simple image-path="../../../assets/pot-plants.svg">
        <div slot="content" class="storybook__content">
          <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="inverse">
            Step 2 • Add broadband
          </agl-ds-h1>
          <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none" appearance="inverse">
            Get $10 off your bill every month when you bundle your broadband
          </agl-ds-h2>
          <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="inverse">
            Terms and conditions apply
          </agl-ds-p>
        </div>
      </agl-ds-banner-simple>
    </div>
    <div slot="content" class="content">
    <agl-ds-address-search label='Connection address'></agl-ds-address-search>

      <agl-ds-h2>Core components</agl-ds-h2>
      <agl-ds-h3>Accordion</agl-ds-h3>

      <agl-ds-accordion accordion-label="Accordion One" is-active-accordion="false">
        <div slot="panel-content">
          <p>1 tab panel text injected into slot</p>
        </div>
      </agl-ds-accordion>
      <agl-ds-accordion accordion-label="Accordion Two" is-last-accordion="true">
        <div slot="panel-content">2 tab panel text injected into slot</div>
      </agl-ds-accordion>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Badge</agl-ds-h3>
      <agl-ds-badge sr-context="This is the extra information that can be added to assist the reader">Default</agl-ds-badge>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Button</agl-ds-h3>
      <agl-ds-button type="primary" sr-context="This is the extra information that can be added to assist the reader"> Submit request </agl-ds-button>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
      <agl-ds-button type="primary" loading="true" sr-context="This is the extra information that can be added to assist the reader">
        Submit request
      </agl-ds-button>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Checkbox</agl-ds-h3>
      <agl-ds-checkbox type="validation" id="chkid" sr-context="This is the extra information that can be added to assist the reader" hint-text="Yes, I would like fries is the correct answer"> Would you like fries with that? </agl-ds-checkbox>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

      <agl-ds-form-field-label heading="Sample checkbox heading">
        <span slot="sub-heading">Sample checkbox sub heading</span>
        <agl-ds-checkbox type="validation" sr-context="This is the extra information that can be added to assist the reader">
          <agl-ds-text>Heading of label</agl-ds-text><br />
          <agl-ds-text>1. First line of label</agl-ds-text><br />
          <agl-ds-text>2. Second line of label</agl-ds-text>
        </agl-ds-checkbox>
      </agl-ds-form-field-label>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Day of month picker</agl-ds-h3>
      <agl-ds-p>This component is not accessible</agl-ds-p>

      <agl-ds-day-of-month-picker value="12" label="Billing day" hint-text="Please select a billing day"> </agl-ds-day-of-month-picker>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Drop down box</agl-ds-h3>
      <agl-ds-dropdownbox
        id="mydropdown1"
        validation-text="Please select a state"
        hint-text="select a state"
        label="State"
        value="wa"
        has-error="false"
        sr-context="This is the extra information that can be added to assist the reader"
      >
        <agl-ds-dropdown-option text="VIC" value="vic"></agl-ds-dropdown-option>
        <agl-ds-dropdown-option text="NSW" value="nsw"></agl-ds-dropdown-option>
        <agl-ds-dropdown-option text="WA" value="wa"></agl-ds-dropdown-option>
        <agl-ds-dropdown-option text="SA" value="sa"></agl-ds-dropdown-option>
        <agl-ds-dropdown-option text="QLD" value="qld" selected="true"></agl-ds-dropdown-option>
      </agl-ds-dropdownbox>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

      <agl-ds-form-field-label heading="Sample heading">
        <span slot="sub-heading">Sample sub heading </span>
        <agl-ds-dropdownbox
          id="mydropdown2"
          validation-text="Please select a state"
          hint-text="select a state"
          label="State"
          value="wa"
          has-error="false"
          sr-context="This is the extra information that can be added to assist the reader"
        >
          <agl-ds-dropdown-option text="VIC" value="vic"></agl-ds-dropdown-option>
          <agl-ds-dropdown-option text="NSW" value="nsw"></agl-ds-dropdown-option>
          <agl-ds-dropdown-option text="WA" value="wa"></agl-ds-dropdown-option>
          <agl-ds-dropdown-option text="SA" value="sa"></agl-ds-dropdown-option>
          <agl-ds-dropdown-option text="QLD" value="qld" selected="true"></agl-ds-dropdown-option>
        </agl-ds-dropdownbox>
      </agl-ds-form-field-label>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Icon</agl-ds-h3>
      <agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm"> </agl-ds-icon>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Illustration</agl-ds-h3>
      <agl-ds-illustration image-path="https://via.placeholder.com/240x360/0bf/fff?text=B"> </agl-ds-illustration>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Link</agl-ds-h3>
      <agl-ds-p
        >A sentence with
        <agl-ds-link href="https://www.agl.com.au" sr-context="This is the extra information that can be added to assist the reader">a link</agl-ds-link></agl-ds-p
      >

      <agl-ds-h3>Modal</agl-ds-h3>
      <agl-ds-button type="primary" id="modalTrigger" sr-context="This is the extra information that can be added to assist the reader" onClick="document.getElementById('modal').openModal()"
        >Show modal</agl-ds-button
      >

      <agl-ds-modal id="modal" appearance="popup">
        <div slot="header">
          <agl-ds-h2 bottom-margin="none" font="fontfamily02" styled-as="title5">The modals header</agl-ds-h2>
        </div>
        <div slot="content">The modal's content</div>
        <div slot="footer">
          <agl-ds-modal-footer type="oneButton" first-button-label="Accept"></agl-ds-modal-footer>
        </div>
      </agl-ds-modal>

      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Next steps</agl-ds-h3>
      <agl-ds-next-steps>
        <agl-ds-next-steps-item
          is-complete="true"
          heading="Quote accepted"
          sub-heading="24 April 2020"
          content="You’re in the 5-business-day cooling off period right now."
        >
        </agl-ds-next-steps-item>
        <agl-ds-next-steps-item is-complete="false" heading="Deposit payment">
          <agl-ds-p styled-as="md"> This is when your deposit of $594.45 is due. </agl-ds-p>
        </agl-ds-next-steps-item>
      </agl-ds-next-steps>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Paragraph</agl-ds-h3>
      <agl-ds-p> Just a random sentence </agl-ds-p>

      <agl-ds-h3>Radio buttons</agl-ds-h3>
      <agl-ds-h4>Type: basic</agl-ds-h4>
      <agl-ds-radio-button-group
        group-name="my-basic-rb1"
        selected-value="1"
        heading="basic radio buttons"
        sub-heading="Sample sub heading"
        id="myId11"
      >
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-basic-rb1" value="1">I am really not sure</agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-basic-rb1" value="2">You know what, I really do love radio buttons</agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>

      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
      <agl-ds-h4>Type: panel</agl-ds-h4>
      <agl-ds-radio-button-group
        group-name="my-panel-rb2"
        id="myId"
        selected-value="2"
        heading="Do you like panel radio buttons?"
        sub-heading="Sample sub heading text"
        validation-text="This is validation error text"
      >
        <agl-ds-radio-button-set>
          <agl-ds-radio-button type="panel" group-name="my-panel-rb2" value="1">
            <span slot="heading">I kinda like radio buttons</span>
            <span slot="panel">
              <agl-ds-radio-button-group
                group-name="my-panel-rb2a"
                heading="Do you like radio buttons?"
                validation-text="This is validation error text"
                id="myId2"
              >
                <agl-ds-radio-button-set>
                  <agl-ds-radio-button group-name="my-panel-rb2a" value="1"
                    >What about this radio. This one has longer text to wrap</agl-ds-radio-button
                  >
                  <agl-ds-radio-button group-name="my-panel-rb2a" value="2">What about this radio</agl-ds-radio-button>
                </agl-ds-radio-button-set>
              </agl-ds-radio-button-group>
            </span>
          </agl-ds-radio-button>
          <agl-ds-radio-button type="panel" group-name="my-panel-rb2" value="3">
            <span slot="heading">I have never liked radio buttons</span>
            <div slot="panel">
              panel content<br />more content<br />more content<br />more content<br />more content<br />more content<br />more content<br />more
              content<br />more content
            </div>
          </agl-ds-radio-button>
          <agl-ds-radio-button type="panel" group-name="my-panel-rb2" value="4">
            <span slot="heading">I dont have a panel</span>
          </agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

      <agl-ds-h4>Type: icon</agl-ds-h4>
      <agl-ds-radio-button-group
        group-name="my-icon-rb"
        id="myIconRbId1"
        heading="Do you like radio buttons?"
        sub-heading="Sub heading as an attribute"
      >
        <agl-ds-radio-button-set>
          <agl-ds-radio-button type="agl_icon_dig_home_32px" group-name="my-icon-rb" value="1">I am really not sure </agl-ds-radio-button>
          <agl-ds-radio-button type="agl_icon_dig_moving_32px" group-name="my-icon-rb" value="3">
            I kinda like radio buttons
          </agl-ds-radio-button>
          <agl-ds-radio-button type="agl_icon_dig_question_32px" group-name="my-icon-rb" value="4">
            I have never liked radio buttons
          </agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

      <agl-ds-h4>Type: image</agl-ds-h4>
      <agl-ds-radio-button-group group-name="my-image-rb"  heading="Do you like radio buttons" sub-heading="A sub heading">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button
            type="image"
            image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
            value="1"
            group-name="my-image-rb"
          >
            I am really not sure
          </agl-ds-radio-button>
          <agl-ds-radio-button
            type="image"
            image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_unit.jpg"
            group-name="my-image-rb"
            value="2"
          >
            You know what, I really do love radio buttons
          </agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>text</agl-ds-h3>
      <agl-ds-text>I'm an example of stand alone text </agl-ds-text>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Text box</agl-ds-h3>
      <agl-ds-textbox
        label="Label for text"
        type="experiential"
        hint-text="Sample hint text"
        placeholder="Sample placeholder text"
      ></agl-ds-textbox>
      <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>

      <agl-ds-form-field-label heading="Address details">
        <span slot="sub-heading">For your home</span>
        <agl-ds-textbox
          label="Label for text"
          type="experiential"
          hint-text="Please enter an address"
          validation-text="You must enter an address"
          placeholder="Placeholder text"
          has-error="false"
        ></agl-ds-textbox>
      </agl-ds-form-field-label>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Tooltip</agl-ds-h3>
      <p>
        I am some text that needs a tooltip<agl-ds-tooltip>Example text: Site size is in an indication of energy consumed.</agl-ds-tooltip>
      </p>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
      <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>

      <agl-ds-h3>Trusted Html Content</agl-ds-h3>
      <agl-ds-trusted-html-content>
        <span>span tag with some more text</span><br />
        <b>b tag with some more text</b><br />
        <a href="https://www.agl.com.au">a tag with some more text</a><br />
        <strong> strong tag with some more text</strong><br />
      </agl-ds-trusted-html-content>
      <agl-ds-spacer orientation="vertical" size="space06" border
      l-ds-trusted-html-content>
      <agl-ds-spacer orientation="vertical" size="space06" border="bottom"></agl-ds-spacer>
    </agl-ds-screen-reader-test>
    <agl-ds-spacer orientation="vertical" size="space06"></agl-ds-spacer>
  </div>
  </agl-ds-simple-container>
`;
};

Core.storyName = 'Core components in the simple container';

Core.parameters = {
  notes: `Notes: This page is a work in progress <br>
   I am not sure that the form field is used correctly see https://accessibility.blog.gov.uk/2016/07/22/using-the-fieldset-and-legend-elements/<br>
     TODO:
     - Forms. For example, indicate any required and optional input, allowed data formats, and timing limitations. Provide such instructions before the <form> element to ensure that it is read aloud by screen readers before they switch to “Forms Mode”. see https://www.w3.org/WAI/tutorials/forms/instructions/  <br>
     - Day of month picker is not accessible <br>
     - might have issues with keypress event on screen readers https://www.accessibility-developer-guide.com/knowledge/keyboard-only/how-to-implement/
     - aria-required="true" should we have this on all required form fields
     - aria-invalid="true"  should we have this on all invalid form fields
     `,
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

//Added styles to give background colour in storybook to show correct fonts
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.storybook-background {background-color: var(--c-primary-01, #001cb0); display: inline-block;}');
style.sheet.insertRule('.storybook-background2 {background-color: #F9F9FB; display: inline-block; width: 100%;}');
style.sheet.insertRule('.hide-error-summary { display: none; }');
