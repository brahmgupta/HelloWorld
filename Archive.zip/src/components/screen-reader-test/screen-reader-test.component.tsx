import { Component, ComponentInterface, h, Host } from '@stencil/core';

@Component({
  tag: 'agl-ds-screen-reader-test',
  shadow: true
})
export class ScreenReaderTestComponent implements ComponentInterface {
  render() {
    return (
      <Host>
        <slot></slot>
      </Host>
    );
  }
}
