import { directive, NodePart } from 'lit-html';

const previousValues = new WeakMap();

/*  This is used to facilitate the addition of javascript to storybook stories
 */

export const script = directive((value) => (part) => {
  if (!(part instanceof NodePart)) {
    throw new Error('unsafeHTML can only be used in text bindings');
  }

  const previousValue = previousValues.get(part);
  if (previousValue !== undefined && value === previousValue.value && part.value === previousValue.script) {
    return;
  }

  const scriptTag = document.createElement('script');
  scriptTag.textContent = value;

  part.setValue(scriptTag);

  previousValues.set(part, { value, scriptTag });
});
