import { Component, h, Host, Prop, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { ContentAlignment } from './guided-container.types';

@Component({
  tag: 'agl-ds-guided-container',
  styleUrl: 'guided-container.component.scss',
  shadow: true
})
export class GuidedContainerComponent implements ComponentInterface {
  @Element() host: HTMLAglDsGuidedContainerElement;
  /**
   * The alignment of the content within the content container
   */
  @Prop() contentAlignment: ContentAlignment = 'center';

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="banner"]'), [
      'div',
      'agl-ds-guided-container',
      'agl-ds-guided-banner',
      'stencil-router'
    ]);
  }

  render() {
    const alignCenter = this.contentAlignment === 'center';

    return (
      <Host>
        <div class="wrapper">
          <div class="left-filler-cell  "> </div>
          <div class="grid-container ">
            <div class="row ">
              <div class="col-sm-12 col-lg-4 ">
                <div class="banner ">
                  <slot name="banner" />
                </div>
              </div>
              <div
                class={{
                  [`col-sm-12`]: true,
                  [`col-lg-6 col-lg-offset-1 `]: alignCenter,
                  [`col-lg-8 `]: !alignCenter
                }}
              >
                <div class={{ content: true, 'content--left': !alignCenter }}>
                  <slot name="content" />
                </div>
              </div>
            </div>
          </div>
          <div class="right-filler-cell "> </div>
        </div>
      </Host>
    );
  }
}
