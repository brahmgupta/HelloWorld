export type ContentAlignment = 'left' | 'center';
