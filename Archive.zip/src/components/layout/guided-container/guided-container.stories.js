import { select, text } from '@storybook/addon-knobs';
import { html, render } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Layout/Guided container',

  parameters: {
    paddings: { disabled: true }
  }
};

export const GuidedContainer = () => html`
  <agl-ds-guided-container content-alignment="${select('content-alignment', ['center', 'left'], 'left')}">
    <div slot="banner" class="banner">
      <agl-ds-guided-banner image-path="../../../assets/pot-plants.svg">
        <span slot="primary-heading">Let's get started. </span>
        <span slot="secondary-heading">Do you have a current AGL electricity or gas account?</span>
        <span slot="description">Typically takes about 3 mins to complete the virtual power plant signup.</span>
      </agl-ds-guided-banner>
    </div>
    <div slot="content" class="content">
      ${html([
        text(
          'Main content',
          `<agl-ds-h1>here is the content</agl-ds-h1>
          <agl-ds-p>
            (styles have has been added to the slotted content passed into web component. and the really long bit to force out the
            container). Also using the grid to space out some text fields below
          </agl-ds-p>
          <div class="grid-container">
            <div class="row">
              <div class="col-sm-6 col-md-6 col-lg-6">
                <agl-ds-textbox label="Input field 1"></agl-ds-textbox>
              </div>
              <div class="col-sm-6 col-md-6 col-lg-6">
                <agl-ds-textbox label="Input field 2"></agl-ds-textbox>
              </div>
            </div>
          </div>
          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12 col-md-6 col-lg-6">
                <agl-ds-textbox label="Input field 3"></agl-ds-textbox>
              </div>
              <div class="col-sm-12 col-md-6 col-lg-6">
                <agl-ds-textbox label="Input field 4"></agl-ds-textbox>
              </div>
            </div>
          </div> `
        )
      ])}
    </div>
  </agl-ds-guided-container>
`;

GuidedContainer.storyName = 'Guided container';
GuidedContainer.parameters = {
  notes,
  // these rules are excluded as the story is not a real world example of how the menu items are consumed
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

//Added styles to remove the preset margins so that the content section sits at the top of the page
//Also add styles to show the borders of the banner and content
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('body {margin: 0;}');
style.sheet.insertRule('.banner {border: 1px solid green;}');
style.sheet.insertRule('.content {border: 1px solid green}');
