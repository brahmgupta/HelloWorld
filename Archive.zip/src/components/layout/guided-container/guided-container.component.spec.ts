import { newSpecPage } from '@stencil/core/testing';
import { GuidedContainerComponent } from './guided-container.component';

describe('Guided container component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [GuidedContainerComponent],
      html: `<agl-ds-guided-container>
              <div slot="banner">banner</div>
              <div slot="content">content</div>
            </agl-ds-guided-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-guided-container>
      <mock:shadow-root>
        <div class="wrapper">
          <div class="left-filler-cell"></div>
          <div class="grid-container">
            <div class="row">
              <div class="col-lg-4 col-sm-12">
                <div class="banner">
                  <slot name="banner"></slot>
                </div>
              </div>
              <div class="col-lg-6 col-lg-offset-1 col-sm-12">
                <div class="content">
                  <slot name="content"></slot>
                </div>
              </div>
            </div>
          </div>
          <div class="right-filler-cell"></div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        banner
      </div>
      <div slot="content">
        content
      </div>
    </agl-ds-guided-container>
    `);
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedContainerComponent],
      html: `<agl-ds-guided-container>
      <div slot="banner">
      <agl-ds-guided-banner image-path="../../../assets/pot-plants.svg">
        <span slot="primary-heading">Let's get started. </span>
        <span slot="secondary-heading">Do you have a current AGL electricity or gas account?</span>
        <span slot="description">Typically takes about 3 mins to complete the virtual power plant signup.</span>
      </agl-ds-guided-banner>
      </div>
      <div slot="content">content</div>
    </agl-ds-guided-container>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [GuidedContainerComponent],
      html: `<agl-ds-guided-container>
              <div slot="banner">
                <p>dummy text</p>
                <agl-ds-guided-banner image-path="../../../assets/pot-plants.svg">
                  <span slot="primary-heading">Let's get started. </span>
                  <span slot="secondary-heading">Do you have a current AGL electricity or gas account?</span>
                  <span slot="description">Typically takes about 3 mins to complete the virtual power plant signup.</span>
                </agl-ds-guided-banner>
              </div>
              <div slot="content">content</div>
            </agl-ds-guided-container>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
