# agl-ds-button



<!-- Auto Generated Below -->


## Properties

| Property           | Attribute           | Description                                               | Type                 | Default    |
| ------------------ | ------------------- | --------------------------------------------------------- | -------------------- | ---------- |
| `contentAlignment` | `content-alignment` | The alignment of the content within the content container | `"center" \| "left"` | `'center'` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
