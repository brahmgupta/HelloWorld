import { html } from 'lit-html';

export default {
  title: 'Layout/Grid'
};

export const ExampleGrid = () => html`<agl-ds-grid-example></agl-ds-grid-example>`;
