import { Component, ComponentInterface, h, Host } from '@stencil/core';

@Component({
  tag: 'agl-ds-grid-example',
  styleUrl: 'grid-example.component.scss',
  shadow: true
})
export class GridExampleComponent implements ComponentInterface {
  render() {
    return (
      <Host>
        <div class="wrapper">
          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12">
                <div class="">
                  <agl-ds-p>
                    This is a grid system that is based on the page being divided into 12 equal cols. It is used to drive the layout
                    components as well as laying out sections of a component where fields need to be responsive or be layed out side by
                    side.
                  </agl-ds-p>
                  <agl-ds-p>
                    All col combinations need to add up to 12. So to divide the section of your page into 2 horizontally use col-x-6 where x
                    is sm,md or lg. The gutters between the columns are also preset. Note that there are only 3 breakpoint options that
                    correspond to the DS breakpoints sm, md and lg.
                  </agl-ds-p>
                  <agl-ds-p></agl-ds-p>
                </div>
              </div>
            </div>
          </div>
          <div class="grid-container">
            <div class="row">
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
              <div class="col-sm-1">
                <div class="box">1</div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
              <div class="col-sm-2">
                <div class="box">2 cols</div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-3">
                <div class="box">3 cols</div>
              </div>
              <div class="col-sm-3">
                <div class="box">3 cols</div>
              </div>
              <div class="col-sm-3">
                <div class="box">3 cols</div>
              </div>
              <div class="col-sm-3">
                <div class="box">3 cols</div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-6">
                <div class="box">6 cols</div>
              </div>
              <div class="col-sm-6">
                <div class="box">6 cols</div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12">
                <div class="">
                  <agl-ds-p></agl-ds-p>
                  <agl-ds-p>
                    To make your sections responsive just set the col class to your desired flow ie see below class="col-sm-12, col-md-4,
                    col-lg-6". Shrink the browser to see the effect. Note it does not line up with the above grid as different breakpoints
                    have different gutters.
                  </agl-ds-p>
                </div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12 col-md-4 col-lg-6">
                <div class="box">12 on small, 4 on medium, 6 on large</div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12">
                <div class="">
                  <agl-ds-p></agl-ds-p>
                  <agl-ds-p>
                    You have other flexbox features (such as Reversing, Reordering, distribution, alignment, auto width, offsets) available
                    see http://flexboxgrid.com/ for details
                  </agl-ds-p>

                  <agl-ds-p>Technical notes:</agl-ds-p>
                  <ol>
                    <li>3 breakpoint sizes (sm, md,lg)</li>
                    <li>
                      Container max-widths for layout should use the sass varaibles $max-width-lg: 1216px; $max-width-md: 943px; and the
                      container should be centered in the page
                    </li>
                    <li>
                      Most grid layouts have gutters at the ends of the row and a negative margin to sort this out. This adaption of the
                      grid removes the end margins so that the grid fits to the edge of the parent container. The parrent container then
                      takes care of padding out the contents.
                    </li>
                  </ol>
                  <agl-ds-spacer orientation="vertical" size="space03"></agl-ds-spacer>
                </div>
              </div>
            </div>
          </div>

          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12 ">
                <div>
                  <agl-ds-h5>Visible and hidden classes</agl-ds-h5>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <agl-ds-h6>visible-* classes </agl-ds-h6>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4 visible-sm ">
                <div class="box">visible-sm </div>
              </div>
              <div class="col-sm-4 visible-md ">
                <div class="box">visible-md </div>
              </div>
              <div class="col-sm-4 visible-lg ">
                <div class="box">visible-lg </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <agl-ds-spacer orientation="vertical" size="space03"></agl-ds-spacer>
                <agl-ds-h6>visible only (ie visible-*-only) classes</agl-ds-h6>
              </div>
            </div>
            <div class="row ">
              <div class="col-sm-6 ">
                <div class="box">visible-sm-only </div>
              </div>
              <div class="col-sm-6  visible-sm-only">
                <div class="box">visible-sm-only </div>
              </div>
            </div>
            <div class="row ">
              <div class="col-sm-6 ">
                <div class="box">visible-md-only </div>
              </div>
              <div class="col-sm-6  visible-md-only">
                <div class="box">visible-md-only </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6 ">
                <div class="box">visible-lg-only </div>
              </div>
              <div class="col-sm-6  visible-lg-only">
                <div class="box">visible-lg-only </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <agl-ds-spacer orientation="vertical" size="space03"></agl-ds-spacer>
                <agl-ds-h6>hidden (ie hidden-*) classes</agl-ds-h6>
              </div>
            </div>
            <div class="row  ">
              <div class="col-sm-6 ">
                <div class="box">hidden-sm </div>
              </div>
              <div class="col-sm-6 hidden-sm visible-md visible-lg">
                <div class="box">visible-md visible-lg</div>
              </div>
            </div>
            <div class="row  ">
              <div class="col-sm-6 ">
                <div class="box">hidden-md </div>
              </div>
              <div class="col-sm-6 hidden-md visible-sm visible-lg">
                <div class="box">visible-sm visible-lg</div>
              </div>
            </div>
            <div class="row  ">
              <div class="col-sm-6 ">
                <div class="box">hidden-lg</div>
              </div>
              <div class="col-sm-6 hidden-lg visible-sm visible-md">
                <div class="box">visible-sm visible-md</div>
              </div>
            </div>
          </div>
        </div>
        <agl-ds-spacer orientation="vertical" size="space04"></agl-ds-spacer>
      </Host>
    );
  }
}
