# agl-ds-grid-example



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [agl-ds-p](../../core/paragraph)
- [agl-ds-spacer](../../core/spacer)
- [agl-ds-h5](../../core/heading/h5)
- [agl-ds-h6](../../core/heading/h6)

### Graph
```mermaid
graph TD;
  agl-ds-grid-example --> agl-ds-p
  agl-ds-grid-example --> agl-ds-spacer
  agl-ds-grid-example --> agl-ds-h5
  agl-ds-grid-example --> agl-ds-h6
  style agl-ds-grid-example fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
