# agl-ds-segmented-container



<!-- Auto Generated Below -->


## Slots

| Slot          | Description                                                                                                                                                                                                                 |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"header"`    | The header section takes slotted content mainly H tags. If the header is not supplied then the wholes section inlcuding the bottom border is omitted                                                                        |
| `"section-x"` | There are 5 sections that takes html content (eg section-1 section-2 etc). If a section is not supplied then the wholes section inlcuding the bottom border is omitted. Note the last section does not have a bottom border |


## Dependencies

### Used by

 - [agl-ds-tile](../../composite/tile)

### Graph
```mermaid
graph TD;
  agl-ds-tile --> agl-ds-segmented-container
  style agl-ds-segmented-container fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
