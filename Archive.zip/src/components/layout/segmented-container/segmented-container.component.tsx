import { Component, ComponentInterface, Element, h } from '@stencil/core';

/**
 * @slot header - The header section takes slotted content mainly H tags. If the header is not supplied then the wholes section inlcuding the bottom border is omitted
 * @slot section-x - There are 5 sections that takes html content (eg section-1 section-2 etc). If a section is not supplied then the wholes section inlcuding the bottom border is omitted. Note the last section does not have a bottom border
 */

@Component({
  tag: 'agl-ds-segmented-container',
  styleUrl: 'segmented-container.component.scss',
  shadow: true
})
export class SegmentedContainerComponent implements ComponentInterface {
  @Element() hostElement: HTMLAglDsSegmentedContainerElement;
  private hasHeader: boolean = false;
  private hasSlot1: boolean = false;
  private hasSlot2: boolean = false;
  private hasSlot3: boolean = false;
  private hasSlot4: boolean = false;
  private hasSlot5: boolean = false;

  componentWillLoad() {
    this.hasHeader = !!this.hostElement.querySelector('[slot="header"]');
    this.hasSlot1 = !!this.hostElement.querySelector('[slot="section-1"]');
    this.hasSlot2 = !!this.hostElement.querySelector('[slot="section-2"]');
    this.hasSlot3 = !!this.hostElement.querySelector('[slot="section-3"]');
    this.hasSlot4 = !!this.hostElement.querySelector('[slot="section-4"]');
    this.hasSlot5 = !!this.hostElement.querySelector('[slot="section-5"]');
  }

  private showHeader(show: boolean) {
    if (show) {
      return (
        <div class="container__header">
          <slot name={'header'} />
        </div>
      );
    }
  }

  private showSection(slotId: string, show: boolean) {
    if (show) {
      return (
        <div class="container__main-segmented">
          <slot name={'section-' + slotId} />
        </div>
      );
    }
  }

  render() {
    return (
      <div class="container">
        {this.showHeader(this.hasHeader)}
        <div class="container__main">
          {this.showSection('1', this.hasSlot1)}
          {this.showSection('2', this.hasSlot2)}
          {this.showSection('3', this.hasSlot3)}
          {this.showSection('4', this.hasSlot4)}
          {this.showSection('5', this.hasSlot5)}
        </div>
      </div>
    );
  }
}
