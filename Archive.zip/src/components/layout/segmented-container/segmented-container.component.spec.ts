import { newSpecPage } from '@stencil/core/testing';
import { SegmentedContainerComponent } from './segmented-container.component';

describe('Status container component', () => {
  it('should render the component with a header and 1 section', async () => {
    const page = await newSpecPage({
      components: [SegmentedContainerComponent],
      html: ` <agl-ds-segmented-container >
      <div slot="header">
         Dummy header
      </div>
      <div slot="section-1">
        Dummy section 1 content
      </div>
    </agl-ds-segmented-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-segmented-container>
      <mock:shadow-root>
        <div class="container">
          <div class="container__header">
            <slot name="header"></slot>
          </div>
          <div class="container__main">
            <div class="container__main-segmented">
              <slot name="section-1"></slot>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="header">
        Dummy header
      </div>
      <div slot="section-1">
        Dummy section 1 content
      </div>
    </agl-ds-segmented-container>
    `);
  });

  it('should render the component with a header and 5 sections', async () => {
    const page = await newSpecPage({
      components: [SegmentedContainerComponent],
      html: ` <agl-ds-segmented-container >
      <div slot="header">
         Dummy header
      </div>
      <div slot="section-1">
        Dummy section 1 content
      </div>
      <div slot="section-2">
        Dummy section 2 content
      </div>
      <div slot="section-3">
        Dummy section 3 content
      </div>
      <div slot="section-4">
        Dummy section 4 content
      </div>
      <div slot="section-5">
        Dummy section 5 content
      </div>

    </agl-ds-segmented-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-segmented-container>
      <mock:shadow-root>
        <div class="container">
          <div class="container__header">
            <slot name="header"></slot>
          </div>
          <div class="container__main">
            <div class="container__main-segmented">
              <slot name="section-1"></slot>
            </div>
            <div class="container__main-segmented">
              <slot name="section-2"></slot>
            </div>
            <div class="container__main-segmented">
              <slot name="section-3"></slot>
            </div>
            <div class="container__main-segmented">
              <slot name="section-4"></slot>
            </div>
            <div class="container__main-segmented">
              <slot name="section-5"></slot>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="header">
        Dummy header
      </div>
      <div slot="section-1">
        Dummy section 1 content
      </div>
      <div slot="section-2">
        Dummy section 2 content
      </div>
      <div slot="section-3">
        Dummy section 3 content
      </div>
      <div slot="section-4">
        Dummy section 4 content
      </div>
      <div slot="section-5">
        Dummy section 5 content
      </div>
    </agl-ds-segmented-container>
    `);
  });

  it('should render the component without a header and 1 section', async () => {
    const page = await newSpecPage({
      components: [SegmentedContainerComponent],
      html: `
      <agl-ds-segmented-container >
        <div slot="section-1">
          Dummy section 1 content
        </div>
      </agl-ds-segmented-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-segmented-container>
      <mock:shadow-root>
        <div class="container">
          <div class="container__main">
            <div class="container__main-segmented">
              <slot name="section-1"></slot>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="section-1">
        Dummy section 1 content
      </div>
    </agl-ds-segmented-container>
    `);
  });
});
