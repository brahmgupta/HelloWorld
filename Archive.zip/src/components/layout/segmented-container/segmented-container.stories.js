import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Layout/Segmented container'
};

export const SegmentedContainerWithHeader = () => html`
  <agl-ds-segmented-container>
    <div slot="header">${html([text('Content', '<agl-ds-h3>This section displays the header contents </agl-ds-h3>')])}</div>
    <div slot="section-1">${html([text('section-1 contents', '<agl-ds-p>section 1 content</agl-ds-p>')])}</div>
    <div slot="section-2">${html([text('section 2 contents', '<agl-ds-p>section 2 content</agl-ds-p>')])}</div>
    <div slot="section-3">${html([text('section 3 contents', '<agl-ds-p>section 3 content</agl-ds-p>')])}</div>
  </agl-ds-segmented-container>
`;

SegmentedContainerWithHeader.storyName = 'Segmented container with Header';
SegmentedContainerWithHeader.parameters = { notes };

export const SegmentedContainerWithOutHeader = () => html`
  <agl-ds-segmented-container>
    <div slot="section-1">${html([text('section-1 contents', '<agl-ds-p>section 1 content</agl-ds-p>')])}</div>
    <div slot="section-2">${html([text('section 2 contents', '<agl-ds-p>section 2 content</agl-ds-p>')])}</div>
    <div slot="section-3">${html([text('section 3 contents', '<agl-ds-p>section 3 content</agl-ds-p>')])}</div>
  </agl-ds-segmented-container>
`;

SegmentedContainerWithOutHeader.storyName = 'Segmented container with out Header';
SegmentedContainerWithOutHeader.parameters = { notes };

//Added styles to remove the preset margins so that the container sits at the edges of the page
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.sb-show-main {margin: 0 !important;}');
style.sheet.insertRule('agl-ds-segmented-container {border: 1px solid green;}');
