import { Component, h, Host, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';

/**
 * @slot banner - This slot is reserved for a banner component
 * @slot sub-banner - This slot is reserved for a sub banner area that is the full width of the page ( contents is centered)
 * @slot contents - Contents in this slot will placed center section of the page
 */

@Component({
  tag: 'agl-ds-simple-container',
  styleUrl: 'simple-container.component.scss',
  shadow: true
})
export class SimpleContainerComponent implements ComponentInterface {
  @Element() host: HTMLAglDsSimpleContainerElement;
  private hasSubBanner: boolean = false;

  componentWillLoad() {
    this.hasSubBanner = !!this.host.querySelector('[slot="sub-banner"]');
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="banner"]'), [
      'div',
      'agl-ds-simple-container',
      'agl-ds-banner-simple'
    ]);
  }

  render() {
    return (
      <Host>
        <div class="banner ">
          <div class="grid-container">
            <div class="row">
              <div class="col-sm-12 col-md-8 col-md-offset-2  col-lg-10 col-lg-offset-1">
                <slot name="banner" />
              </div>
            </div>
          </div>
        </div>
        {this.hasSubBanner && (
          <div class="sub-banner ">
            <div class="grid-container">
              <div class="row">
                <div class="col-sm-12 col-md-8 col-md-offset-2  col-lg-10 col-lg-offset-1">
                  <slot name="sub-banner" />
                </div>
              </div>
            </div>
          </div>
        )}
        <div class="content grid-container">
          <div class="row">
            <div class="col-sm-12 col-md-8 col-md-offset-2 col-lg-8 col-lg-offset-2 ">
              <slot name="content" />
            </div>
          </div>
        </div>
      </Host>
    );
  }
}
