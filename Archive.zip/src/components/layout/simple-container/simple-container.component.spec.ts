import { newSpecPage } from '@stencil/core/testing';
import { SimpleContainerComponent } from './simple-container.component';

describe('simple container component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [SimpleContainerComponent],
      html: `<agl-ds-simple-container>
              <div slot="banner">banner</div>
              <div slot="sub-banner">sub banner</div>
              <div slot="content">content</div>
            </agl-ds-simple-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-simple-container>
      <mock:shadow-root>
        <div class="banner">
          <div class="grid-container">
            <div class="row">
              <div class="col-lg-10 col-lg-offset-1 col-md-8 col-md-offset-2 col-sm-12">
                <slot name="banner"></slot>
              </div>
            </div>
          </div>
        </div>
         <div class="sub-banner">
           <div class="grid-container">
             <div class="row">
               <div class="col-lg-10 col-lg-offset-1 col-md-8 col-md-offset-2 col-sm-12">
                 <slot name="sub-banner"></slot>
               </div>
             </div>
           </div>
         </div>
        <div class="grid-container content">
          <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-12">
              <slot name="content"></slot>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        banner
      </div>
      <div slot="sub-banner">
        sub banner
      </div>
      <div slot="content">
        content
      </div>
    </agl-ds-simple-container>
    `);
  });

  it('should render the component without the sub banner if its not passed', async () => {
    const page = await newSpecPage({
      components: [SimpleContainerComponent],
      html: `<agl-ds-simple-container>
              <div slot="banner">banner</div>
              <div slot="content">content</div>
            </agl-ds-simple-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-simple-container>
      <mock:shadow-root>
        <div class="banner">
          <div class="grid-container">
            <div class="row">
              <div class="col-lg-10 col-lg-offset-1 col-md-8 col-md-offset-2 col-sm-12">
                <slot name="banner"></slot>
              </div>
            </div>
          </div>
        </div>
        <div class="grid-container content">
          <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-12">
              <slot name="content"></slot>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        banner
      </div>
      <div slot="content">
        content
      </div>
    </agl-ds-simple-container>
    `);
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SimpleContainerComponent],
      html: `<agl-ds-simple-container>
      <div slot="banner">
      <agl-ds-banner-simple image-path="../../../assets/pot-plants.svg">
          <div slot="content" class="storybook__content">
            <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="muted">Step 2 • Add broadband</agl-ds-h1>
            <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">Get $10 off your bill every month when you bundle your broadband</agl-ds-h2>
            <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">Terms and conditions apply</agl-ds-p>
          </div>
          </agl-ds-banner-simple>
      </div>
      <div slot="content">content</div>
    </agl-ds-simple-container`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [SimpleContainerComponent],
      html: `<agl-ds-simple-container>
              <div slot="banner">
              <p>dummy text</p>
              <agl-ds-banner-simple image-path="../../../assets/pot-plants.svg">
                <div slot="content" class="storybook__content">
                  <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="muted">Step 2 • Add broadband</agl-ds-h1>
                  <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">Get $10 off your bill every month when you bundle your broadband</agl-ds-h2>
                  <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">Terms and conditions apply</agl-ds-p>
                </div>
                </agl-ds-banner-simple>
              </div>
              <div slot="content">content</div>
            </agl-ds-simple-container`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
