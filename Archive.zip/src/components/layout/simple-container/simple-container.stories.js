import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Layout/simple container',

  parameters: {
    paddings: { disabled: true }
  }
};

export const SimpleContainer = () => html`
  <agl-ds-simple-container>
    <div slot="banner" class="banner">
      <agl-ds-banner-simple image-path="../../../assets/pot-plants.svg">
        <div slot="content" class="storybook__content">
          <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="muted">
            Step 2 • Add broadband
          </agl-ds-h1>
          <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">
            Get $10 off your bill every month when you bundle your broadband
          </agl-ds-h2>
          <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">
            Terms and conditions apply
          </agl-ds-p>
        </div>
      </agl-ds-banner-simple>
    </div>
    <div slot="content" class="content">
      <agl-ds-h1>here is the content</agl-ds-h1>
      <agl-ds-p>
        (styles have has been added to the slotted content passed into web component. and the really long bit to force out the container).
        Also using the grid to space out some text fields below
      </agl-ds-p>
      <div class="grid-container">
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 1"></agl-ds-textbox>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 2"></agl-ds-textbox>
          </div>
        </div>
      </div>
      <div class="grid-container">
        <div class="row">
          <div class="col-sm-12 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 3"></agl-ds-textbox>
          </div>
          <div class="col-sm-12 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 4"></agl-ds-textbox>
          </div>
        </div>
      </div>
    </div>
  </agl-ds-simple-container>
`;

SimpleContainer.storyName = 'Simple container';
SimpleContainer.parameters = {
  notes,
  // these rules are excluded as the story is not a real world example of how the menu items are consumed
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

export const SimpleContainerWithSubHeading = () => html`
  <agl-ds-simple-container>
    <div slot="banner" class="banner">
      <agl-ds-banner-simple image-path="../../../assets/pot-plants.svg">
        <div slot="content" class="storybook__content">
          <agl-ds-h1 class="storybook__content-p1" styled-as="title6" bottom-margin="none" appearance="muted">
            Step 2 • Add broadband
          </agl-ds-h1>
          <agl-ds-h2 class="storybook__content-heading" styled-as="title1" bottom-margin="none">
            Get $10 off your bill every month when you bundle your broadband
          </agl-ds-h2>
          <agl-ds-p class="storybook__content-p2" styled-as="sm" bottom-margin="none" appearance="muted">
            Terms and conditions apply
          </agl-ds-p>
        </div>
      </agl-ds-banner-simple>
    </div>
    <div slot="sub-banner">Your quote number is 30102033</div>
    <div slot="content" class="content">
      <agl-ds-h1>here is the content</agl-ds-h1>
      <agl-ds-p>
        (styles have has been added to the slotted content passed into web component. and the really long bit to force out the container).
        Also using the grid to space out some text fields below
      </agl-ds-p>
      <div class="grid-container">
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 1"></agl-ds-textbox>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 2"></agl-ds-textbox>
          </div>
        </div>
      </div>
      <div class="grid-container">
        <div class="row">
          <div class="col-sm-12 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 3"></agl-ds-textbox>
          </div>
          <div class="col-sm-12 col-md-6 col-lg-6">
            <agl-ds-textbox label="Input field 4"></agl-ds-textbox>
          </div>
        </div>
      </div>
    </div>
  </agl-ds-simple-container>
`;

SimpleContainerWithSubHeading.storyName = 'Simple container with sub heading';
SimpleContainerWithSubHeading.parameters = {
  notes,
  // these rules are excluded as the story is not a real world example of how the menu items are consumed
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

//Added styles to remove the preset margins so that the content section sits at the top of the page
//Also add styles to show the borders of the banner and content
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('body {margin: 0;}');
style.sheet.insertRule('.banner {border: 1px solid green;}');
style.sheet.insertRule('.content {border-left: 1px solid green; border-rightS: 1px solid green}');
