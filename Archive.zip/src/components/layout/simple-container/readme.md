# agl-ds-simple-container



<!-- Auto Generated Below -->


## Slots

| Slot           | Description                                                                                            |
| -------------- | ------------------------------------------------------------------------------------------------------ |
| `"banner"`     | This slot is reserved for a banner component                                                           |
| `"contents"`   | Contents in this slot will placed center section of the page                                           |
| `"sub-banner"` | This slot is reserved for a sub banner area that is the full width of the page ( contents is centered) |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
