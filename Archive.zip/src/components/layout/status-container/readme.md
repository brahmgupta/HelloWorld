# agl-ds-status-container



<!-- Auto Generated Below -->


## Slots

| Slot | Description                                                                                                                                                                                   |
| ---- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|      | This container displays the slotted contents at <ul><li>100% of the screen on small devices</li><li>33% of the screen on medium devices</li><li>50% of the screen on large devices.</li></ul> |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
