import { Component, ComponentInterface, h } from '@stencil/core';

/**
 * @slot - This container displays the slotted contents at <ul><li>100% of the screen on small devices</li><li>33% of the screen on medium devices</li><li>50% of the screen on large devices.</li></ul>
 */

@Component({
  tag: 'agl-ds-status-container',
  styleUrl: 'status-container.component.scss',
  shadow: true
})
export class StatusContainerComponent implements ComponentInterface {
  render() {
    return (
      <div class="status-container">
        <div class="status-container__inner">
          <slot />
        </div>
      </div>
    );
  }
}
