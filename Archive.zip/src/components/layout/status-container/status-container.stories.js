import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Layout/Status container',

  parameters: {
    paddings: { disabled: true }
  }
};

export const StatusContainer = () => html`
  <style>
    .sb-show-main {
      margin: 0 !important;
    }
    .outer {
      border: 1px solid green;
    }
    .content {
      border: 1px solid blue;
    }
    ul {
      margin-left: 20px !important;
      margin-top: 40px !important;
    }
  </style>
  <div class="outer">
    <agl-ds-status-container>
      <div class="content">
        ${html([
          text(
            'Content',
            `This container displays the contents at
            <ul>
              <li>100% of the screen on small devices</li>
              <li>33% of the screen on medium devices</li>
              <li>50% of the screen on large devices.</li>
            </ul>
            <br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
            aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. `
          )
        ])}
      </div>
    </agl-ds-status-container>
  </div>
`;

StatusContainer.storyName = 'Status container';
StatusContainer.parameters = { notes };
