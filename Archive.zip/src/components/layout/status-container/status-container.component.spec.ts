import { newSpecPage } from '@stencil/core/testing';
import { StatusContainerComponent } from './status-container.component';

describe('Status container component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [StatusContainerComponent],
      html: `
      <agl-ds-status-container >
        <div class="content">
          Main content
        </div>
      </agl-ds-status-container>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-status-container>
      <mock:shadow-root>
        <div class="status-container">
          <div class="status-container__inner">
            <slot></slot>
          </div>
        </div>
      </mock:shadow-root>
      <div class="content">
        Main content
      </div>
    </agl-ds-status-container>
      `
    );
  });
});
