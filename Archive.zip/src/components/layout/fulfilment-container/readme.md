# agl-ds-fulfilment-container



<!-- Auto Generated Below -->


## Properties

| Property                | Attribute                 | Description                                                                                                                                                                                                                                                                                                                                                                                                                   | Type                          | Default |
| ----------------------- | ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------- | ------- |
| `sidebarStickyLocation` | `sidebar-sticky-location` | Will set the sidebar to stick to top or bottom on small and medium breakpoints. A value of none will leave the sidebar at the bottom of the component as a non sticky element The top sticky location will have a height of 48px and the bottom sticky will have a height of 120px This prop also determines where the sidebar will be placed in the dom, either directly under the header or at the bottom of the component. | `"bottom" \| "none" \| "top"` | `'top'` |
| `stickySideBarHeader`   | `sticky-side-bar-header`  | Header text for the sticky header section. The header is prefixed with Vew/Hide depending of the open/closed state                                                                                                                                                                                                                                                                                                            | `string`                      | `''`    |


## Methods

### `adjustMainContentHeight() => Promise<void>`

Adjusts the main content height to match with the height of the sidebar

#### Returns

Type: `Promise<void>`




## Slots

| Slot              | Description                                                                                                                                                                       |
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"banner"`        | Contents in this slot will be placed in the full width header, most of the time this is likely to be agl-ds-banner-simple                                                         |
| `"content"`       | Contents in this slot will placed in the main content section                                                                                                                     |
| `"error-summary"` | ***Deprecated use the notification slot instead ***: Contents in this slot will be placed just below the full width header. It is designed for the agl-ds-error-summary component |
| `"notification"`  | Contents in this slot will be placed just above the contents section. It is designed for the agl-ds-error-summary or agl-ds-notification components                               |
| `"sidebar"`       | Contents in this slot will placed in the sidebar for desktop and in a sticky header/footer for mobile and tablet                                                                  |
| `"stepper"`       | Contents in this slot is reserved for the agl-ds-stepper component and will placed just below the banner                                                                          |


## Dependencies

### Depends on

- [agl-ds-spacer](../../core/spacer)
- [agl-ds-text](../../core/text)
- [agl-ds-card](../../core/card)

### Graph
```mermaid
graph TD;
  agl-ds-fulfilment-container --> agl-ds-spacer
  agl-ds-fulfilment-container --> agl-ds-text
  agl-ds-fulfilment-container --> agl-ds-card
  style agl-ds-fulfilment-container fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
