import { newSpecPage } from '@stencil/core/testing';
import { FulfilmentContainer } from './fulfilment-container.component';

describe('fulfilment container', () => {
  it('should render with contents in the correct slots', async () => {
    const page = await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container>
        <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
        <div id="content" slot="content"><div class="left-content">content</div></div>
        <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
        <div id="extra-content" slot="extra-content">extra-content</div>
      </agl-ds-fulfilment-container>`,
      supportsShadowDom: true
    });

    //note that the following expected html has the undefined for the width of one of the containers. The reason for this is that the code is looking for the clientWidth and and Jest does not add that property to the object
    expect(page.root).toEqualHtml(`
    <agl-ds-fulfilment-container>
      <mock:shadow-root>
        <div class="wrapper">
          <div class="wrapper__banner">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12" style="margin-top: 0px;">
                  <slot name="banner"></slot>
                </div>
              </div>
            </div>
          </div>
          <agl-ds-spacer orientation="vertical" size="resp-space04"></agl-ds-spacer>
          <div class="wrapper__main-content">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                  <div class="grid-container">
                    <div class="reverse-row row wrapper__main-content-sidebar">
                      <div class="col-lg-4 col-md-12 col-sm-12 wrapper__main-content-sidebar-top">
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-sticky-top" sr-context="screen reader context" style="top: 0px; width: undefinedpx; left: 16px;">
                            <div class="wrapper__main-content-sidebar-top-sticky-top-header">
                              <agl-ds-text appearance="highlight" fontweight="semibold" styledas="sm">
                                View
                              </agl-ds-text>
                            </div>
                            <span aria-hidden="true" class="wrapper__main-content-sidebar-top-sticky-top-header-icon">
                              svg contents from: src/assets/Icon-chevron-down.svg
                            </span>
                          </div>
                        </div>
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-row">
                            <div class="overlay"></div>
                            <div tabindex="0"></div>
                            <div class="dropdown-start-pos reset-up wrapper__main-content-sidebar-top-sidebar" style="top: 0;">
                              <div class="wrapper__main-content-sidebar-top-sidebar-inner">
                                <div class="grid-container">
                                  <div class="row">
                                    <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                                      <agl-ds-card appearance="elevated">
                                        <slot name="sidebar"></slot>
                                      </agl-ds-card>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-8 col-lg-offset-0 col-md-12 col-sm-12 wrapper__main-content-margin-override">
                        <div>
                          <slot name="content"></slot>
                        </div>
                        <div>
                          <slot name="extra-content"></slot>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        <agl-ds-banner-simple banner-text="header">
          banner text
        </agl-ds-banner-simple>
      </div>
      <div id="content" slot="content">
        <div class="left-content">
          content
        </div>
      </div>
      <div id="sidebar" slot="sidebar">
        <div class="sidebar-demo">
          sidebar
        </div>
      </div>
      <div id="extra-content" slot="extra-content">
        extra-content
      </div>
    </agl-ds-fulfilment-container>
      `);
  });

  it('should render with contents in the correct slots including the error summary', async () => {
    const page = await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container>
        <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
        <div slot="notification"><agl-ds-error-summary></agl-ds-error-summary></div>
        <div id="content" slot="content"><div class="left-content">content</div></div>
        <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
        <div id="extra-content" slot="extra-content">extra-content</div>
      </agl-ds-fulfilment-container>`,
      supportsShadowDom: true
    });
    //note that the following expected html has the undefined for the width of one of the containers. The reason for this is that the code is looking for the clientWidth and and Jest does not add that property to the object
    expect(page.root).toEqualHtml(`
    <agl-ds-fulfilment-container>
      <mock:shadow-root>
        <div class="wrapper">
          <div class="wrapper__banner">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12" style="margin-top: 0px;">
                  <slot name="banner"></slot>
                </div>
              </div>
            </div>
          </div>
          <agl-ds-spacer orientation="vertical" size="resp-space04"></agl-ds-spacer>
          <div class="wrapper__main-content">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                  <div class="grid-container">
                    <div class="reverse-row row wrapper__main-content-sidebar">
                      <div class="col-lg-4 col-md-12 col-sm-12 wrapper__main-content-sidebar-top">
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-sticky-top" sr-context="screen reader context" style="top: 0px; width: undefinedpx; left: 16px; ">
                            <div class="wrapper__main-content-sidebar-top-sticky-top-header">
                              <agl-ds-text appearance="highlight" fontweight="semibold" styledas="sm">
                                View
                              </agl-ds-text>
                            </div>
                            <span aria-hidden="true" class="wrapper__main-content-sidebar-top-sticky-top-header-icon">
                              svg contents from: src/assets/Icon-chevron-down.svg
                            </span>
                          </div>
                        </div>
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-row">
                            <div class="overlay"></div>
                            <div tabindex="0"></div>
                            <div class="dropdown-start-pos reset-up wrapper__main-content-sidebar-top-sidebar" style="top: 0;">
                              <div class="wrapper__main-content-sidebar-top-sidebar-inner">
                                <div class="grid-container">
                                  <div class="row">
                                    <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                                      <agl-ds-card appearance="elevated">
                                        <slot name="sidebar"></slot>
                                      </agl-ds-card>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-8 col-lg-offset-0 col-md-12 col-sm-12 wrapper__main-content-margin-override">
                        <div>
                          <slot name="notification"></slot>
                          <slot name="content"></slot>
                        </div>
                        <div>
                          <slot name="extra-content"></slot>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        <agl-ds-banner-simple banner-text="header">
          banner text
        </agl-ds-banner-simple>
      </div>
      <div slot="notification">
        <agl-ds-error-summary></agl-ds-error-summary>
      </div>
      <div id="content" slot="content">
        <div class="left-content">
          content
        </div>
      </div>
      <div id="sidebar" slot="sidebar">
        <div class="sidebar-demo">
          sidebar
        </div>
      </div>
      <div id="extra-content" slot="extra-content">
        extra-content
      </div>
    </agl-ds-fulfilment-container>
      `);
  });

  //note that the following expected html has the undefined for the width of one of the containers. The reason for this is that the code is looking for the clientWidth and and Jest does not add that property to the object
  it('should render with contents in the correct slots including the stepper', async () => {
    const page = await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container>
        <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
        <div slot="stepper">
        <agl-ds-stepper>
          <agl-ds-step step-id="step1" step-number="1" description="Mobile setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step2" step-number="2" description="Energy setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step3" step-number="3" description="Internet setup" status="active"></agl-ds-step>
          <agl-ds-step step-id="step4" step-number="4" description="Personal details" status="Incomplete"></agl-ds-step>
        </agl-ds-stepper>
        <div id="content" slot="content"><div class="left-content">content</div></div>
        <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
        <div id="extra-content" slot="extra-content">extra-content</div>
      </agl-ds-fulfilment-container>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-fulfilment-container>
      <mock:shadow-root>
        <div class="wrapper">
          <div class="wrapper__banner">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12" style="margin-top: 0px;">
                  <slot name="banner"></slot>
                </div>
              </div>
            </div>
          </div>
          <div class="wrapper__stepper">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                  <slot name="stepper"></slot>
                </div>
              </div>
            </div>
          </div>
          <agl-ds-spacer orientation="vertical" size="resp-space04"></agl-ds-spacer>
          <div class="wrapper__main-content">
            <div class="grid-container">
              <div class="row">
                <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                  <div class="grid-container">
                    <div class="reverse-row row wrapper__main-content-sidebar">
                      <div class="col-lg-4 col-md-12 col-sm-12 wrapper__main-content-sidebar-top">
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-sticky-top" sr-context="screen reader context" style="top: 0px; width: undefinedpx; left: 16px;">
                            <div class="wrapper__main-content-sidebar-top-sticky-top-header">
                              <agl-ds-text appearance="highlight" fontweight="semibold" styledas="sm">
                                View
                              </agl-ds-text>
                            </div>
                            <span aria-hidden="true" class="wrapper__main-content-sidebar-top-sticky-top-header-icon">
                              svg contents from: src/assets/Icon-chevron-down.svg
                            </span>
                          </div>
                        </div>
                        <div class="grid-container">
                          <div class="row wrapper__main-content-sidebar-top-row">
                            <div class="overlay"></div>
                            <div tabindex="0"></div>
                            <div class="dropdown-start-pos reset-up wrapper__main-content-sidebar-top-sidebar" style="top: 0;">
                              <div class="wrapper__main-content-sidebar-top-sidebar-inner">
                                <div class="grid-container">
                                  <div class="row">
                                    <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                                      <agl-ds-card appearance="elevated">
                                        <slot name="sidebar"></slot>
                                      </agl-ds-card>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-8 col-lg-offset-0 col-md-12 col-sm-12 wrapper__main-content-margin-override">
                        <div>
                          <slot name="content"></slot>
                        </div>
                        <div>
                          <slot name="extra-content"></slot>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <div slot="banner">
        <agl-ds-banner-simple banner-text="header">
          banner text
        </agl-ds-banner-simple>
      </div>
      <div slot="stepper">
        <agl-ds-stepper>
          <agl-ds-step description="Mobile setup" status="completed" step-id="step1" step-number="1"></agl-ds-step>
          <agl-ds-step description="Energy setup" status="completed" step-id="step2" step-number="2"></agl-ds-step>
          <agl-ds-step description="Internet setup" status="active" step-id="step3" step-number="3"></agl-ds-step>
          <agl-ds-step description="Personal details" status="Incomplete" step-id="step4" step-number="4"></agl-ds-step>
        </agl-ds-stepper>
        <div id="content" slot="content">
          <div class="left-content">
            content
          </div>
        </div>
        <div id="sidebar" slot="sidebar">
          <div class="sidebar-demo">
            sidebar
          </div>
        </div>
        <div id="extra-content" slot="extra-content">
          extra-content
        </div>
      </div>
    </agl-ds-fulfilment-container>
      `);
  });

  it('should put sidebar slot underneath content when sidebarDomLocation is bottom', async () => {
    const page = await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container sidebar-dom-order="bottom">
      <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
      <div id="content" slot="content"><div class="left-content">content</div></div>
      <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
      <div id="extra-content" slot="extra-content">extra-content</div>
    </agl-ds-fulfilment-container>`,
      supportsShadowDom: false
    });

    //note that the following expected html has the undefined for the width of one of the containers. The reason for this is that the code is looking for the clientWidth and and Jest does not add that property to the object
    expect(page.root).toEqualHtml(`
    <agl-ds-fulfilment-container sidebar-dom-order="bottom">
      <div class="wrapper">
        <div class="wrapper__banner">
          <div class="grid-container">
            <div class="row">
              <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12" style="margin-top: 0px;">
                <div slot="banner">
                  <agl-ds-banner-simple banner-text="header">
                    banner text
                  </agl-ds-banner-simple>
                </div>
              </div>
            </div>
          </div>
        </div>
        <agl-ds-spacer orientation="vertical" size="resp-space04"></agl-ds-spacer>
        <div class="wrapper__main-content">
          <div class="grid-container">
            <div class="row">
              <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                <div class="grid-container">
                  <div class="reverse-row row wrapper__main-content-sidebar">
                    <div class="col-lg-4 col-md-12 col-sm-12 wrapper__main-content-sidebar-top">
                      <div class="grid-container">
                        <div class="row wrapper__main-content-sidebar-top-sticky-top" sr-context="screen reader context" style="top: 0px; width: undefinedpx; left: 16px;">
                          <div class="wrapper__main-content-sidebar-top-sticky-top-header">
                            <agl-ds-text appearance="highlight" fontweight="semibold" styledas="sm">
                              View
                            </agl-ds-text>
                          </div>
                          <span aria-hidden="true" class="wrapper__main-content-sidebar-top-sticky-top-header-icon">
                            svg contents from: src/assets/Icon-chevron-down.svg
                          </span>
                        </div>
                      </div>
                      <div class="grid-container">
                        <div class="row wrapper__main-content-sidebar-top-row">
                          <div class="overlay"></div>
                          <div tabindex="0"></div>
                          <div class="dropdown-start-pos reset-up wrapper__main-content-sidebar-top-sidebar" style="top: 0;">
                            <div class="wrapper__main-content-sidebar-top-sidebar-inner">
                              <div class="grid-container">
                                <div class="row">
                                  <div class="col-lg-12 col-lg-offset-0 col-md-8 col-md-offset-2 col-sm-12">
                                    <agl-ds-card appearance="elevated">
                                      <div id="sidebar" slot="sidebar">
                                        <div class="sidebar-demo">
                                          sidebar
                                        </div>
                                      </div>
                                    </agl-ds-card>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-8 col-lg-offset-0 col-md-12 col-sm-12 wrapper__main-content-margin-override">
                      <div>
                        <div id="content" slot="content">
                          <div class="left-content">
                            content
                          </div>
                        </div>
                      </div>
                      <div>
                        <div id="extra-content" slot="extra-content">
                          extra-content
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </agl-ds-fulfilment-container>
    `);
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container sidebar-dom-order="bottom">
      <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
      <div slot="error-summary"><agl-ds-error-summary></agl-ds-error-summary></div>
      <div id="content" slot="content"><div class="left-content">content</div></div>
      <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
      <div id="extra-content" slot="extra-content">extra-content</div>
    </agl-ds-fulfilment-container>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FulfilmentContainer],
      html: `<agl-ds-fulfilment-container sidebar-dom-order="bottom">
      <div slot="banner"><agl-ds-banner-simple banner-text="header">banner text</agl-ds-banner-simple></div>
      <div slot="error-summary"><p>dummy text</p><agl-ds-error-summary></agl-ds-error-summary></div>
      <div id="content" slot="content"><div class="left-content">content</div></div>
      <div id="sidebar" slot="sidebar"><div class="sidebar-demo">sidebar</div></div>
      <div id="extra-content" slot="extra-content">extra-content</div>
    </agl-ds-fulfilment-container>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
