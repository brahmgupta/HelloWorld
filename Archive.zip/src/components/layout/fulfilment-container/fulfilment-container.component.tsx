import { Component, ComponentInterface, Element, Method, Prop, State, h } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, resizeSVGsForEdge } from '../../../global/utils/utils';

import { CardAppearance } from '../../core/card/card.types';
import iconChevron from '../../../assets/Icon-chevron-down.svg';
import { StickyLocation } from './fulfilment-container.types';

/**
 * @slot banner - Contents in this slot will be placed in the full width header, most of the time this is likely to be agl-ds-banner-simple
 * @slot error-summary - ***Deprecated use the notification slot instead ***: Contents in this slot will be placed just below the full width header. It is designed for the agl-ds-error-summary component
 * @slot notification - Contents in this slot will be placed just above the contents section. It is designed for the agl-ds-error-summary or agl-ds-notification components
 * @slot content - Contents in this slot will placed in the main content section
 * @slot sidebar - Contents in this slot will placed in the sidebar for desktop and in a sticky header/footer for mobile and tablet
 * @slot stepper - Contents in this slot is reserved for the agl-ds-stepper component and will placed just below the banner
 */
@Component({
  tag: 'agl-ds-fulfilment-container',
  styleUrl: 'fulfilment-container.component.scss',
  shadow: true
})
export class FulfilmentContainer implements ComponentInterface {
  @Element() host: HTMLAglDsFulfilmentContainerElement;

  /**
   * Will set the sidebar to stick to top or bottom on small and medium breakpoints.
   * A value of none will leave the sidebar at the bottom of the component as a non sticky element
   * The top sticky location will have a height of 48px and the bottom sticky will have a height of 120px
   * This prop also determines where the sidebar will be placed in the dom, either directly under the header or at the bottom of the component.

   */
  @Prop() sidebarStickyLocation: StickyLocation = 'top';

  /**
   * Header text for the sticky header section. The header is prefixed with Vew/Hide depending of the open/closed state
   */
  @Prop() stickySideBarHeader: string = '';

  @State() showDropDownModal: boolean = false;
  @State() stickyHeader: string = 'View';
  @State() hideSideBar: boolean = false;
  private dropdown: HTMLDivElement;
  private content: HTMLDivElement;
  private arrow: HTMLSpanElement;
  private card: HTMLAglDsCardElement;
  private trigger: HTMLDivElement;
  private banner: HTMLDivElement;
  private wrapper: HTMLDivElement;
  private stepper: HTMLDivElement;
  private mainContentWrapper: HTMLDivElement;
  private spacer: HTMLAglDsSpacerElement;
  private hasNotification: boolean = false;
  private hasErrorSummary: boolean = false;
  private hasStepper: boolean = false;
  private stickyStartPos = 0;
  private cardAppearance: CardAppearance = 'elevated';

  private setMainContentHeight() {
    // this condition is for the scenario where the sidebar height exceeds the main content
    // the extra 128 px is between the bottom of the main content and the page footer
    if (this.card.clientHeight > this.mainContentWrapper.clientHeight) {
      this.mainContentWrapper.style.minHeight = this.card.clientHeight + 128 + 'px';
    }
  }

  private resetLargeViews() {
    this.dropdown.classList.add('reset-down');
    this.dropdown.classList.remove('reset-up');

    this.dropdown.style.top = '0';
    //re-add the border from the card
    this.card.appearance = 'elevated';
    this.setMainContentHeight();
  }

  private resetSmallAndMediumViews() {
    this.showDropDownModal = false;
    this.dropdown.classList.remove('reset-down');
    this.dropdown.classList.add('reset-up');
    //remove the border from the card
    const bannerBoundingClientRect = this.banner.getBoundingClientRect();
    this.card.appearance = 'flat';
    //get the height of the banner to set the position of the sticky header
    this.stickyStartPos = -(
      bannerBoundingClientRect.height +
      this.trigger.getBoundingClientRect().height +
      this.spacer.getBoundingClientRect().height +
      (this.hasStepper ? this.stepper.getBoundingClientRect().height : 0)
    );
    this.banner.style.marginTop = this.trigger.getBoundingClientRect().height + 'px';
    this.trigger.style.top = String(this.stickyStartPos) + 'px';

    const docWidth = document.documentElement.clientWidth || document.body.clientWidth;
    this.trigger.style.width = docWidth + 'px';
    let left = '';
    if (this.wrapper.getBoundingClientRect().width < 720) {
      left = -(bannerBoundingClientRect.left - 16) + 'px';
      if (window.pageYOffset > this.wrapper.offsetTop) {
        left = -(bannerBoundingClientRect.left - 32) + 'px';
      }
    } else {
      left = -(bannerBoundingClientRect.left - 8) + 'px';
      if (window.pageYOffset > this.wrapper.offsetTop) {
        left = '8px';
      }
    }
    this.trigger.style.left = left;
  }

  private openDropDownModal() {
    this.showDropDownModal = !this.showDropDownModal;
    const wrapperBoundingClientRect = this.wrapper.getBoundingClientRect();
    //if we have a scroll bar
    const scrollBarWidth = window.innerWidth - wrapperBoundingClientRect.width;
    if (this.showDropDownModal) {
      const docWidth = document.documentElement.clientWidth || document.body.clientWidth;
      this.trigger.style.width = docWidth + scrollBarWidth + 'px';
      let left = '';
      if (wrapperBoundingClientRect.width < 720) {
        left = '0px';
        if (window.pageYOffset > this.wrapper.offsetTop) {
          //we have scrolled past the top
          left = '16px';
        }
      } else {
        if (window.pageYOffset > this.wrapper.offsetTop) {
          //we have scrolled past the top
          left = '8px';
        } else {
          left = -(this.banner.getBoundingClientRect().left - 8) + 'px';
          if (scrollBarWidth > 0) {
            left = -(this.banner.getBoundingClientRect().left - 5) + 'px';
          }
        }
      }
      this.trigger.style.left = left;

      this.dropdown.classList.remove('reset-down');
      this.dropdown.classList.remove('reset-up');
      this.dropdown.classList.add('slide-down');
      this.dropdown.classList.remove('slide-up');
      const dropdownTop = this.trigger.getBoundingClientRect().top + this.trigger.getBoundingClientRect().height;
      this.dropdown.style.top = dropdownTop + 'px';
      this.dropdown.style.height = '';
      const amountOfOverlayToShow = 64;
      const maxHeight = window.innerHeight - dropdownTop - amountOfOverlayToShow;

      if (Number(this.dropdown.getBoundingClientRect().height) > maxHeight) {
        this.dropdown.style.height = maxHeight + 'px';
      }

      document.body.style.overflow = 'hidden'; //stop the scroll of main content
      this.stickyHeader = 'Hide';
      this.arrow.classList.add('rotate-apply');
      this.arrow.classList.remove('rotate-remove');
    } else {
      this.trigger.style.width = window.innerWidth + scrollBarWidth + 'px';
      let left = '';
      if (wrapperBoundingClientRect.width < 720) {
        if (window.pageYOffset > this.wrapper.offsetTop) {
          //we have scrolled past the top
          left = '16px';
        } else {
          this.trigger.style.width = window.innerWidth + 'px';
          left = -(this.banner.getBoundingClientRect().left - 16) + 'px';
          if (scrollBarWidth > 0) {
            left = -(this.banner.getBoundingClientRect().left - 16) + 'px';
          }
        }
      } else {
        if (window.pageYOffset > this.wrapper.offsetTop) {
          //we have scrolled past the top
          left = '8px';
        } else {
          this.trigger.style.width = window.innerWidth + 'px';
          left = -(this.banner.getBoundingClientRect().left - 8) + 'px';
          if (scrollBarWidth > 0) {
            left = -(this.banner.getBoundingClientRect().left - 16) + 'px';
          }
        }
      }
      this.trigger.style.left = left;
      this.arrow.classList.remove('rotate-apply');
      this.arrow.classList.add('rotate-remove');
      this.dropdown.classList.remove('slide-down');
      this.dropdown.classList.add('slide-up');
      document.body.style.overflow = ''; //restore the scroll of main content
      this.stickyHeader = 'View';
    }
  }

  /**
   * Adjusts the main content height to match with the height of the sidebar
   */
  @Method()
  async adjustMainContentHeight() {
    this.setMainContentHeight();
  }

  private resetViews() {
    this.dropdown.style.top = '0';
    this.banner.style.marginTop = '0';
    if (this.wrapper.getBoundingClientRect().width > 991) {
      this.resetLargeViews();
    } else {
      this.resetSmallAndMediumViews();
    }
  }

  private setStickyHeader() {
    if (this.sidebarStickyLocation === 'top') {
      let smallOffset = 16;
      let mediumOffset = 8;

      if (window.pageYOffset > this.wrapper.offsetTop) {
        //we have scrolled past the top
        this.trigger.classList.add('sticky');
        smallOffset = 32;
        mediumOffset = 8;
      } else {
        this.trigger.classList.remove('sticky');
      }
      let left = '';
      const wrapperBoundingClientRect = this.wrapper.getBoundingClientRect();
      if (wrapperBoundingClientRect.width < 720) {
        left = -(this.banner.getBoundingClientRect().left - smallOffset) + 'px';
      } else if (wrapperBoundingClientRect.width < 991) {
        left = -(this.banner.getBoundingClientRect().left - mediumOffset) + 'px';
        if (window.pageYOffset > this.wrapper.offsetTop) {
          //we have scrolled past the top
          left = '8px';
        }
      }
      this.trigger.style.left = left;
    }
  }

  private throttle = (func, limit) => {
    let inThrottle;
    return (...args) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = setTimeout(() => (inThrottle = false), limit);
      }
    };
  };

  private throttledScrollHandler = this.throttle(() => {
    if (this.wrapper.getBoundingClientRect().width <= 991) {
      if (this.sidebarStickyLocation === 'top') {
        this.setStickyHeader();
      } else {
        const position = this.content.getBoundingClientRect();

        if (Math.floor(position.bottom) <= window.innerHeight) {
          this.hideSideBar = true;
        } else {
          this.hideSideBar = false;
        }
      }
    }
  }, 5);

  async disconnectedCallback() {
    window.removeEventListener('scroll', this.throttledScrollHandler);
    window.removeEventListener('resize', this.resetViews);
  }

  componentDidLoad() {
    if (this.sidebarStickyLocation === 'top') {
      this.resetViews();
      setTimeout(() => {
        //make sure page starts at the top
        window.scrollTo(0, 0);
        window.onscroll = () => {
          this.setStickyHeader();
        };
      }, 500);

      window.addEventListener('resize', this.resetViews.bind(this));
      resizeSVGsForEdge(this.arrow, '10', '6', '10', '6', '10', '6');
    }
    this.throttledScrollHandler();
    window.addEventListener('scroll', this.throttledScrollHandler.bind(this));
  }

  componentWillLoad() {
    this.hasErrorSummary = !!this.host.querySelector('[slot="error-summary"]');
    this.hasNotification = this.hasErrorSummary || !!this.host.querySelector('[slot="notification"]');
    this.hasStepper = !!this.host.querySelector('[slot="stepper"]');

    if (this.host.querySelector('[slot="error-summary"]')) {
      checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="error-summary"]'), ['div', 'agl-ds-error-summary']);
    }
    if (this.host.querySelector('[slot="notification"]')) {
      checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="notification"]'), [
        'div',
        'agl-ds-error-summary',
        'agl-ds-button',
        'agl-ds-notification'
      ]);
    }
  }

  render() {
    return (
      <div class="wrapper" ref={(el) => (this.wrapper = el)}>
        <div class="wrapper__banner">
          <div class="grid-container">
            <div class="row ">
              <div class="col-sm-12 col-md-8 col-md-offset-2 col-lg-12 col-lg-offset-0" ref={(el) => (this.banner = el)}>
                <slot name="banner"></slot>
              </div>
            </div>
          </div>
        </div>
        {this.hasStepper && (
          <div class="wrapper__stepper" ref={(el) => (this.stepper = el)}>
            <div class="grid-container">
              <div class="row ">
                <div class="col-sm-12 col-md-8 col-md-offset-2 col-lg-12 col-lg-offset-0">
                  <slot name="stepper"></slot>
                </div>
              </div>
            </div>
          </div>
        )}
        <agl-ds-spacer orientation="vertical" size="resp-space04" ref={(el) => (this.spacer = el)}></agl-ds-spacer>

        <div class="wrapper__main-content" ref={(el) => (this.mainContentWrapper = el)}>
          <div class="grid-container">
            {/* main contents */}
            <div class="row">
              <div class="col-sm-12 col-md-8 col-md-offset-2 col-lg-12 col-lg-offset-0">
                <div class="grid-container ">
                  <div
                    class={{
                      'wrapper__main-content-sidebar  row ': true,
                      'reverse-row': this.sidebarStickyLocation === 'top'
                    }}
                  >
                    {this.sidebarStickyLocation === 'top' && (
                      <div class="wrapper__main-content-sidebar-top col-sm-12 col-md-12 col-lg-4">
                        <div class="grid-container">
                          <div
                            class="wrapper__main-content-sidebar-top-sticky-top row"
                            onClick={() => this.openDropDownModal()}
                            sr-context="screen reader context"
                            ref={(el) => (this.trigger = el)}
                          >
                            <div class="wrapper__main-content-sidebar-top-sticky-top-header">
                              <agl-ds-text appearance="highlight" fontWeight="semibold" styledAs="sm">
                                {this.stickyHeader + ' ' + this.stickySideBarHeader}
                              </agl-ds-text>
                            </div>
                            <span
                              aria-hidden="true"
                              class="wrapper__main-content-sidebar-top-sticky-top-header-icon"
                              innerHTML={iconChevron}
                              ref={(el) => (this.arrow = el)}
                            />
                          </div>
                        </div>
                        <div class="grid-container ">
                          <div class="row wrapper__main-content-sidebar-top-row">
                            <div class={{ overlay: true, visible: this.showDropDownModal }}></div>
                            <div tabIndex={0}></div>
                            <div class="wrapper__main-content-sidebar-top-sidebar dropdown-start-pos" ref={(el) => (this.dropdown = el)}>
                              <div class="wrapper__main-content-sidebar-top-sidebar-inner ">
                                <div class="grid-container">
                                  <div class="row">
                                    <div class="col-sm-12 col-md-8 col-md-offset-2 col-lg-12 col-lg-offset-0">
                                      <agl-ds-card appearance={this.cardAppearance} ref={(el) => (this.card = el)}>
                                        <slot name="sidebar"></slot>
                                      </agl-ds-card>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    <div
                      class={{
                        'col-sm-12 col-md-12  col-lg-8 col-lg-offset-0': true,
                        'wrapper__main-content-bottom': this.sidebarStickyLocation === 'bottom' || this.sidebarStickyLocation === 'none',
                        'wrapper__main-content-margin-override': this.sidebarStickyLocation === 'top'
                      }}
                    >
                      <div ref={(el) => (this.content = el)}>
                        {this.hasErrorSummary && <slot name="error-summary"></slot>}
                        {this.hasNotification && <slot name="notification"></slot>}

                        <slot name="content"></slot>
                      </div>
                      <div>
                        <slot name="extra-content"></slot>
                      </div>
                    </div>

                    {(this.sidebarStickyLocation === 'bottom' || this.sidebarStickyLocation === 'none') && (
                      <div
                        class={{
                          'col-sm-12 col-lg-4 col-lg-offset-0': true,
                          'wrapper__main-content-bottom-sticky-sidebar': this.sidebarStickyLocation === 'bottom',
                          'wrapper__main-content-bottom-sidebar': this.sidebarStickyLocation === 'none',
                          hidden: this.sidebarStickyLocation === 'bottom' && this.hideSideBar
                        }}
                      >
                        <slot name="sidebar"></slot>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
