/**
 * Will set the sidebar to stick to top or bottom on small and medium breakpoints.
 * A value of none will leave the sidebar at the bottom of the component as a non sticky element
 * The top sticky location will have a height of 48px and the bottom sticky will have a height of 120px
 * This prop also determines where the sidebar will be placed in the dom, either directly under the header or at the bottom of the component.
 */
export type StickyLocation = 'top' | 'bottom' | 'none';
