import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Layout/Fulfilment container (sticky header or footer at small & medium breakpoints)',

  parameters: {
    paddings: { disable: true }
  }
};

export const Default = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="top">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>

      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div>
          sidebar content<br /><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor
          sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum the end
        </div>
      </div>
    </agl-ds-fulfilment-container>`;
};

Default.storyName = 'with sticky header';
Default.parameters = {
  notes,
  paddings: { disable: true },
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

export const WithErrorSummary = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="top">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>
      <div slot="notification"><agl-ds-error-summary></agl-ds-error-summary></div>
      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div>
          sidebar content<br /><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor
          sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumm the end
        </div>
      </div>
    </agl-ds-fulfilment-container>`;
};

WithErrorSummary.storyName = 'with sticky header & error summary';
WithErrorSummary.parameters = {
  notes,
  paddings: { disable: true },
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

export const WithErrorSummaryAndStepper = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="top">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>
      <div slot="stepper">
        <agl-ds-stepper>
          <agl-ds-step step-id="step1" step-number="1" description="Mobile setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step2" step-number="2" description="Energy setup" status="completed"></agl-ds-step>
          <agl-ds-step step-id="step3" step-number="3" description="Internet setup" status="active"></agl-ds-step>
          <agl-ds-step step-id="step4" step-number="4" description="Personal details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step5" step-number="5" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step6" step-number="6" description="Review and submit" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step7" step-number="7" description="Completed" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step8" step-number="8" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step9" step-number="9" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step10" step-number="10" description="Review and submit" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step11" step-number="11" description="Completed" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step12" step-number="12" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step13" step-number="13" description="Billing details" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step13" step-number="14" description="Review and submit" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step15" step-number="15" description="Completed" status="Incomplete"></agl-ds-step>
          <agl-ds-step step-id="step16" step-number="16" description="Billing details" status="Incomplete"></agl-ds-step>
        </agl-ds-stepper>
      </div>
      <div slot="notification"><agl-ds-error-summary></agl-ds-error-summary></div>
      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div>
          sidebar content<br /><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua.<br />
          1Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
          in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<br />
          2Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor
          sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
          voluptate velit esse cillum dolore eu fugiat nulla pariatur.<br />
          3Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
          enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur.<br />
          4 Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor
          sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
          voluptate velit esse cillum dolore eu fugiat nulla pariatur.<br />
          5Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
          enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt
          in culpa qui officia deserunt mollit anim id est laborum the end
        </div>
      </div>
    </agl-ds-fulfilment-container>`;
};

WithErrorSummaryAndStepper.storyName = 'with sticky header & error summary and stepper';
WithErrorSummaryAndStepper.parameters = {
  notes,
  paddings: { disable: true },
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

export const WithResponsiveSpacerAtBottom = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="top">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>

      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div>
          sidebar content<br /><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor
          sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br />
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br />Duis aute irure
          dolor in reprehenderit in voluptate velit esse cillum dolore<br />
          eu fugiat nulla pariatur.<br />
          Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum the end
        </div>
      </div>
      <div slot="extra-content">Extra content</div>
    </agl-ds-fulfilment-container>`;
};

WithResponsiveSpacerAtBottom.storyName = 'with sticky header & extra content slot';
WithResponsiveSpacerAtBottom.parameters = {
  notes,
  paddings: { disable: true },
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

export const WithStickyFooter = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="bottom">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>

      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div class="sidebar-demo-bottom"><agl-ds-button>click me</agl-ds-button></div>
      </div>
    </agl-ds-fulfilment-container>`;
};

WithStickyFooter.storyName = 'with a sticky footer with notification bar';
WithStickyFooter.parameters = {
  notes,
  paddings: { disable: true },
  a11y: {
    options: {
      rules: {
        // this rule is excluded due to the gradient of the banner of which UX has assessed the contrast
        'color-contrast': { enabled: false }
      }
    }
  }
};

const chevron = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
    <path d="M5.043,7.293l4.5-4.5a1,1,0,1,1,1.414,1.414L7.1641,8l3.7929,3.793a1,1,0,1,1-1.414,1.414l-4.5-4.5A.9994.9994,0,0,1,5.043,7.293Z" fill="#001cb0" class="primary-fill">
</path>
    <rect width="16" height="16" transform="translate(16 16) rotate(180)" fill="none">
</rect>
</svg>`;

export const WithNonStickyFooter = () => {
  return html` <div class="header">AGL header from AEM</div>
    <agl-ds-fulfilment-container sticky-side-bar-header="sticky sidebar" sidebar-sticky-location="none">
      <div slot="banner"><agl-ds-banner-simple banner-text="banner"></agl-ds-banner-simple></div>
      <div slot="stepper">
        <div class="back-button">
          <agl-ds-button type="tertiary" size="sm" href="https://www.agl.com.au" icon="${chevron}" icon-size="xxs" icon-position="left">
            Back to home
          </agl-ds-button>
        </div>
      </div>
      <div slot="content">
        <div class="left-content">
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content<br />
          content<br />content<br />content<br />content<br />content last<br />
        </div>
      </div>
      <div slot="sidebar">
        <div class="sidebar-demo-bottom"><agl-ds-button>click me</agl-ds-button></div>
      </div>
    </agl-ds-fulfilment-container>`;
};

WithNonStickyFooter.storyName = 'with a non sticky footer';
WithNonStickyFooter.parameters = { notes, paddings: { disable: true } };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.sidebar-demo-bottom { border: 1px solid black;  text-align: center;}');
style.sheet.insertRule('.left-content {  border: 1px solid black;}');
style.sheet.insertRule('.back-button { width: 150px}');
style.sheet.insertRule('.header { background-color:#7dcd8a; height:100px; z-index:99; position:relative}');
