import { Component, Host, h, ComponentInterface } from '@stencil/core';

@Component({
  tag: 'agl-ds-theme-pd',
  styleUrl: 'pd.scss',
  shadow: false
})
export class ThemePD implements ComponentInterface {
  render() {
    return (
      <Host>
        <div class="theme-pd">
          <slot></slot>
        </div>
      </Host>
    );
  }
}
