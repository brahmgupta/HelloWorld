import { Component, ComponentInterface, Host, h } from '@stencil/core';

@Component({
  tag: 'agl-ds-colour-palette',
  styleUrl: 'colour-palette.component.scss',
  shadow: true
})
export class ColourPaletteComponent implements ComponentInterface {
  private createTable = (title: string, cells) => {
    const table = [];
    const children = [];
    for (let j = 0; j < cells; j++) {
      const className = 'c-' + title.toLowerCase() + '-0' + (j + 1);
      children.push(
        <td class={className}>
          <div></div>
          <div></div>
        </td>
      );
    }
    table.push(<tr>{children}</tr>);
    return (
      <table>
        <th>{title}</th>
        {table}
      </table>
    );
  };

  private createTableAlt = (title: string, cells: any, newRowAt: number = null) => {
    const table = [];
    let children = [];
    for (let j = 0; j < cells.length; j++) {
      children.push(
        <td class={cells[j]}>
          <div></div>
          <div></div>
        </td>
      );
      if (newRowAt && j % newRowAt === newRowAt - 1) {
        table.push(<tr>{children}</tr>);
        children = [];
      }
    }
    table.push(<tr>{children}</tr>);
    return (
      <table>
        <th>{title}</th>
        {table}
      </table>
    );
  };

  render() {
    let primaryTints = [1, 2].map((c) => [90, 80, 70, 60, 50, 40, 30, 20, 10].map((t) => `c-primary-0${c}-tint-${t}`));
    primaryTints = Array.prototype.concat.apply([], primaryTints);
    let secondaryTints = [1, 2, 3, 4].map((c) => [90, 80, 70, 60, 50, 40, 30, 20, 10].map((t) => `c-secondary-0${c}-tint-${t}`));
    secondaryTints = Array.prototype.concat.apply([], secondaryTints);
    let tertiaryTints = [1, 2, 3, 4].map((c) => [90, 80, 70, 60, 50, 40, 30, 20, 10].map((t) => `c-tertiary-0${c}-tint-${t}`));
    tertiaryTints = Array.prototype.concat.apply([], tertiaryTints);

    return (
      <Host>
        {this.createTable('Primary', 2)}
        {this.createTableAlt('Tints - primary', primaryTints, 9)}
        {this.createTableAlt('Shades - primary', ['c-primary-01-shade-20'])}
        {this.createTable('Secondary', 4)}
        {this.createTableAlt('Tints - secondary', secondaryTints, 9)}
        {this.createTable('Tertiary', 4)}
        {this.createTableAlt('Tints - tertiary', tertiaryTints, 9)}
        {this.createTable('Neutral', 8)}
        {this.createTableAlt('Validation levels', ['information', 'warning', 'error', 'success'])}
        {this.createTableAlt('Tints - Validation', ['success-tint-20', 'error-tint-20'])}
        {this.createTableAlt('Tab Component', ['c-tab-text-active', 'c-tab-border-active', 'c-tab-text'])}
        {this.createTableAlt('Focus ring', ['focus-ring-colour'])}
        {this.createTableAlt('Gradient', ['gradient', 'gradient01'])}
        {this.createTableAlt('Shadows', ['shadow1', 'shadow2', 'shadow3', 'shadow4', 'shadow5', 'shadow6'])}
      </Host>
    );
  }
}
