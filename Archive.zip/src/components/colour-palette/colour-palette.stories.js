import { html } from 'lit-html';

export default {
  title: 'Colour pallette'
};

export const Palette = () => html`<agl-ds-colour-palette></agl-ds-colour-palette>`;
