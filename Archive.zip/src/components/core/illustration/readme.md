# agl-ds-illustration



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                                                                                                                                         | Type                                                                                                | Default     |
| -------------- | --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- | ----------- |
| `altText`      | `alt-text`      | Adds alt text to images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text | `string`                                                                                            | `''`        |
| `bottomMargin` | `bottom-margin` | Determines the over-ride bottom margin size                                                                                                                                         | `"none" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space05" \| "space06"` | `'space04'` |
| `imagePath`    | `image-path`    | The path of the illustration to be displayed                                                                                                                                        | `string`                                                                                            | `undefined` |
| `size`         | `size`          | The size of the illustration to be displayed on the banner                                                                                                                          | `"lg" \| "md" \| "sm" \| "xl" \| "xs"`                                                              | `'sm'`      |


## Dependencies

### Used by

 - [agl-ds-banner-simple](../../composite/banner/banner-simple)
 - [agl-ds-illustration-text-simple](../../composite/illustration-text/simple)

### Graph
```mermaid
graph TD;
  agl-ds-banner-simple --> agl-ds-illustration
  agl-ds-illustration-text-simple --> agl-ds-illustration
  style agl-ds-illustration fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
