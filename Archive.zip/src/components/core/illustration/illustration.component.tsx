import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { BottomMargin } from '../../../global/component.types';
import { IllustrationSize } from './illustration.types';

@Component({
  tag: 'agl-ds-illustration',
  styleUrl: 'illustration.component.scss',
  shadow: true
})
export class IllustrationComponent implements ComponentInterface {
  /**
   * The path of the illustration to be displayed
   */
  @Prop() imagePath: string;

  /**
   * The size of the illustration to be displayed on the banner
   */
  @Prop() size: IllustrationSize = 'sm';

  /**
   * Determines the over-ride bottom margin size
   */
  @Prop() bottomMargin: BottomMargin = 'space04';

  /**
   * Adds alt text to images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text
   */
  @Prop() altText: string = '';

  render() {
    return (
      <Host>
        {this.altText && <span class="sr-only">Image: {this.altText}</span>}
        <img
          aria-hidden="true"
          src={this.imagePath}
          class={{ illustration: true, ['illustration__size--' + this.size]: true, ['agl-ds--bottom-margin-' + this.bottomMargin]: true }}
        />
      </Host>
    );
  }
}
