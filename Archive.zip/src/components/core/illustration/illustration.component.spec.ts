import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { IllustrationComponent } from './illustration.component';

describe('Illustration Component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [IllustrationComponent],
      html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="lg"></agl-ds-illustration>`
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-illustration image-path="../../../assets/man-with-mobile.svg" size="lg">
        <mock:shadow-root>
          <img aria-hidden="true" class="agl-ds--bottom-margin-space04 illustration illustration__size--lg" src="../../../assets/man-with-mobile.svg">
        </mock:shadow-root>
      </agl-ds-illustration>
    `);
  });

  it('should render my component with alt text', async () => {
    const page = await newSpecPage({
      components: [IllustrationComponent],
      html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="lg" alt-text="dummy alt text"></agl-ds-illustration>`
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-illustration alt-text="dummy alt text" image-path="../../../assets/man-with-mobile.svg" size="lg">
      <mock:shadow-root>
        <span class="sr-only">
          Image: dummy alt text
        </span>
        <img aria-hidden="true" class="agl-ds--bottom-margin-space04 illustration illustration__size--lg" src="../../../assets/man-with-mobile.svg">
      </mock:shadow-root>
    </agl-ds-illustration>
    `);
  });

  describe('pass details to display the illustration size', () => {
    let page: SpecPage;

    it('should present a "extra small" illustration', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="xs"></agl-ds-illustration>`,
        supportsShadowDom: false
      });
      const illustration = page.doc.querySelector('.illustration__size--xs');
      expect(illustration).toBeTruthy();
    });

    it('should present a "small" illustration', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="sm"></agl-ds-illustration>`,
        supportsShadowDom: false
      });
      const illustration = page.doc.querySelector('.illustration__size--sm');
      expect(illustration).toBeTruthy();
    });

    it('should present a "medium" illustration', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="md"></agl-ds-illustration>`,
        supportsShadowDom: false
      });
      const illustration = page.doc.querySelector('.illustration__size--md');
      expect(illustration).toBeTruthy();
    });

    it('should present an "extra large" illustration', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html: `<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="xl"></agl-ds-illustration>`,
        supportsShadowDom: false
      });
      const illustration = page.doc.querySelector('.illustration__size--xl');
      expect(illustration).toBeTruthy();
    });

    it('should render the component with the bottom margin', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html: '<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="md"></agl-ds-illustration>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('.illustration__size--md');
      const classList = element.classList.contains('agl-ds--bottom-margin-space04');
      expect(classList).toBeTruthy();
    });

    it('should render the component with the bottom margin suppressed', async () => {
      page = await newSpecPage({
        components: [IllustrationComponent],
        html:
          '<agl-ds-illustration  image-path="../../../assets/man-with-mobile.svg" size="md" bottom-margin="none"></agl-ds-illustration>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('.illustration__size--md');
      const classList = element.classList.contains('agl-ds--bottom-margin-none');
      expect(classList).toBeTruthy();
    });
  });
});
