export type IllustrationSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
