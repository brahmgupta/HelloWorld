import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/illustration'
};

export const Illustration = () => html`
  <agl-ds-illustration
    image-path="${text('Path', '../../../assets/man-with-mobile.svg')}"
    size="${select('Image size', ['xs', 'sm', 'md', 'lg', 'xl'], 'lg')}"
    bottom-margin="${select('bottom margin', ['', 'none'], '')}"
    alt-text="${text('Alt text', 'here is some text that describes the image for screen readers to announce')}"
  >
  </agl-ds-illustration>
  <agl-ds-p>A line of text to illustrate the bottom margin on the illustration</agl-ds-text>
`;

Illustration.parameters = { notes };
