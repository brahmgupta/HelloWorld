import { newSpecPage } from '@stencil/core/testing';
import { ListComponent } from './list.component';

describe('list component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [ListComponent],
      html: `<agl-ds-list><agl-ds-list-item><agl-ds-tile></agl-ds-tile></agl-ds-list-item></agl-ds-list>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-list>
         <mock:shadow-root>
           <ul class="list list--horizontal list--space02">
             <slot></slot>
           </ul>
          </mock:shadow-root>
           <agl-ds-list-item>
             <agl-ds-tile></agl-ds-tile>
           </agl-ds-list-item>
        </agl-ds-list>`
    );
  });
});
