import { Component, ComponentInterface, Element, Host, h, Prop } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../../global/utils/utils';
import { SpaceSize } from '../../spacer/spacer.types';

/**
 *@slot default - Content slot for `list-item`s to be displayed in the list
 */

@Component({
  tag: 'agl-ds-list',
  styleUrl: 'list.component.scss',
  shadow: true
})
export class ListComponent implements ComponentInterface {
  @Element() host: HTMLAglDsListElement;

  /**
   * Sets the visual orientation of the list, either 'vertical' or 'horizontal'
   */
  @Prop() orientation: 'vertical' | 'horizontal' = 'horizontal';

  /**
   * Allow the items in the list to wrap to the next row or column
   */
  @Prop() wrap: boolean = false;

  /**
   * Set the gap spacing between items
   */
  @Prop() spacing: SpaceSize = 'space02';

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host as HTMLElement, ['agl-ds-list', 'agl-ds-list-item']);
  }

  render() {
    return (
      <Host>
        <ul
          class={{
            list: true,
            'list--horizontal': this.orientation === 'horizontal',
            'list--vertical': this.orientation === 'vertical',
            'list--wrap': this.wrap,
            ['list--' + this.spacing]: true
          }}
        >
          <slot></slot>
        </ul>
      </Host>
    );
  }
}
