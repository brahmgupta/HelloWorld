# agl-ds-list



<!-- Auto Generated Below -->


## Properties

| Property      | Attribute     | Description                                                                | Type                                                                                                                               | Default        |
| ------------- | ------------- | -------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `orientation` | `orientation` | Sets the visual orientation of the list, either 'vertical' or 'horizontal' | `"horizontal" \| "vertical"`                                                                                                       | `'horizontal'` |
| `spacing`     | `spacing`     | Set the gap spacing between items                                          | `"resp-space04" \| "resp-space06" \| "resp-space08" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space06"` | `'space02'`    |
| `wrap`        | `wrap`        | Allow the items in the list to wrap to the next row or column              | `boolean`                                                                                                                          | `false`        |


## Slots

| Slot        | Description                                               |
| ----------- | --------------------------------------------------------- |
| `"default"` | Content slot for `list-item`s to be displayed in the list |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
