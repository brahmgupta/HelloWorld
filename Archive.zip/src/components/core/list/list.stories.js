import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './list/readme.md';

export default {
  title: 'Core/List'
};

export const List = () => {
  const optionOrientation = select('Orientation', ['vertical', 'horizontal'], 'horizontal');
  const optionWrap = select('Wrap', [true, false], false);
  const optionSpacing = select('Spacing', ['space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'], 'space03');

  return html`
    <agl-ds-spacer orientation="vertical"></agl-ds-spacer>
    <agl-ds-list orientation="${optionOrientation}" wrap="${optionWrap}" spacing="${optionSpacing}">
      <agl-ds-list-item>
        <agl-ds-tile id="tl" theme="primary01" active="false" hoverable="true" name="heading and content tile">
          <div slot="tile-heading" style="height:48px; display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center;">
              <agl-ds-icon icon-path="../../../assets/agl_icon_dig_solar_yes_32px.svg" size="sm"> </agl-ds-icon>
              <agl-ds-p style="padding-left:8px" styled-as="md" bottom-margin="none">I'm a Tile</agl-ds-p>
            </div>
            <agl-ds-link styled-as="md">Link</agl-ds-link>
          </div>
          <div slot="tile-content" style="height:96px; display:flex; flex-direction:column; align-items:center; justify-content:center;">
            <agl-ds-p styled-as="lg" bottom-margin="none">With some great content</agl-ds-p>
            <agl-ds-p styled-as="sm" bottom-margin="none">And some smaller but still great content</agl-ds-p>
          </div>
        </agl-ds-tile>
      </agl-ds-list-item>
      <agl-ds-list-item>
        <agl-ds-card appearance="border" hoverable="true">
          <div style="padding:12px;">
            <agl-ds-p>I'm a card, woohoo!</agl-ds-p>
            <agl-ds-p>Like a tile, but generic-er</agl-ds-p>
          </div>
        </agl-ds-card>
      </agl-ds-list-item>
      <agl-ds-list-item>
        <agl-ds-h2>I'm a heading</agl-ds-h2>
        <agl-ds-p>And some text</agl-ds-p>
        <agl-ds-p>sitting here in the list</agl-ds-p>
      </agl-ds-list-item>
    </agl-ds-list>
  `;
};

List.parameters = { notes };
List.storyname = 'Tile list';
