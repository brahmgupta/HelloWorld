# agl-ds-list-item



<!-- Auto Generated Below -->


## Slots

| Slot        | Description                           |
| ----------- | ------------------------------------- |
| `"default"` | content to be placed in the list item |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
