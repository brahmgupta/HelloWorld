import { newSpecPage } from '@stencil/core/testing';
import { ListItemComponent } from './list-item.component';

describe('list item component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [ListItemComponent],
      html: `<agl-ds-list-item><agl-ds-tile></agl-ds-tile></agl-ds-list-item>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-list-item>
         <mock:shadow-root>
           <li class="list-item">
             <slot></slot>
           </li>
          </mock:shadow-root>
          <agl-ds-tile></agl-ds-tile>
       </agl-ds-list-item>
        `
    );
  });
});
