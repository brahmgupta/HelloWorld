import { Component, ComponentInterface, h } from '@stencil/core';

/**
 *@slot default - content to be placed in the list item
 */

@Component({
  tag: 'agl-ds-list-item',
  styleUrl: 'list-item.component.scss',
  shadow: true
})
export class ListItemComponent implements ComponentInterface {
  render() {
    return (
      <li class={{ 'list-item': true }}>
        <slot></slot>
      </li>
    );
  }
}
