import { boolean, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Checkbox'
};

export const DefaultCheckbox = () => {
  const opt1Checked = boolean('Option 1 checked', false);
  const opt2Checked = boolean('Option 2 checked', true);
  const opt3Checked = boolean('Option 3 checked', true);
  const opt1Label = text('Option 1 label', 'checkbox option 1');
  const opt2Label = text('Option 2 label', 'checkbox option 2');
  const opt3Label = text('Option 3 label', 'checkbox option 3');

  return html`
    <agl-ds-checkbox id="opt1" checked="${opt1Checked}" value="opt1">${opt1Label}</agl-ds-checkbox>

    <agl-ds-checkbox id="opt2" checked="${opt2Checked}" value="opt2"> ${opt2Label} </agl-ds-checkbox>

    <agl-ds-checkbox id="opt3" checked="${opt3Checked}" value="opt3">${opt3Label}</agl-ds-checkbox>
  `;
};

DefaultCheckbox.storyName = 'Default checkbox';
DefaultCheckbox.parameters = { notes };

export const ValidationCheckbox = () => {
  const opt1Checked = boolean('Option 1 checked', false);
  const opt1Label = text('Option 1 label', 'checkbox option 1');
  const validationText = text('Option 1 validation text', 'This is validation error text');
  const hintText = text('Option 1 hint text', 'This is hint text');

  return html`
    <agl-ds-checkbox
      id="myId"
      checked="${opt1Checked}"
      type="validation"
      value="chk1"
      hint-text="${hintText}"
      validation-text="${validationText}"
    >
      ${opt1Label}
    </agl-ds-checkbox>
    <label>
      <input type="checkbox" id="myid" onClick="document.getElementById('myId').setAttribute('has-error',this.checked)" />
      Toggle Error
    </label>
    <br />
    <br />
    <agl-ds-checkbox type="validation">
      <agl-ds-text>Heading of label</agl-ds-text><br />
      <agl-ds-text>1. First line of label</agl-ds-text><br />
      <agl-ds-text>2. Second line of label</agl-ds-text><br />
      <agl-ds-text>2. Second line of label</agl-ds-text>
    </agl-ds-checkbox>
  `;
};

ValidationCheckbox.storyName = 'Validation checkbox';
ValidationCheckbox.parameters = { notes };
