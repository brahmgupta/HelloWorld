import { newSpecPage } from '@stencil/core/testing';
import { CheckboxComponent } from './checkbox.component';
import * as utils from './../../../../global/utils/utils';

describe('Checkbox component', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should render default minimal layout', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox value="chk1">checkbox option 1</agl-ds-checkbox>`
    });

    expect(page.root).toEqualHtml(`
    <agl-ds-checkbox value="chk1">
      <div class="checkbox">
        <input aria-describedby="" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="chk1">
        <label htmlfor="111" id="label111">
          checkbox option 1
        </label>
      </div>
    </agl-ds-checkbox>
      `);
  });

  it('should render checkbox with validation message', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox value="chk1" validation-text="invalid option">checkbox option 1</agl-ds-checkbox>`
    });

    expect(page.root).toEqualHtml(`
    <agl-ds-checkbox validation-text="invalid option" value="chk1">
      <div class="checkbox">
        <input aria-describedby="hint111" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="chk1">
        <label htmlfor="111" id="label111">
          checkbox option 1
        </label>
      </div>
      <agl-ds-hint-validation-message asdescribedbyid="hint111">
        <div slot="validation-text">
          invalid option
        </div>
        <div slot="hint-text"></div>
      </agl-ds-hint-validation-message>
    </agl-ds-checkbox>
    `);
    const hasError = page.root.querySelector('.error-state');
    expect(hasError).toBeDefined();
  });

  it('should render checkbox without validation message', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox value="chk1" validation-text="invalid option">checkbox option 1</agl-ds-checkbox>`
    });

    expect(page.root).toEqualHtml(`
    <agl-ds-checkbox validation-text="invalid option" value="chk1">
      <div class="checkbox">
        <input aria-describedby="hint111" aria-invalid="false" id="111" tabindex="0" type="checkbox" value="chk1">
        <label htmlfor="111" id="label111">
          checkbox option 1
        </label>
      </div>
      <agl-ds-hint-validation-message asdescribedbyid="hint111">
        <div slot="validation-text">
          invalid option
        </div>
        <div slot="hint-text"></div>
      </agl-ds-hint-validation-message>
    </agl-ds-checkbox>
    `);
    const hasError = page.root.querySelector('.error-state');
    expect(hasError).toBeDefined();
  });

  it('should not check the checkbox when checked is false', async () => {
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox checked=false>checkbox option 1</agl-ds-checkbox>`,
      supportsShadowDom: false
    });
    const input = page.root.querySelector('input');
    expect(input.checked).toBeFalsy();
  });

  it('should check the checkbox when checked is true', async () => {
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox checked=true>checkbox option 1</agl-ds-checkbox>`,
      supportsShadowDom: false
    });
    const input = page.root.querySelector('input');
    expect(input.checked).toBeTruthy();
  });

  it('should set the aria-describedby attribute if the validation text is passed', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const errorText = 'dummy error text';
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox validation-text="${errorText}">checkbox option 1</agl-ds-checkbox>`
    });

    const checkbox = page.root.querySelector('.checkbox input[type="checkbox"]');
    expect(checkbox.getAttribute('aria-describedby')).toEqual('hint111');
  });

  it('should set the aria-describedby attribute if the hint text is passed', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const hintText = 'dummy hint text';
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox hint-text="` + hintText + `">checkbox option 1</agl-ds-checkbox>`
    });

    const checkbox = page.root.querySelector('.checkbox input[type="checkbox"]');
    expect(checkbox.getAttribute('aria-describedby')).toEqual('hint111');
  });

  it('should set the aria-describedby attribute to `` if the hint text and validation text is not passed', async () => {
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox >checkbox option 1</agl-ds-checkbox>`
    });

    const checkbox = page.root.querySelector('.checkbox input[type="checkbox"]');
    expect(checkbox.getAttribute('aria-describedby')).toEqual('');
  });

  it('should set the aria-invalid attribute to false when error = false', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const errorText = 'dummy error text';
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox has-error="false" validation-text="${errorText}">checkbox option 1</agl-ds-checkbox>`
    });

    const checkbox = page.root.querySelector('.checkbox input[type="checkbox"]');
    expect(checkbox.getAttribute('aria-invalid')).toEqual('false');
  });

  it('should set the aria-invalid attribute to true when error = true', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '111');
    const errorText = 'dummy error text';
    const page = await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox has-error="true" validation-text="` + errorText + `">checkbox option 1</agl-ds-checkbox>`
    });

    const checkbox = page.root.querySelector('.checkbox input[type="checkbox"]');
    expect(checkbox.getAttribute('aria-invalid')).toEqual('true');
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox value="chk1"><agl-ds-text>test</agl-ds-text><agl-ds-link>test</agl-ds-link><br></agl-ds-checkbox>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [CheckboxComponent],
      html: `<agl-ds-checkbox value="chk1"><p>dummy text</p></agl-ds-checkbox>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
