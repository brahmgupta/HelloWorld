export type CheckboxType = 'default' | 'validation';

export interface CheckboxChangeEventDetail {
  checked: boolean;
  value: string;
}
