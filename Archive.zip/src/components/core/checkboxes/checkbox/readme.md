# agl-ds-checkbox



<!-- Auto Generated Below -->


## Properties

| Property         | Attribute         | Description                                                                                                                                                                                                                                           | Type                        | Default                  |
| ---------------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------- | ------------------------ |
| `checkboxId`     | `checkbox-id`     | Unique ID for the checkbox and for binding the label to the checkbox                                                                                                                                                                                  | `string`                    | `generateRandomNumber()` |
| `checked`        | `checked`         | Is the check box in a checked state or not when first displayed.                                                                                                                                                                                      | `boolean`                   | `false`                  |
| `hasError`       | `has-error`       | Shows the radio buttons in the group in an error state                                                                                                                                                                                                | `boolean`                   | `false`                  |
| `hintText`       | `hint-text`       | The validation/ error text for the radio button group                                                                                                                                                                                                 | `string`                    | `''`                     |
| `srContext`      | `sr-context`      | provide screen reader users with additional context or to convey information not available in HTML alone                                                                                                                                              | `string`                    | `''`                     |
| `type`           | `type`            | The layout type of checkbox                                                                                                                                                                                                                           | `"default" \| "validation"` | `'default'`              |
| `validationText` | `validation-text` | The validation/ error text for the radio button group                                                                                                                                                                                                 | `string`                    | `''`                     |
| `value`          | `value`           | The value of the toggle does not mean if it's checked or not, use the `checked` property for that.  The value of a toggle is analogous to the value of a `<input type="checkbox">`, it's only used when the toggle participates in a native `<form>`. | `string`                    | `'on'`                   |


## Events

| Event           | Description            | Type                                     |
| --------------- | ---------------------- | ---------------------------------------- |
| `checkedChange` | Checkbox changed event | `CustomEvent<CheckboxChangeEventDetail>` |


## Methods

### `setFocus() => Promise<void>`

Sets focus to the Error summary

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-selection-card](../../../composite/selection-card)

### Depends on

- [agl-ds-hint-validation-message](../../hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-checkbox --> agl-ds-hint-validation-message
  agl-ds-selection-card --> agl-ds-checkbox
  style agl-ds-checkbox fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
