import { Component, h, Prop, Host, Element, Watch, EventEmitter, Event, ComponentInterface, Method } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';
import { CheckboxType, CheckboxChangeEventDetail } from './checkbox.types';

@Component({
  tag: 'agl-ds-checkbox',
  styleUrl: 'checkbox.component.scss',
  shadow: false,
  scoped: true
})
export class CheckboxComponent implements ComponentInterface {
  @Element() host: HTMLAglDsCheckboxElement;
  /**
   *  Unique ID for the checkbox and for binding the label to the checkbox
   */
  @Prop() checkboxId: string = generateRandomNumber();

  /**
   * The layout type of checkbox
   */
  @Prop() type: CheckboxType = 'default';

  /**
   * The validation/ error text for the radio button group
   */
  @Prop() validationText: string = '';

  /**
   * The validation/ error text for the radio button group
   */
  @Prop() hintText: string = '';

  /**
   * Shows the radio buttons in the group in an error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Is the check box in a checked state or not when first displayed.
   */
  @Prop({ mutable: true }) checked: boolean = false;

  /**
   * The value of the toggle does not mean if it's checked or not, use the `checked`
   * property for that.
   *
   * The value of a toggle is analogous to the value of a `<input type="checkbox">`,
   * it's only used when the toggle participates in a native `<form>`.
   */
  @Prop() value: string = 'on';

  /**
   * provide screen reader users with additional context or to convey information not available in HTML alone
   */
  @Prop() srContext: string = '';

  /**
   * Checkbox changed event
   */
  @Event() checkedChange: EventEmitter<CheckboxChangeEventDetail>;

  private inputElement: HTMLInputElement;

  // propagate value change from model to view
  @Watch('checked')
  valueChange(checked: boolean): void {
    if (this.inputElement) {
      this.inputElement.checked = checked;
    }
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-checkbox', 'agl-ds-text', 'agl-ds-link', 'br', 'span']);
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);
  }

  /**
   * Sets focus to the Error summary
   */
  @Method()
  async setFocus() {
    this.inputElement.focus();
  }

  // propagate value change from view to model
  private inputChanged(ev: any): void {
    const val = ev.target && ev.target.checked;
    this.checked = val; // needs to be set for ngmodel and formcontrolname

    const { checked, value } = this;
    this.checkedChange.emit({ checked, value }); // emit value and checked for the checkedChange event
  }

  /**
   * Rendering validation message for an error state
   */
  private renderValidationMessage(): any {
    return this.validationText !== '' || this.hintText !== '' ? (
      <agl-ds-hint-validation-message asDescribedbyId={'hint' + this.checkboxId} hasError={this.hasError ? true : false}>
        <div slot="validation-text">{this.validationText}</div>
        <div slot="hint-text">{this.hintText}</div>
      </agl-ds-hint-validation-message>
    ) : null;
  }

  render() {
    const { checked, hasError, hintText, type, validationText, value } = this;
    return (
      <Host>
        <div class={{ checkbox: true, 'checkbox--border': type === 'validation', 'checkbox--error': hasError }}>
          <input
            tabindex="0"
            ref={(l) => (this.inputElement = l)}
            onChange={(event: UIEvent) => this.inputChanged(event)}
            type="checkbox"
            id={this.checkboxId}
            checked={checked}
            value={value}
            aria-invalid={hasError ? 'true' : 'false'}
            aria-describedby={validationText !== '' || hintText !== '' ? 'hint' + this.checkboxId : ''}
          />
          <label id={'label' + this.checkboxId} htmlFor={this.checkboxId}>
            <slot />
            {this.srContext ? <span class="sr-only"> {this.srContext}</span> : ''}
          </label>
        </div>
        {this.renderValidationMessage()}
      </Host>
    );
  }
}
