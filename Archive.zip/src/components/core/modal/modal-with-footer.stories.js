import { select } from '@storybook/addon-knobs';
import * as modalFooterNotes from './modal-footer/readme.md';
import * as modalNotes from './modal/readme.md';

const allNotes = `${modalNotes.default}\n\n${modalFooterNotes.default}`;
const modalHeader = `<agl-ds-h3 bottom-margin="none">Header slot</agl-ds-h3>`;
const modalContent = `
<agl-ds-p>Features and benefits</agl-ds-p>
<agl-ds-p
  >Nunc malesuada, ante sit amet elementum ullamcorper, nisi sapien finibus lorm, vitae lacinia nunc tortor sit amet tortor. Morbi id dui
  vitae ipsum sodales aliquet sed eu eros. Nulla lorem ipsum, elementum eu interdum vitae, feugiat ac nisi.
</agl-ds-p>
<agl-ds-p>Conditions</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
`;
const modalFooter = `<agl-ds-modal-footer type="primaryAndSecondary" first-button-label="Agree" second-button-label="Back"></agl-ds-modal-footer>`;

export default {
  title: 'Core/Modal'
};

export const ModalWithModalFooter = () => {
  const modal = document.createElement('agl-ds-modal');

  modal.innerHTML = `
      <div slot="header">${modalHeader}</div>
      <div slot="content">${modalContent}</div>
      <div slot="footer">${modalFooter}</div>`;

  modal.animationType = select('AnimationType', ['popup', 'slidedown'], 'slidedown');

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Trigger Modal';
  button.id = 'trigger';
  button.onclick = () => {
    //when calling openmodal function, need to pass in the element that need to be focused after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passin the actual button under shadowroot.
    modal.openModal();
  };
  const container = document.createElement('div');

  container.appendChild(modal);

  container.appendChild(button);
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
  }, 1000);
  return container;
};

ModalWithModalFooter.storyName = 'Modal with modal footer';
ModalWithModalFooter.parameters = {
  allNotes,
  axetest: {
    beforeAxeTestAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  },
  storyshots: {
    visualRegression: {
      screenshotHeight: 500,
      beforeScreenshotAsyncFunc: async (page) => {
        await storyPageManipulation(page);
      }
    }
  }
};

const storyPageManipulation = async (page) => {
  await page.waitForSelector('#trigger', { visible: true });
  await page.waitForTimeout(1250); // allow time for the setTimeout's that attach events to the #trigger buttons in the stories
  await page.click('#trigger');
};
