# agl-ds-modal



<!-- Auto Generated Below -->


## Properties

| Property         | Attribute          | Description                                                                                                                                                                                                                                              | Type                            | Default       |
| ---------------- | ------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------- | ------------- |
| `animationType`  | `animation-type`   | Animation type for different modals                                                                                                                                                                                                                      | `"popup" \| "slidedown"`        | `'slidedown'` |
| `appearance`     | `appearance`       | <span style="color:red">**[DEPRECATED]**</span> This prop will be combined with animation type ie slidedown will always be fullwidth<br/><br/>Flag to fix the width of Modal. If center screen, the max-width will be 800px and max-height will be 600px | `"centerscreen" \| "fullwidth"` | `'fullwidth'` |
| `disableScroll`  | `disable-scroll`   | Disable scroll for popup appearance.                                                                                                                                                                                                                     | `boolean`                       | `false`       |
| `modalTriggerId` | `modal-trigger-id` | Id of modal trigger.                                                                                                                                                                                                                                     | `string`                        | `''`          |


## Events

| Event         | Description                   | Type                   |
| ------------- | ----------------------------- | ---------------------- |
| `modalClosed` | Fires when modal is closed.   | `CustomEvent<string>`  |
| `modalOpened` | Fires when modal is opened    | `CustomEvent<void>`    |
| `modalScroll` | Fires when the onScroll event | `CustomEvent<UIEvent>` |


## Methods

### `closeModal(action?: ModalCloseAction) => Promise<void>`

Public method to close the modal

#### Returns

Type: `Promise<void>`



### `disabledWhileWait(disabled: boolean) => Promise<void>`

Public method that disables everything in the modal and prevents close by backdrop click or on escape.

#### Returns

Type: `Promise<void>`



### `openModal(el: HTMLElement) => Promise<void>`

Public method to open the modal. This component requires the trigger element to be passed via the modal.setTriggerButton() method as an anonymous function, so that focus can be returned to it after the modal has closed

#### Returns

Type: `Promise<void>`



### `setTriggerButton(getTriggerButton: () => HTMLElement) => Promise<void>`

Public method to set the modal trigger element

#### Returns

Type: `Promise<void>`




## Slots

| Slot        | Description                                                                   |
| ----------- | ----------------------------------------------------------------------------- |
| `"content"` | Content placed in this slot will be placed at the body section of the modal   |
| `"footer"`  | Content placed in this slot will be placed at the footer section of the modal |
| `"header"`  | Content placed in this slot will be placed at the header section of the modal |


## Dependencies

### Used by

 - [agl-ds-manual-address-entry](../../../composite/addresssearch/manual-address-entry)

### Depends on

- [agl-ds-icon](../../icon)

### Graph
```mermaid
graph TD;
  agl-ds-modal --> agl-ds-icon
  agl-ds-manual-address-entry --> agl-ds-modal
  style agl-ds-modal fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
