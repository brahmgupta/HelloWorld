jest.doMock('../../../../global/utils/utils', () => {
  return {
    hideFocusRingWhenUsingMouse: () => null
  };
});
import { newSpecPage } from '@stencil/core/testing';
import { ModalComponent } from './modal.component';
jest.useFakeTimers();

describe('modalComponent', () => {
  it('should render default modal', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal></agl-ds-modal>`
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-modal>
      <div tabindex="0"></div>
      <div class="agl-ds-modal__full-screen agl-ds-modal__wrapper hide">
        <div class="agl-ds-modal__container" role="dialog">
          <div role="document">
            <div class="agl-ds-modal__header-container">
              <button class="agl-ds-modal__close-button">
                <agl-ds-icon alt-text="Close the modal dialog" icon="svg contents from: src/assets/icon-close.svg" size="xxs"></agl-ds-icon>
              </button>
              <div class="agl-ds-modal__heading"></div>
            </div>
            <div class="agl-ds-modal__content"></div>
          </div>
        </div>
        <div tabindex="0"></div>
      </div>
      <div class="agl-ds-modal__shade"></div>
    </agl-ds-modal>
      `
    );
  });

  it('should add fixed width classes when animation-type set to popup', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal animation-type="popup"></agl-ds-modal>`
    });

    const container = page.root.querySelector('.agl-ds-modal__container');
    expect(container.classList.contains('agl-ds-modal__container--center-screen')).toBe(true);
  });

  it('should add visible class when open modal', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal animation-type="popup"></agl-ds-modal>`
    });

    const wrapper = page.root.querySelector('.agl-ds-modal__wrapper');
    page.root.openModal();
    await page.waitForChanges();
    expect(wrapper.classList.contains('agl-ds-modal__wrapper--visible')).toBe(true);
  });

  it('should add slide down class if animation type is slidedown when open modal', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal animation-type="slidedown"></agl-ds-modal>`
    });

    const wrapper = page.root.querySelector('.agl-ds-modal__wrapper');
    page.root.openModal();
    await page.waitForChanges();
    expect(wrapper.classList.contains('slide-down')).toBe(true);
  });

  it('should remove visible class when close modal', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal></agl-ds-modal>`
    });

    const wrapper = page.root.querySelector('.agl-ds-modal__wrapper');
    page.root.openModal();
    await page.waitForChanges();
    page.root.closeModal();
    await page.waitForChanges();
    expect(wrapper.classList.contains('agl-ds-modal__wrapper--visible')).toBe(false);
  });

  it('should not close the modal when `disabledWhileWait` method is called with value true and shaded backdrop was clicked', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal></agl-ds-modal>`
    });

    const wrapper: HTMLElement = page.root.querySelector('.agl-ds-modal__wrapper');
    page.root.openModal();
    page.root.disabledWhileWait(true);
    await page.waitForChanges();
    wrapper.click();
    await page.waitForChanges();
    const disableWhileWaitOverlay: HTMLElement = page.root.querySelector('.agl-ds-modal__header-container--disable-while-wait');
    expect(disableWhileWaitOverlay).toBeTruthy();
    expect(wrapper.classList.contains('agl-ds-modal__wrapper--visible')).toBe(true);
  });

  it('should remove slide down class if animation type is slidedown when close modal', async () => {
    const page = await newSpecPage({
      components: [ModalComponent],
      html: `<agl-ds-modal animation-type="slidedown"></agl-ds-modal>`
    });

    const wrapper = page.root.querySelector('.agl-ds-modal__wrapper');
    page.root.openModal();
    await page.waitForChanges();
    page.root.closeModal();
    await page.waitForChanges();
    expect(wrapper.classList.contains('slide-down')).toBe(false);
  });
});
