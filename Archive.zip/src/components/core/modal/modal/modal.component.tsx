import { Component, Host, Prop, h, Method, Event, EventEmitter, Element, ComponentInterface, State } from '@stencil/core';
import { hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';
import iconClose from '../../../../assets/icon-close.svg';
import { AnimationType, ModalAppearance, ModalCloseAction } from './modal.types';

/** Known issues TODO
 *  1. In screen reader browse mode, pressing the enter key does not fire the close button and the dialog remains
 *  open while the focus is placed back on the modal trigger button
 *  2. Once the modal is opened shift tab ( ie reverse order) will miss the footer buttons
 **/

/**
 * @slot
 * @slot header - Content placed in this slot will be placed at the header section of the modal
 * @slot content - Content placed in this slot will be placed at the body section of the modal
 * @slot footer - Content placed in this slot will be placed at the footer section of the modal
 */

@Component({
  tag: 'agl-ds-modal',
  styleUrl: 'modal.component.scss',
  shadow: false,
  scoped: true
})
export class ModalComponent implements ComponentInterface {
  @Element() hostElement: HTMLAglDsModalElement;

  /**
   * Animation type for different modals
   */
  @Prop() animationType: AnimationType = 'slidedown';

  /**
   * Flag to fix the width of Modal. If center screen, the max-width will be 800px and max-height will be 600px
   * @deprecated This prop will be combined with animation type ie slidedown will always be fullwidth
   */
  @Prop({ mutable: true }) appearance: ModalAppearance = 'fullwidth'; //TODO remove all references to appearance when the prop is removed

  /**
   * Disable scroll for popup appearance.
   */
  @Prop() disableScroll: boolean = false;

  /**
   * Id of modal trigger.
   */
  @Prop() modalTriggerId: string = '';

  /**
   * Fires when modal is opened
   */
  @Event() modalOpened: EventEmitter<void>;

  /**
   * Fires when modal is closed.
   */
  @Event() modalClosed: EventEmitter<string>;

  /**
   * Fires when the onScroll event
   */
  @Event() modalScroll: EventEmitter<UIEvent>;

  @State() disableWhileWait: boolean = false;

  private handleScrollEvent = (event: UIEvent): void => {
    this.modalScroll.emit(event);
  };

  private hasFooterSlot: boolean;

  private modalTrigger: HTMLElement;

  private shade: HTMLDivElement;

  private modalContainer: HTMLDivElement;

  private modalWrapper: HTMLDivElement;

  private lastFocus: EventTarget | Element;

  private closeInputElement: HTMLButtonElement;
  private headerElement: HTMLDivElement;
  private disableWhileWaitElement: HTMLDivElement;
  private contentElement: HTMLDivElement;
  private footerElement: HTMLDivElement;

  private closeModalWhenClickOutside = (event: FocusEvent) => {
    if (this.disableWhileWait) {
      return;
    }
    let insideModalArea;
    if (this.appearance === 'fullwidth') {
      insideModalArea = this.modalWrapper;
    } else {
      insideModalArea = this.modalContainer;
    }
    if (!insideModalArea.contains(event.target as Node)) {
      this.closeModal('clickOutside');
    }
  };

  /*
   * When functions move focus around, set this true so the trapfocus listener
   * can ignore the events.
   */
  private ignoreFocusChanges = false;

  private trapFocus = (event: FocusEvent) => {
    if (this.disableWhileWait) {
      // need to disable all elements within the modal so that user can not use the tab key
      this.disableWhileWaitElement.focus();
    } else {
      if (this.ignoreFocusChanges) {
        return;
      }
      if (this.modalContainer.contains(event.target as Node)) {
        this.lastFocus = event.target;
      } else {
        this.focusFirstDescendant(this.modalContainer);
        if (this.lastFocus == document.activeElement) {
          this.focusLastDescendant(this.modalContainer);
        }
        this.lastFocus = document.activeElement;
      }
    }
  };

  private focusFirstDescendant(element) {
    for (let i = 0; i < element.childNodes.length; i++) {
      const child = element.childNodes[i];
      if (this.attemptFocus(child) || this.focusFirstDescendant(child)) {
        return true;
      }
    }
    return false;
  }

  private focusLastDescendant(element) {
    for (let i = element.childNodes.length - 1; i >= 0; i--) {
      const child = element.childNodes[i];
      if (this.attemptFocus(child) || this.focusLastDescendant(child)) {
        return true;
      }
    }
    return false;
  }

  private attemptFocus(element) {
    if (!this.isFocusable(element)) {
      return false;
    }
    this.ignoreFocusChanges = true;
    try {
      element.focus();
    } catch (e) {
      return false;
    }
    this.ignoreFocusChanges = false;

    return document.activeElement === element;
  }

  private isFocusable(element) {
    if (element.tabIndex > 0 || ((element.tabIndex === 0 || element.tabIndex === -1) && element.getAttribute('tabIndex') !== null)) {
      return true;
    }

    if (element.disabled) {
      return false;
    }

    switch (element.nodeName) {
      case 'A':
        return !!element.href && element.rel != 'ignore';
      case 'INPUT':
        return element.type != 'hidden' && element.type != 'file';
      case 'BUTTON':
      case 'SELECT':
      case 'TEXTAREA':
        return true;
      default:
        return false;
    }
  }

  private handleButtonKeyDown(e: KeyboardEvent): void {
    if (this.disableWhileWait) {
      return;
    }
    const key = e.key || e.keyCode;
    if (key === 'Escape' || key === 'Esc' || key === 27) {
      this.closeModal();
    }
  }

  private resetContainerHeight = () => {
    this.shade.style.height = `${window.innerHeight}px`;
    const headerStyles = window.getComputedStyle(this.headerElement);
    const headerHeight = parseInt(headerStyles.height) + parseInt(headerStyles.marginTop);
    let footerHeight = 0;
    if (this.footerElement) {
      const footerStyles = window.getComputedStyle(this.footerElement);
      footerHeight = parseInt(footerStyles.height) + parseInt(footerStyles.marginTop);
    }
    this.contentElement.style.maxHeight = this.modalContainer.clientHeight - headerHeight - footerHeight + 'px';
  };

  private debounce = (callback, wait) => {
    let timeout;
    return (...args) => {
      const context = this;
      clearTimeout(timeout);
      timeout = setTimeout(() => callback.apply(context, args), wait);
    };
  };

  private debouncedResetContainerHeight = this.debounce(this.resetContainerHeight, 20);

  /**
   * Public method to open the modal. This component requires the trigger element to be passed via the modal.setTriggerButton() method as an anonymous function, so that focus can be returned to it after the modal has closed
   * @param {HTMLElement} el, the element need to be focused after modal close. This parameter is deprecated in favour of the setTriggerButton method
   */
  @Method()
  async openModal(el: HTMLElement) {
    //this is here until the deprecated param can be removed
    // eslint-disable-next-line no-self-assign
    el = el;

    if (this.animationType === 'slidedown') {
      this.modalWrapper.classList.add('slide-down');
      this.modalWrapper.classList.remove('slide-up');
    }
    if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-BUTTON') {
      this.modalTrigger.shadowRoot.querySelector('button').setAttribute('aria-expanded', 'true');
    } else if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-LINK') {
      //to announce to the screen reader that the trigger is collapsed
      this.modalTrigger.shadowRoot.querySelector('a').setAttribute('aria-expanded', 'true');
    }
    this.modalWrapper.classList.remove('hide');
    this.modalWrapper.classList.add('agl-ds-modal__wrapper--visible');
    this.shade.classList.remove('agl-ds-modal__shade--hidden');
    this.shade.classList.add('agl-ds-modal__shade--visible');
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
    document.addEventListener('focus', this.trapFocus, true);
    document.addEventListener('click', this.closeModalWhenClickOutside, true);
    document.addEventListener('keydown', this.handleButtonKeyDown.bind(this), true);
    window.addEventListener('resize', this.debouncedResetContainerHeight, true);
    this.resetContainerHeight();
    this.modalOpened.emit();

    setTimeout(() => {
      this.closeInputElement.focus();
    }, 100);
  }

  /**
   * Public method to close the modal
   */
  @Method()
  async closeModal(action: ModalCloseAction = 'manual') {
    if (this.animationType === 'slidedown') {
      this.modalWrapper.classList.add('slide-up');
      this.modalWrapper.classList.remove('slide-down');
    }
    this.modalWrapper.classList.add('hide');
    this.modalWrapper.classList.remove('agl-ds-modal__wrapper--visible');
    this.shade.classList.add('agl-ds-modal__shade--hidden');
    this.shade.classList.remove('agl-ds-modal__shade--visible');
    document.getElementsByTagName('body')[0].style.overflow = 'auto';
    document.removeEventListener('focus', this.trapFocus, true);
    document.removeEventListener('click', this.closeModalWhenClickOutside, true);
    window.removeEventListener('resize', this.debouncedResetContainerHeight, true);
    this.modalClosed.emit(action);
    if (this.modalTrigger) {
      if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-BUTTON') {
        //to announce to the screen reader that the trigger is collapsed
        this.modalTrigger.shadowRoot.querySelector('button').setAttribute('aria-expanded', 'false');
        (this.modalTrigger as HTMLAglDsButtonElement).setFocus();
      } else if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-LINK') {
        //to announce to the screen reader that the trigger is collapsed
        this.modalTrigger.shadowRoot.querySelector('a').setAttribute('aria-expanded', 'false');
        (this.modalTrigger as HTMLAglDsLinkElement).setFocus();
      } else if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-TEXTBOX') {
        (this.modalTrigger as HTMLAglDsLinkElement).setFocus();
      }
    }
  }

  /**
   * Public method that disables everything in the modal and prevents close by backdrop click or on escape.
   */
  @Method()
  async disabledWhileWait(disabled: boolean) {
    this.disableWhileWait = disabled;
  }

  /**
   * Public method to set the modal trigger element
   * @param {Function} getTriggerButton, The anonymous function that returns the element that needs to be focused on after modal close
   */
  @Method()
  async setTriggerButton(getTriggerButton: () => HTMLElement) {
    const checkTrigger = async (fn: () => HTMLElement): Promise<HTMLElement> => {
      //limit the number of tries. If it does not find the object then an error is logged but the page will render TODO maybe increase the number of tries
      const maxTriesToFindTriggerElement = 200;
      for (let x = 0; x < maxTriesToFindTriggerElement; x++) {
        if (fn() === null) {
          try {
            await new Promise((resolve) => requestAnimationFrame(resolve));
          } catch {
            //here for jest to handle the promise
          }
        } else {
          break;
        }
        if (x === maxTriesToFindTriggerElement - 1) {
          console.error(
            'This component requires the trigger element to be passed via the modal.setTriggerButton() method as an anonymous function, so that focus can be returned to it after the modal has closed'
          );
        }
      }
      return fn();
    };
    checkTrigger(getTriggerButton).then((trigger) => {
      this.modalTrigger = trigger;
      if (this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-BUTTON' || this.modalTrigger?.tagName.toUpperCase() === 'AGL-DS-LINK') {
        (this.modalTrigger as HTMLAglDsButtonElement).srContext = '(dialog)';
        (this.modalTrigger as HTMLAglDsButtonElement).ariaAttribute = [{ attribute: 'aria-expanded', value: 'false' }];
      }
    });
  }

  componentWillLoad() {
    this.hasFooterSlot = !!this.hostElement.querySelector('[slot="footer"]');
    if (this.animationType === 'slidedown') {
      this.appearance = 'fullwidth';
    } else {
      this.appearance = 'centerscreen';
    }
  }
  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.closeInputElement);
  }

  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    return (
      <Host>
        <div tabIndex={0}></div>
        <div
          class={{
            hide: true,
            'agl-ds-modal__wrapper': true,
            'agl-ds-modal__wrapper--center-screen': this.appearance === 'centerscreen',
            'agl-ds-modal__full-screen': this.appearance === 'fullwidth'
          }}
          ref={(el) => (this.modalWrapper = el)}
        >
          <div
            class={{
              'agl-ds-modal__container': true,
              'agl-ds-modal__container--center-screen': this.appearance === 'centerscreen',
              'agl-ds-modal__container--disable-scroll': this.disableScroll
            }}
            ref={(el) => (this.modalContainer = el)}
            role="dialog"
          >
            <div role="document">
              <div class="agl-ds-modal__header-container">
                {this.disableWhileWait && (
                  <div
                    tabindex={0}
                    class="agl-ds-modal__header-container--disable-while-wait"
                    ref={(el) => (this.disableWhileWaitElement = el)}
                  ></div>
                )}

                <button
                  ref={(el) => (this.closeInputElement = el)}
                  class={{
                    'agl-ds-modal__close-button': true,
                    'agl-ds-modal__close-button--center-screen': this.appearance === 'centerscreen'
                  }}
                  onClick={() => {
                    this.closeModal('iconButton');
                  }}
                >
                  <agl-ds-icon icon={iconClose} size="xxs" alt-text="Close the modal dialog"></agl-ds-icon>
                </button>

                <div
                  ref={(el) => (this.headerElement = el)}
                  class={{
                    'agl-ds-modal__heading': true,
                    'agl-ds-modal__heading--center-screen': this.appearance === 'centerscreen'
                  }}
                >
                  <slot name="header" />
                </div>
              </div>

              <div
                ref={(el) => (this.contentElement = el)}
                class={{
                  'agl-ds-modal__content': true,
                  'agl-ds-modal__content--center-screen': this.appearance === 'centerscreen'
                }}
                onScroll={(event: UIEvent) => {
                  this.handleScrollEvent(event);
                }}
              >
                <slot name="content" />
              </div>

              {this.hasFooterSlot && (
                <div
                  ref={(el) => (this.footerElement = el)}
                  class={{
                    'agl-ds-modal__footer': true,
                    'agl-ds-modal__footer--center-screen': this.appearance === 'centerscreen'
                  }}
                >
                  <slot name="footer" />
                </div>
              )}
            </div>
          </div>
          <div tabIndex={0}></div>
        </div>
        <div class="agl-ds-modal__shade" ref={(el) => (this.shade = el)}></div>
      </Host>
    );
  }
}
