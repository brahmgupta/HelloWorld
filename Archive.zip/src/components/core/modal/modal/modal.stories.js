import { select, boolean } from '@storybook/addon-knobs';
import notes from './readme.md';

const commonStoryshots = {
  axetest: {
    beforeAxeTestAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  },
  visualRegression: {
    screenshotHeight: 750,
    beforeScreenshotAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  }
};

const storyPageManipulation = async (page) => {
  await page.waitForSelector('#trigger', { visible: true });
  await page.waitForTimeout(1250); // allow time for the setTimeout's that attach events to the #trigger buttons in the stories
  await page.click('#trigger');
};

const modalHeader = `<agl-ds-h3 bottom-margin="none" >Header slot</agl-ds-h3>`;
const modalContent = `
<agl-ds-p>Features and benefits</agl-ds-p>
<agl-ds-p
  >Nunc malesuada, ante sit amet elementum ullamcorper, nisi sapien finibus lorm, vitae lacinia nunc tortor sit amet tortor. Morbi id dui
  vitae ipsum sodales aliquet sed eu eros. Nulla lorem ipsum, elementum eu interdum vitae, feugiat ac nisi.
</agl-ds-p>
<agl-ds-p>Conditions</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
<agl-ds-p
  >Cras varius gravida massa, vel ultrices libero ultricies et. Aliquam placerat mollis condimentum. Aliquam molestie orci sit amet sem
  dignissim, at sagittis ipsum vehicula. Donec maximus ante vitae eros fringilla, vitae tempus tellus ornare. Suspendisse sit amet libero
  tellus.
</agl-ds-p>
`;
const modalFooter = `<agl-ds-button>Button in Footer slot</agl-ds-button>`;

export default {
  title: 'Core/Modal/Modal',
  parameters: {
    paddings: { disabled: true }
  }
};

export const Modal = () => {
  const spacer = document.createElement('agl-ds-spacer');
  spacer.orientation = 'vertical';
  spacer.size = 'space04';
  const spacer2 = document.createElement('agl-ds-spacer');
  spacer2.orientation = 'vertical';
  spacer2.size = 'space04';
  const modal = document.createElement('agl-ds-modal');
  modal.innerHTML = `
  <div slot="header">${modalHeader}</div>
  <div slot="content">${modalContent}</div>
  <div slot="footer">${modalFooter}</div>`;
  modal.animationType = select('AnimationType', ['popup', 'slidedown'], 'slidedown');
  modal.disableWhileWait = select('DisableWhileWait', ['true', 'false'], 'false');

  const modal2 = document.createElement('agl-ds-modal');
  modal2.innerHTML = `
  <div slot="header">${modalHeader}</div>
  <div slot="content">${modalContent}</div>
  <div slot="footer">${modalFooter}</div>`;
  modal2.animationType = select('AnimationType', ['popup', 'slidedown'], 'slidedown');

  const modal3 = document.createElement('agl-ds-modal');
  modal3.innerHTML = `
  <div slot="header">${modalHeader}</div>
  <div slot="content">${modalContent}</div>
  <div slot="footer">${modalFooter}</div>`;
  modal3.animationType = select('AnimationType', ['popup', 'slidedown'], 'slidedown');

  const notification = document.createElement('agl-ds-notification');
  notification.heading = 'Notification car that has the button inside the shadow dom';
  notification.buttonText = 'Open modal from a button';
  notification.addEventListener('buttonClick', () => {
    modal.openModal();
  });

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Open modal from a button with an id';
  button.id = 'trigger';
  button.onclick = () => {
    modal2.openModal();
  };

  const link = document.createElement('agl-ds-link');
  link.innerHTML = 'Open modal from a link';
  link.href = 'javascript:void(0)';
  link.openNewWindow = 'false';
  link.id = 'link-trigger';
  link.onclick = () => {
    modal3.openModal();
  };

  const container = document.createElement('div');
  container.appendChild(modal);
  container.appendChild(modal2);
  container.appendChild(modal3);
  container.appendChild(notification);
  container.appendChild(spacer);
  container.appendChild(button);
  container.appendChild(spacer2);
  container.appendChild(link);

  const text = document.createElement('div');
  text.innerHTML = '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>Some text to show when the modals are open';
  container.appendChild(text);
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.setTriggerButton(() => {
      return document.querySelector('agl-ds-notification').shadowRoot.querySelector('agl-ds-button');
    });
    modal2.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
    modal3.setTriggerButton(() => {
      return document.querySelector('agl-ds-link');
    });
  }, 1000);
  return container;
};

Modal.storyName = 'modal';
Modal.parameters = { notes, storyshots: commonStoryshots };

export const ModalWithoutFooter = () => {
  const modal = document.createElement('agl-ds-modal');

  modal.innerHTML = `
    <div slot="header">${modalHeader}</div>
    <div slot="content">${modalContent}</div>`;

  modal.animationType = select('AnimationType', ['popup', 'slidedown'], 'popup');

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Trigger Modal';
  button.id = 'trigger';
  button.onclick = () => {
    //when calling openmodal function, need to pass in the element that need to be focused after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.openModal();
  };
  const container = document.createElement('div');

  container.appendChild(modal);

  container.appendChild(button);
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
  }, 1000);
  return container;
};

ModalWithoutFooter.storyName = 'modal-without-footer';
ModalWithoutFooter.parameters = {
  notes,
  storyshots: commonStoryshots
};

export const ModalScrollableContent = () => {
  const modal = document.createElement('agl-ds-modal');

  modal.innerHTML = `
    <div slot="header">${modalHeader}</div>
    <div slot="content">
      ${modalContent}
      ${modalContent}
      ${modalContent}
      ${modalContent}
      ${modalContent}
      ${modalContent}
      ${modalContent}
      ${modalContent}
    </div>
    <div slot="footer">${modalFooter}</div>`;

  modal.animationType = select('AnimationType', ['popup', 'slidedown'], 'popup');

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Trigger Modal';
  button.id = 'trigger';
  button.onclick = () => {
    //when calling openmodal function, need to pass in the element that need to be focused after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.openModal();
  };
  const container = document.createElement('div');

  container.appendChild(modal);

  container.appendChild(button);
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
  }, 1000);
  return container;
};

ModalScrollableContent.storyName = 'modal-scrollable-content';
ModalScrollableContent.parameters = { notes, storyshots: commonStoryshots };

export const ModalDisableScroll = () => {
  const modal = document.createElement('agl-ds-modal');

  modal.innerHTML = `
  <div slot="header">${modalHeader}</div>
  <div slot="content">
    ${modalContent}
    ${modalContent}
  </div>
  <div slot="footer">${modalFooter}</div>`;

  modal.animationType = select('AnimationType', ['popup', 'slidedown'], 'slidedown');
  modal.disableScroll = boolean('disableScroll', true);
  modal.modalTriggerId = 'trigger';

  const button = document.createElement('agl-ds-button');
  button.innerHTML = 'Trigger Modal';
  button.id = 'trigger';
  button.onclick = () => {
    //when calling openmodal function, need to pass in the element that need to be focused after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.openModal();
  };
  const container = document.createElement('div');
  container.appendChild(modal);
  container.appendChild(button);
  setTimeout(() => {
    //when setting up the modal, need to pass in the element that need to be focused to after modal close for accessibility purpose,
    //in this example, the button component is wrapped in div which is not focusable, need to passing the actual button under shadowroot.
    modal.setTriggerButton(() => {
      return document.querySelector('#trigger');
    });
  }, 1000);
  return container;
};

ModalDisableScroll.storyName = 'modal-disable-scroll';
ModalDisableScroll.parameters = { notes, storyshots: commonStoryshots };
