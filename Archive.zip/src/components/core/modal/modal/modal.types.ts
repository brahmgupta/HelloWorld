export type AnimationType = 'popup' | 'slidedown';

export type ModalAppearance = 'fullwidth' | 'centerscreen';

export type ModalCloseAction = 'manual' | 'clickOutside' | 'iconButton';
