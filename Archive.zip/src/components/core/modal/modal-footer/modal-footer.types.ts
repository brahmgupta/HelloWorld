export type ModalFooterType = 'oneButton' | 'twoButton' | 'primaryAndSecondaryButton' | 'buttonAndLink';
