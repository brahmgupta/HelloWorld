import { Component, ComponentInterface, Element, Event, EventEmitter, h, Host, Prop } from '@stencil/core';
import { ButtonType } from '../../button/button.types';
import leftArrow from '../../../../assets/agl_left_arrow.svg';
import { ModalFooterType } from './modal-footer.types';

@Component({
  tag: 'agl-ds-modal-footer',
  styleUrl: 'modal-footer.component.scss',
  shadow: true
})
export class ModalFooterComponent implements ComponentInterface {
  @Element() hostElement: HTMLAglDsModalFooterElement;

  /**
   * Flag to configure the button configuration for the footer
   */
  @Prop() type: ModalFooterType = 'oneButton';

  /**
   * Set the display name of the first button. Will default to 'Confirm' if not set
   */
  @Prop() firstButtonLabel: string = 'Confirm';

  /**
   * Set the display name of the second button if relevant. Will default to 'Back' if not set
   */
  @Prop() secondButtonLabel: string = 'Back';

  /**
   * Flag to determine if the loading indicator is to be displayed for primary button
   */
  @Prop() firstButtonLoading: boolean = false;

  /**
   * Flag to determine if the loading indicator is to be displayed for secondary button
   */
  @Prop() secondButtonLoading: boolean = false;

  /**
   * Fires when when first button is clicked
   */
  @Event() firstButtonClicked: EventEmitter<void>;

  /**
   * Fires when modal is closed.
   */
  @Event() secondButtonClicked: EventEmitter<void>;

  private onFirstButtonClicked(): void {
    this.firstButtonClicked.emit();
  }

  private onSecondButtonClicked(): void {
    this.secondButtonClicked.emit();
  }

  private primaryButtonType(): ButtonType {
    return this.type === 'twoButton' ? 'secondary' : 'primary';
  }

  private secondaryButtonType(): ButtonType {
    return this.type === 'buttonAndLink' ? 'tertiary' : 'secondary';
  }

  /**
   * Render Icon
   */
  private renderSecondaryButton() {
    return (
      <agl-ds-button
        class={{
          'agl-ds-modal-footer__button': true,
          'agl-ds-modal-footer__button--reverse': this.type === 'buttonAndLink'
        }}
        type={this.secondaryButtonType()}
        onClick={() => {
          this.onSecondButtonClicked();
        }}
        iconPosition={this.type === 'buttonAndLink' ? 'left' : null}
        icon={this.type === 'buttonAndLink' ? leftArrow : ''}
        loading={this.secondButtonLoading}
      >
        {this.secondButtonLabel}
      </agl-ds-button>
    );
  }

  /**
   * Create HTML representation of component DOM and return this
   for output to the browser DOM
   */
  render() {
    return (
      <Host>
        <div
          class={{
            'agl-ds-modal-footer': true,
            'agl-ds-modal-footer--reverse': this.type === 'buttonAndLink',
            'agl-ds-modal-footer--center': this.type !== 'buttonAndLink'
          }}
        >
          <agl-ds-button
            class={{
              'agl-ds-modal-footer__button': true,
              'agl-ds-modal-footer__button--reverse': this.type === 'buttonAndLink'
            }}
            onClick={() => {
              this.onFirstButtonClicked();
            }}
            type={this.primaryButtonType()}
            loading={this.firstButtonLoading}
          >
            {this.firstButtonLabel}
          </agl-ds-button>
          {this.type !== 'oneButton' && this.renderSecondaryButton()}
        </div>
      </Host>
    );
  }
}
