import { newSpecPage } from '@stencil/core/testing';
import { ModalFooterComponent } from './modal-footer.component';

describe('ModalFooterComponent', () => {
  it('should render default modal-footer component', async () => {
    const page = await newSpecPage({
      components: [ModalFooterComponent],
      html: `<agl-ds-modal-footer></agl-ds-modal-footer>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-modal-footer>
        		<mock:shadow-root>
              <div class="agl-ds-modal-footer agl-ds-modal-footer--center">
                  <agl-ds-button class="agl-ds-modal-footer__button" type="primary">
                      Confirm
                  </agl-ds-button>
              </div>
            </mock:shadow-root>
        </agl-ds-modal-footer>
    `);
  });

  describe('oneButton', () => {
    it('should render one button', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="oneButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons.length).toBe(1);
    });

    it('should render button as primary', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="oneButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const button = page.root.querySelector('.agl-ds-modal-footer__button');
      const buttonType = button.attributes.getNamedItem('type').value;
      expect(buttonType).toBe('primary');
    });

    it('should display default button name', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="oneButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const button = page.root.querySelector('.agl-ds-modal-footer__button');
      expect(button.innerHTML).toBe('Confirm');
    });

    it('should display provided button name', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="oneButton" first-button-label="Test First Button"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const button = page.root.querySelector('.agl-ds-modal-footer__button');
      expect(button.innerHTML).toBe('Test First Button');
    });
  });

  describe('twoButton', () => {
    it('should render two buttons', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="twoButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons.length).toBe(2);
    });

    it('should render buttons as both secondary', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="twoButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      const firstButtonType = buttons[0].attributes.getNamedItem('type').value;
      const secondButtonType = buttons[1].attributes.getNamedItem('type').value;
      expect(firstButtonType).toBe('secondary');
      expect(secondButtonType).toBe('secondary');
    });

    it('should display default button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="twoButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Confirm');
      expect(buttons[1].innerHTML).toBe('Back');
    });

    it('should display provided button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="twoButton" first-button-label="Test First Button" second-button-label="Test Second Button"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Test First Button');
      expect(buttons[1].innerHTML).toBe('Test Second Button');
    });
  });

  describe('primaryAndSecondaryButton', () => {
    it('should render two buttons', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons.length).toBe(2);
    });

    it('should render buttons, one as primary one as secondary', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      const firstButtonType = buttons[0].attributes.getNamedItem('type').value;
      const secondButtonType = buttons[1].attributes.getNamedItem('type').value;
      expect(firstButtonType).toBe('primary');
      expect(secondButtonType).toBe('secondary');
    });

    it('should display default button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Confirm');
      expect(buttons[1].innerHTML).toBe('Back');
    });

    it('should display provided button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton" first-button-label="Test First Button" second-button-label="Test Second Button"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Test First Button');
      expect(buttons[1].innerHTML).toBe('Test Second Button');
    });

    it('should display loader when toggled', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton" first-button-loading="true" second-button-loading="true"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const firstButton = page.root.querySelectorAll('.agl-ds-modal-footer__button')[0];
      const secondButton = page.root.querySelectorAll('.agl-ds-modal-footer__button')[1];
      const firstButtonLoaderAttr = firstButton.attributes.getNamedItem('loading');
      const secondButtonLoaderAttr = secondButton.attributes.getNamedItem('loading');
      expect(firstButtonLoaderAttr).toBeTruthy();
      expect(secondButtonLoaderAttr).toBeTruthy();
    });

    it('should not display loader by default', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="primaryAndSecondaryButton"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const firstButton = page.root.querySelectorAll('.agl-ds-modal-footer__button')[0];
      const secondButton = page.root.querySelectorAll('.agl-ds-modal-footer__button')[1];
      const firstButtonLoaderAttr = firstButton.attributes.getNamedItem('loading');
      const secondButtonLoaderAttr = secondButton.attributes.getNamedItem('loading');
      expect(firstButtonLoaderAttr).toBeFalsy();
      expect(secondButtonLoaderAttr).toBeFalsy();
    });
  });

  describe('buttonAndLink', () => {
    it('should render two buttons', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="buttonAndLink"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons.length).toBe(2);
    });

    it('should render buttons, one as primary one as secondary', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="buttonAndLink"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      const firstButtonType = buttons[0].attributes.getNamedItem('type').value;
      const secondButtonType = buttons[1].attributes.getNamedItem('type').value;
      expect(firstButtonType).toBe('primary');
      expect(secondButtonType).toBe('tertiary');
    });

    it('should render icon for secondary button', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="buttonAndLink"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const secondButton = page.root.querySelectorAll('.agl-ds-modal-footer__button')[1];
      const iconPosition = secondButton.attributes.getNamedItem('iconposition').value;
      const icon = secondButton.attributes.getNamedItem('icon').value;
      expect(iconPosition).toBe('left');
      expect(icon).toEqual(expect.stringContaining('agl_left_arrow.svg'));
    });

    it('should display default button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="buttonAndLink"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Confirm');
      expect(buttons[1].innerHTML).toBe('Back');
    });

    it('should display provided button names', async () => {
      const page = await newSpecPage({
        components: [ModalFooterComponent],
        html: `<agl-ds-modal-footer type="buttonAndLink" first-button-label="Test First Button" second-button-label="Test Second Button"></agl-ds-modal-footer>`,
        supportsShadowDom: false
      });
      const buttons = page.root.querySelectorAll('.agl-ds-modal-footer__button');
      expect(buttons[0].innerHTML).toBe('Test First Button');
      expect(buttons[1].innerHTML).toBe('Test Second Button');
    });
  });
});
