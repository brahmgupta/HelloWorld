import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

const firstButtonLabelKnob = () => text('firstButtonLabel', 'Primary action');
const secondButtonLabelKnob = () => text('secondButtonLabel', 'Secondary action');
const firstButtonLoadingKnob = () => select('firstButtonLoading', ['true', 'false'], 'false');
const secondButtonLoadingKnob = () => select('secondButtonLoading', ['true', 'false'], 'false');

export default {
  title: 'Core/Modal/Modal footer'
};

export const WithOneButton = () => html`
  <agl-ds-modal-footer type="oneButton" first-button-label="${firstButtonLabelKnob()}"></agl-ds-modal-footer>
`;

WithOneButton.storyName = 'with one button';
WithOneButton.parameters = { notes };

export const WithTwoButton = () => html`
  <agl-ds-modal-footer
    type="twoButton"
    first-button-label="${firstButtonLabelKnob()}"
    second-button-label="${secondButtonLabelKnob()}"
  ></agl-ds-modal-footer>
`;

WithTwoButton.storyName = 'with two button';
WithTwoButton.parameters = { notes };

export const WithPrimaryAndSecondaryButton = () => html`
  <agl-ds-modal-footer
    type="primaryAndSecondaryButton"
    first-button-label="${firstButtonLabelKnob()}"
    second-button-label="${secondButtonLabelKnob()}"
  ></agl-ds-modal-footer>
`;

WithPrimaryAndSecondaryButton.storyName = 'with primaryAndSecondaryButton';
WithPrimaryAndSecondaryButton.parameters = { notes };

export const WithPrimaryAndSecondaryButtonLoading = () => html`
  <agl-ds-modal-footer
    type="primaryAndSecondaryButton"
    first-button-label="${firstButtonLabelKnob()}"
    second-button-label="${secondButtonLabelKnob()}"
    first-button-loading="${firstButtonLoadingKnob()}"
    second-button-loading="${secondButtonLoadingKnob()}"
  ></agl-ds-modal-footer>
`;

WithPrimaryAndSecondaryButtonLoading.storyName = 'with primary and secondary button loading';
WithPrimaryAndSecondaryButtonLoading.parameters = { notes };

export const WithButtonAndLink = () => html`
  <agl-ds-modal-footer
    type="buttonAndLink"
    first-button-label="${firstButtonLabelKnob()}"
    second-button-label="${secondButtonLabelKnob()}"
  ></agl-ds-modal-footer>
`;

WithButtonAndLink.storyName = 'with buttonAndLink';
WithButtonAndLink.parameters = { notes };
