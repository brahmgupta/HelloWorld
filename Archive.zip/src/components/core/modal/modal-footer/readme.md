# agl-ds-modal-footer



<!-- Auto Generated Below -->


## Properties

| Property              | Attribute               | Description                                                                              | Type                                                                           | Default       |
| --------------------- | ----------------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ | ------------- |
| `firstButtonLabel`    | `first-button-label`    | Set the display name of the first button. Will default to 'Confirm' if not set           | `string`                                                                       | `'Confirm'`   |
| `firstButtonLoading`  | `first-button-loading`  | Flag to determine if the loading indicator is to be displayed for primary button         | `boolean`                                                                      | `false`       |
| `secondButtonLabel`   | `second-button-label`   | Set the display name of the second button if relevant. Will default to 'Back' if not set | `string`                                                                       | `'Back'`      |
| `secondButtonLoading` | `second-button-loading` | Flag to determine if the loading indicator is to be displayed for secondary button       | `boolean`                                                                      | `false`       |
| `type`                | `type`                  | Flag to configure the button configuration for the footer                                | `"buttonAndLink" \| "oneButton" \| "primaryAndSecondaryButton" \| "twoButton"` | `'oneButton'` |


## Events

| Event                 | Description                             | Type                |
| --------------------- | --------------------------------------- | ------------------- |
| `firstButtonClicked`  | Fires when when first button is clicked | `CustomEvent<void>` |
| `secondButtonClicked` | Fires when modal is closed.             | `CustomEvent<void>` |


## Dependencies

### Depends on

- [agl-ds-button](../../button)

### Graph
```mermaid
graph TD;
  agl-ds-modal-footer --> agl-ds-button
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  style agl-ds-modal-footer fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
