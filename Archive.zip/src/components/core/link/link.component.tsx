import { Component, h, Prop, Host, Element, ComponentInterface, Watch, Method } from '@stencil/core';
import { AriaAttributes, FontSizes } from '../../../global/component.types';

import { checkSlottedContentForInvalidHTML, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import linkSvg from '../../../assets/icon-chevron-right.svg';
import { LinkAppearance } from './link.types';
@Component({
  tag: 'agl-ds-link',
  styleUrl: 'link.component.scss',
  shadow: true
})
export class LinkComponent implements ComponentInterface {
  @Element() host: HTMLAglDsLinkElement;

  /**
   * Determines the over-ride size of the text. By default it will inherit the font from the parent p tag
   */
  @Prop() styledAs: FontSizes = 'inherit';

  /**
   * Determines the over-ride font colour
   */
  @Prop() appearance: LinkAppearance = 'default';

  /**
   * The destination url for the navigation card click. To scroll to a given page element pass "#" and the id of the element eg "#mytextfield". Note this also sets
   * openNewWindow to false
   */
  @Prop() href: string = '';

  /**
   * The offset from the top of the page, used when scrolling to the given element.
   */
  @Prop() scrollToOffset: number = 160;

  /**
   * provide screen reader users with additional context or to convey information not available in HTML alone. Supplying this will override the default "Opens in new window"
   */
  @Prop({ mutable: true }) srContext: string = '';

  /**
   * sets any aria attributes on the component
   */
  @Prop() ariaAttribute: AriaAttributes[] = [];

  /**
   * Determines if the destination is opened in a new window
   */
  @Prop() openNewWindow: boolean = true;

  /**
   * Sets focus to the button
   */
  @Method()
  async setFocus() {
    this.inputElement.focus();
  }

  @Watch('ariaAttribute')
  setAriaAttribute() {
    if (this.inputElement && this.ariaAttribute) {
      this.ariaAttribute.map((item) => {
        this.inputElement.setAttribute(item.attribute, item.value);
      });
    }
  }

  @Watch('srContext')
  setSrContext(newValue: string) {
    if (newValue) {
      this.srContext = newValue;
    }
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-link', 'agl-ds-text']);
    this.setSrContext(this.srContext);
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);
  }

  private inputElement: HTMLAnchorElement;
  /**
   * Callback function for onClick
   */
  @Prop() callbackOnClick: (event: MouseEvent) => void = null;

  private getElement(elementId: string, parent: any) {
    let element = parent.getElementById(elementId);
    if (!element) {
      // this is included to reduce the number of elements the function needs to recursively search through
      const els = parent.querySelectorAll(
        ':not(meta):not(link):not(style):not(script):not(div):not(span):not(img):not(table):not(tr):not(td):not(th):not(agl-ds-text):not(agl-ds-p):not(agl-ds-spacer)'
      );
      for (let e = 0; e < els.length; e++) {
        if (els[e].shadowRoot) {
          if (els[e].shadowRoot.getElementById(elementId)) {
            element = els[e].shadowRoot.getElementById(elementId);
            return element;
          } else {
            element = this.getElement(elementId, els[e].shadowRoot);
            if (element) {
              return element;
            }
          }
        }
      }
    }
    return element;
  }

  private doScrolling(elementId) {
    if (elementId === '') return false;
    const duration = 700;
    const startingY = window.pageYOffset;
    const element = this.getElement(elementId, document);
    if (!element) {
      throw new Error(`${elementId} is not a valid element id to use with the agl-ds-link 'scroll to' feature`);
    }
    const elementY = window.pageYOffset + element.getBoundingClientRect().top;

    const diff = elementY - startingY - this.scrollToOffset;
    let start = 0;

    // Bootstrap our animation - it will get called right before next frame shall be rendered.
    window.requestAnimationFrame(function step(timestamp) {
      if (!start) start = timestamp;
      // Elapsed milliseconds since start of scrolling.
      const time = timestamp - start;
      // Get percent of completion in range [0, 1].
      const percent = Math.min(time / duration, 1);

      window.scrollTo(0, startingY + diff * percent);

      // Proceed with animation as long as we wanted it to.
      if (time < duration) {
        window.requestAnimationFrame(step);
      } else {
        if (element.setFocus) {
          element.setFocus();
        } else {
          element.focus();
        }
      }
    });
  }

  render() {
    const isIdHref = this.href.toString().startsWith('#');
    const href = isIdHref ? 'javascript:void(0)' : this.href;
    const openNewWindow = isIdHref ? false : this.openNewWindow;

    if (!(['display01', 'display02', 'inherit', 'lg', 'md', 'sm', 'xl', 'xs'] as FontSizes[]).includes(this.styledAs)) {
      throw new Error(this.styledAs + ' is not a valid font size');
    }

    if (!(['default', 'inverse', 'secondary'] as LinkAppearance[]).includes(this.appearance)) {
      throw new Error(this.appearance + ' is not a valid font colour');
    }

    return (
      <Host>
        <a
          ref={(el) => (this.inputElement = el)}
          rel={openNewWindow ? 'noopener noreferrer' : ''}
          target={openNewWindow ? '_blank' : '_self'}
          class={{
            ['agl-ds-' + this.styledAs]: true,
            ['agl-ds-a-' + this.appearance + '-colour']: true
          }}
          href={href}
          onClick={(e) => {
            if (isIdHref) {
              const idToScrollTo = this.href.replace('#', '');
              this.doScrolling(idToScrollTo);
            }
            if (this.callbackOnClick) {
              this.callbackOnClick(e);
              return true;
            }
          }}
        >
          {this.srContext ? <span class="sr-only"> {this.srContext}</span> : ''}
          {this.openNewWindow ? <span class="sr-only">, opens in new window</span> : ''}
          <slot />
          {this.appearance === 'secondary' && <span innerHTML={linkSvg} />}
        </a>
      </Host>
    );
  }
}
