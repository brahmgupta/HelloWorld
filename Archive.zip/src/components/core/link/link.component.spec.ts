import { newSpecPage } from '@stencil/core/testing';
import { LinkComponent } from './link.component';

describe('Link component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: `<agl-ds-link href="http://www.agl.com.au">dummy text</agl-ds-link>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-link href="http://www.agl.com.au">
        <mock:shadow-root>
          <a class="agl-ds-a-default-colour agl-ds-inherit" href="http://www.agl.com.au" rel="noopener noreferrer" target="_blank">
            <span class="sr-only">
              , opens in new window
            </span>
            <slot></slot>
          </a>
        </mock:shadow-root>
      dummy text
    </agl-ds-link>
    `);
  });

  it('should render the component styled with the inherited font from the `par`ent p tag', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link>dummy link text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-inherit');
    expect(classList).toBeTruthy();
  });

  it('should render the component styled with xl font', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link styled-as="xl">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-xl');
    expect(classList).toBeTruthy();
  });

  it('should render the component styled with lg font', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link styled-as="lg">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-lg');
    expect(classList).toBeTruthy();
  });

  it('should render the component styled with md font', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link styled-as="md">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-md');
    expect(classList).toBeTruthy();
  });

  it('should render the component styled with sm font', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link styled-as="sm">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-sm');
    expect(classList).toBeTruthy();
  });

  it('should render the component styled with xs font', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link styled-as="xs">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-xs');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the default colour', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link>dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-a-default-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the inverse colour', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link appearance="inverse">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const classList = element.classList.contains('agl-ds-a-inverse-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with secondary colour class', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link appearance="secondary">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-link appearance="secondary">
      <a class="agl-ds-a-secondary-colour agl-ds-inherit" href="" rel="noopener noreferrer" target="_blank">
        <span class="sr-only">
          , opens in new window
        </span>
        dummy text
        <span>
          svg contents from: src/assets/icon-chevron-right.svg
        </span>
      </a>
    </agl-ds-link>
    `);
  });

  it('should render the component to open in a new window', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link>dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const targetValue = element.attributes.getNamedItem('target').value;
    const relValue = element.attributes.getNamedItem('rel').value;

    expect(targetValue).toBe('_blank');
    expect(relValue).toBe('noopener noreferrer');
  });

  it('should render the component to open in the same window', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link open-new-window="false">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('a');
    const targetValue = element.attributes.getNamedItem('target').value;
    const relValue = element.attributes.getNamedItem('rel').value;

    expect(targetValue).toBe('_self');
    expect(relValue).toBe('');
  });

  it('should render the component with passed in srContent to over-ride default', async () => {
    const dummyText = 'dummy sr content';
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link sr-context="' + dummyText + '">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const elements = await page.doc.querySelectorAll('span');
    expect(elements[0].childNodes[0].nodeValue).toEqual(' ' + dummyText);
    expect(elements[1].childNodes[0].nodeValue).toEqual(', opens in new window');
  });

  it('should render the component with passed in srContent when opened in the same window', async () => {
    const dummyText = 'dummy sr content';
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link sr-context="' + dummyText + '">dummy text</agl-ds-link>',
      supportsShadowDom: false
    });
    const elements = await page.doc.querySelectorAll('span');
    expect(elements[0].childNodes[0].nodeValue).toEqual(' ' + dummyText);
  });

  it('should render the component to be able to scroll to the passed in element id', async () => {
    const page = await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link href="#myid">dummy text</agl-ds-link><input id="myid" type="text"  value="myid">',
      supportsShadowDom: false
    });

    const link = page.root.querySelectorAll('a')[0];
    expect(link.href).toBe('javascript:void(0)');

    const clickSpy = jest.fn();
    page.win.addEventListener('click', clickSpy);

    page.win.dispatchEvent(new Event('click'));

    await page.waitForChanges();
    expect(clickSpy).toHaveBeenCalled();
  });

  it('should render the component with the correct href', async () => {
    const validHref = 'http://www.agl.com.au/';
    const page = await newSpecPage({
      components: [LinkComponent],
      html: `<agl-ds-link href="${validHref}">dummy text</agl-ds-link><input id="myid" type="text"  value="myid">`,
      supportsShadowDom: false
    });

    const link = page.root.querySelectorAll('a')[0];
    expect(link.href).toBe(validHref);
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link href="http://www.agl.com.au"><agl-ds-text>dummy text</agl-ds-text></agl-ds-link>',
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [LinkComponent],
      html: '<agl-ds-link href="http://www.agl.com.au"><p>dummy text</p></agl-ds-link>',
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
