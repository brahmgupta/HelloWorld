export type LinkAppearance = 'default' | 'inverse' | 'secondary';
