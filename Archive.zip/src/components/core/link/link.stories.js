import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/link'
};

export const Link = () => html`
  <agl-ds-p styled-as="${select('Example sentence - styled as', ['xs', 'sm', 'md', 'lg', 'xl'], 'md')}">
    Here is a sentence that contains an

    <agl-ds-link
      styled-as="${select('Link tag - styled as', ['xs', 'sm', 'md', 'lg', 'xl', 'inherit'], 'inherit')}"
      appearance="default"
      open-new-window="${select('Open in new window', [true, false], true)}"
      href="${text('href', 'https://www.agl.com.au')}"
      sr-context="${text('sr-context', 'sr-context to further inform the user')}"
    >
      ${text('Link text', 'example link')}
    </agl-ds-link>
  </agl-ds-p>
`;

Link.storyName = 'link';
Link.parameters = { notes };

export const LinkWithInverseBackground = () => html`
  <div style="background-color:var(--c-primary-01, #001cb0);">
    <agl-ds-p appearance="inverse" styled-as="${select('Example sentence - styled as', ['xs', 'sm', 'md', 'lg', 'xl'], 'md')}">
      Here is a sentence with an inverse background colour that contains an

      <agl-ds-link
        styled-as="${select('Link tag - styled as', ['xs', 'sm', 'md', 'lg', 'xl', 'inherit'], 'inherit')}"
        appearance="inverse"
        open-new-window="${select('Open in new window', [true, false], true)}"
        href="${text('href', 'https://www.agl.com.au')}"
        sr-context="${text('sr-context', 'sr-context to further inform the user')}"
      >
        ${text('Link text', 'example link')}
      </agl-ds-link>
    </agl-ds-p>
  </div>
`;

LinkWithInverseBackground.storyName = 'link with inverse background';
LinkWithInverseBackground.parameters = { notes };

export const LinkWithOperationBeforeRedirecting = () => {
  const link = document.createElement('agl-ds-link');
  link.callbackOnClick = (e) => {
    console.log('Operation starts (counter to 100,000).');
    for (let i = 0; i <= 100000; i++) {
      console.log('Counter in callback: ', i);
    }
    console.log('Operation ends.');
  };
  link.setAttribute('styled-as', select('Link tag - styled as', ['xs', 'sm', 'md', 'lg', 'xl', 'inherit'], 'md'));
  link.setAttribute('open-new-window', select('Open in new window', [true, false], false));
  link.setAttribute('href', text('href', 'https://www.agl.com.au'));
  link.setAttribute('sr-context', text('sr-context', 'Redirecting to href happens when callback operation has finished.'));
  link.innerText = 'Example link with operation';
  return link;
};

LinkWithOperationBeforeRedirecting.storyName = 'link with operation before redirecting';
LinkWithOperationBeforeRedirecting.parameters = { notes };

export const LinkWithSecondaryColour = () => html`
  <agl-ds-link
    styled-as="${select('Link tag - styled as', ['xs', 'sm', 'md', 'lg', 'xl', 'inherit'], 'md')}"
    appearance="secondary"
    open-new-window="${select('Open in new window', [true, false], true)}"
    href="${text('href', 'https://www.agl.com.au')}"
    sr-context="${text('sr-context', 'sr-context to further inform the user')}"
  >
    ${text('Link text', 'Here is a long example link that shows the icon aligning to the top row of text')}
  </agl-ds-link>
`;

LinkWithSecondaryColour.storyName = 'link with secondary colour';
LinkWithSecondaryColour.parameters = { notes };
