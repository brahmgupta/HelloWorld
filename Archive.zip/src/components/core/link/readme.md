# agl-ds-link



<!-- Auto Generated Below -->


## Properties

| Property          | Attribute          | Description                                                                                                                                                                           | Type                                                                              | Default     |
| ----------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- | ----------- |
| `appearance`      | `appearance`       | Determines the over-ride font colour                                                                                                                                                  | `"default" \| "inverse" \| "secondary"`                                           | `'default'` |
| `ariaAttribute`   | --                 | sets any aria attributes on the component                                                                                                                                             | `AriaAttributes[]`                                                                | `[]`        |
| `callbackOnClick` | --                 | Callback function for onClick                                                                                                                                                         | `(event: MouseEvent) => void`                                                     | `null`      |
| `href`            | `href`             | The destination url for the navigation card click. To scroll to a given page element pass "#" and the id of the element eg "#mytextfield". Note this also sets openNewWindow to false | `string`                                                                          | `''`        |
| `openNewWindow`   | `open-new-window`  | Determines if the destination is opened in a new window                                                                                                                               | `boolean`                                                                         | `true`      |
| `scrollToOffset`  | `scroll-to-offset` | The offset from the top of the page, used when scrolling to the given element.                                                                                                        | `number`                                                                          | `160`       |
| `srContext`       | `sr-context`       | provide screen reader users with additional context or to convey information not available in HTML alone. Supplying this will override the default "Opens in new window"              | `string`                                                                          | `''`        |
| `styledAs`        | `styled-as`        | Determines the over-ride size of the text. By default it will inherit the font from the parent p tag                                                                                  | `"display01" \| "display02" \| "inherit" \| "lg" \| "md" \| "sm" \| "xl" \| "xs"` | `'inherit'` |


## Methods

### `setFocus() => Promise<void>`

Sets focus to the button

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-notification](../../composite/notification-card)

### Graph
```mermaid
graph TD;
  agl-ds-notification --> agl-ds-link
  style agl-ds-link fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
