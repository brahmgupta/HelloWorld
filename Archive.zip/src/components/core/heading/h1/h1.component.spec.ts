import { newSpecPage } from '@stencil/core/testing';
import { BottomMargin } from '../../../../global/component.types';
import { H1Component } from '../h1/h1.component';

describe('H1 component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: `<agl-ds-h1>
              dummy header
            </agl-ds-h1>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-h1>
          <mock:shadow-root>
            <h1 class="agl-ds-default-colour agl-ds-title1">
              <slot></slot>
            </h1>
          </mock:shadow-root>
          dummy header
        </agl-ds-h1>
    `);
  });

  it('should render the component with an h1 tag and styled as an title1', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1>dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const tagClassList = element.classList.contains('agl-ds-title1');
    const colourClassList = element.classList.contains('agl-ds-default-colour');
    expect(tagClassList).toBeTruthy();
    expect(colourClassList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title1', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title1">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title1');
    expect(classList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title2', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title2">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title2');
    expect(classList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title3', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title3">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title3');
    expect(classList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title4', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title4">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title4');
    expect(classList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title5', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title5">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title5');
    expect(classList).toBeTruthy();
  });

  it('should render the component with an h1 tag and styled as title6', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 styled-as="title6">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-title6');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the alternate font', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 font="fontfamily02" >dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-fontfamily02');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the default colour', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1>dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-default-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the muted colour', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 appearance="muted">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-muted-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the highlighted colour', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 appearance="highlight">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-highlight-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the inverse colour', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 appearance="inverse">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds-inverse-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the bottom margin suppressed', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: '<agl-ds-h1 bottom-margin="none">dummy header</agl-ds-h1>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains('agl-ds--bottom-margin-none');
    expect(classList).toBeTruthy();
  });

  it('should render the component with no bottom margin if bottom-margin="none" and bottom-margin=space06', async () => {
    const page = await newSpecPage({
      components: [H1Component],
      html: `<agl-ds-h1 bottom-margin="none" bottom-margin="space06">dummy header</agl-ds-h1>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('h1');
    const classList = element.classList.contains(`agl-ds--bottom-margin-space06`);
    expect(classList).toBeFalsy();
  });

  (['none', 'space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'] as BottomMargin[]).map((margin) => {
    it('should render the component with the correct bottom margin if suppress-margin=false', async () => {
      const page = await newSpecPage({
        components: [H1Component],
        html: `<agl-ds-h1 bottom-margin="${margin}">dummy header</agl-ds-h1>`,
        supportsShadowDom: false
      });

      const element = await page.doc.querySelector('h1');
      const classList = element.classList.contains(`agl-ds--bottom-margin-${margin}`);
      expect(classList).toBeTruthy();
    });
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [H1Component],
      html: `<agl-ds-h1><agl-ds-text>dummy header</agl-ds-text></agl-ds-h1>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [H1Component],
      html: `<agl-ds-h1><p>dummy text</p></agl-ds-h1>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
