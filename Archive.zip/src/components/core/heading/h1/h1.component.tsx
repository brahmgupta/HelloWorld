import { Component, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { Appearance, FontType, TitleType, BottomMargin } from '../../../../global/component.types';
import { Heading } from './../heading.component';

@Component({
  tag: 'agl-ds-h1',
  styleUrl: './../heading.component.scss',
  shadow: true
})
export class H1Component implements ComponentInterface {
  @Element() host: HTMLAglDsH1Element;
  /**
   * Determines the over-ride size of the heading - the symantic tag remains the same
   */
  @Prop() styledAs: TitleType = 'title1';

  /**
   * Determines the over-ride heading font
   */
  @Prop() font: FontType = null;

  /**
   * Determines the over-ride heading font colour
   */
  @Prop() appearance: Appearance = 'default';

  /**
   * Determines the over-ride bottom margin size
   */
  @Prop() bottomMargin: BottomMargin = null;

  render() {
    return (
      <Heading
        host={this.host}
        type="h1"
        styledAs={this.styledAs}
        font={this.font}
        appearance={this.appearance}
        bottomMargin={this.bottomMargin}
      />
    );
  }
}
