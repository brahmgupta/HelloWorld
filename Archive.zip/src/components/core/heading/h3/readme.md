# agl-ds-h3



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                                      | Type                                                                                                | Default     |
| -------------- | --------------- | -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- | ----------- |
| `appearance`   | `appearance`    | Determines the over-ride heading font colour                                     | `"default" \| "highlight" \| "inverse" \| "muted" \| "secondary-highlight"`                         | `'default'` |
| `bottomMargin` | `bottom-margin` | Determines the over-ride bottom margin size                                      | `"none" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space05" \| "space06"` | `null`      |
| `font`         | `font`          | Determines the over-ride heading font                                            | `"fontfamily01" \| "fontfamily02"`                                                                  | `null`      |
| `styledAs`     | `styled-as`     | Determines the over-ride size of the heading - the symantic tag remains the same | `"title1" \| "title2" \| "title3" \| "title4" \| "title5" \| "title6"`                              | `'title3'`  |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
