import { newSpecPage } from '@stencil/core/testing';
import { H3Component } from '../h3/h3.component';

describe('H3 component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [H3Component],
      html: `<agl-ds-h3>
              dummy header
            </agl-ds-h3>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-h3>
          <mock:shadow-root>
            <h3 class="agl-ds-default-colour agl-ds-title3">
              <slot></slot>
            </h3>
          </mock:shadow-root>
          dummy header
        </agl-ds-h3>
    `);
  });
});
