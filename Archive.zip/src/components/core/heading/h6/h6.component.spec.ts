import { newSpecPage } from '@stencil/core/testing';
import { H6Component } from '../h6/h6.component';

describe('H6 component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [H6Component],
      html: `<agl-ds-h6>
              dummy header
            </agl-ds-h6>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-h6>
          <mock:shadow-root>
            <h6 class="agl-ds-default-colour agl-ds-title6">
              <slot></slot>
            </h6>
          </mock:shadow-root>
          dummy header
        </agl-ds-h6>
    `);
  });
});
