import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Heading/H6'
};

const styledAsKnob = () => select('styled as', ['title1', 'title2', 'title3', 'title4', 'title5', 'title6'], 'title6');
const fontKnob = () => select('font family', [null, 'fontfamily01', 'fontfamily02'], null);
const appearanceKnob = () => select('appearance', ['default', 'muted', 'highlight', 'inverse', 'secondary-highlight'], 'default');
const bottomMarginKnob = () =>
  select('bottom margin', ['', 'none', 'space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'], '');

export const H6 = () => html`
  <agl-ds-h6 styled-as="${styledAsKnob()}" font="${fontKnob()}" appearance="${appearanceKnob()}" bottom-margin="${bottomMarginKnob()}">
    ${text('heading text', "I'm an H6 heading")}
  </agl-ds-h6>
  Sample text to show bottom padding
`;

H6.storyName = 'h6';
H6.parameters = { notes };
