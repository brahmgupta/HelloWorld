# agl-ds-h1



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute    | Description                                                                      | Type                                                                                                       | Default                 |
| ------------ | ------------ | -------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- | ----------------------- |
| `appearance` | `appearance` | Determines the over-ride heading font colour                                     | `Appearance.default or Appearance.highlight or Appearance.muted`                                           | `Appearance.default`    |
| `font`       | `font`       | Determines the over-ride heading font                                            | `FontType.fontfamily01 or FontType.fontfamily02`                                                           | `FontType.fontfamily01` |
| `styledAs`   | `styled-as`  | Determines the over-ride size of the heading - the symantic tag remains the same | `HeadingType.h1 or HeadingType.h2 or HeadingType.h3 or HeadingType.h4 or HeadingType.h5 or HeadingType.h6` | `HeadingType.h1`        |


## Dependencies

### Used by

 - [agl-ds-guided-banner](../guided-banner)

### Graph
```mermaid
graph TD;
  agl-ds-guided-banner --> agl-ds-h1
  style agl-ds-h1 fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
