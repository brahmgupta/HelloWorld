# agl-ds-h2



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                                      | Type                                                                                                | Default     |
| -------------- | --------------- | -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- | ----------- |
| `appearance`   | `appearance`    | Determines the over-ride heading font colour                                     | `"default" \| "highlight" \| "inverse" \| "muted" \| "secondary-highlight"`                         | `'default'` |
| `bottomMargin` | `bottom-margin` | Determines the over-ride bottom margin size                                      | `"none" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space05" \| "space06"` | `null`      |
| `font`         | `font`          | Determines the over-ride heading font                                            | `"fontfamily01" \| "fontfamily02"`                                                                  | `null`      |
| `styledAs`     | `styled-as`     | Determines the over-ride size of the heading - the symantic tag remains the same | `"title1" \| "title2" \| "title3" \| "title4" \| "title5" \| "title6"`                              | `'title2'`  |


## Dependencies

### Used by

 - [agl-ds-guided-banner](../../../composite/banner/guided-banner)
 - [agl-ds-manual-address-entry](../../../composite/addresssearch/manual-address-entry)
 - [agl-ds-navigation-card](../../../composite/navigation-card)

### Graph
```mermaid
graph TD;
  agl-ds-guided-banner --> agl-ds-h2
  agl-ds-manual-address-entry --> agl-ds-h2
  agl-ds-navigation-card --> agl-ds-h2
  style agl-ds-h2 fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
