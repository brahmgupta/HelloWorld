import { Component, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { FontType, Appearance, TitleType, BottomMargin } from '../../../../global/component.types';
import { Heading } from './../heading.component';

@Component({
  tag: 'agl-ds-h2',
  styleUrl: './../heading.component.scss',
  shadow: true
})
export class H2Component implements ComponentInterface {
  @Element() host: HTMLAglDsH2Element;
  /**
   * Determines the over-ride size of the heading - the symantic tag remains the same
   */
  @Prop() styledAs: TitleType = 'title2';

  /**
   * Determines the over-ride heading font
   */
  @Prop() font: FontType = null;

  /**
   * Determines the over-ride heading font colour
   */
  @Prop() appearance: Appearance = 'default';

  /**
   * Determines the over-ride bottom margin size
   */
  @Prop() bottomMargin: BottomMargin = null;

  render() {
    return (
      <Heading
        host={this.host}
        type="h2"
        styledAs={this.styledAs}
        font={this.font}
        appearance={this.appearance}
        bottomMargin={this.bottomMargin}
      />
    );
  }
}
