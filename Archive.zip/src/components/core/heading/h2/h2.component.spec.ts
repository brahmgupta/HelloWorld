import { newSpecPage } from '@stencil/core/testing';
import { H2Component } from '../h2/h2.component';

describe('H2 component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [H2Component],
      html: `<agl-ds-h2>
              dummy header
            </agl-ds-h2>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-h2>
          <mock:shadow-root>
            <h2 class="agl-ds-default-colour agl-ds-title2">
              <slot></slot>
            </h2>
          </mock:shadow-root>
          dummy header
        </agl-ds-h2>
    `);
  });
});
