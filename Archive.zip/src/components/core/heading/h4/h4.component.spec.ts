import { newSpecPage } from '@stencil/core/testing';
import { H4Component } from '../h4/h4.component';

describe('H4 component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [H4Component],
      html: `<agl-ds-h4>
              dummy header
            </agl-ds-h4>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-h4>
          <mock:shadow-root>
            <h4 class="agl-ds-default-colour agl-ds-title4">
              <slot></slot>
            </h4>
          </mock:shadow-root>
          dummy header
        </agl-ds-h4>
    `);
  });
});
