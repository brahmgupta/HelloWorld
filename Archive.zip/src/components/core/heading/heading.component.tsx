import { FunctionalComponent, h, Host } from '@stencil/core';
import { HeadingType, FontType, Appearance, TitleType, BottomMargin } from '../../../global/component.types';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';

interface HeadingProps {
  host: HTMLAglDsH1Element | HTMLAglDsH2Element | HTMLAglDsH3Element | HTMLAglDsH4Element | HTMLAglDsH5Element | HTMLAglDsH6Element;
  type: HeadingType;
  styledAs: TitleType;
  font: FontType;
  appearance: Appearance;
  bottomMargin: BottomMargin;
}

export const Heading: FunctionalComponent<HeadingProps> = ({ host, type, styledAs, font, appearance, bottomMargin }) => {
  checkSlottedContentForInvalidHTML(host, [
    'agl-ds-h1',
    'agl-ds-h2',
    'agl-ds-h3',
    'agl-ds-h4',
    'agl-ds-h5',
    'agl-ds-h6',
    'agl-ds-text',
    'span',
    'slot',
    'br'
  ]);

  if (type && !(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] as HeadingType[]).includes(type)) {
    throw new Error(type + ' is not a valid type');
  }

  if (styledAs && !(['title1', 'title2', 'title3', 'title4', 'title5', 'title6'] as TitleType[]).includes(styledAs)) {
    throw new Error(styledAs + ' is not a valid title type');
  }

  if (String(font) !== 'null' && !(['fontfamily01', 'fontfamily02'] as FontType[]).includes(font)) {
    throw new Error(font + ' is not a valid font type');
  }

  if (appearance && !(['default', 'highlight', 'inverse', 'muted', 'secondary-highlight'] as Appearance[]).includes(appearance)) {
    throw new Error(appearance + ' is not a valid font colour');
  }

  const Tag = type;
  return (
    <Host>
      <Tag
        class={{
          ['agl-ds-' + styledAs]: true,
          ['agl-ds-' + font]: font !== null,
          ['agl-ds-' + appearance + '-colour']: true,
          ['agl-ds--bottom-margin-' + bottomMargin]: !!bottomMargin
        }}
      >
        <slot />
      </Tag>
    </Host>
  );
};
