import { text, number, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Day of month picker'
};

export const Default = () =>
  html` <agl-ds-day-of-month-picker
    value="${number('Selected day', new Date().getDate())}"
    type="${select('type', ['default', 'default-inverse'], 'default')}"
    label="${text('label', 'Billing day')}"
    hint-text="${text('Hint text', 'Hint text')}"
  >
  </agl-ds-day-of-month-picker>`;

Default.parameters = { notes };
