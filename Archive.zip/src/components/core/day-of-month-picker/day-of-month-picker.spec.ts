import { newSpecPage } from '@stencil/core/testing';
import { DayOfMonthPickerComponent } from './day-of-month-picker.component';

describe('Day of month picker', () => {
  it('should create component with selected day', async () => {
    const page = await newPageWithDayOfMonthPicker(10);

    const button = page.root.querySelector('button');
    expect(button.innerText).toBe('10svg contents from: src/assets/icon-calendar.svg');
  });

  it('should open picker when button is clicked', async () => {
    const page = await newPageWithDayOfMonthPicker(10);

    const button = page.root.querySelector('button');
    const dayPickerContainer = page.root.querySelector('.agl-day-of-month-picker__day-container');
    expect(dayPickerContainer).not.toHaveClass('agl-day-of-month-picker__day-container--open');

    button.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    expect(dayPickerContainer).toHaveClass('agl-day-of-month-picker__day-container--open');
  });

  it('should change number when a new number is selected', async () => {
    const page = await newPageWithDayOfMonthPicker(10);

    const button = page.root.querySelector('button');
    const dayPickerContainer = page.root.querySelector('.agl-day-of-month-picker__day-container');

    button.focus = jest.fn();
    button.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    const numberSecondOnGrid = page.root.querySelectorAll('td')[1];
    numberSecondOnGrid.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    expect(dayPickerContainer).not.toHaveClass('agl-day-of-month-picker__day-container--open');
    expect(button.innerText).toBe('2svg contents from: src/assets/icon-calendar.svg');
  });
});

const newPageWithDayOfMonthPicker = async (selectedDay: number) => {
  return await newSpecPage({
    components: [DayOfMonthPickerComponent],
    html: `<agl-ds-day-of-month-picker value="${selectedDay}"></agl-ds-day-of-month-picker>`,
    supportsShadowDom: false
  });
};
