export type DayPickerNavigationArrowKey = 'ArrowUp' | 'ArrowDown' | 'ArrowRight' | 'ArrowLeft';

export type DayPickerNavigationInternetExplorerArrowKey = 'Up' | 'Down' | 'Right' | 'Left';

export type DayPickerNavigationChordKey = 'Control' | 'Home' | 'End';

export type DayPickerKey =
  | DayPickerNavigationArrowKey
  | DayPickerNavigationChordKey
  | DayPickerNavigationInternetExplorerArrowKey
  | 'Enter'
  | 'Escape'
  | 'Esc' // Internet explorer uses 'Esc'
  | 'Space';

export type DayPickerControlType = 'default' | 'default-inverse';

export type IEArrowKeyToArrowKey = Record<DayPickerNavigationInternetExplorerArrowKey, DayPickerNavigationArrowKey>;
