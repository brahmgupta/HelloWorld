# agl-ds-day-of-month-picker



<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description                                                                                                                                                                                             | Type                             | Default                |
| ---------- | ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------- | ---------------------- |
| `hintText` | `hint-text` | The hint text for the day picker                                                                                                                                                                        | `string`                         | `''`                   |
| `label`    | `label`     | The label for the day picker                                                                                                                                                                            | `string`                         | `'Day of month'`       |
| `type`     | `type`      | Type for the control, either default or default-inverse                                                                                                                                                 | `"default" \| "default-inverse"` | `'default'`            |
| `value`    | `value`     | The selected day in the day picker  Defaults to current local day of the month using vanilla js getDate() https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getDate | `number`                         | `new Date().getDate()` |


## Events

| Event         | Description                   | Type                  |
| ------------- | ----------------------------- | --------------------- |
| `daySelected` | Fires when an day is selected | `CustomEvent<number>` |


## Dependencies

### Depends on

- [agl-ds-text](../text)
- [agl-ds-p](../paragraph)
- [agl-ds-hint-validation-message](../hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-day-of-month-picker --> agl-ds-text
  agl-ds-day-of-month-picker --> agl-ds-p
  agl-ds-day-of-month-picker --> agl-ds-hint-validation-message
  style agl-ds-day-of-month-picker fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
