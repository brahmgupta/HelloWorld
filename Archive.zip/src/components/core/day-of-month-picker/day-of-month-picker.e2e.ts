import { E2EElement, E2EPage, newE2EPage } from '@stencil/core/testing';

describe('Day of month picker keyboard navigation', () => {
  it('should render the component', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="10"></agl-ds-day-of-month-picker>`);
    const comp = await page.find('agl-ds-day-of-month-picker');

    expect(comp).not.toBeNull();
  });

  it('should open the day picker with enter key', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="10"></agl-ds-day-of-month-picker>`);
    const button = await page.find('agl-ds-day-of-month-picker >>> button');
    expect(button.innerText).toEqualText('10');
    const gridContainer = await page.find('agl-ds-day-of-month-picker >>> .agl-day-of-month-picker__day-container');
    expect(gridContainer).not.toHaveClass('agl-day-of-month-picker__day-container--open');

    await button.focus();
    await button.press('Enter');

    await page.waitForChanges();

    expect(gridContainer).toHaveClass('agl-day-of-month-picker__day-container--open');
  });

  it('should hide the day picker with the esc key', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="10"></agl-ds-day-of-month-picker>`);

    const gridContainer = await page.find('agl-ds-day-of-month-picker >>> .agl-day-of-month-picker__day-container');
    expect(gridContainer).not.toHaveClass('agl-day-of-month-picker__day-container--open');

    await openPicker(page);
    expect(gridContainer).toHaveClass('agl-day-of-month-picker__day-container--open');

    const grid = await page.find('agl-ds-day-of-month-picker >>> .agl-day-of-month-picker__day-grid');
    expect(grid).toBeDefined();
    await page.keyboard.press('Escape');

    await page.waitForChanges();
    expect(gridContainer).not.toHaveClass('agl-day-of-month-picker__day-container--open');
  });

  it('should navigate two cells right with keyboard and update value', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="10"></agl-ds-day-of-month-picker>`);
    await openPicker(page);
    await page.keyboard.press('ArrowRight');
    await page.keyboard.press('ArrowRight');
    await page.waitForChanges();

    const allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 12);

    await page.keyboard.press('Enter');
    await page.waitForChanges();

    const button = await page.find('agl-ds-day-of-month-picker >>> button');
    expect(button.innerText).toEqualText('12');
  });

  it('should navigate with all keys', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="10"></agl-ds-day-of-month-picker>`);
    let allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');

    await openPicker(page);

    await page.keyboard.press('End');
    await page.waitForChanges();
    allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 14);

    await page.keyboard.press('Home');
    await page.waitForChanges();
    allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 8);

    await page.keyboard.down('Control');
    await page.keyboard.press('Home');
    await page.waitForChanges();
    allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 1);

    await page.keyboard.down('Control');
    await page.keyboard.press('End');
    await page.waitForChanges();

    allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 31);
  });

  it('should not navigate down if row below is partial', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-day-of-month-picker value="19"></agl-ds-day-of-month-picker>`);

    await openPicker(page);

    await page.keyboard.press('ArrowDown');
    await page.keyboard.press('ArrowDown');
    await page.waitForChanges();
    const allCellsContent = await page.findAll('agl-ds-day-of-month-picker >>> agl-ds-p');
    assertCellNavigatedTo(allCellsContent, 26);
  });
});

const openPicker = async (page: E2EPage) => {
  const button = await page.find('agl-ds-day-of-month-picker >>> button');
  await button.focus();
  await page.keyboard.press('Enter');
  await page.waitForChanges();
};

const assertCellNavigatedTo = (cells: E2EElement[], n: number) => {
  const cell = cells[n - 1];
  expect(cell).toHaveClass('agl-day-of-month-picker__day-item-content--navigated');
};
