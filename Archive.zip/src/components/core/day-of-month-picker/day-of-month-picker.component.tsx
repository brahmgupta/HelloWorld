import { Component, EventEmitter, h, Prop, State, Event, Listen, Host, Element, ComponentInterface } from '@stencil/core';
import iconCalendar from '../../../assets/icon-calendar.svg';
import { generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import {
  DayPickerNavigationChordKey,
  DayPickerNavigationArrowKey,
  DayPickerKey,
  DayPickerControlType,
  IEArrowKeyToArrowKey,
  DayPickerNavigationInternetExplorerArrowKey
} from './day-of-month-picker.types';

@Component({
  tag: 'agl-ds-day-of-month-picker',
  styleUrl: 'day-of-month-picker.component.scss',
  shadow: true
})
export class DayOfMonthPickerComponent implements ComponentInterface {
  @Element() host: HTMLAglDsDayOfMonthPickerElement;
  /**
   * The selected day in the day picker
   *
   * Defaults to current local day of the month using vanilla js getDate()
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getDate
   */
  @Prop({ mutable: true }) value: number = new Date().getDate();

  /**
   * The label for the day picker
   */
  @Prop() label: string = 'Day of month';

  /**
   * The hint text for the day picker
   */
  @Prop() hintText: string = '';

  /**
   * Type for the control, either default or default-inverse
   */
  @Prop() type: DayPickerControlType = 'default';

  /**
   * Whether the picker is visible or not
   */
  @State() pickerOpen: boolean = false;

  /**
   * The day currently highlighted in the picker when the user navigates with a keyboard
   */
  @State() navigatedDay: number = 1;

  /**
   * Whether keys for chord key stokes (e.g. Control + Home for first cell) are currently pressed
   */
  @State() chordKeysDown: Record<DayPickerNavigationChordKey, boolean> = {
    Control: false,
    Home: false,
    End: false
  };

  /**
   * Fires when an day is selected
   */
  @Event() daySelected: EventEmitter<number>;

  @Listen('click', { capture: true, target: 'window' })
  handleClick(e) {
    if (this.pickerOpen && !this.daysGridElement.contains(e.target)) {
      this.closePicker();
    }
  }

  private daysGridElement: HTMLTableElement;
  private buttonElement: HTMLButtonElement;
  private gridRefs: HTMLElement[] = [];
  private elementsPerRow: number = 7;
  private daysInMonth: number = 31;
  private grid: number[][] = this.makeDayGrid(this.daysInMonth, this.elementsPerRow);
  private timeOutId: number = null;
  private uniqueHintValidationId: string = generateRandomNumber();
  private uniqueLabelId: string = generateRandomNumber();
  private normaliseIEArrowKey: IEArrowKeyToArrowKey = { Up: 'ArrowUp', Down: 'ArrowDown', Right: 'ArrowRight', Left: 'ArrowLeft' };

  private get canNavigateRight(): boolean {
    return this.navigatedDay < this.daysInMonth;
  }

  private get canNavigateLeft(): boolean {
    return this.navigatedDay > 1;
  }

  private get canNavigateDown(): boolean {
    return this.navigatedDay <= this.daysInMonth - this.elementsPerRow;
  }

  private get canNavigateUp(): boolean {
    return this.navigatedDay > this.elementsPerRow;
  }

  private makeDayGrid(numberOfDays: number, elementsPerRow: number): number[][] {
    let daysLeft: number = numberOfDays;
    const grid = [];
    while (daysLeft > 0) {
      const smallerNumber = Math.min(elementsPerRow, daysLeft);
      const row: number[] = [];
      for (let i = 1; i <= smallerNumber; i++) {
        row.push(numberOfDays - daysLeft + i);
      }
      grid.push(row);
      daysLeft -= smallerNumber;
    }
    return grid;
  }

  private handleButtonClick(): void {
    if (!this.pickerOpen) {
      this.openPicker();
    }
  }

  private handleButtonKeyDown(e: KeyboardEvent): void {
    if (e.key === 'Enter' && !this.pickerOpen) {
      this.openPicker();
    }
  }

  private openPicker(): void {
    this.pickerOpen = true;
    this.onElementReady(this.daysGridElement).then(() => {
      this.daysGridElement.focus();
    });
  }

  private onElementReady = (elem: HTMLElement) =>
    new Promise((resolve) => {
      const waitForElement = () => {
        if (elem.offsetParent) {
          resolve(elem);
        } else {
          window.requestAnimationFrame(waitForElement);
        }
      };
      waitForElement();
    });

  private closePicker(focusButton: boolean = false): void {
    this.navigatedDay = this.value;
    this.pickerOpen = false;
    if (focusButton) {
      this.buttonElement.focus();
    }
  }

  private selectDay(day: number): void {
    this.value = day;
    this.daySelected.emit(day);
    this.closePicker(true);
  }

  private ieArrowEvent(arrowKey: DayPickerNavigationInternetExplorerArrowKey): void {
    this.arrowEvent(this.normaliseIEArrowKey[arrowKey]);
  }

  private arrowEvent(key: DayPickerNavigationArrowKey): void {
    if (key === 'ArrowUp' && this.canNavigateUp) {
      this.navigatedDay -= this.elementsPerRow;
    } else if (key === 'ArrowDown' && this.canNavigateDown) {
      this.navigatedDay += this.elementsPerRow;
    } else if (key === 'ArrowLeft' && this.canNavigateLeft) {
      this.navigatedDay--;
    } else if (key === 'ArrowRight' && this.canNavigateRight) {
      this.navigatedDay++;
    }
    this.focusCell(this.navigatedDay);
  }

  private chordEvent(key: DayPickerNavigationChordKey): void {
    this.chordKeysDown[key] = true;
    switch (key) {
      case 'Home':
        this.navigatedDay = this.chordKeysDown['Control'] ? 1 : this.startOfRowIndex(this.navigatedDay);
        break;
      case 'End':
        this.navigatedDay = this.chordKeysDown['Control'] ? this.daysInMonth : this.endOfRowIndex(this.navigatedDay);
        break;
      default:
        return;
    }
    this.focusCell(this.navigatedDay);
  }

  private handleDayKeyDown(e: KeyboardEvent): void {
    switch (e.key as DayPickerKey) {
      case 'ArrowUp':
      case 'ArrowDown':
      case 'ArrowLeft':
      case 'ArrowRight':
        this.arrowEvent(e.key as DayPickerNavigationArrowKey);
        break;
      case 'Up':
      case 'Down':
      case 'Left':
      case 'Right':
        this.ieArrowEvent(e.key as DayPickerNavigationInternetExplorerArrowKey);
        break;
      case 'Enter':
      case 'Space':
        this.selectDay(this.navigatedDay);
        break;
      case 'Control':
      case 'Home':
      case 'End':
        this.chordEvent(e.key as DayPickerNavigationChordKey);
        break;
      case 'Escape':
      case 'Esc':
        this.closePicker(true);
        this.buttonElement.focus();
        break;
      default:
        return;
    }
    e.preventDefault();
  }

  private handleDayKeyUp(e: KeyboardEvent): void {
    switch (e.key as DayPickerNavigationChordKey) {
      case 'Control':
      case 'Home':
      case 'End':
        this.chordKeysDown[e.key] = false;
        break;
      default:
        return;
    }
    e.preventDefault();
  }

  private getColIndex(day: number): number {
    const index = day % this.elementsPerRow;
    return index !== 0 ? index : this.elementsPerRow;
  }

  private endOfRowIndex(day: number): number {
    const endOfRow: number = Math.ceil(day / this.elementsPerRow) * this.elementsPerRow;
    return Math.min(endOfRow, this.daysInMonth);
  }

  private startOfRowIndex(day: number): number {
    const index = this.getColIndex(day);
    return day - index + 1;
  }

  private focusCell(day: number): void {
    this.gridRefs[day - 1].focus();
  }

  // Close picker on next tick.
  // If a child element is focused it will clear this timeout before the picker is closed.
  // More details: https://reactjs.org/docs/accessibility.html#mouse-and-pointer-events
  private onBlurHandler(): void {
    this.timeOutId = setTimeout(() => {
      this.closePicker();
    });
  }

  private onChildElementFocusHandler(): void {
    clearTimeout(this.timeOutId);
  }

  componentWillLoad() {
    this.navigatedDay = this.value;
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.buttonElement);
    hideFocusRingWhenUsingMouse(this.daysGridElement);
  }

  render() {
    return (
      <Host>
        <div class="agl-day-of-month-picker__container">
          <agl-ds-text styledAs="xs" appearance="muted" id={this.uniqueLabelId} class="agl-day-of-month-picker__label">
            {this.label}
          </agl-ds-text>
          <button
            aria-haspopup="grid"
            aria-expanded={String(this.pickerOpen)}
            id={`${this.uniqueLabelId}-button`}
            aria-labelledby={`${this.uniqueLabelId} ${this.uniqueLabelId}-button`}
            aria-owns={`${this.uniqueLabelId}-picker`}
            class={{
              'agl-day-of-month-picker__button': true,
              'agl-day-of-month-picker__button--inverse': this.type === 'default-inverse'
            }}
            ref={(el) => (this.buttonElement = el)}
            onClick={() => this.handleButtonClick()}
            onKeyDown={(event) => {
              this.handleButtonKeyDown(event);
            }}
          >
            {this.value}
            <span class="agl-day-of-month-picker__icon" aria-hidden="true" innerHTML={iconCalendar} />
          </button>
          <div
            class={{
              'agl-day-of-month-picker__day-container': true,
              'agl-day-of-month-picker__day-container--open': this.pickerOpen
            }}
          >
            <table
              class="agl-day-of-month-picker__day-grid"
              role="grid"
              id={`${this.uniqueLabelId}-picker`}
              aria-label={`Day of month picker`}
              ref={(el) => (this.daysGridElement = el)}
              tabindex="-1"
              onKeyDown={(event) => {
                this.handleDayKeyDown(event);
              }}
              onKeyUp={(event) => {
                this.handleDayKeyUp(event);
              }}
              onBlur={() => {
                this.onBlurHandler();
              }}
            >
              <tbody role="rowgroup">
                {this.grid.map((row) => {
                  return (
                    <tr role="row">
                      {row.map((day) => {
                        return (
                          <td
                            role="gridcell"
                            ref={(el) => this.gridRefs.push(el)}
                            class="agl-day-of-month-picker__day-item"
                            tabindex="-1"
                            onClick={() => {
                              this.selectDay(day);
                            }}
                            onFocus={() => {
                              this.onChildElementFocusHandler();
                            }}
                            onBlur={() => {
                              this.onBlurHandler();
                            }}
                            // Don't focus on mouse down
                            onMouseDown={(e) => e.preventDefault()}
                          >
                            <agl-ds-p
                              bottomMargin="none"
                              appearance={this.value === day ? 'inverse' : 'default'}
                              styledAs="sm"
                              class={{
                                'agl-day-of-month-picker__day-item-content': true,
                                'agl-day-of-month-picker__day-item-content--selected': this.value === day,
                                'agl-day-of-month-picker__day-item-content--navigated': this.navigatedDay === day && this.value !== day
                              }}
                            >
                              {day}
                            </agl-ds-p>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <agl-ds-hint-validation-message asDescribedbyId={this.uniqueHintValidationId}>
            <div slot="hint-text">{this.hintText}</div>
          </agl-ds-hint-validation-message>
        </div>
      </Host>
    );
  }
}
