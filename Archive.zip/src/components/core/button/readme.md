# agl-ds-button



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute         | Description                                                                                                                                                                    | Type                                     | Default     |
| --------------- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------- | ----------- |
| `ariaAttribute` | --                | sets aria attributes on the component                                                                                                                                          | `AriaAttributes[]`                       | `[]`        |
| `href`          | `href`            | provide href property for the anchor element, if the href element is not present the button will be rendered as a button element else it will be rendered as an anchor element | `string`                                 | `undefined` |
| `icon`          | `icon`            | The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps) If both iconPath and icon are set, icon will be preferred over iconPath                              | `string`                                 | `undefined` |
| `iconPath`      | `icon-path`       | The path of an icon to be displayed along with text                                                                                                                            | `string`                                 | `undefined` |
| `iconPosition`  | `icon-position`   | Position of an Icon. A position of center is for use with an icon and no text                                                                                                  | `"center" \| "left" \| "right"`          | `'right'`   |
| `iconSize`      | `icon-size`       | Size of the Icon                                                                                                                                                               | `"lg" \| "md" \| "sm" \| "xs" \| "xxs"`  | `'xxs'`     |
| `inputType`     | `input-type`      | The type of button to render.  Either `submit` or `button`.  Do not use this property if you set a value to @href                                                              | `"button" \| "submit"`                   | `'button'`  |
| `loading`       | `loading`         | Determines if the loading svg is to be displayed                                                                                                                               | `boolean`                                | `false`     |
| `mode`          | `mode`            | provide if button is reverse mode or default                                                                                                                                   | `"default" \| "reverse"`                 | `'default'` |
| `openNewWindow` | `open-new-window` | specify if the target link to be opened in new window                                                                                                                          | `boolean`                                | `false`     |
| `size`          | `size`            | The size of the button                                                                                                                                                         | `"lg" \| "sm"`                           | `'lg'`      |
| `srContext`     | `sr-context`      | provide screen reader users with additional context or to convey information not available in HTML alone                                                                       | `string`                                 | `''`        |
| `type`          | `type`            | The type of button to be displayed                                                                                                                                             | `"primary" \| "secondary" \| "tertiary"` | `'primary'` |


## Methods

### `rotateButtonIcon() => Promise<void>`

Public method to rotate and icon if present.

#### Returns

Type: `Promise<void>`



### `setButtonState(setState: boolean, state?: string) => Promise<void>`

Public method to set the state of the button (ie for use with the agl-ds-menu). The default set state is active.

#### Returns

Type: `Promise<void>`



### `setFocus() => Promise<void>`

Sets focus to the button

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [agl-ds-guided-banner](../../composite/banner/guided-banner)
 - [agl-ds-manual-address-entry](../../composite/addresssearch/manual-address-entry)
 - [agl-ds-modal-footer](../modal/modal-footer)
 - [agl-ds-notification](../../composite/notification-card)

### Depends on

- [agl-ds-icon](../icon)
- [agl-ds-loading-indicator](../loading-indicator)

### Graph
```mermaid
graph TD;
  agl-ds-button --> agl-ds-icon
  agl-ds-button --> agl-ds-loading-indicator
  agl-ds-guided-banner --> agl-ds-button
  agl-ds-manual-address-entry --> agl-ds-button
  agl-ds-modal-footer --> agl-ds-button
  agl-ds-notification --> agl-ds-button
  style agl-ds-button fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
