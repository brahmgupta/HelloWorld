export type ButtonType = 'primary' | 'secondary' | 'tertiary';

export type ButtonMode = 'reverse' | 'default';

export type IconPosition = 'left' | 'right' | 'center';

export type ButtonSize = 'sm' | 'lg';

export type ButtonInputType = 'button' | 'submit';
