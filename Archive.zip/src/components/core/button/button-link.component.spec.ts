import { newSpecPage } from '@stencil/core/testing';
import { ButtonComponent } from './button.component';

describe('button component with link', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [ButtonComponent],
      html: `<agl-ds-button href="https://agl.com.au"></agl-ds-button>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-button href="https://agl.com.au">
				<mock:shadow-root>
					<a class="agl-ds-primary--default agl-ds-lg button" href="https://agl.com.au" rel="" target="_self">
					<slot></slot></a>
				</mock:shadow-root>
			</agl-ds-button>`
    );
  });

  describe('pass details to display the correct button type', () => {
    it('should present a "primary button" with correct text on button', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button  href="https://agl.com.au">primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-primary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "secondary button" with correct text on button', async () => {
      const text = 'secondary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="secondary"  href="https://agl.com.au">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-secondary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "tertiary button" with correct text on button', async () => {
      const text = 'tertiary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="tertiary"  href="https://agl.com.au">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-tertiary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "primary reverse button" with correct  text on button', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="primary" mode="reverse"  href="https://agl.com.au">primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-primary--reverse');
      expect(button).toBeTruthy();
    });

    it('should present a "secondary reverse button" with correct text on button', async () => {
      const text = 'secondary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="secondary" mode="reverse"  href="https://agl.com.au">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-secondary--reverse');
      expect(button).toBeTruthy();
    });

    it('should present a "tertiary reverse button" with correct text on button', async () => {
      const text = 'tertiary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="tertiary" mode="reverse"  href="https://agl.com.au">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('a.agl-ds-tertiary--reverse');
      expect(button).toBeTruthy();
    });

    it('should render the component to open in a new window', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button href="https://agl.com.au" open-new-window="true">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('a');
      const targetValue = element.attributes.getNamedItem('target').value;
      const relValue = element.attributes.getNamedItem('rel').value;

      expect(targetValue).toBe('_blank');
      expect(relValue).toBe('noopener noreferrer');
    });

    it('should render the component to open in the same window', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button href="https://agl.com.au" open-new-window="false">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('a');
      const targetValue = element.attributes.getNamedItem('target').value;
      const relValue = element.attributes.getNamedItem('rel').value;

      expect(targetValue).toBe('_self');
      expect(relValue).toBe('');
    });

    it('should render the component with passed in srContent to over-ride default', async () => {
      const dummyText = 'dummy sr content';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button href="https://agl.com.au" sr-context="' + dummyText + '">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const elements = await page.doc.querySelectorAll('span');
      expect(elements[0].childNodes[0].nodeValue).toEqual(' ' + dummyText);
    });

    it('should render the component with passed in srContent when opened in the same window', async () => {
      const dummyText = 'dummy sr content';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button href="https://agl.com.au" open-new-window="false" sr-context="' + dummyText + '">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const elements = await page.doc.querySelectorAll('span');
      expect(elements[0].childNodes[0].nodeValue).toEqual(' ' + dummyText);
    });
  });
});
