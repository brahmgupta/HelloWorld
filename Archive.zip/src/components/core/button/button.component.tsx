import { Component, h, Host, Prop, Element, ComponentInterface, Method, Watch } from '@stencil/core';
import { AriaAttributes } from '../../../global/component.types';
import { checkSlottedContentForInvalidHTML, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import { IconSize } from '../icon/icon.types';
import { ButtonType, ButtonMode, IconPosition, ButtonSize, ButtonInputType } from './button.types';

@Component({
  tag: 'agl-ds-button',
  styleUrl: './button.component.scss',
  shadow: true
})
export class ButtonComponent implements ComponentInterface {
  @Element() host: HTMLAglDsButtonElement;

  /**
   * The size of the button
   */
  @Prop() size: ButtonSize = 'lg';
  /**
   * The type of button to render.  Either `submit` or `button`.  Do not use this property if you set a value to @href
   */
  @Prop() inputType: ButtonInputType = 'button';

  /**
   * The type of button to be displayed
   */
  @Prop() type: ButtonType = 'primary';

  /**
   * Determines if the loading svg is to be displayed
   */
  @Prop() loading: boolean = false;

  /**
   * provide screen reader users with additional context or to convey information not available in HTML alone
   */
  @Prop({ mutable: true }) srContext: string = '';

  /**
   * sets aria attributes on the component
   */
  @Prop() ariaAttribute: AriaAttributes[] = [];

  /**
   * provide if button is reverse mode or default
   */
  @Prop() mode: ButtonMode = 'default';

  /**
   * provide href property for the anchor element, if the href element is not present the button will be rendered as a button
   * element else it will be rendered as an anchor element
   */
  @Prop() href: string;

  /**
   * specify if the target link to be opened in new window
   */
  @Prop() openNewWindow: boolean = false;

  /**
   * The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps)
   * If both iconPath and icon are set, icon will be preferred over iconPath
   */

  @Prop() icon: string;
  /**
   * The path of an icon to be displayed along with text
   */
  @Prop() iconPath: string;

  /**
   * Position of an Icon. A position of center is for use with an icon and no text
   */
  @Prop() iconPosition: IconPosition = 'right';

  /**
   * Size of the Icon
   */
  @Prop() iconSize: IconSize = 'xxs';

  @Watch('ariaAttribute')
  setAriaAttribute() {
    if (this.inputElement && this.ariaAttribute) {
      this.ariaAttribute.map((item) => {
        this.inputElement.setAttribute(item.attribute, item.value);
      });
    }
  }

  @Watch('srContext')
  setSrContext(newValue: string) {
    if (newValue) {
      this.srContext = newValue;
    }
  }

  /**
   * Sets focus to the button
   */
  @Method()
  async setFocus() {
    this.inputElement.focus();
  }

  /**
   * Public method to set the state of the button (ie for use with the agl-ds-menu). The default set state is active.
   */
  @Method()
  async setButtonState(setState: boolean, state: string = 'active') {
    if (setState) {
      this.inputElement.classList.add('agl-ds-' + this.type + '--' + this.mode + '-' + state);
    } else {
      this.inputElement.classList.remove('agl-ds-' + this.type + '--' + this.mode + '-' + state);
    }
  }

  /**
   * Public method to rotate and icon if present.
   */
  @Method()
  async rotateButtonIcon() {
    if (this.hasIcon()) {
      if (this.iconElement.classList.contains('rotate-icon-apply')) {
        this.iconElement.classList.add('rotate-icon-remove');
        this.iconElement.classList.remove('rotate-icon-apply');
      } else {
        this.iconElement.classList.add('rotate-icon-apply');
        this.iconElement.classList.remove('rotate-icon-remove');
      }
    }
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-button']);
    this.setSrContext(this.srContext);
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);

    //As the default value is ButtonInputType.button just check if they have manually set it to the submit type
    //and warn if they have also set the href
    if (this.inputType === 'submit' && !!this.href) {
      console.warn(
        'Using `inputType = submit` with href will result in the `inputType` being ignored. It will render an anchor tag as a button.'
      );
    }

    this.setAriaAttribute();
  }
  private inputElement: HTMLAnchorElement | HTMLButtonElement;
  private iconElement: HTMLAglDsIconElement;

  /**
   * Render Icon
   */
  private renderIcon() {
    return (
      <agl-ds-icon
        ref={(el) => (this.iconElement = el)}
        class={{ 'button-icon': true, ['button-icon--' + this.iconPosition]: true }}
        icon={this.icon}
        iconPath={this.iconPath}
        size={this.iconSize}
      ></agl-ds-icon>
    );
  }

  /**
   * Get loading Indicator Type
   */
  private getLoadingIndicator() {
    const loadIndicatorType =
      (this.mode === 'default' && this.type === 'primary') || (this.mode === 'reverse' && this.type !== 'primary') ? 'inverse' : 'default';
    return <agl-ds-loading-indicator size="sm" type={loadIndicatorType} />;
  }

  private hasIcon(): boolean {
    return !!(this.iconPath || this.icon);
  }

  render() {
    return (
      <Host>
        {this.href && (
          <a
            class={{
              button: true,
              ['agl-ds-' + this.size]: true,
              ['icon-left']: this.iconPosition === 'left',
              ['icon-center--' + this.size]: this.iconPosition === 'center',
              ['agl-ds-' + this.type + '--' + this.mode]: true,
              'remove-underline': this.hasIcon()
            }}
            href={this.href}
            rel={this.openNewWindow ? 'noopener noreferrer' : ''}
            target={this.openNewWindow ? '_blank' : '_self'}
            ref={(el) => (this.inputElement = el)}
          >
            {!this.loading && <slot />}
            {!this.loading && this.hasIcon() && this.renderIcon()}
            {this.loading && this.getLoadingIndicator()}
            {this.srContext ? <span class="sr-only"> {this.srContext}</span> : ''}
            {this.openNewWindow ? <span class="sr-only">, opens in new window</span> : ''}
          </a>
        )}

        {!this.href && (
          <button
            class={{
              button: true,
              ['agl-ds-' + this.size]: true,
              ['icon-left']: this.iconPosition === 'left',
              ['icon-center--' + this.size]: this.iconPosition === 'center',
              ['agl-ds-' + this.type + '--' + this.mode]: true,
              'remove-underline': this.hasIcon()
            }}
            type={this.inputType}
            ref={(el) => (this.inputElement = el)}
          >
            {!this.loading && <slot />}
            {!this.loading && this.hasIcon() && this.renderIcon()}
            {this.loading && this.getLoadingIndicator()}
            {this.srContext ? <span class="sr-only"> {this.srContext}</span> : ''}
          </button>
        )}
      </Host>
    );
  }
}
