import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

const inputTypeKnob = () => select('Input Type', ['button', 'submit'], 'button');
const loadingKnob = () => select('loading', ['true', 'false'], 'false');
const positionKnob = () => select('Icon position', ['left', 'right'], 'right');
const iconPathKnob = () => text('Icon path', '../../../assets/agl_icon_cross.svg');
const iconSizeKnob = () => select('Icon size', ['xxs', 'xs'], 'xxs');
const iconPrimaryKnob = () =>
  text(
    'Icon using primary colour',

    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
      <path d="M8.707,10.957l4.5-4.5a1,1,0,1,0-1.414-1.414L8,8.8359,4.207,5.043A1,1,0,1,0,2.793,6.457l4.5,4.5A.9994.9994,0,0,0,8.707,10.957Z" fill="#001cb0" class="primary-fill"/>
      <rect width="16" height="16" transform="translate(16) rotate(90)" fill="none"/>
    </svg>`
  );

const iconNeutralKnob = () =>
  text(
    'Icon using neutral colour',
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
      <path d="M8.707,10.957l4.5-4.5a1,1,0,1,0-1.414-1.414L8,8.8359,4.207,5.043A1,1,0,1,0,2.793,6.457l4.5,4.5A.9994.9994,0,0,0,8.707,10.957Z" class="neutral-08-fill" fill="#ffffff"/>
      <rect width="16" height="16" transform="translate(16) rotate(90)" fill="none"/>
    </svg>`
  );
const buttonLabelKnob = () => text('Button label', 'Button label');
const srContextKnob = () => text('SR context', 'Screen reader only context');
const openNewWindowKnob = () => select('Open new Window', ['true', 'false'], 'false');
const sizeKnob = () => select('Size', ['lg', 'sm'], 'lg');

const buttonTypes = ['primary', 'secondary', 'tertiary'];

const crossIcon1 = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
<path d="M13.414 12l3.793-3.793a1 1 0 10-1.414-1.414L12 10.586 8.207 6.793a1 1 0 10-1.414 1.414L10.586 12l-3.793 3.793a1 1 0 101.414 1.414L12 13.414l3.793 3.793a1 1 0 001.414-1.414z" fill="#ffffff" >
</path>
<path fill="none" d="M0 0h24v24H0z">
</path>
</svg>`;

const centerIcon2 = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
<path d="M13.414 12l3.793-3.793a1 1 0 10-1.414-1.414L12 10.586 8.207 6.793a1 1 0 10-1.414 1.414L10.586 12l-3.793 3.793a1 1 0 101.414 1.414L12 13.414l3.793 3.793a1 1 0 001.414-1.414z"  class="primary-fill" >
</path>
<path fill="none" d="M0 0h24v24H0z">
</path>
</svg>`;

export default {
  title: 'Core/Button'
};

export const Button = () => html`
  <div class="button-container">
    <div class="button-row">
      <agl-ds-h3>Default buttons</agl-ds-h3>
    </div>
    <div class="button-row">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'bd0'}"
              type="${buttonType}"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              onclick="alert('Ive been clicked')"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarybd0').setButtonState(this.checked); document.getElementById('secondarybd0').setButtonState(this.checked); document.getElementById('tertiarybd0').setButtonState(this.checked);"
        />
        Set active state
      </label>
    </div>

    <div class="button-row button-heading">
      <agl-ds-h3>Reverse buttons</agl-ds-h3>
    </div>
    <div class="button-row button-reverse">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'br0'}"
              type="${buttonType}"
              mode="reverse"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              onclick="alert('Ive been clicked')"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarybr0').setButtonState(this.checked); document.getElementById('secondarybr0').setButtonState(this.checked); document.getElementById('tertiarybr0').setButtonState(this.checked);"
        />
        Set active state
      </label>
    </div>
  </div>
`;

Button.parameters = {
  notes
};

export const ButtonWithIcon = () => html`
  <div class="button-container">
    <div class="button-row">
      <agl-ds-h3>Default buttons</agl-ds-h3>
    </div>
    <div class="button-row">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'bd1'}"
              type="${buttonType}"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              icon="${buttonType !== 'primary' ? iconPrimaryKnob() : iconNeutralKnob()}"
              icon-path="${iconPathKnob()}"
              icon-size="${iconSizeKnob()}"
              icon-position="${positionKnob()}"
              onclick="alert('Ive been clicked')"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarybd1').rotateButtonIcon();document.getElementById('secondarybd1').rotateButtonIcon();document.getElementById('tertiarybd1').rotateButtonIcon()"
        />
        Rotate icons - this used in cases like when a button is used as the trigger for the menu.
      </label>
    </div>

    <div class="button-row  button-heading">
      <agl-ds-h3>Icon button</agl-ds-h3>
    </div>
    <div class="button-row">
      <agl-ds-button size="lg" icon-size="sm" icon="${crossIcon1}" icon-position="center" sr-context="close"></agl-ds-button
      >&nbsp;&nbsp;&nbsp;
      <agl-ds-button
        size="sm"
        type="tertiary"
        icon-size="sm"
        icon="${centerIcon2}"
        icon-position="center"
        sr-context="close"
      ></agl-ds-button>
    </div>
    <div class="button-row">
      An example of a primary and tertiary button with icon-position = center to illustrate how to make a icon button
    </div>

    <div class="button-row button-heading">
      <agl-ds-h3>Reverse buttons</agl-ds-h3>
    </div>
    <div class="button-row button-reverse">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'br1'}"
              type="${buttonType}"
              mode="reverse"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              icon="${buttonType === 'primary' ? iconPrimaryKnob() : iconNeutralKnob()}"
              icon-path="${iconPathKnob()}"
              icon-size="${iconSizeKnob()}"
              icon-position="${positionKnob()}"
              onclick="alert('Ive been clicked')"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarybr1').rotateButtonIcon();document.getElementById('secondarybr1').rotateButtonIcon();document.getElementById('tertiarybr1').rotateButtonIcon()"
        />
        Rotate icons - this used in cases like when a button is used as the trigger for the menu.
      </label>
    </div>
  </div>
`;

ButtonWithIcon.storyName = 'Button with Icon';
ButtonWithIcon.parameters = { notes };

export const ButtonLink = () => html`
  <div class="button-container">
    <div class="button-row">
      <agl-ds-h3>Default button links</agl-ds-h3>
    </div>
    <div class="button-row">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'ld1'}"
              type="${buttonType}"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              href="https://www.agl.com.au"
              open-new-window="${openNewWindowKnob()}"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primaryld1').setButtonState(this.checked); document.getElementById('secondaryld1').setButtonState(this.checked); document.getElementById('tertiaryld1').setButtonState(this.checked);"
        />
        Set active state
      </label>
    </div>

    <div class="button-row button-heading">
      <agl-ds-h3>Reverse button links</agl-ds-h3>
    </div>
    <div class="button-row button-reverse">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'lr1'}"
              type="${buttonType}"
              mode="reverse"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              href="https://www.agl.com.au"
              open-new-window="${openNewWindowKnob()}"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarylr1').rotateButtonIcon();document.getElementById('secondarylr1').rotateButtonIcon();document.getElementById('tertiarylr1').rotateButtonIcon()"
        />
        Set active state
      </label>
    </div>
  </div>
`;

ButtonLink.storyName = 'Button Link';
ButtonLink.parameters = {
  notes
};

export const ButtonLinkWithIcon = () => html`
  <div class="button-container">
    <div class="button-row">
      <agl-ds-h3>Default button links</agl-ds-h3>
    </div>
    <div class="button-row">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'ld1'}"
              type="${buttonType}"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              href="https://www.agl.com.au"
              open-new-window="${openNewWindowKnob()}"
              icon="${buttonType !== 'primary' ? iconPrimaryKnob() : iconNeutralKnob()}"
              icon-path="${iconPathKnob()}"
              icon-position="${positionKnob()}"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primaryld1').rotateButtonIcon();document.getElementById('secondaryld1').rotateButtonIcon();document.getElementById('tertiaryld1').rotateButtonIcon()"
        />
        Rotate icons - this used in cases like when a button is used as the trigger for the menu.
      </label>
    </div>

    <div class="button-row  button-heading">
      <agl-ds-h3>Icon link button</agl-ds-h3>
    </div>
    <div class="button-row">
      <agl-ds-button
        size="lg"
        href="https://www.agl.com.au"
        icon-size="sm"
        icon="${crossIcon1}"
        icon-position="center"
        sr-context="close"
      ></agl-ds-button
      >&nbsp;&nbsp;&nbsp;
      <agl-ds-button
        size="sm"
        type="tertiary"
        href="https://www.agl.com.au"
        icon-size="sm"
        icon="${centerIcon2}"
        icon-position="center"
        sr-context="close"
      ></agl-ds-button>
    </div>
    <div class="button-row">
      An example of a primary and tertiary button with icon-position = center to illustrate how to make a icon button
    </div>

    <div class="button-row button-heading">
      <agl-ds-h3>Reverse button links</agl-ds-h3>
    </div>
    <div class="button-row button-reverse">
      ${buttonTypes.map(
        (buttonType) => html`
          <div>
            <agl-ds-button
              id="${buttonType + 'lr1'}"
              type="${buttonType}"
              mode="reverse"
              size="${sizeKnob()}"
              input-type="${inputTypeKnob()}"
              loading="${loadingKnob()}"
              sr-context="${srContextKnob()}"
              href="https://www.agl.com.au"
              open-new-window="${openNewWindowKnob()}"
              icon="${buttonType === 'primary' ? iconPrimaryKnob() : iconNeutralKnob()}"
              icon-path="${iconPathKnob()}"
              icon-position="${positionKnob()}"
            >
              ${buttonType} label
            </agl-ds-button>
          </div>
        `
      )}
    </div>
    <div class="button-row">
      <label>
        <input
          type="checkbox"
          onClick="document.getElementById('primarylr1').rotateButtonIcon();document.getElementById('secondarylr1').rotateButtonIcon();document.getElementById('tertiarylr1').rotateButtonIcon()"
        />
        Rotate icons - this used in cases like when a button is used as the trigger for the menu.
      </label>
    </div>
  </div>
`;

ButtonLinkWithIcon.storyName = 'Button Link with Icon';
ButtonLinkWithIcon.parameters = { notes };

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('.button-container { width: 100%;  padding-right:32px   margin-right: auto; margin-left: auto;}');
style.sheet.insertRule(
  '.button-row {   box-sizing: border-box;  display: flex;  flex: 0 1 auto;  -webkit-box-orient: horizontal;  -webkit-box-direction: normal;  flex-direction: row;  flex-wrap: wrap; padding-right:48px } '
);
style.sheet.insertRule('.button-heading { padding-top: 32px;} ');
style.sheet.insertRule('.button-reverse { background-color: var(--c-primary-01, #001cb0); }');
style.sheet.insertRule(
  '@media only screen and (max-width: 991px) {.button-row > div {  flex: 0 0 auto; flex-basis: 100%;  max-width: 100%; padding: 16px 32px; text-align: center;} }'
);
style.sheet.insertRule(
  '@media only screen and (min-width: 992px) {.button-row > div {  flex: 0 0 auto; flex-basis: 25%;  padding: 16px 32px; text-align: center;} }'
);
