import { newSpecPage } from '@stencil/core/testing';
import { ButtonComponent } from './button.component';

describe('button component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [ButtonComponent],
      html: `<agl-ds-button></agl-ds-button>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-button>
				<mock:shadow-root>
					<button type="button" class="agl-ds-primary--default agl-ds-lg  button">
					<slot></slot>
				</mock:shadow-root>
			</agl-ds-button>`
    );
  });

  it('should render my component as a submit button', async () => {
    const page = await newSpecPage({
      components: [ButtonComponent],
      html: `<agl-ds-button input-type="submit"></agl-ds-button>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-button input-type="submit">
				<mock:shadow-root>
					<button type="submit" class="agl-ds-primary--default agl-ds-lg button">
					<slot></slot>
				</mock:shadow-root>
			</agl-ds-button>`
    );
  });

  describe('pass details to display the correct button type', () => {
    it('should present a "primary button" with correct text on button', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button>primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-primary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "secondary button" with correct text on button', async () => {
      const text = 'secondary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="secondary">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-secondary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "tertiary button" with correct text on button', async () => {
      const text = 'tertiary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="tertiary" >' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-tertiary--default');
      expect(button).toBeTruthy();
    });

    it('should present a "primary reverse button" with correct  text on button', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="primary" mode="reverse">primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-primary--reverse');
      expect(button).toBeTruthy();
    });

    it('should present a "secondary reverse button" with correct text on button', async () => {
      const text = 'secondary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="secondary" mode="reverse">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-secondary--reverse');
      expect(button).toBeTruthy();
    });

    it('should present a "tertiary reverse button" with correct text on button', async () => {
      const text = 'tertiary button';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button type="tertiary" mode="reverse">' + text + '</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('button.agl-ds-tertiary--reverse');
      expect(button).toBeTruthy();
    });

    it('should show the loader', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button loading="true">primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('agl-ds-loading-indicator');
      expect(button).toBeTruthy();
    });

    it('should not show the loader', async () => {
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button loading="false">primary button</agl-ds-button>',
        supportsShadowDom: false
      });
      const button = page.doc.querySelector('.loader');
      expect(button).toBeFalsy();
    });

    it('should render the component with passed in srContent to over-ride default', async () => {
      const dummyText = 'dummy sr content';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button sr-context="' + dummyText + '">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('span');
      expect(element.childNodes[0].nodeValue).toEqual(' ' + dummyText);
    });

    it('should render the component with passed in srContent when opened in the same window', async () => {
      const dummyText = 'dummy sr content';
      const page = await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button open-new-window="false" sr-context="' + dummyText + '">dummy text</agl-ds-button>',
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('span');
      expect(element.childNodes[0].nodeValue).toEqual(' ' + dummyText);
    });

    ['primary', 'secondary', 'tertiary'].map((type: string) => {
      it(`should not show Icon when loading for button type ${type}`, async () => {
        const page = await newSpecPage({
          components: [ButtonComponent],
          html: `<agl-ds-button loading="true" type="${type}" icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">primary button</agl-ds-button>`,
          supportsShadowDom: false
        });

        const element = page.doc.querySelector('agl-ds-icon');
        expect(element).toBeNull();
      });
    });

    ['primary', 'secondary', 'tertiary'].map((type: string) => {
      it(`should not show Icon when there is no "icon-path" for button type ${type}`, async () => {
        const page = await newSpecPage({
          components: [ButtonComponent],
          html: `<agl-ds-button type="${type}">primary button</agl-ds-button>`,
          supportsShadowDom: false
        });

        const element = page.doc.querySelector('agl-ds-icon');
        expect(element).toBeNull();
      });
    });

    ['primary', 'secondary', 'tertiary'].map((type: string) => {
      it(`should show Icon when there is "icon-path" for button type ${type}`, async () => {
        const page = await newSpecPage({
          components: [ButtonComponent],
          html: `<agl-ds-button type="${type}" icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">primary button</agl-ds-button>`,
          supportsShadowDom: false
        });

        const element = page.doc.querySelector('agl-ds-icon');
        expect(element).toBeTruthy();
        expect(element.getAttribute('size')).toEqual('xxs');
      });
    });

    ['primary', 'secondary', 'tertiary'].map((type: string) => {
      it(`should display Icon on left of text for button type ${type}`, async () => {
        const page = await newSpecPage({
          components: [ButtonComponent],
          html: `<agl-ds-button type="${type}" icon-position="left" icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">primary button</agl-ds-button>`,
          supportsShadowDom: false
        });

        const buttonClass = page.doc.querySelector('button').classList.contains('icon-left');
        const icon = page.doc.querySelector('agl-ds-icon');

        expect(buttonClass).toBeTruthy();
        expect(icon).toBeTruthy();
      });
    });

    ['primary', 'secondary', 'tertiary'].map((type: string) => {
      it(`should display Icon on right of text for button type ${type}`, async () => {
        const page = await newSpecPage({
          components: [ButtonComponent],
          html: `<agl-ds-button type="${type}" icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A">primary button</agl-ds-button>`,
          supportsShadowDom: false
        });

        const buttonClass = page.doc.querySelector('button').classList.contains('.icon-left');
        const icon = page.doc.querySelector('agl-ds-icon');

        expect(buttonClass).toBeFalsy();
        expect(icon).toBeTruthy();
      });
    });

    it('should not console.error when valid html tags are passed in via the slot', async () => {
      console.error = () => {
        /**/
      };

      const consoleSpy = jest.spyOn(console, 'error');
      await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button>dummy text</agl-ds-button>',
        supportsShadowDom: true
      });
      expect(consoleSpy).not.toHaveBeenCalled();
    });

    it('should console.error when an invalid html tag is passed in via the slot', async () => {
      console.error = () => {
        /**/
      };
      const consoleSpy = jest.spyOn(console, 'error');
      await newSpecPage({
        components: [ButtonComponent],
        html: '<agl-ds-button><p>dummy text</p></agl-ds-button>',
        supportsShadowDom: true
      });
      expect(consoleSpy).toHaveBeenCalledWith(
        'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
      );
    });
  });
});
