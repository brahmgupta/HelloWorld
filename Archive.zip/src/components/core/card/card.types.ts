export type CardAppearance = 'border' | 'border-bottom' | 'flat' | 'elevated' | 'filled';

export type CardCorner = 'square' | 'rounded';
