import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { CardComponent } from './card.component';
import { CardAppearance } from './card.types';

describe('card component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [CardComponent],
      html: `<agl-ds-card></agl-ds-card>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-card class="card__corner--square card__appearance--elevated">
          <mock:shadow-root>
              <slot></slot>
          </mock:shadow-root>
        </agl-ds-card>
      `
    );
  });

  [['appearance']].map(([targetAttr]) => {
    describe(`pass details to display the correct ${targetAttr} class`, () => {
      let page: SpecPage;

      (['border', 'border-bottom', 'elevated', 'filled', 'flat'] as CardAppearance[]).map((direction) => {
        it(`should present a card with "${direction}" ${targetAttr}`, async () => {
          page = await newSpecPage({
            components: [CardComponent],
            html: `<agl-ds-card ${targetAttr}="${direction}">content</agl-ds-card>`,
            supportsShadowDom: false
          });
          const badge = page.doc.querySelector(`agl-ds-card.card__${targetAttr}--${direction}`);
          expect(badge).toBeTruthy();
        });
      });
    });
  });
});
