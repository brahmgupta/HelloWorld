import { Component, Host, h, Prop, Watch, ComponentInterface } from '@stencil/core';
import { CardAppearance, CardCorner } from './card.types';

@Component({
  tag: 'agl-ds-card',
  styleUrl: 'card.component.scss',
  shadow: true
})
export class CardComponent implements ComponentInterface {
  /**
   * Set the appearance of the card component
   * Options are `"border"`, `"border-bottom"`, `"flat"`, or `"elevated"`
   * Default sets to `"elevated"`
   */
  @Prop() appearance?: CardAppearance = 'elevated';

  /**
   * Set the border radius of the card component
   * Options are `"square"`, `"rounded"`
   */
  @Prop() corner?: CardCorner = 'square';

  /**
   * Set if the card component is hoverable
   * Options are `true`, and `false`
   * Default sets to `false`
   */
  @Prop() hoverable?: boolean = false;

  @Watch('appearance')
  valueWatchHandler(newValue: CardAppearance) {
    this.cardAppearance = newValue;
  }

  componentWillLoad() {
    this.valueWatchHandler(this.appearance);
  }
  private cardAppearance: CardAppearance;

  render() {
    const { corner, hoverable } = this;

    return (
      <Host
        class={{
          [`card--hoverable`]: hoverable,
          [`card__appearance--${this.cardAppearance}`]: true,
          [`card__corner--${corner}`]: true
        }}
      >
        <slot></slot>
      </Host>
    );
  }
}
