import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

const CardAppearance = {
  Border: 'border',
  BorderBottom: 'border-bottom',
  Flat: 'flat',
  Elevated: 'elevated',
  Filled: 'filled'
};

const CardCorner = {
  square: 'square',
  rounded: 'rounded'
};

export default {
  title: 'Core/Card'
};

export const Card = () => {
  const optionAppearance = select('Appearance', Object.values(CardAppearance), CardAppearance.Elevated);
  const optionCardCorner = select('Corner', Object.values(CardCorner), CardCorner.square);
  const optionHoverable = select('Hoverable', [true, false], false);

  const cardBase = (content) => html`
    <div style="margin: 10px">
      <agl-ds-card appearance="${optionAppearance}" corner="${optionCardCorner}" hoverable="${optionHoverable}">${content}</agl-ds-card>
    </div>
  `;

  return html`
    <style>
      .sb-show-main {
        background: rgb(255, 255, 255);
        background: linear-gradient(90deg, rgba(245, 245, 245, 1) 30%, rgba(255, 255, 255, 1) 80%);
        font-family: 'Open Sans', sans-serif;
      }

      .pad-20 {
        padding: 20px;
      }
    </style>

    ${cardBase(html`<span class="pad-20"></span>`)}
  `;
};

Card.parameters = {
  notes
};
