# agl-ds-card



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute    | Description                                                                                                                                | Type                                                              | Default      |
| ------------ | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------- | ------------ |
| `appearance` | `appearance` | Set the appearance of the card component Options are `"border"`, `"border-bottom"`, `"flat"`, or `"elevated"` Default sets to `"elevated"` | `"border" \| "border-bottom" \| "elevated" \| "filled" \| "flat"` | `'elevated'` |
| `corner`     | `corner`     | Set the border radius of the card component Options are `"square"`, `"rounded"`                                                            | `"rounded" \| "square"`                                           | `'square'`   |
| `hoverable`  | `hoverable`  | Set if the card component is hoverable Options are `true`, and `false` Default sets to `false`                                             | `boolean`                                                         | `false`      |


## Dependencies

### Used by

 - [agl-ds-banner-callout](../../composite/banner/banner-callout)
 - [agl-ds-feature-card](../../composite/icon-text-card/feature-card)
 - [agl-ds-feature-item](../../composite/icon-text-card/feature-item)
 - [agl-ds-fulfilment-container](../../layout/fulfilment-container)
 - [agl-ds-menu-dropdown](../../composite/menu-dropdown/menu-dropdown)
 - [agl-ds-prefooter](../../composite/icon-text-card/prefooter)
 - [agl-ds-promo-card](../../composite/icon-text-card/promo-card)
 - [agl-ds-segmented-card](../../composite/segmented-card)
 - [agl-ds-spotlight](../../composite/image-text-card/spotlight)
 - [agl-ds-triptych](../../composite/image-text-card/triptych)

### Graph
```mermaid
graph TD;
  agl-ds-banner-callout --> agl-ds-card
  agl-ds-feature-card --> agl-ds-card
  agl-ds-feature-item --> agl-ds-card
  agl-ds-fulfilment-container --> agl-ds-card
  agl-ds-menu-dropdown --> agl-ds-card
  agl-ds-prefooter --> agl-ds-card
  agl-ds-promo-card --> agl-ds-card
  agl-ds-segmented-card --> agl-ds-card
  agl-ds-spotlight --> agl-ds-card
  agl-ds-triptych --> agl-ds-card
  style agl-ds-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
