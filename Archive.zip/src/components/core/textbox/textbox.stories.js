import { select, text, number, boolean } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Textbox'
};

export const Default = () => html`
  <agl-ds-h1 styled-as="title3">Textbox</agl-ds-h1>
  <agl-ds-textbox
    id="myId1"
    text-box-id="txt-check1"
    label="${text('label', 'label for input')}"
    type="${select('type', ['default', 'default-inverse'], 'default')}"
    value="${text('value', '')}"
    max-length="${number('max length', 100)}"
    input-type="${select('input type', ['text', 'tel', 'url', 'email', 'number', 'search'], 'text')}"
    validation-text="${text('validation text', 'validation text')}"
    is-input-valid="${boolean('is valid?', false)}"
    valid-text="${text('valid text', '')}"
    hint-text="${text('hint text', 'hint text')}"
  >
  </agl-ds-textbox>
  <label><input type="checkbox" onClick="document.getElementById('myId1').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br />
  <br />
  <agl-ds-h1 styled-as="title3">Textbox (slotted hint text with a link)</agl-ds-h1>
  <agl-ds-textbox id="myId12" label="${text('label', 'label for input')}" validation-text="validation text">
    <div slot="hint-text">I am a hint text message with a link <agl-ds-link>click here</agl-ds-link></div>
  </agl-ds-textbox>
  <label><input type="checkbox" onClick="document.getElementById('myId12').setAttribute('has-error',this.checked)" />Toggle Error</label>
`;

Default.storyName = 'default';
Default.parameters = {
  notes
};

export const Experiential = () => html`
  <agl-ds-textbox
    id="myId2"
    text-box-id="txt-check"
    label="Label for text"
    type="experiential"
    validation-text="${text('validation text', 'validation text')}"
    hint-text="${text('hint text', 'hint text')}"
    placeholder="${text('placeholder', 'Placeholder text')}"
    value="${text('value', '')}"
    is-input-valid="${boolean('is valid?', false)}"
    valid-text="${text('valid text', '')}"
    max-length="${number('max length', 100)}"
    input-type="${select('input type', ['text', 'tel', 'url', 'email', 'number', 'search'])}"
  ></agl-ds-textbox>
  <label><input type="checkbox" onClick="document.getElementById('myId2').setAttribute('has-error',this.checked)" />Toggle Error</label>
`;

Experiential.storyName = 'experiential';
Experiential.parameters = { notes };
