# agl-ds-textbox



<!-- Auto Generated Below -->


## Properties

| Property              | Attribute              | Description                                                                                                                                                                                                                                                                                                                                    | Type                                                          | Default                  |
| --------------------- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- | ------------------------ |
| `browserAutocomplete` | `browser-autocomplete` | The browsers autocomplete property of the input                                                                                                                                                                                                                                                                                                | `boolean`                                                     | `true`                   |
| `hasError`            | `has-error`            | Flag to show error state                                                                                                                                                                                                                                                                                                                       | `boolean`                                                     | `false`                  |
| `hintText`            | `hint-text`            | Hint text will be shown underneath the textbox but will be hidden if there is an error. There is also a slot which can be used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading. There is also a prop to pass text. | `string`                                                      | `undefined`              |
| `inputType`           | `input-type`           | The type property of the input e.g. text, email, number                                                                                                                                                                                                                                                                                        | `"email" \| "number" \| "search" \| "tel" \| "text" \| "url"` | `'text'`                 |
| `isInputValid`        | `is-input-valid`       | Flag to show valid state                                                                                                                                                                                                                                                                                                                       | `boolean`                                                     | `false`                  |
| `label`               | `label`                | The label text for the input, will be hidden if type is experiential TODO This needs to be mandatory in order to be accessible                                                                                                                                                                                                                 | `string`                                                      | `''`                     |
| `maxLength`           | `max-length`           | The maxlength property of the input                                                                                                                                                                                                                                                                                                            | `number`                                                      | `undefined`              |
| `placeholder`         | `placeholder`          | The placeholder property for the input, only used if type is experiential                                                                                                                                                                                                                                                                      | `string`                                                      | `undefined`              |
| `suffixIcon`          | `suffix-icon`          | An custom icon inside of the textbox e.g. calendar                                                                                                                                                                                                                                                                                             | `string`                                                      | `undefined`              |
| `textBoxId`           | `text-box-id`          | The input ID                                                                                                                                                                                                                                                                                                                                   | `string`                                                      | `generateRandomNumber()` |
| `type`                | `type`                 | Type for the control, either default, default-inverse or experiential                                                                                                                                                                                                                                                                          | `"default" \| "default-inverse" \| "experiential"`            | `'default'`              |
| `validText`           | `valid-text`           | Text to show when valid                                                                                                                                                                                                                                                                                                                        | `string`                                                      | `''`                     |
| `validationText`      | `validation-text`      | Validation text to show when the has error flag is true                                                                                                                                                                                                                                                                                        | `string`                                                      | `undefined`              |
| `value`               | `value`                | The value for the input                                                                                                                                                                                                                                                                                                                        | `string`                                                      | `undefined`              |


## Events

| Event             | Description                                        | Type                         |
| ----------------- | -------------------------------------------------- | ---------------------------- |
| `suffixIconClick` | Click event fired when clicking on the suffix icon | `CustomEvent<void>`          |
| `textboxBlur`     | Forwards the blur event of the input               | `CustomEvent<FocusEvent>`    |
| `textboxFocus`    | Forwards the focus event of the input              | `CustomEvent<FocusEvent>`    |
| `textboxInput`    | Forwards the input event of the input              | `CustomEvent<InputEvent>`    |
| `textboxKeydown`  | Forwards the keydown event of the input            | `CustomEvent<KeyboardEvent>` |
| `valueChange`     | Text box value changed event                       | `CustomEvent<any>`           |


## Methods

### `blurInput() => Promise<void>`

Public method to trigger blur event for the input

#### Returns

Type: `Promise<void>`



### `clearInput() => Promise<void>`

Public method to clear the input

#### Returns

Type: `Promise<void>`



### `focusInput() => Promise<void>`

Public method to focus on the input

#### Returns

Type: `Promise<void>`



### `getInputElement() => Promise<HTMLInputElement>`

Public method to retrieve the input dom element

#### Returns

Type: `Promise<HTMLInputElement>`



### `selectInput() => Promise<void>`

Public method to select the input

#### Returns

Type: `Promise<void>`



### `setFocus() => Promise<void>`

Sets focus to the textbox

#### Returns

Type: `Promise<void>`



### `setInput(textValue: string) => Promise<void>`

Public method to clear the input

#### Returns

Type: `Promise<void>`




## Slots

| Slot          | Description                                                                                                                                                                                     |
| ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"hint-text"` | Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading. There is also a prop to pass text. |


## Dependencies

### Used by

 - [agl-ds-autocomplete](../../composite/autocomplete)
 - [agl-ds-internal-flatpickr](../datepicker)
 - [agl-ds-manual-address-entry](../../composite/addresssearch/manual-address-entry)

### Depends on

- [agl-ds-hint-validation-message](../hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-textbox --> agl-ds-hint-validation-message
  agl-ds-autocomplete --> agl-ds-textbox
  agl-ds-internal-flatpickr --> agl-ds-textbox
  agl-ds-manual-address-entry --> agl-ds-textbox
  style agl-ds-textbox fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
