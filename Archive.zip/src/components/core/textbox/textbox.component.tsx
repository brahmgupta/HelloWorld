import { Component, h, Host, Prop, Event, EventEmitter, Method, State, Element, ComponentInterface, Watch } from '@stencil/core';
import { generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import { TextboxType, InputType } from './textbox.types';

/**
 * @slot hint-text - Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading.
 * There is also a prop to pass text.
 */
@Component({
  tag: 'agl-ds-textbox',
  styleUrl: 'textbox.component.scss',
  shadow: false,
  scoped: true
})
export class TextBoxComponent implements ComponentInterface {
  @Element() host: HTMLAglDsTextboxElement;
  /**
   * internalised Unique ID for the validation text
   */
  private uniqueHintValidationId: string = generateRandomNumber();

  /**
   * The input ID
   */
  @Prop() textBoxId: string = generateRandomNumber();

  /**
   * The label text for the input, will be hidden if type is experiential
   * TODO This needs to be mandatory in order to be accessible
   */
  @Prop() label: string = '';

  /**
   * The value for the input
   */
  // eslint-disable-next-line @stencil/strict-mutable
  @Prop({ mutable: true }) value: string;

  /**
   * The type property of the input e.g. text, email, number
   */
  @Prop() inputType: InputType = 'text';

  /**
   * The placeholder property for the input, only used if type is experiential
   */
  @Prop() placeholder: string;

  /**
   * The maxlength property of the input
   */
  @Prop() maxLength?: number;

  /**
   * The browsers autocomplete property of the input
   */
  @Prop() browserAutocomplete: boolean = true;

  /**
   * Flag to show error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Flag to show valid state
   */
  @Prop() isInputValid: boolean = false;

  /**
   * Text to show when valid
   */
  @Prop() validText: string = '';

  /**
   * Type for the control, either default, default-inverse or experiential
   */
  @Prop() type: TextboxType = 'default';

  /**
   * Validation text to show when the has error flag is true
   */
  @Prop() validationText: string;

  /**
   * Hint text will be shown underneath the textbox but will be hidden if there is an error. There is also a slot which can be used for the inclusion of Phrasing content
   * (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading. There is also a prop to pass text.
   */
  @Prop() hintText: string;

  /**
   * An custom icon inside of the textbox e.g. calendar
   */
  @Prop() suffixIcon: string;

  /**
   * Forwards the blur event of the input
   */
  @Event() textboxBlur: EventEmitter<FocusEvent>;

  /**
   * Forwards the focus event of the input
   */
  @Event() textboxFocus: EventEmitter<FocusEvent>;

  /**
   * Forwards the input event of the input
   */
  @Event() textboxInput: EventEmitter<InputEvent>;

  /**
   * Forwards the keydown event of the input
   */
  @Event() textboxKeydown: EventEmitter<KeyboardEvent>;

  /**
   * Click event fired when clicking on the suffix icon
   */
  @Event() suffixIconClick: EventEmitter<void>;

  /**
   * Text box value changed event
   */
  @Event({ bubbles: false }) valueChange: EventEmitter;

  /**
   * State value to keep track of the input focus, used to apply classes to animate the border and label
   */
  @State() inputFocused: boolean;

  /**
   * State value to keep track of the input value
   */
  @State() inputValue: string;

  @Watch('value')
  valueWatchHandler(newValue: string) {
    this.inputValue = newValue;
  }

  private inputElement: HTMLInputElement;

  /**
   * Public method to focus on the input
   */
  @Method()
  async focusInput() {
    this.inputElement.focus();
  }

  /**
   * Public method to trigger blur event for the input
   */
  @Method()
  async blurInput() {
    this.inputElement.blur();
  }

  /**
   * Public method to clear the input
   */
  @Method()
  async clearInput() {
    this.inputValue = '';
  }

  /**
   * Public method to clear the input
   */
  @Method()
  async setInput(textValue: string) {
    this.inputValue = textValue;
  }

  /**
   * Public method to select the input
   */
  @Method()
  async selectInput() {
    this.inputElement.select();
  }

  /**
   * Public method to retrieve the input dom element
   */
  @Method()
  async getInputElement(): Promise<HTMLInputElement> {
    return this.inputElement;
  }

  /**
   * Sets focus to the textbox
   */
  @Method()
  async setFocus() {
    this.inputElement.focus();
  }

  componentWillLoad() {
    if (!this.label) {
      // TODO change this throw an error. It will be a breaking change.
      console.warn(`The "label" prop for ${this.textBoxId} is mandatory: please provide a value.`);
    }

    this.inputValue = this.value;
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);
  }

  private focusHandler(event: FocusEvent) {
    this.inputFocused = true;
    this.textboxFocus.emit(event);
  }

  private blurHandler(event: FocusEvent) {
    this.inputFocused = false;
    this.textboxBlur.emit(event);
  }

  private inputHandler(event: InputEvent) {
    this.inputValue = (event.target as HTMLInputElement).value;
    this.textboxInput.emit(event);
  }

  private keyDownHandler(event: KeyboardEvent) {
    this.textboxKeydown.emit(event);
  }
  private changeHandler(event: Event) {
    const val = event.target && (event.target as HTMLInputElement).value;
    this.value = val; //needs to be set for ngmodel and formcontrolname
    this.valueChange.emit((event.target as HTMLInputElement).value); // emit the value for the valuechange event
  }

  private renderHintText() {
    if (this.isInputValid) {
      return <div slot="hint-text">{this.validText}</div>;
    } else if (this.hintText?.length > 0 || this.host.querySelector('[slot="hint-text"]')?.innerHTML.length > 0) {
      return <div slot="hint-text">{this.hintText ? this.hintText : <slot name="hint-text"></slot>}</div>;
    }
    return '';
  }

  render() {
    let classPrefix: string;
    switch (this.type) {
      case 'default':
      case 'default-inverse':
        classPrefix = 'agl-ds-textbox-default';
        break;
      case 'experiential':
        classPrefix = 'agl-ds-textbox-experiential';
        break;
      default:
        classPrefix = 'agl-ds-textbox-default';
        break;
    }

    const isInputActive = this.inputFocused;
    const inputHasValue = !!this.inputValue;
    return (
      <Host>
        <div class={classPrefix}>
          <div class={`${classPrefix}__container`}>
            <label
              class={{
                [`${classPrefix}__label`]: true,
                [`${classPrefix}__label--has-value`]: inputHasValue,
                [`${classPrefix}__label--active`]: isInputActive || inputHasValue,
                [`${classPrefix}__label--error`]: this.hasError,
                ['sr-only']: this.type === 'experiential'
              }}
              htmlFor={this.textBoxId}
            >
              {this.label}
            </label>
            <input
              class={{
                [`${classPrefix}__input--default`]: this.type === 'default' || this.type === 'experiential',
                [`${classPrefix}__input--inverse`]: this.type === 'default-inverse',
                [`${classPrefix}__input--active`]: isInputActive,
                [`${classPrefix}__input--valid`]: this.isInputValid && !this.hasError,
                [`${classPrefix}__input--error`]: this.hasError
              }}
              type={this.inputType}
              id={this.textBoxId}
              name={this.textBoxId}
              onBlur={(e) => this.blurHandler(e)}
              onInput={(e: InputEvent) => this.inputHandler(e)}
              onKeyDown={(e) => this.keyDownHandler(e)}
              onFocus={(e) => this.focusHandler(e)}
              onChange={(e: Event) => this.changeHandler(e)}
              value={this.inputValue}
              placeholder={this.type === 'experiential' ? this.placeholder : undefined}
              maxLength={this.maxLength}
              autoComplete={this.browserAutocomplete ? undefined : 'off'} //chrome has a bug with the auto-complete TODO check this with fields the need auto complete on
              ref={(el) => (this.inputElement = el)}
              aria-describedBy={this.uniqueHintValidationId}
              aria-invalid={`${this.hasError}`}
            />
            {this.type !== 'experiential' && !this.hasError && (
              <span
                class={{
                  [`${classPrefix}__bar`]: true,
                  [`${classPrefix}__bar--active`]: isInputActive
                }}
              />
            )}
            {this.suffixIcon &&
              !this.hasError && [
                <span
                  innerHTML={this.suffixIcon}
                  onClick={(ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    this.suffixIconClick.emit();
                  }}
                  class={`${classPrefix}__suffix-icon`}
                  aria-hidden="true"
                />
              ]}
            {this.hasError && [
              <span
                class={{
                  'input-overlay': true,
                  ['input-overlay--inverse']: this.type === 'default-inverse',
                  ['input-overlay--experiential']: this.type === 'experiential'
                }}
              ></span>,
              <svg
                class={`${classPrefix}__error-icon`}
                focusable="false"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
              >
                <rect width="24" height="24" fill="none" />
                <path d="M12,2.5,1,21.5H23Zm1,16H11v-2h2Zm-2-4v-4h2v4Z" />
              </svg>
            ]}
            {this.isInputValid && !this.hasError && (
              <svg
                class={{
                  'text-input__icon': true,
                  ['text-input__icon--experiential']: this.type === 'experiential'
                }}
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                aria-hidden="true"
                focusable="false"
                width="24"
                height="24"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path>
              </svg>
            )}
          </div>
          <agl-ds-hint-validation-message asDescribedbyId={this.uniqueHintValidationId} hasError={this.hasError}>
            <div slot="validation-text">{this.validationText}</div>
            {this.renderHintText()}
          </agl-ds-hint-validation-message>
        </div>
      </Host>
    );
  }
}
