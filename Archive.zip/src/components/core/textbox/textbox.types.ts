export type TextboxType = 'default' | 'default-inverse' | 'experiential';

export type InputType = 'text' | 'tel' | 'url' | 'email' | 'number' | 'search';
