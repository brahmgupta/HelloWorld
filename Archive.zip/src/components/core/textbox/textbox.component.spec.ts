import { newSpecPage } from '@stencil/core/testing';
import { TextBoxComponent } from './textbox.component';
import * as utils from './../../../global/utils/utils';

describe('textboxcomponent', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  const dummyUniqueId = '11';
  it('should render default textbox', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label" type="default" has-error="false" max-length="100" input-type="text" label="test" text-box-id="test"><div slot="hint-text">dummy text</div></agl-ds-textbox>`
    });

    expect(page.root).toEqualHtml(
      `<agl-ds-textbox has-error="false" input-type="text" label="dummy label" max-length="100" text-box-id="test" type="default">
      <div class="agl-ds-textbox-default">
        <div class="agl-ds-textbox-default__container">
          <label class="agl-ds-textbox-default__label" htmlfor="test">
            dummy label
          </label>
          <input aria-describedby="` +
        dummyUniqueId +
        `" aria-invalid="false" class="agl-ds-textbox-default__input--default" id="test" maxlength="100" name="test" type="text">
          <span class="agl-ds-textbox-default__bar"></span>
        </div>
        <agl-ds-hint-validation-message asdescribedbyid="` +
        dummyUniqueId +
        `">
          <div slot="validation-text"></div>
          <div slot="hint-text">
            <div slot="hint-text">
              dummy text
            </div>
          </div>
        </agl-ds-hint-validation-message>
      </div>
    </agl-ds-textbox>

    `
    );
  });

  it('should render default textbox with the hint text as slotted content', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox type="default" has-error="false" max-length="100" input-type="text" label="test" text-box-id="test">
              <div slot="hint-text">I am a hint text message with a link <agl-ds-link>click here</agl-ds-link></div>
            </agl-ds-textbox>`
    });

    expect(page.root).toEqualHtml(
      `<agl-ds-textbox has-error="false" input-type="text" label="test" max-length="100" text-box-id="test" type="default">
      <div class="agl-ds-textbox-default">
        <div class="agl-ds-textbox-default__container">
          <label class="agl-ds-textbox-default__label" htmlfor="test">
            test
          </label>
          <input aria-describedby="` +
        dummyUniqueId +
        `" aria-invalid="false" class="agl-ds-textbox-default__input--default" id="test" maxlength="100" name="test" type="text">
          <span class="agl-ds-textbox-default__bar"></span>
        </div>
        <agl-ds-hint-validation-message asdescribedbyid="` +
        dummyUniqueId +
        `">
          <div slot="validation-text"></div>
          <div slot="hint-text">
            <div slot="hint-text">
              I am a hint text message with a link
              <agl-ds-link>
                click here
              </agl-ds-link>
            </div>
          </div>
        </agl-ds-hint-validation-message>
      </div>
    </agl-ds-textbox>`
    );
  });

  it('should render default inverse textbox', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label" type="default-inverse" has-error="false" max-length="100" input-type="text" text-box-id="test"></agl-ds-textbox>`
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-textbox label="dummy label" has-error="false" input-type="text" max-length="100" text-box-id="test" type="default-inverse">
        <div class="agl-ds-textbox-default">
          <div class="agl-ds-textbox-default__container">
            <label class="agl-ds-textbox-default__label" htmlfor="test">
              dummy label
            </label>
            <input aria-describedby="` +
        dummyUniqueId +
        `" aria-invalid="false" class="agl-ds-textbox-default__input--inverse" id="test" maxlength="100" name="test" type="text">
            <span class="agl-ds-textbox-default__bar"></span>
          </div>
          <agl-ds-hint-validation-message asdescribedbyid="` +
        dummyUniqueId +
        `">
            <div slot="validation-text"></div>
          </agl-ds-hint-validation-message>
        </div>
      </agl-ds-textbox>
            `
    );
  });

  it('should render experiential textbox', async () => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label" type="experiential" has-error="false" max-length="100" input-type="text" text-box-id="test"></agl-ds-textbox>`
    });
    expect(page.root).toEqualHtml(
      `
    <agl-ds-textbox label="dummy label" has-error="false" input-type="text" max-length="100" text-box-id="test" type="experiential">
      <div class="agl-ds-textbox-experiential">
        <div class="agl-ds-textbox-experiential__container">
          <label class="agl-ds-textbox-experiential__label sr-only" htmlfor="test">
            dummy label
          </label>
          <input aria-describedby="11" aria-invalid="false" class="agl-ds-textbox-experiential__input--default" id="test" maxlength="100" name="test" type="text">
        </div>
        <agl-ds-hint-validation-message asdescribedByid="` +
        dummyUniqueId +
        `">
          <div slot="validation-text"></div>
        </agl-ds-hint-validation-message>
      </div>
    </agl-ds-textbox>
    `
    );
  });

  it('should add error classes when has error true', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label" has-error="true"></agl-ds-textbox>`
    });

    const input = page.root.querySelector('input');
    const label = page.root.querySelector('label');
    expect(input.classList.contains('agl-ds-textbox-default__input--error')).toBe(true);
    expect(label.classList.contains('agl-ds-textbox-default__label--error')).toBe(true);
  });

  it('should add valid classes when is valid', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label" is-input-valid="true"></agl-ds-textbox>`
    });

    const input = page.root.querySelector('input');
    expect(input.classList.contains('agl-ds-textbox-default__input--valid')).toBe(true);
  });

  it('should fire textboxBlur on blur of the input', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label"></agl-ds-textbox>`
    });
    const blurSpy = jest.fn();
    page.win.addEventListener('textboxBlur', blurSpy);
    const input = page.root.querySelector('input');
    input.dispatchEvent(new Event('blur'));
    await page.waitForChanges();
    expect(blurSpy).toHaveBeenCalled();
  });

  it('should fire textboxInput on input of the input', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label"></agl-ds-textbox>`
    });
    const inputSpy = jest.fn();
    page.win.addEventListener('textboxInput', inputSpy);
    const input = page.root.querySelector('input');
    input.value = 'test';
    input.dispatchEvent(new Event('input'));
    await page.waitForChanges();
    expect(inputSpy).toHaveBeenCalled();
    const eventDetail = inputSpy.mock.calls[inputSpy.mock.calls.length - 1][0].detail.target.value;
    expect(eventDetail).toBe('test');
  });

  it('should fire textboxKeydown on keydown of the input', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label"></agl-ds-textbox>`
    });
    const keydownSpy = jest.fn();
    page.win.addEventListener('textboxKeydown', keydownSpy);
    const input = page.root.querySelector('input');
    input.dispatchEvent(new Event('keydown'));
    await page.waitForChanges();
    expect(keydownSpy).toHaveBeenCalled();
  });

  it('should retrieve the input element when getInputElement is called', async () => {
    const page = await newSpecPage({
      components: [TextBoxComponent],
      html: `<agl-ds-textbox label="dummy label"></agl-ds-textbox>`
    });
    const input = page.root.querySelector('input');
    const textboxInput = await page.root.getInputElement();
    expect(textboxInput).toBe(input);
  });
});
