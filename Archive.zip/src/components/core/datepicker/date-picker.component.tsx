import { Component, ComponentInterface, Event, EventEmitter, h, Prop } from '@stencil/core';
import { DateLimit, DateOption, Options } from 'flatpickr/dist/types/options';
import { formatDate, parseDate } from './utils/flatpickr.utils';
import { DatePickerTheme, DateSelectionMultiple, DateSelectionSingular, DateValidationError } from './base-date-picker.model';

@Component({
  tag: 'agl-ds-beta-date-picker-do-not-use',
  styleUrl: 'date-picker.component.scss',
  shadow: {
    delegatesFocus: true
  }
})
export class DatePickerComponent implements ComponentInterface {
  /**
   * Inline label
   */
  @Prop() label: string;

  /**
   * Hint text will be shown underneath the textbox but will be hidden if there is an error
   */
  @Prop() hintText: string;

  /**
   * Flag to show error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Validation text to show when the has error flag is true
   */
  @Prop() validationText: string;

  /**
   * Fires when an day is selected
   */
  @Event({ bubbles: false }) selected: EventEmitter<DateSelectionSingular>;

  /**
   * Event that fires when datepicker is initialised with default values
   */
  @Event({ bubbles: false }) initialised: EventEmitter<DateSelectionSingular>;

  /**
   * Event that fires when datepicker is opened
   */
  @Event({ bubbles: false }) opened: EventEmitter<void>;

  /**
   * Event that fires when datepicker is closed
   */
  @Event({ bubbles: false }) closed: EventEmitter<void>;

  /**
   * Event that fires when an invalid date is entered
   */
  @Event({ bubbles: false }) errorOnInput: EventEmitter<DateValidationError>;

  /**
   * Date format for input textbox e.g. d-m-Y
   * d	Day of the month, 2 digits with leading zeros	01 to 31
   * D	A textual representation of a day	Mon through Sun
   * l (lowercase 'L')	A full textual representation of the day of the week	Sunday through Saturday
   * j	Day of the month without leading zeros	1 to 31
   * J	Day of the month without leading zeros and ordinal suffix	1st, 2nd, to 31st
   * w	Numeric representation of the day of the week	0 (for Sunday) through 6 (for Saturday)
   * W	Numeric representation of the week	0 (first week of the year) through 52 (last week of the year)
   * F	A full textual representation of a month	January through December
   * m	Numeric representation of a month, with leading zero	01 through 12
   * n	Numeric representation of a month, without leading zeros	1 through 12
   * M	A short textual representation of a month	Jan through Dec
   * U	The number of seconds since the Unix Epoch	1413704993
   * y	A two digit representation of a year	99 or 03
   * Y	A full numeric representation of a year, 4 digits	1999 or 2003
   */
  @Prop() dateFormat?: string = 'd/m/Y';

  /**
   * Alternative Date format for processing e.g. backend api request e.g. d-m-Y
   */
  @Prop() returnedDateFormat?: string;

  /**
   * the default value for the date picker
   */
  @Prop() defaultValue: string;

  /**
   * Dates to disable passed in as an array in the specified format (alt date format given preference). Delimit dates using |
   */
  @Prop() disabledDates?: string[] | string;

  /**
   * Dates to enabled passed in as an array in the specified format (alt date format given preference). Delimit dates using |
   */
  @Prop() enabledDates?: string[] | string;

  /**
   * Minimum date to enable from. Either a formatted date or number of todays before today
   */
  @Prop() minDate?: string;

  /**
   * Maximum date to enable to. Either a formatted date or number of todays after today
   */
  @Prop() maxDate?: string | number;

  /**
   * Disable weekends
   */
  @Prop() disableWeekends?: boolean;

  /**
   * All manual keyboard entry
   */
  @Prop() allowInput?: boolean;

  /**
   * Allow users to enter or select invalid dates but publish an error event
   */
  @Prop() allowInvalidEntryAndSelection?: boolean;

  /**
   * Disable native mobile date picker
   */
  @Prop() disableNativeMobilePicker?: boolean;

  /**
   * Indicates date picker theme
   * Available themes: `"default"`, `"default-inverse"`,
   * `"default"` will be applied when type is not specified
   */
  @Prop() theme?: DatePickerTheme = 'default';

  private lastSelection: DateSelectionSingular;

  private getDatePickerOptions(): Options {
    return {
      dateFormat: this.dateFormat,
      defaultDate: this.getDefaultDate(),
      disable: this.getDisabledDates(),
      enable: this.getEnableDates(),
      minDate: this.getMinOrMaxDate(this.minDate, true),
      maxDate: this.getMinOrMaxDate(this.maxDate, false),
      allowInput: this.allowInput
    };
  }

  private onDateChange(ev: CustomEvent<DateSelectionMultiple>, isInitialChange: boolean): void {
    const selection = ev.detail;
    if (Array.isArray(selection.formattedSelectedDates) && selection.formattedSelectedDates.length > 0) {
      const eventToEmit: DateSelectionSingular = {
        formattedSelectedDate: selection.formattedSelectedDates.slice(-1).pop(),
        altFormattedSelectedDate: selection.selectedDates
          .map((dt) => formatDate(dt, this.returnedDateFormat || this.dateFormat))
          .slice(-1)
          .pop()
      };
      if (isInitialChange) {
        this.initialised.emit(eventToEmit);
      } else {
        this.selected.emit(eventToEmit);
      }
      this.lastSelection = eventToEmit;
    }
  }

  private disableWeekendsCallback(date: Date) {
    return date.getDay() === 0 || date.getDay() === 6;
  }

  private getDisabledDates(): DateLimit<DateOption>[] {
    let disabledDates: DateLimit<DateOption>[] = [];

    if (Array.isArray(this.disabledDates)) {
      disabledDates = this.disabledDates;
    } else if (typeof this.disabledDates === 'string') {
      disabledDates = this.disabledDates.split('|');
    }
    if (this.disableWeekends) {
      disabledDates.push(this.disableWeekendsCallback);
    }
    return disabledDates
      ?.filter((dt) => !!dt)
      .map((dt) => (typeof dt === 'string' ? parseDate(dt, this.returnedDateFormat || this.dateFormat) : dt));
  }

  private getEnableDates(): DateLimit<DateOption>[] {
    let enabledDates: DateLimit<DateOption>[] = [];

    if (Array.isArray(this.enabledDates)) {
      enabledDates = this.enabledDates;
    } else if (typeof this.enabledDates === 'string') {
      enabledDates = this.enabledDates.split('|');
    }
    return enabledDates
      ?.filter((dt) => !!dt)
      .map((dt) => (typeof dt === 'string' ? parseDate(dt, this.returnedDateFormat || this.dateFormat) : dt));
  }

  private getMinOrMaxDate(dateValue: string | number, isMin: boolean): DateOption | null {
    if (dateValue !== null && dateValue !== undefined) {
      const strDateValue = String(dateValue);
      const isNumeric: boolean = !!strDateValue.match(/^-?\d+$/);
      if (!isNumeric) {
        return dateValue;
      } else if (isNumeric) {
        const todayPlusOrMinusDays = this.defaultValue ? parseDate(this.defaultValue, this.dateFormat) : new Date();
        if (isMin) {
          todayPlusOrMinusDays.setDate(todayPlusOrMinusDays.getDate() - parseInt(strDateValue));
        } else {
          todayPlusOrMinusDays.setDate(todayPlusOrMinusDays.getDate() + parseInt(strDateValue));
        }
        return formatDate(todayPlusOrMinusDays, this.dateFormat) || null;
      }
    }

    return null;
  }

  private getDefaultDate(): string | Date {
    const isDefaultConversionNeeded = this.defaultValue && this.returnedDateFormat && this.returnedDateFormat !== this.dateFormat;
    if (isDefaultConversionNeeded) {
      if (!this.lastSelection || this.lastSelection.formattedSelectedDate !== this.defaultValue) {
        const parsedValue = parseDate(this.defaultValue, this.returnedDateFormat);
        return parsedValue ? parsedValue : this.defaultValue;
      }
    }
    return this.defaultValue;
  }

  render() {
    return (
      <agl-ds-internal-flatpickr
        theme={this.theme}
        label={this.label}
        hintText={this.hintText}
        options={this.getDatePickerOptions()}
        onDaySelected={(ev) => this.onDateChange(ev, false)}
        onInitialised={(ev) => this.onDateChange(ev, true)}
        onOpened={() => this.opened.emit()}
        onClosed={() => this.closed.emit()}
        onErrorOnInput={(e: CustomEvent<DateValidationError>) => this.errorOnInput.emit(e.detail as DateValidationError)}
        hasError={this.hasError}
        validationText={this.validationText}
        disableNativeMobilePicker={this.disableNativeMobilePicker}
        allowInvalidEntryAndSelection={this.allowInvalidEntryAndSelection}
      ></agl-ds-internal-flatpickr>
    );
  }
}
