import { Instance } from 'flatpickr/dist/types/instance';

export function removeKeyDownHandlerForFlatpickr(instance: Instance): void {
  const flatpickrKeydownEvent = (instance._handlers || []).find((flatpickrEvents) => flatpickrEvents.event === 'keydown');
  if (flatpickrKeydownEvent) {
    flatpickrKeydownEvent.element.removeEventListener('keydown', flatpickrKeydownEvent.handler);
  }
}

export function getNextOrPreviousDayElementforFlatpickrNav(instance: Instance, currentElement: HTMLElement, delta: number): HTMLElement {
  let elementFound: HTMLElement;
  let loopingElement = currentElement;
  let iterations = 0;
  let offsetDaysBy: number = delta;
  while (!elementFound) {
    iterations = iterations + 1;
    const getDayElements = () =>
      Array.from(instance.daysContainer.querySelectorAll('.flatpickr-day:not(.prevMonthDay):not(.nextMonthDay)'));
    const dayElements = getDayElements();
    const currentElementIndex = dayElements.findIndex((dayElement) => dayElement === loopingElement);

    const isYearNavigatingForward = delta === 365;
    const isYearNavigatingBackward = delta === -365;
    const isMonthNavigatingForward = delta === 28;
    const isMonthNavigatingBackward = delta === -28;
    const isDayNavigatingToNextMonth = currentElementIndex + delta > dayElements.length - 1;
    const isDayNavigatingToPreviousMonth = currentElementIndex + delta < 0;

    if (isYearNavigatingForward) {
      instance.changeYear(instance.currentYear + 1);
      loopingElement = getDayElements()[0] as HTMLElement;
      offsetDaysBy = 0;
      delta = 1;
      continue;
    } else if (isYearNavigatingBackward) {
      instance.changeYear(instance.currentYear - 1);
      loopingElement = getDayElements().slice(-1).pop() as HTMLElement;
      offsetDaysBy = 0;
      delta = -1;
      continue;
    } else if (isMonthNavigatingForward) {
      instance.changeMonth(1);
      loopingElement = getDayElements()[0] as HTMLElement;
      offsetDaysBy = 0;
      delta = 1;
      continue;
    } else if (isMonthNavigatingBackward) {
      instance.changeMonth(-1);
      loopingElement = getDayElements().slice(-1).pop() as HTMLElement;
      offsetDaysBy = 0;
      delta = -1;
      continue;
    } else if (isDayNavigatingToNextMonth) {
      instance.changeMonth(1, true, true);
      loopingElement = getDayElements()[0] as HTMLElement;
      offsetDaysBy = 0;
      continue;
    } else if (isDayNavigatingToPreviousMonth) {
      instance.changeMonth(-1, true, true);
      loopingElement = getDayElements().slice(-1).pop() as HTMLElement;
      offsetDaysBy = 0;
      continue;
    } else {
      loopingElement = dayElements[currentElementIndex + offsetDaysBy] as HTMLElement;
    }

    const isSelectableDayElement = loopingElement && !loopingElement.classList.contains('flatpickr-disabled');
    if (isSelectableDayElement) {
      elementFound = loopingElement;
      offsetDaysBy = delta > 0 ? 1 : -1;
    } else {
      offsetDaysBy = delta;
    }

    const hasEncounteredMaxorMinDate = iterations > 31;
    if (hasEncounteredMaxorMinDate) {
      return currentElement;
    }
  }
  return elementFound;
}
