import { text, boolean } from '@storybook/addon-knobs';
import flatpickr from 'flatpickr';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Date Picker'
};

export const Default = () => {
  const d = new Date();
  const disableDate1 = new Date();
  disableDate1.setDate(disableDate1.getDate() - 2);
  const disableDate2 = new Date();
  disableDate2.setDate(disableDate2.getDate() + 1);

  const minDate = new Date();
  minDate.setMonth(minDate.getMonth() - 1);

  const maxDate = new Date();
  maxDate.setMonth(maxDate.getMonth() + 1);

  const dayFormat = 'd/m/Y';
  const returnedDateFormat = 'F d, Y';
  const disableDates = [disableDate1, disableDate2].map((dt) => getDateString(dt, returnedDateFormat)).join('|');

  return html`<div>
      <agl-ds-beta-date-picker-do-not-use
        default-value="${text('default date', flatpickr.formatDate(d, returnedDateFormat))}"
        allow-invalid-entry-and-selection=${boolean('allow Invalid', true)}
        label="${text('inline label', 'dd/mm/yyyy')}"
        hint-text="${text('hint text', 'connection date should be connected one month before or after')}"
        date-format="${text('date format', dayFormat)}"
        returned-date-format="${text('returned date format', returnedDateFormat)}"
        disabled-dates="${text('disabled dates', disableDates)}"
        disable-weekends="${boolean('disable weekends', true)}"
        @selected=${(e) => {
          document.querySelector('#output').innerHTML = `Date selected: ${JSON.stringify(e.detail)}`;
          document.querySelector('#error').innerHTML = ``;
        }}
        @errorOnInput=${(e) => {
          setTimeout(() => {
            document.querySelector('#error').innerHTML = `Error: ${JSON.stringify(e.detail)}`;
          });
        }}
        min-date="${text('min date', flatpickr.formatDate(minDate, dayFormat))}"
        max-date="${text('max date', flatpickr.formatDate(maxDate, dayFormat))}"
        validation-text="${text('validation text', 'validation text')}"
        allow-input=${boolean('allow Input', true)}
      >
      </agl-ds-beta-date-picker-do-not-use>
    </div>
    <br />
    <span id="output"></span><br /><br />
    <span id="error"></span><br /><br />
    <label
      ><input
        type="checkbox"
        onClick="document.querySelector('agl-ds-beta-date-picker-do-not-use').setAttribute('has-error',this.checked)"
      />Toggle Error</label
    > `;
};

Default.parameters = { notes };

Default.parameters = { notes };
const getDateString = (d, format) => {
  d.setDate(d.getDate() + 1);
  return flatpickr.formatDate(d, format);
};
