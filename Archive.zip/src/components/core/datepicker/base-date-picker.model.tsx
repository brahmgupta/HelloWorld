import { DateOption } from 'flatpickr/dist/types/options';
export interface DateSelectionMultiple {
  selectedDates: Date[];
  formattedSelectedDates: string[];
}

export interface DateSelectionSingular {
  formattedSelectedDate: string;
  altFormattedSelectedDate: string;
}

export type DatePickerTheme = 'default';

export interface DateValidationError {
  type: string;
  compareAgainst: DateOption;
  message?: string;
}
