import { Component, ComponentInterface, Element, Event, EventEmitter, h, Host, Prop, Watch } from '@stencil/core';
import flatpickr from 'flatpickr';
import { Instance } from 'flatpickr/dist/types/instance';
import { CustomLocale } from 'flatpickr/dist/types/locale';
import { Options, DateOption } from 'flatpickr/dist/types/options';
import iconCalendar from '../../../assets/icon-calendar.svg';
import { generateRandomNumber } from '../../../global/utils/utils';
import { DatePickerTheme, DateSelectionMultiple, DateValidationError } from './base-date-picker.model';
import { getNextOrPreviousDayElementforFlatpickrNav, removeKeyDownHandlerForFlatpickr } from './flatpickr-keyboard-navigation.util';

// This component is built with Flatpickr (https://flatpickr.js.org/)
// This is an interal component to be used only within design system components but not 'recommended' to be used externally as a standalone web component
@Component({
  tag: 'agl-ds-internal-flatpickr',
  styleUrl: 'flatpickr.component.scss'
})
export class FlatpickrComponent implements ComponentInterface {
  private uniqueId: string = generateRandomNumber();

  @Element() private element: HTMLAglDsInternalFlatpickrElement;

  /**
   * Inline label
   */
  @Prop() label: string;

  /**
   * Hint text will be shown underneath the textbox but will be hidden if there is an error
   */
  @Prop() hintText: string;

  /**
   * Flag to show error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Validation text to show when the has error flag is true
   */
  @Prop() validationText: string;

  /**
   * Fires when an day is selected
   */
  @Event({ bubbles: false }) daySelected: EventEmitter<DateSelectionMultiple>;

  /**
   * Event that fires when datepicker is initialised with default values
   */
  @Event({ bubbles: false }) initialised: EventEmitter<DateSelectionMultiple>;

  /**
   * Event that fires when datepicker is opened
   */
  @Event({ bubbles: false }) opened: EventEmitter<void>;

  /**
   * Event that fires when datepicker is closed
   */
  @Event({ bubbles: false }) closed: EventEmitter<void>;

  /**
   * Event that fires when an invalid date is entered
   */
  @Event({ bubbles: false }) errorOnInput: EventEmitter<DateValidationError>;

  /**
   * flatpickr configuration options
   */
  @Prop() public options: Options = {};

  /**
   * Disable native mobile date picker
   */
  @Prop() disableNativeMobilePicker?: boolean;

  /**
   * Allow users to enter or select invalid dates but publish an error event
   */
  @Prop() allowInvalidEntryAndSelection?: boolean;

  /**
   * Custom css theme for injecting as a css class e.g. flatpickr--${this.theme}
   */
  @Prop() theme?: DatePickerTheme = 'default';

  private instance: Instance;
  private textboxElement: HTMLAglDsTextboxElement;
  private textboxInputId: string = 'text' + this.uniqueId;
  private inFocusElement: HTMLElement;

  componentDidLoad(): void {
    if (this.instance) {
      return;
    }
    const defaultOptions = { ...this.options };
    if (this.allowInvalidEntryAndSelection) {
      delete defaultOptions.minDate;
      delete defaultOptions.maxDate;
      delete defaultOptions.disable;
      delete defaultOptions.enable;
    }

    const textboxInputElement: HTMLInputElement = this.element.querySelector('#' + this.textboxInputId);
    textboxInputElement.addEventListener('focus', () => {
      if (this.options.allowInput) {
        textboxInputElement.select();
      }
    });
    this.instance = flatpickr(textboxInputElement, {
      ...defaultOptions,
      appendTo: this.element,
      onChange: (selection) => {
        const selectedDates = this.getSelectedDate(selection);
        this.daySelected.emit(selectedDates);
        if (this.allowInvalidEntryAndSelection) {
          const validationError = this.customValidation(selectedDates);
          if (validationError) {
            this.errorOnInput.emit(validationError);
          }
        }
      },
      onOpen: () => {
        const selected: HTMLElement = this.element.querySelector('.selected') || this.element.querySelector('.today');
        this.inFocusElement = selected;
        this.opened.emit();
      },
      onClose: () => {
        this.inFocusElement = null;
        this.closed.emit();
      },
      errorHandler: (error) => {
        this.errorOnInput.emit({
          type: 'Format',
          compareAgainst: null,
          message: String(error)
        });
      },
      disableMobile: this.disableNativeMobilePicker || (defaultOptions.disable || []).concat(defaultOptions.enable || []).length === 0, // https://flatpickr.js.org/mobile-support/ disable and enable are not guaranteed to work on native mobile date pickers
      locale: ({
        weekdays: {
          shorthand: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
        }
      } as Partial<CustomLocale>) as CustomLocale
    });
    const displayedValue = this.getSelectedDate(this.instance.selectedDates).formattedSelectedDates.join();
    textboxInputElement.value = displayedValue;
    this.textboxElement.value = displayedValue;

    // Customisation1
    // in-built flatpickr keyboard navigation does not work with shadow dom so using a custom keydown event handler
    // in-built flatpickr keyboard nav uses document.body or document.activeElement for looking up current element with focus and so its breaks with shadow dom
    // It might be worth submitting a PR to flatpickr to do a shadow dom check on document.activeElement i.e. if !!document.activeElement.shadowRoot
    removeKeyDownHandlerForFlatpickr(this.instance);
    this.initialised.emit(this.getSelectedDate(this.instance.selectedDates));
  }

  @Watch('options')
  onOptionsChange(options: Options): void {
    if (this.instance) {
      Object.keys(options).forEach((key) => {
        if (key === 'defaultDate') {
          this.instance.setDate(options[key]);
        } else {
          this.instance.set(key as keyof Options, options[key]);
        }
      });
    }
  }

  private getSelectedDate(selectedDates: Date[] = []): DateSelectionMultiple {
    return {
      selectedDates: selectedDates,
      formattedSelectedDates: selectedDates.map((dt) => this.instance.formatDate(dt, this.options.dateFormat))
    };
  }

  // see note 'Customisation1' on overriding default keyboard nav with custom keyboard navigation
  private handleKeydown(ev: KeyboardEvent) {
    let delta: number = null;
    const isChangingYearForward = ev.altKey && (ev.code === 'ArrowUp' || ev.code === 'ArrowRight');
    const isChangingYearBackward = ev.altKey && (ev.code === 'ArrowDown' || ev.code === 'ArrowLeft');
    const isChangingMonthForward = ev.shiftKey && (ev.code === 'ArrowUp' || ev.code === 'ArrowRight');
    const isChangingMonthBackward = ev.shiftKey && (ev.code === 'ArrowDown' || ev.code === 'ArrowLeft');

    if (isChangingYearForward) {
      delta = 365;
    } else if (isChangingYearBackward) {
      delta = -365;
    } else if (isChangingMonthForward) {
      delta = 28;
    } else if (isChangingMonthBackward) {
      delta = -28;
    } else {
      switch (ev.code) {
        case 'ArrowUp':
          delta = -7;
          break;
        case 'ArrowDown':
          delta = 7;
          break;
        case 'ArrowLeft':
          delta = -1;
          break;
        case 'ArrowRight':
          delta = 1;
          break;
      }
    }
    if (this.instance.isOpen) {
      if (delta !== null) {
        const elementToFocusOn: HTMLElement = getNextOrPreviousDayElementforFlatpickrNav(this.instance, this.inFocusElement, delta);
        if (elementToFocusOn) {
          elementToFocusOn.focus();
          this.inFocusElement = elementToFocusOn;
        }
      } else if (ev.code === 'Enter' && this.inFocusElement) {
        this.inFocusElement.click();
      }
    }
  }

  private customValidation(selectedDates: DateSelectionMultiple): DateValidationError {
    let validationError: DateValidationError;
    selectedDates.selectedDates.forEach((selectedDate) => {
      if (!validationError && !!this.options.minDate && this.options.minDate !== 'undefined') {
        if (flatpickr.compareDates(this.instance.parseDate(this.options.minDate, this.options.dateFormat), selectedDate, true) > 0) {
          validationError = {
            type: 'minDate',
            compareAgainst: this.options.minDate
          };
        }
      }
      if (!validationError && !!this.options.maxDate && this.options.maxDate !== 'undefined') {
        if (flatpickr.compareDates(this.instance.parseDate(this.options.maxDate, this.options.dateFormat), selectedDate, true) < 0) {
          validationError = {
            type: 'maxDate',
            compareAgainst: this.options.maxDate
          };
        }
      }
      if (!validationError && Array.isArray(this.options.disable) && this.options.disable.length > 0) {
        const hasDisableDate = this.options.disable.find((option) => {
          if (typeof option === 'function') {
            return option(selectedDate);
          } else {
            return flatpickr.compareDates(this.instance.parseDate(option as DateOption, this.options.dateFormat), selectedDate, true) === 0;
          }
        });
        if (hasDisableDate) {
          validationError = {
            type: 'disabledDates',
            compareAgainst:
              typeof hasDisableDate === 'function' ? null : flatpickr.formatDate(hasDisableDate as Date, this.options.dateFormat)
          };
        }
      }
      if (!validationError && Array.isArray(this.options.enable) && this.options.enable.length > 0) {
        const doesNotContainEnableDate = this.options.enable.find(
          (option) =>
            flatpickr.compareDates(this.instance.parseDate(option as DateOption, this.options.dateFormat), selectedDate, true) !== 0
        );
        if (doesNotContainEnableDate) {
          validationError = {
            type: 'enabledDates',
            compareAgainst: flatpickr.formatDate(doesNotContainEnableDate as Date, this.options.dateFormat) as DateOption
          };
        }
      }
    });
    return validationError;
  }

  connectedCallback() {
    this.element.addEventListener('keydown', (ev) => this.handleKeydown(ev));
  }

  disconnectedCallback() {
    this.element.removeEventListener('keydown', (ev) => this.handleKeydown(ev));
    this.instance.destroy();
  }

  render() {
    return (
      <Host class={`flatpickr--${this.theme}`}>
        <agl-ds-textbox
          textBoxId={this.textboxInputId}
          suffixIcon={iconCalendar}
          onSuffixIconClick={() => this.instance.open()}
          label={this.label}
          hintText={this.hintText}
          hasError={this.hasError}
          validationText={this.validationText}
          ref={(el) => (this.textboxElement = el)}
        ></agl-ds-textbox>
      </Host>
    );
  }
}
