import { newE2EPage, E2EPage } from '@stencil/core/testing';
import { formatDate, parseDate } from './utils/flatpickr.utils';

describe('Date Picker component', () => {
  it('should render the component', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
    const datepickr = await page.find(`agl-ds-beta-date-picker-do-not-use`);
    const textbox: HTMLInputElement = ((await page.find(
      `agl-ds-beta-date-picker-do-not-use >>> input.sc-agl-ds-textbox`
    )) as unknown) as HTMLInputElement;
    expect(textbox).toBeTruthy();
    expect(datepickr).toBeTruthy();
  });

  it('should set a default value with the provided value', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
    const datePicker: any = await page.find(`agl-ds-beta-date-picker-do-not-use`);
    expect(datePicker.getAttribute('default-value')).toBe('21/12/2020');
  });

  it('should not set a default value when not provided a value', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use></agl-ds-beta-date-picker-do-not-use>`);
    const datePicker: any = await page.find(`agl-ds-beta-date-picker-do-not-use`);
    expect(datePicker.getAttribute('default-value')).toBe(null);
  });

  it('should open the date picker', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use></agl-ds-beta-date-picker-do-not-use>`);
    expect(await isCalendarVisible(page)).toBe(false);
    await openDatePicker(page);
    expect(await isCalendarVisible(page)).toBe(true);
  });

  it('should check if default date is selected on the date picker', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
    await openDatePicker(page);
    expect(await getSelectedDate(page)).toBe('December 21, 2020');
  });

  it('should change the selected date to next day', async () => {
    const page = await newE2EPage();
    await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
    await openDatePicker(page);
    await setSelectedDateAsNextDay(page);
    expect(await getSelectedDate(page)).toBe('December 22, 2020');
  });

  it('should emit an output event for date selection using alt date format', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="December 21, 2020" date-format="d-m-Y" returned-date-format="F j, Y"></agl-ds-beta-date-picker-do-not-use>`
    );
    const daySelectedEvent = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('selected');
    await openDatePicker(page);
    await setSelectedDateAsNextDay(page);

    expect(daySelectedEvent).toHaveReceivedEventDetail({
      altFormattedSelectedDate: 'December 22, 2020',
      formattedSelectedDate: '22-12-2020'
    });
  });

  it('should disable weekends', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" disable-weekends></agl-ds-beta-date-picker-do-not-use>`
    );
    await openDatePicker(page);
    expect(await isWeekendDisabled(page)).toBe(true);
  });

  it('should set a label text', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" label="testLabel"></agl-ds-beta-date-picker-do-not-use>`
    );

    const label: HTMLLabelElement = ((await page.find(
      `agl-ds-beta-date-picker-do-not-use >>> label.sc-agl-ds-textbox`
    )) as unknown) as HTMLLabelElement;
    expect(label.innerText).toBe('testLabel');
  });

  it('should set a hint text', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" hint-text="testHint"></agl-ds-beta-date-picker-do-not-use>`
    );

    const hint: HTMLDivElement = ((await page.find(
      `agl-ds-beta-date-picker-do-not-use >>> div.message-container__hint-text-section > div.sc-agl-ds-textbox`
    )) as unknown) as HTMLDivElement;
    expect(hint.innerText).toBe('testHint');
  });

  it('should set a min and max date with formatted dates', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" min-date="18/12/2020" max-date="25/12/2020"></agl-ds-beta-date-picker-do-not-use>`
    );

    await openDatePicker(page);
    expect(await isWeekendDisabled(page)).toBe(true);
    expect(await isDisableDateGreyedOut(page)).toBe(true);
  });

  it('should set a min and max date with number of days with default date', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" min-date="3" max-date="4"></agl-ds-beta-date-picker-do-not-use>`
    );

    await openDatePicker(page);
    const defaultDate: Date = parseDate('21/12/2020');
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](-2), 'F j, Y'))).toBe(false);
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](-3), 'F j, Y'))).toBe(false);
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](-4), 'F j, Y'))).toBe(true);
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](5), 'F j, Y'))).toBe(true);
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](4), 'F j, Y'))).toBe(false);
    expect(await isDateDisabled(page, formatDate(defaultDate['fp_incr'](3), 'F j, Y'))).toBe(false);
  });

  it('should disable a date', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" disabled-dates="11/12/2020|26/12/2020"></agl-ds-beta-date-picker-do-not-use>`
    );
    await openDatePicker(page);
    expect(await isWeekendDisabled(page)).toBe(true);
    expect(await isDisableDateGreyedOut(page)).toBe(true);
  });

  it('should enable a date but disable others', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" enabled-dates="${formatDate(
        new Date(),
        'Y-m-d'
      )}" returned-date-format="Y-m-d"></agl-ds-beta-date-picker-do-not-use>`
    );
    await openDatePicker(page);
    expect(await isDateDisabled(page, formatDate(new Date()['fp_incr'](-1), 'F j, Y'))).toBe(true);
    expect(await isDateDisabled(page, formatDate(new Date(), 'F j, Y'))).toBe(false);
    expect(await isDateDisabled(page, formatDate(new Date()['fp_incr'](+1), 'F j, Y'))).toBe(true);
  });

  it('should shown an error', async () => {
    const page = await newE2EPage();
    await page.setContent(
      `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" has-error validation-text="you have an error"></agl-ds-beta-date-picker-do-not-use>`
    );

    const label: HTMLLabelElement = ((await page.find(
      'agl-ds-beta-date-picker-do-not-use >>> label.agl-ds-textbox-default__label--error'
    )) as unknown) as HTMLLabelElement;
    expect(label).toBeTruthy();

    const datePickerIcon: any = await page.find(`agl-ds-beta-date-picker-do-not-use >>> .agl-ds-textbox-default__suffix-icon`);
    expect(datePickerIcon).toBeFalsy();

    const hint: HTMLDivElement = ((await page.find(
      `agl-ds-beta-date-picker-do-not-use >>> div.sc-agl-ds-textbox`
    )) as unknown) as HTMLDivElement;
    expect(hint.innerText).toBe('you have an error');
  });

  describe('should allow keyboard navigation', () => {
    it('to next day', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, 1);
      expect(await getSelectedDate(page)).toBe('December 22, 2020');
    });

    it('to previous day', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, -1);
      expect(await getSelectedDate(page)).toBe('December 20, 2020');
    });

    it('to next week', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, 7);
      expect(await getSelectedDate(page)).toBe('December 28, 2020');
    });

    it('to previous week', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, -7);
      expect(await getSelectedDate(page)).toBe('December 14, 2020');
    });

    it('to next month with week navigation', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="28/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 28, 2020');
      await setKeyboardNav(page, 7);
      expect(await getSelectedDate(page)).toBe('January 1, 2021');
    });

    it('to next month with day navigation', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="31/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 31, 2020');
      await setKeyboardNav(page, 7);
      expect(await getSelectedDate(page)).toBe('January 1, 2021');
    });

    it('only if date picker is open', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="28/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await setKeyboardNav(page, 7);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 28, 2020');
    });

    it('to skip over disable date', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="25/12/2020" disable-weekends></agl-ds-beta-date-picker-do-not-use>`
      );
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 25, 2020');
      await setKeyboardNav(page, 1);
      expect(await getSelectedDate(page)).toBe('December 28, 2020');
    });

    it('to next month', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, 1, 'Shift');
      expect(await getSelectedDate(page)).toBe('January 1, 2021');
    });

    it('to previous month', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, -1, 'Shift');
      expect(await getSelectedDate(page)).toBe('November 30, 2020');
    });

    it('to next year', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, 1, 'Alt');
      expect(await getSelectedDate(page)).toBe('December 1, 2021');
    });

    it('to previous year', async () => {
      const page = await newE2EPage();
      await page.setContent(`<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020"></agl-ds-beta-date-picker-do-not-use>`);
      await openDatePicker(page);
      expect(await getSelectedDate(page)).toBe('December 21, 2020');
      await setKeyboardNav(page, -1, 'Alt');
      expect(await getSelectedDate(page)).toBe('December 31, 2019');
    });
  });

  describe('should allow invalid dates', () => {
    it('not publish event if flag not set', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" min-date="18/12/2020"></agl-ds-beta-date-picker-do-not-use>`
      );
      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, -1, 'Alt');
      expect(errorOnInput).toHaveReceivedEventTimes(0);
    });

    it('publish event for min date error', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" min-date="18/12/2020" allow-invalid-entry-and-selection></agl-ds-beta-date-picker-do-not-use>`
      );

      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, -1, 'Alt');
      expect(errorOnInput).toHaveReceivedEventDetail({
        compareAgainst: '18/12/2020',
        type: 'minDate'
      });
    });

    it('publish event for max date error', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" max-date="26/12/2020" allow-invalid-entry-and-selection></agl-ds-beta-date-picker-do-not-use>`
      );

      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, 7);
      expect(await getSelectedDate(page)).toBe('December 28, 2020');
      expect(errorOnInput).toHaveReceivedEventDetail({
        compareAgainst: '26/12/2020',
        type: 'maxDate'
      });
    });

    it('publish event for disabled date error', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" disabled-dates="22/12/2020" allow-invalid-entry-and-selection></agl-ds-beta-date-picker-do-not-use>`
      );

      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, 1);
      expect(await getSelectedDate(page)).toBe('December 22, 2020');
      expect(errorOnInput).toHaveReceivedEventDetail({
        compareAgainst: '22/12/2020',
        type: 'disabledDates'
      });
    });

    it('publish event for disable weekend error', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" enabled-dates="21/12/2020" allow-invalid-entry-and-selection></agl-ds-beta-date-picker-do-not-use>`
      );

      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, 7);
      expect(errorOnInput).toHaveReceivedEventDetail({
        compareAgainst: '21/12/2020',
        type: 'enabledDates'
      });
    });

    it('publish event for disabled wekeend error', async () => {
      const page = await newE2EPage();
      await page.setContent(
        `<agl-ds-beta-date-picker-do-not-use default-value="21/12/2020" disable-weekends allow-invalid-entry-and-selection></agl-ds-beta-date-picker-do-not-use>`
      );

      const errorOnInput = await (await page.find(`agl-ds-beta-date-picker-do-not-use`)).spyOnEvent('errorOnInput');
      await openDatePicker(page);
      await setKeyboardNav(page, -1);
      expect(errorOnInput).toHaveReceivedEventDetail({
        compareAgainst: null,
        type: 'disabledDates'
      });
    });
  });
});

const isCalendarVisible = async (page: E2EPage): Promise<boolean> => {
  return await page.evaluate(() => {
    const element = document.querySelector(`agl-ds-beta-date-picker-do-not-use`).shadowRoot.querySelector('.flatpickr-calendar');
    const style = getComputedStyle(element);
    return style.display === 'block';
  });
};

const openDatePicker = async (page: E2EPage): Promise<void> => {
  const datePickerIcon: any = await page.find(`agl-ds-beta-date-picker-do-not-use >>> .agl-ds-textbox-default__suffix-icon`);
  await datePickerIcon.click();
};

const getSelectedDate = async (page: E2EPage): Promise<string> => {
  return await page.evaluate(() => {
    const element = document.querySelector(`agl-ds-beta-date-picker-do-not-use`).shadowRoot.querySelector('.selected');
    return element.getAttribute('aria-label');
  });
};

const setSelectedDateAsNextDay = async (page: E2EPage): Promise<void> => {
  await page.evaluate(() => {
    const element: HTMLElement = document
      .querySelector(`agl-ds-beta-date-picker-do-not-use`)
      .shadowRoot.querySelector('[aria-label="December 22, 2020"]');
    return element.click();
  });
};

const isWeekendDisabled = async (page: E2EPage): Promise<boolean> => {
  return await page.evaluate(() => {
    const element: HTMLElement = document
      .querySelector(`agl-ds-beta-date-picker-do-not-use`)
      .shadowRoot.querySelector('[aria-label="December 26, 2020"]');
    return element.classList.contains('flatpickr-disabled');
  });
};

const isDisableDateGreyedOut = async (page: E2EPage): Promise<boolean> => {
  return await page.evaluate(() => {
    const element: HTMLElement = document
      .querySelector(`agl-ds-beta-date-picker-do-not-use`)
      .shadowRoot.querySelector('[aria-label="December 11, 2020"]');
    return element.classList.contains('flatpickr-disabled');
  });
};

const isDateDisabled = async (page: E2EPage, dateValue: string): Promise<boolean> => {
  return await page.evaluate((ariaLabel) => {
    const element: HTMLElement = document
      .querySelector(`agl-ds-beta-date-picker-do-not-use`)
      .shadowRoot.querySelector(`[aria-label="${ariaLabel}"]`);
    return element.classList.contains('flatpickr-disabled');
  }, dateValue);
};

const setKeyboardNav = async (page: E2EPage, delta: number, comboKey?: string): Promise<void> => {
  if (comboKey) {
    page.keyboard.down(comboKey);
  }
  if (delta === 1) {
    await page.keyboard.press('ArrowRight');
  } else if (delta === -1) {
    await page.keyboard.press('ArrowLeft');
  } else if (delta === 7) {
    await page.keyboard.press('ArrowDown');
  } else if (delta === -7) {
    await page.keyboard.press('ArrowUp');
  }

  await page.keyboard.press('Enter');
};
