import { formatDate, parseDate } from './flatpickr.utils';

describe('Util', () => {
  it('should Parse date', () => {
    const dateToCompare: Date = stringToDate('17/9/2014', 'dd/MM/yyyy', '/');
    const dateActual: Date = parseDate('17/9/2014', 'd/m/Y');
    expect(dateToCompare.getTime()).toBe(dateActual.getTime());
  });

  it('should format date', () => {
    const dateToCompare: Date = stringToDate('17/9/2014', 'dd/MM/yyyy', '/');
    const stringActual: string = formatDate(dateToCompare, 'd/m/Y');
    expect(stringActual).toBe('17/09/2014');
  });
});

function stringToDate(date: string, format: string, delimiter: string): Date {
  const formatLowerCase = format.toLowerCase();
  const formatItems = formatLowerCase.split(delimiter);
  const dateItems = date.split(delimiter);
  const monthIndex = formatItems.indexOf('mm');
  const dayIndex = formatItems.indexOf('dd');
  const yearIndex = formatItems.indexOf('yyyy');
  let month = parseInt(dateItems[monthIndex]);
  month -= 1;
  const formatedDate = new Date(Number(dateItems[yearIndex]), month, Number(dateItems[dayIndex]));
  return formatedDate;
}
