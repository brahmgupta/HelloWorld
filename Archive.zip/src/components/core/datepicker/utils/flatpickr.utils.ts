import { DateOption } from 'flatpickr/dist/types/options';
import flatpickr from 'flatpickr';

export function parseDate(date: DateOption, format: string = 'd/m/Y', timeless?: boolean): Date | undefined {
  return flatpickr.parseDate(date, format, timeless);
}

export function formatDate(date: Date, format: string): string {
  return flatpickr.formatDate(date, format);
}
