import { Component, h, Prop, Host, Element, ComponentInterface } from '@stencil/core';
import { FontType, Appearance, FontSizes, BottomMargin } from '../../../global/component.types';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';

@Component({
  tag: 'agl-ds-p',
  styleUrl: 'paragraph.component.scss',
  shadow: true
})
export class ParagraphComponent implements ComponentInterface {
  @Element() host: HTMLAglDsPElement;

  /**
   * Determines the over-ride size of the text
   */
  @Prop() styledAs: FontSizes = 'md';

  /**
   * Determines the over-ride font
   */
  @Prop() font: FontType = 'fontfamily02';

  /**
   * Determines the over-ride font colour
   */
  @Prop() appearance: Appearance = 'default';

  /**
   * Determines the over-ride bottom margin size
   */
  @Prop() bottomMargin: BottomMargin = null;

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-p', 'agl-ds-text', 'agl-ds-link', 'slot', 'agl-ds-tooltip', 'span']);
  }

  render() {
    if (!(['display01', 'display02', 'inherit', 'lg', 'md', 'sm', 'xl', 'xs'] as FontSizes[]).includes(this.styledAs)) {
      throw new Error(this.styledAs + ' is not a valid font size');
    }

    if (!(['fontfamily01', 'fontfamily02'] as FontType[]).includes(this.font)) {
      throw new Error(this.font + ' is not a valid font type');
    }

    if (
      this.appearance &&
      !(['default', 'highlight', 'inverse', 'muted', 'secondary-highlight'] as Appearance[]).includes(this.appearance)
    ) {
      throw new Error(this.appearance + ' is not a valid font colour');
    }

    return (
      <Host>
        <p
          class={{
            ['agl-ds-' + this.styledAs]: true,
            ['agl-ds-' + this.font]: true,
            ['agl-ds-' + this.appearance + '-colour']: true,
            ['agl-ds--bottom-margin-' + this.bottomMargin]: !!this.bottomMargin
          }}
        >
          <slot />
        </p>
      </Host>
    );
  }
}
