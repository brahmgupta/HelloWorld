import { newSpecPage } from '@stencil/core/testing';
import { BottomMargin } from '../../../global/component.types';
import { ParagraphComponent } from './paragraph.component';

describe('paragraph component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: `<agl-ds-p>dummy text</agl-ds-p>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
        <agl-ds-p>
          <mock:shadow-root>
            <p class="agl-ds-default-colour agl-ds-fontfamily02 agl-ds-md">
              <slot></slot>
            </p>
          </mock:shadow-root>
          dummy text
        </agl-ds-p>
    `);
  });

  it('should render the component with a p tag and styled with xl font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p styled-as="xl">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-xl');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a p tag and styled with lg font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p styled-as="lg">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-lg');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a p tag and styled with md font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p styled-as="md">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-md');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a p tag and styled with sm font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p styled-as="sm">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-sm');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a p tag and styled with xs font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p styled-as="xs">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-xs');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the default font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p>dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-fontfamily02');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the alternate font', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p font="fontfamily01">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-fontfamily01');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the default colour', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p>dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-default-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the muted colour', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p appearance="muted">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-muted-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the highlighted colour', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p appearance="highlight">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-highlight-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the inverse colour', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p appearance="inverse">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds-inverse-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the bottom margin suppressed', async () => {
    const page = await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p  bottom-margin="none">dummy text</agl-ds-p>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('p');
    const classList = element.classList.contains('agl-ds--bottom-margin-none');
    expect(classList).toBeTruthy();
  });

  (['none', 'space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'] as BottomMargin[]).map((margin) => {
    it('should render the component with the correct bottom margin', async () => {
      const page = await newSpecPage({
        components: [ParagraphComponent],
        html: `<agl-ds-p bottom-margin="${margin}">dummy text</agl-ds-p>`,
        supportsShadowDom: false
      });
      const element = await page.doc.querySelector('p');
      const classList = element.classList.contains(`agl-ds--bottom-margin-${margin}`);
      expect(classList).toBeTruthy();
    });
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [ParagraphComponent],
      html: `<agl-ds-p><agl-ds-text>dummy text</agl-ds-text><agl-ds-link>dummy text</agl-ds-link></agl-ds-p>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [ParagraphComponent],
      html: '<agl-ds-p><p>dummy text</p></agl-ds-p>',
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
