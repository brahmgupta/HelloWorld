# agl-ds-p



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                 | Type                                                                                                | Default          |
| -------------- | --------------- | ------------------------------------------- | --------------------------------------------------------------------------------------------------- | ---------------- |
| `appearance`   | `appearance`    | Determines the over-ride font colour        | `"default" \| "highlight" \| "inverse" \| "muted" \| "secondary-highlight"`                         | `'default'`      |
| `bottomMargin` | `bottom-margin` | Determines the over-ride bottom margin size | `"none" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space05" \| "space06"` | `null`           |
| `font`         | `font`          | Determines the over-ride font               | `"fontfamily01" \| "fontfamily02"`                                                                  | `'fontfamily02'` |
| `styledAs`     | `styled-as`     | Determines the over-ride size of the text   | `"display01" \| "display02" \| "inherit" \| "lg" \| "md" \| "sm" \| "xl" \| "xs"`                   | `'md'`           |


## Dependencies

### Used by

 - [agl-ds-day-of-month-picker](../day-of-month-picker)
 - [agl-ds-feature-card](../../composite/icon-text-card/feature-card)
 - [agl-ds-feature-item](../../composite/icon-text-card/feature-item)
 - [agl-ds-grid-example](../../layout/grid)
 - [agl-ds-guided-banner](../../composite/banner/guided-banner)
 - [agl-ds-illustration-text-simple](../../composite/illustration-text/simple)
 - [agl-ds-navigation-card](../../composite/navigation-card)
 - [agl-ds-next-steps-item](../next-steps/next-steps-item)
 - [agl-ds-notification](../../composite/notification-card)
 - [agl-ds-prefooter](../../composite/icon-text-card/prefooter)
 - [agl-ds-promo-card](../../composite/icon-text-card/promo-card)
 - [agl-ds-stepper](../../composite/stepper)

### Graph
```mermaid
graph TD;
  agl-ds-day-of-month-picker --> agl-ds-p
  agl-ds-feature-card --> agl-ds-p
  agl-ds-feature-item --> agl-ds-p
  agl-ds-grid-example --> agl-ds-p
  agl-ds-guided-banner --> agl-ds-p
  agl-ds-illustration-text-simple --> agl-ds-p
  agl-ds-navigation-card --> agl-ds-p
  agl-ds-next-steps-item --> agl-ds-p
  agl-ds-notification --> agl-ds-p
  agl-ds-prefooter --> agl-ds-p
  agl-ds-promo-card --> agl-ds-p
  agl-ds-stepper --> agl-ds-p
  style agl-ds-p fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
