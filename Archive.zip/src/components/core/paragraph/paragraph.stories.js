import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Paragraph'
};

export const P = () => html`
  <agl-ds-p
    styled-as="${select('styled as', ['xs', 'sm', 'md', 'lg', 'xl'], 'md')}"
    font="${select('font family', ['fontfamily01', 'fontfamily02'], 'fontfamily01')}"
    appearance="${select('appearance', ['default', 'muted', 'highlight', 'inverse', 'secondary-highlight'], 'default')}"
    bottom-margin="${select(
      'bottom margin',
      ['', 'none', 'space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'],
      ''
    )}"
  >
    ${text('body text', "I'm an example of body text")}.
  </agl-ds-p>
  Sample text to show bottom padding
`;

P.storyName = 'p';
P.parameters = { notes };
