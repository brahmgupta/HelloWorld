export type ContainerSize = 'sm' | 'md' | 'lg' | 'auto';

export type TrustedHTMLFontSizes = 'xs' | 'sm' | 'md';

export type BackgroundColor = 'none' | 'fill';

export type ContainerBorder = 'all' | 'none' | 'suppress-bottom';
