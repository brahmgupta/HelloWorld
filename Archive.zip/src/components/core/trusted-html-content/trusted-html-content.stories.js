import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Trusted html content component'
};

export const Default = () => {
  const styles = 'font-family:courier; font-weight:900; font-size:13px; color:blue';
  return html`<div style="padding:60px; font-family:'Open Sans', sans-serif; line-height:22px;">
      <h2>Disclaimer</h2>
      <br />This component is designed to modify the styles of trusted content passed into the slot. Only a basic set of HTML tags will be
      restyled to comply with the Design System. As it is primarily used to consume content from an RTE it is the content authors
      responsibility to ensure that only the basic html tags covered in this component are used. Acceptable HTML tags as as follows:<br /><br />
      <ul style=" list-style-type: disc; margin-left: 32px;">
        <li>h2-h6</li>
        <li>p</li>
        <li>span</li>
        <li>a</li>
        <li>b</li>
        <li>strong</li>
        <li>i</li>
        <li>ol</li>
        <li>ul</li>
        <li>table</li>
        <li>th</li>
        <li>tr</li>
        <li>td</li>
        <li>img</li>
      </ul>
      <br /><br />
      It should also be noted that it should consume only trusted HTML<br /><br />
    </div>
    <div style="padding:0 60px;">
      <p style="${styles}">Here is the p tag outside of the agl-ds-trusted-html-content that has inline style of "${styles}".</p>
      <p style="${styles}">
        All tags within the container have the same inline styles applied to show how they have been 'over-ridden' by the component styles
      </p>
    </div>
    <div style="margin: 60px;">
      Example 1
      <agl-ds-trusted-html-content
        styled-as="${select('styled as', ['xs', 'sm', 'md'], 'xs')}"
        background-color="${select('background color', ['none', 'fill'], 'none')}"
        container-border="${select('container border', ['all', 'none', 'suppress-bottom'], 'all')}"
        container-size="${select('container size', ['sm', 'md', 'lg', 'auto'], 'lg')}"
      >
        <h2 style="${styles}">heading 2 with some more text</h2>
        <h3 style="${styles}">heading 3 with some more text</h3>
        <h4 style="${styles}">heading 4 with some more text</h4>
        <h5 style="${styles}">heading 5 with some more text</h5>
        <h6 style="${styles}">heading 6 with some more text</h6>
        <p style="${styles}">p tag with some more text</p>
        <span style="${styles}">span tag with some more text</span><br />
        <b style="${styles}">b tag with some more text</b><br />
        <a href="https://www.agl.com.au" style="${styles}">a tag with some more text</a><br />
        <strong style="${styles}"> strong tag with some more text</strong><br />
        <i style="${styles}"> i tag with some more text</i><br />
        <ul style="${styles}">
          <li>un-ordered list 1</li>
          <li>un-ordered list 2</li>
          <li>un-ordered list 3</li>
        </ul>
        <ol style="${styles}">
          <li>ordered list 1</li>
          <li>ordered list 2</li>
          <li>ordered list 3</li>
        </ol>
        <table style="${styles}">
          <tr>
            <th>table header</th>
          </tr>
          <tr>
            <td>table cell</td>
          </tr>
        </table>

        <img
          aria-hidden="true"
          src="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
        />
      </agl-ds-trusted-html-content>
    </div>

    <div style="margin: 60px;">
      Example 2 (real content from AEM)
      <agl-ds-trusted-html-content
        styled-as="${select('styled as 2', ['xs', 'sm', 'md'], 'xs')}"
        background-color="${select('background color 2', ['none', 'fill'], 'none')}"
        container-border="${select('container border 2', ['all', 'none', 'suppress-bottom'], 'all')}"
        container-size="${select('container size 2', ['sm', 'md', 'lg', 'auto'], 'md')}"
      >
        <div id="ddTermsAndConditionsContent" class="tmp-terms-and-conditions">
          <p><b>Direct Debit Arrangement and Service Agreement (AGL)</b></p>
          <p>
            By providing your payment method details to us (AGL), you accept and understand that these terms and conditions (<b
              >Terms and Conditions</b
            >) apply to your requested and authorised payment arrangement (<b>Direct Debit arrangement</b>) and you authorise your financial
            institution or any other payment service provider and AGL (User ID’s 348045, 348041, 373578, 23237282, 23237324, 23426448,
            23836422, 23836414, 23836406, 409321, 409312 and 409310) to arrange for funds to be debited from your relevant account in
            payment of amounts you owe to AGL from time to time (unless and until you cancel your Direct Debit arrangement). AGL is
            authorised to use your Direct Debit arrangement in accordance with these Terms and Conditions.
          </p>
          <p>
            You should contact your financial institution or any other payment service provider if you are uncertain about providing your
            payment authority to us.
          </p>
          <p>&nbsp;</p>
          <p><b>Terms and conditions</b></p>
          <ol>
            <li>
              AGL is authorised to use your nominated payment method to arrange the payment of amounts due and payable to AGL by you until
              your Direct Debit arrangement is cancelled or terminated in accordance with these Terms and Conditions.
            </li>
            <li>
              Your authorised payment method details will be securely stored by AGL, and may be used by AGL, in accordance with the AGL
              Stored Payment Method terms and conditions available at
              <a
                href="https://www.agl.com.au/terms-conditions/stored-payment-method?cidi=A10769"
                target="_blank"
                title="Stored Payment Method Terms and conditions"
                >agl.com.au/spmterms</a
              >
            </li>
            <li>This service is not available for use in making payments from some passbook savings accounts.&nbsp;</li>
            <li>
              If your Direct Debit arrangement relies on a credit card or debit card, it can only be a Visa or MasterCard credit card or
              debit card (as applicable) and you authorise AGL to request payment from your nominated card account, using your current card
              and any replacement or substitute of that card from time to time. If your credit card or debit card has reached its expiry
              date, you should still provide AGL with your new details at least three business days prior to the next payment due date.
            </li>
            <li>Bank transaction fees and Government taxes may apply.</li>
            <li>
              Payment obligations falling on a non-business day will be processed using your Direct Debit arrangement on the next business
              day. If you are uncertain as to when a debit will be processed by your financial institution or any other payment service
              provider, you may contact them directly.
            </li>
            <li>
              If sufficient funds are not available in your nominated payment method account at the time of processing a payment, a
              dishonour fee may be charged by your financial institution or any other payment service provider to cover reasonable
              administrative and processing costs. It is your responsibility to ensure that you have sufficient funds available in your
              nominated payment method account by the due date for the payment of any bill payable to AGL.
            </li>
            <li>
              AGL may terminate your Direct Debit arrangement if two consecutive payments are refused by your financial institution or any
              other payment service provider. You must then pay your bills using another payment method available to you and accepted by
              AGL.
            </li>
            <li>
              If you wish to change your Direct Debit arrangement (including your payment details), you must provide AGL with a new Direct
              Debit arrangement at least three business days prior to when the next bill is due to be paid.
            </li>
            <li>
              To cancel or terminate your Direct Debit arrangement you must notify AGL, your financial institution or any other payment
              service provider, at least three business days prior to when your next payment is due. If you cancel your Direct Debit
              arrangement, or debit item, by notifying your financial institution or any other payment service provider, you must use your
              best endeavours to notify AGL as soon as practicable after the cancellation.
            </li>
            <li>
              If you request us to cancel your Direct Debit arrangement and do not provide us with a new Direct Debit arrangement, we will
              terminate your Direct Debit arrangement within three Business Days of being notified of your cancellation request.
            </li>
            <li>
              If you are leaving AGL, a final bill will be sent to you and the amount due will be debited using your Direct Debit
              arrangement.
            </li>
            <li>AGL may vary these Terms and Conditions at any time on not less than 14 days' notice.</li>
            <li>
              AGL reserves the right, at any time, to withdraw this payment arrangement or stop or change a Direct Debit arrangement with 15
              days prior notice. In the event that AGL ceases to trade, all Direct Debit arrangements will be cancelled immediately and both
              you and your financial institution or payment service provider will be notified.
            </li>
            <li>
              You should check your account statements from your financial institution or any other payment service provider. Contact AGL
              Battery Support team on &lt;<b>1300 337 118</b>&gt; &lt;<b>8.30am - 5pm AEST, Monday - Friday</b>&gt; for assistance or if you
              have a dispute about any payment or arrangement details. We will investigate the dispute and provide our response within 20
              business days. You may also raise your dispute with your financial institution or any other payment service provider.
            </li>
          </ol>
          <p><b>Privacy</b></p>
          <ul>
            <li>
              The personal information collected by AGL under these Terms and Conditions is required to set up your Direct Debit
              arrangement. Failure to provide the information will mean AGL is unable to complete your request to set up your Direct Debit
              arrangement.
            </li>
            <li>
              Details of your Direct Debit arrangement, including your Direct Debit arrangement details (which are tokenised in the case of
              credit and debit cards), may be used in connection with your payment for products and services that AGL makes available to
              you.
            </li>
            <li>
              Your personal information will be handled in accordance with AGL's Privacy Policy or otherwise as required or authorised by
              law, or as consented to by you. All Direct Debit arrangement details will be held securely by AGL and handled in accordance
              with AGL's Privacy Policy which includes AGL's Credit Reporting Policy and can be accessed at
              <a title="Privacy Policy" href="https://www.agl.com.au/privacy-policy?cidi=A10770" target="_blank"
                >agl.com.au/privacy-policy</a
              >
            </li>
          </ul>
          <p><b>AGL Stored Payment Method Terms and Conditions</b></p>
          <p>
            You agree to allow AGL to use, disclose and store any of your details collected by AGL under these Terms and Conditions in
            accordance with the AGL Stored Payment Method terms and conditions available at
            <a
              href="https://www.agl.com.au/terms-conditions/stored-payment-method?cidi=A10769"
              target="_blank"
              title="Stored Payment Terms and conditions"
              >agl.com.au/spmterms</a
            >
          </p>
          <p><b>Additional Terms and Conditions for Bill Smoothing</b></p>
          <p>
            The Terms and Conditions relating to your Bill Smoothing arrangement will continue to apply. If you would like to view the full
            Bill Smoothing Terms and Conditions, head to
            <a
              title="Bill Smoothing Terms and conditions"
              href="https://www.agl.com.au/terms-conditions/bill-smoothing-residential?cidi=A10771"
              target="_blank"
              >agl.com.au/smoothingterms</a
            >
          </p>
        </div>
      </agl-ds-trusted-html-content>
    </div> `;
};

Default.storyName = 'Trusted html content component';
Default.parameters = { notes };
