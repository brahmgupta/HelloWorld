# agl-ds-trusted-html-content



<!-- Auto Generated Below -->


## Properties

| Property          | Attribute          | Description                                             | Type                                   | Default  |
| ----------------- | ------------------ | ------------------------------------------------------- | -------------------------------------- | -------- |
| `backgroundColor` | `background-color` | Determines the background colour of the container       | `"fill" \| "none"`                     | `'none'` |
| `containerBorder` | `container-border` | Determines which of the container borders are displayed | `"all" \| "none" \| "suppress-bottom"` | `'all'`  |
| `containerSize`   | `container-size`   | Determines the size of the container                    | `"auto" \| "lg" \| "md" \| "sm"`       | `'sm'`   |
| `styledAs`        | `styled-as`        | Determines the over-ride size of the text               | `"md" \| "sm" \| "xs"`                 | `'md'`   |


## Events

| Event             | Description                   | Type                   |
| ----------------- | ----------------------------- | ---------------------- |
| `containerScroll` | Fires when the onScroll event | `CustomEvent<UIEvent>` |


## Slots

| Slot                                                                                                               | Description |
| ------------------------------------------------------------------------------------------------------------------ | ----------- |
| `"The trusted HTML content placed in this slot will be re-styled according to the component/Design System styles"` |             |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
