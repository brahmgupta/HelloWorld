import { newSpecPage } from '@stencil/core/testing';
import { TrustedHTMLContentComponent } from './trusted-html-content.component';

describe('Trusted HTML content component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-trusted-html-content>
      <div class="trusted-content-container trusted-content-container-background-color__none trusted-content-container-container-border__all trusted-content-container-font-size__md trusted-content-container-size__sm">
        <p>
          dummy text
        </p>
      </div>
    </agl-ds-trusted-html-content>
    `);
  });

  it('should render the component with the contents styled as xs', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content styled-as="xs"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-font-size__xs');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the contents styled as sm', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content styled-as="sm"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-font-size__sm');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the contents styled as md', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content styled-as="md"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-font-size__md');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a small container', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content container-size="sm"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-size__sm');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a medium container', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content container-size="md"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-size__md');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a large container', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content container-size="lg"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-size__lg');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a auto container', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content container-size="auto"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-size__auto');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the container having a background colour', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content  background-color="fill"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-background-color__fill');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the container having the bottom border suppressed', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content  background-color="fill"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-background-color__fill');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the container having all borders suppressed', async () => {
    const page = await newSpecPage({
      components: [TrustedHTMLContentComponent],
      html: `<agl-ds-trusted-html-content  background-color="none"><p>dummy text</p></agl-ds-trusted-html-content>`,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('div');
    const classList = element.classList.contains('trusted-content-container-background-color__none');
    expect(classList).toBeTruthy();
  });
});
