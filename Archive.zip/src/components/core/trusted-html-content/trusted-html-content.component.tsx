import { Component, h, Host, Prop, EventEmitter, Event, ComponentInterface } from '@stencil/core';
import { ContainerSize, TrustedHTMLFontSizes, BackgroundColor, ContainerBorder } from './trusted-html-content.types';

/**
 *@slot The trusted HTML content placed in this slot will be re-styled according to the component/Design System styles
 */

@Component({
  tag: 'agl-ds-trusted-html-content',
  styleUrl: 'trusted-html-content.component.scss',
  shadow: false
})
export class TrustedHTMLContentComponent implements ComponentInterface {
  /**
   * Determines the over-ride size of the text
   */
  @Prop() styledAs: TrustedHTMLFontSizes = 'md';

  /**
   * Determines the size of the container
   */
  @Prop() containerSize: ContainerSize = 'sm';

  /**
   * Determines the background colour of the container
   */
  @Prop() backgroundColor: BackgroundColor = 'none';

  /**
   * Determines which of the container borders are displayed
   */
  @Prop() containerBorder: ContainerBorder = 'all';

  /**
   * Fires when the onScroll event
   */
  @Event() containerScroll: EventEmitter<UIEvent>;

  private handleScrollEvent = (event: UIEvent): void => {
    this.containerScroll.emit(event);
  };

  render() {
    return (
      <Host>
        <div
          onScroll={(event: UIEvent) => {
            this.handleScrollEvent(event);
          }}
          class={{
            'trusted-content-container': true,
            ['trusted-content-container-font-size__' + this.styledAs]: true,
            ['trusted-content-container-size__' + this.containerSize]: true,
            ['trusted-content-container-background-color__' + this.backgroundColor]: true,
            ['trusted-content-container-container-border__' + this.containerBorder]: true
          }}
        >
          <slot />
        </div>
      </Host>
    );
  }
}
