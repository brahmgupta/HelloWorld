import { Component, Host, Element, Event, EventEmitter, Prop, State, h, ComponentInterface } from '@stencil/core';
import { generateRandomNumber, hideFocusRingWhenUsingMouse, resizeSVGsForEdge } from '../../../global/utils/utils';
import iconClose from '../../../assets/icon-close.svg';
import { FontType } from '../../../global/component.types';

@Component({
  tag: 'agl-ds-accordion',
  styleUrl: 'accordion.component.scss',
  shadow: true
})
export class AccordionComponent implements ComponentInterface {
  /**
   * internalised Unique ID for the binding Accordion button to its panel
   */
  private uniqueID: string = generateRandomNumber();
  private svgSpan: HTMLSpanElement;

  /**
   * Text to display on the Accordion button
   */
  @Prop() accordionLabel: string;

  /**
   * Toggle accordion initial state to expanded
   */
  @Prop() isActiveAccordion: boolean = false;
  /**
   * Display a bottom border on the accordion panel when open. The last Accordion item should have this set to true
   */
  @Prop() isLastAccordion: boolean = false;

  /**
   * The font family of the accordion label
   */
  @Prop() labelFont: FontType = 'fontfamily02';

  /**
   * Track state changes (I.e. whether the Accordion component is open or closed)
   */
  @State() toggle: boolean = false;

  /**
   * Track component events (I.e. activation of Accordion component)
   */
  @Event() toggleEvent: EventEmitter;

  /**
   *this component as HTML Element
   */
  @Element() hostElement: HTMLAglDsAccordionElement;

  /**
   * Set default accordion expanded based on isActiveAccordion property value
   */
  componentDidLoad() {
    if (this.isActiveAccordion) {
      this.toggle = !this.toggle;
      this.adjustHeight('acc-' + this.uniqueID);
    }
    hideFocusRingWhenUsingMouse(this.inputElement);
    resizeSVGsForEdge(this.svgSpan, '16', '16', '16', '16', '16', '16');

    if (String(this.labelFont) !== 'null' && !(['fontfamily01', 'fontfamily02'] as FontType[]).includes(this.labelFont)) {
      throw new Error(this.labelFont + ' is not a valid font type');
    }
  }

  private inputElement: HTMLButtonElement;
  /**
   * This will manage the accordion component event and state changes
   */
  private toggleComponent(id: string): void {
    this.toggle = !this.toggle;
    // When the user click emit the toggle state value
    // A event can emit any type of value
    this.toggleEvent.emit({ visible: this.toggle });

    this.adjustHeight(id);
  }

  /**
   * Adjust the height of the accordion panel based on the scroll height of the slotted content, used in expand/collapse animation
   */
  private adjustHeight(id: string): void {
    const panel = this.hostElement.shadowRoot.querySelector('#' + id);
    const panelChild = this.hostElement.querySelector('[slot="panel-content"]');

    if (this.toggle) {
      panel.setAttribute(
        'style',
        'max-height: ' +
          (panelChild && panelChild.scrollHeight) +
          'px; overflow: visible; transition: max-height 0.5s ease-out, visibility 0.5s step-end;'
      );
    } else {
      panel.setAttribute('style', 'max-height: 0;');
    }
  }

  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    return (
      <Host>
        <div class="accordion">
          <button
            ref={(el) => (this.inputElement = el)}
            id={'btn_acc-' + this.uniqueID}
            aria-controls={'acc-' + this.uniqueID}
            class={{
              'accordion-button': true,
              active: this.toggle,
              'is-last-accordion': this.isLastAccordion && !this.toggle
            }}
            aria-expanded={this.toggle ? 'true' : 'false'}
            onClick={() => this.toggleComponent('acc-' + this.uniqueID)}
          >
            <span
              class={{
                'accordion-label': true,
                ['agl-ds-' + this.labelFont]: true
              }}
            >
              {this.accordionLabel}
            </span>
            <span class={{ 'accordion-icon': true, expanded: this.toggle, collapsed: !this.toggle }}>
              <span ref={(el) => (this.svgSpan = el)} aria-hidden="true" innerHTML={iconClose} />
            </span>
          </button>

          <div
            id={'acc-' + this.uniqueID}
            aria-labelledby={'btn_acc-' + this.uniqueID}
            class={{ 'accordion-panel': true, active: this.toggle, 'is-last-accordion': this.isLastAccordion }}
            role="region"
          >
            <slot name="panel-content" />
          </div>
        </div>
      </Host>
    );
  }
}
