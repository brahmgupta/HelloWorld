jest.doMock('../../../global/utils/utils', () => {
  return {
    generateRandomNumber: () => 52,
    hideFocusRingWhenUsingMouse: () => null,
    resizeSVGsForEdge: () => null
  };
});

import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { AccordionComponent } from './accordion.component';

describe('accordion component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [AccordionComponent],
      html: `<agl-ds-accordion></agl-ds-accordion>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-accordion>
			<mock:shadow-root>
				<div class="accordion">
					<button id="btn_acc-52" aria-controls="acc-52" class="accordion-button" aria-expanded="false">
						<span class="accordion-label agl-ds-fontfamily02"></span>
						<span class="accordion-icon collapsed">
              <span aria-hidden="true">
                svg contents from: src/assets/icon-close.svg
              </span>
						</span>
					</button>
					<div id="acc-52" aria-labelledby="btn_acc-52" class="accordion-panel" role="region">
						<slot name="panel-content"></slot>
					</div>
				</div>
				</mock:shadow-root>
		</agl-ds-accordion>`
    );
  });

  describe('pass details to display the accordion with correct attributes', () => {
    let page: SpecPage;
    let element;

    it('should present an accordion with correct ID on button', async () => {
      page = await newSpecPage({
        components: [AccordionComponent],
        html: '<agl-ds-accordion></agl-ds-accordion> ',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('button');
      expect(element.id).toEqual('btn_acc-52');
    });

    it('should present an accordion with correct ID on content panel', async () => {
      page = await newSpecPage({
        components: [AccordionComponent],
        html: '<agl-ds-accordion></agl-ds-accordion> ',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('.accordion-panel');
      expect(element.id).toEqual('acc-52');
    });

    it('should present an accordion with correct text on button', async () => {
      const text = 'Accordion Button';
      page = await newSpecPage({
        components: [AccordionComponent],
        html: '<agl-ds-accordion accordion-label="' + text + '"></agl-ds-accordion>',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('.accordion-label');
      expect(element.innerText).toEqual(text);
    });

    it('should present an accordion button with a bottom border', async () => {
      page = await newSpecPage({
        components: [AccordionComponent],
        html: '<agl-ds-accordion accordion-label="Acccordion label" is-last-accordion="true"></agl-ds-accordion>',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('button');
      const button = element.classList.contains('is-last-accordion');
      expect(button).toBeTruthy();
    });

    it('should present an accordion with the provided label style type', async () => {
      page = await newSpecPage({
        components: [AccordionComponent],
        html: '<agl-ds-accordion accordion-label="Accordion Button" label-font="fontfamily01"></agl-ds-accordion>',
        supportsShadowDom: false
      });
      element = await page.doc.querySelector('.accordion-label');
      const classList = element.classList.contains('agl-ds-fontfamily01');
      expect(classList).toBeTruthy();
    });
  });
});
