# agl-ds-accordion



<!-- Auto Generated Below -->


## Properties

| Property            | Attribute             | Description                                                                                                    | Type                               | Default          |
| ------------------- | --------------------- | -------------------------------------------------------------------------------------------------------------- | ---------------------------------- | ---------------- |
| `accordionLabel`    | `accordion-label`     | Text to display on the Accordion button                                                                        | `string`                           | `undefined`      |
| `isActiveAccordion` | `is-active-accordion` | Toggle accordion initial state to expanded                                                                     | `boolean`                          | `false`          |
| `isLastAccordion`   | `is-last-accordion`   | Display a bottom border on the accordion panel when open. The last Accordion item should have this set to true | `boolean`                          | `false`          |
| `labelFont`         | `label-font`          | The font family of the accordion label                                                                         | `"fontfamily01" \| "fontfamily02"` | `'fontfamily02'` |


## Events

| Event         | Description                                                     | Type               |
| ------------- | --------------------------------------------------------------- | ------------------ |
| `toggleEvent` | Track component events (I.e. activation of Accordion component) | `CustomEvent<any>` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
