import { boolean, text, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Accordion'
};

export const Accordion = () => html`
  <agl-ds-accordion
    id="storyshots-hook"
    accordion-label="${text('Accordion 1 label', 'Accordion One')}"
    is-active-accordion=${boolean('Is active Accordion 1', false)}
  >
    <div slot="panel-content">
      <p>1 tab panel text injected into slot</p>
      <p>2 tab panel text injected into slot</p>
      <p>3 tab panel text injected into slot</p>
      <p>4 tab panel text injected into slot</p>
      <p>5 tab panel text injected into slot</p>
    </div>
  </agl-ds-accordion>
  <agl-ds-accordion
    accordion-label="${text('Accordion 2 label', 'Accordion Two')}"
    label-font="${select('Accordion 2 label font', [null, 'fontfamily01', 'fontfamily02'], 'fontfamily02')}"
    is-active-accordion=${boolean('Is active Accordion 2', false)}
    is-last-accordion=${boolean('Is last Accordion', true)}
  >
    <div slot="panel-content">
      <p>1 tab panel text injected into slot</p>
      <p>2 tab panel text injected into slot</p>
      <p>3 tab panel text injected into slot</p>
      <p>4 tab panel text injected into slot</p>
      <p>5 tab panel text injected into slot</p>
    </div>
  </agl-ds-accordion>
`;

Accordion.parameters = {
  notes,
  axetest: {
    beforeAxeTestAsyncFunc: async (page) => {
      await storyPageManipulation(page);
    }
  },
  storyshots: {
    visualRegression: {
      screenshotHeight: 500,
      beforeScreenshotAsyncFunc: async (page) => {
        await storyPageManipulation(page);
      }
    }
  }
};

const storyPageManipulation = async (page) => {
  await page.waitForSelector('#storyshots-hook', { visible: true });
  await page.click('#storyshots-hook');
  await page.waitForTimeout(500); // wait for the animation to finish
};

const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule("agl-ds-accordion p {font-size: 16px; font-family: 'Open Sans',  sans-serif;}");
style.sheet.insertRule('agl-ds-accordion p:first-of-type {margin-top: 16px;}');
style.sheet.insertRule('agl-ds-accordion p:last-of-type {margin-bottom: 16px;}');
