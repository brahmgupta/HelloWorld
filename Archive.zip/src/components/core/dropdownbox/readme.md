# agl-ds-dropdownbox



<!-- Auto Generated Below -->


## Properties

| Property            | Attribute            | Description                                                                                                                                                      | Type                             | Default                  |
| ------------------- | -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------- | ------------------------ |
| `customOptions`     | --                   | The options for the dropdownbox passed in from consumer.  Use this prop where the available options for the drop down may change dynamically based on user input | `DropdownOptionProps[]`          | `[]`                     |
| `dropdownDirection` | `dropdown-direction` | The dropdown direction. set to up when the dropdown is at the bottom of the page.                                                                                | `"down" \| "dynamic" \| "up"`    | `'down'`                 |
| `hasError`          | `has-error`          | Flag to show error state                                                                                                                                         | `boolean`                        | `false`                  |
| `hintText`          | `hint-text`          | The hintText property for the dropdownbox                                                                                                                        | `string`                         | `''`                     |
| `label`             | `label`              | The label for the Drop down select input field                                                                                                                   | `string`                         | `''`                     |
| `selectId`          | `select-id`          | Unique ID for the label of the dropdown                                                                                                                          | `string`                         | `generateRandomNumber()` |
| `selectedValue`     | `selected-value`     | Sets the selected value of the radio button group                                                                                                                | `string`                         | `undefined`              |
| `type`              | `type`               | Type for the control, either default or default-inverse                                                                                                          | `"default" \| "default-inverse"` | `'default'`              |
| `validationText`    | `validation-text`    | The errorText property for the dropdownbox                                                                                                                       | `string`                         | `''`                     |
| `value`             | `value`              | The default selected value for the dropdownbox                                                                                                                   | `string`                         | `''`                     |


## Events

| Event                | Description                        | Type                               |
| -------------------- | ---------------------------------- | ---------------------------------- |
| `dropdownButtonBlur` | Fires when the trigger button blur | `CustomEvent<string>`              |
| `dropdownClosed`     | Fires when the dropdown is closed  | `CustomEvent<string>`              |
| `optionSelected`     | Fires when an option is selected   | `CustomEvent<DropdownOptionProps>` |


## Methods

### `clearSelectedValue() => Promise<void>`

Public method to clear selected value

#### Returns

Type: `Promise<void>`




## Slots

| Slot | Description                                                                                                                                    |
| ---- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
|      | The content placed in this slot must be a agl-ds-dropdown-option. The agl-ds-dropdown-option provides the data for this dropdownbox component. |


## Dependencies

### Used by

 - [agl-ds-manual-address-entry](../../composite/addresssearch/manual-address-entry)

### Depends on

- [agl-ds-dropdown-option](dropdownoption)
- [agl-ds-hint-validation-message](../hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-dropdownbox --> agl-ds-dropdown-option
  agl-ds-dropdownbox --> agl-ds-hint-validation-message
  agl-ds-manual-address-entry --> agl-ds-dropdownbox
  style agl-ds-dropdownbox fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
