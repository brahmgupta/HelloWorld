import { Component, ComponentInterface, Element, Event, EventEmitter, Host, Listen, Method, Prop, State, Watch, h } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';

import chevronDownIcon from '../../../assets/Icon-chevron-down.svg';
import { DropdownDirection } from './common/dropdownbox.types';
import { DropdownOptionProps } from './common/dropdownbox.model';
import { DropdownboxType } from './dropdownbox.types';

/**
 * @slot - The content placed in this slot must be a agl-ds-dropdown-option.
 * The agl-ds-dropdown-option provides the data for this dropdownbox component.
 */
@Component({
  tag: 'agl-ds-dropdownbox',
  styleUrl: 'dropdownbox.component.scss',
  shadow: false,
  scoped: true
})
export class DropdownBoxComponent implements ComponentInterface {
  @Element() host: HTMLAglDsDropdownboxElement;

  /**
   * Unique ID for the label of the dropdown
   */
  @Prop() selectId: string = generateRandomNumber();

  /**
   * The label for the Drop down select input field
   */
  @Prop() label: string = '';

  /**
   * The hintText property for the dropdownbox
   */
  @Prop() hintText: string = '';

  /**
   * The errorText property for the dropdownbox
   */
  @Prop() validationText: string = '';

  /**
   * Flag to show error state
   */

  @Prop() hasError: boolean = false;

  /**
   * The default selected value for the dropdownbox
   */
  @Prop() value: string = '';

  /**
   * Sets the selected value of the radio button group
   */
  @Prop({ mutable: true }) selectedValue: string;

  /**
   * The dropdown direction. set to up when the dropdown is at the bottom of the page.
   */
  @Prop() dropdownDirection: DropdownDirection = 'down';

  /**
   * Type for the control, either default or default-inverse
   */
  @Prop() type: DropdownboxType = 'default';
  /**
   * The options for the dropdownbox passed in from consumer.  Use this prop where the available options for the drop down may change dynamically based on user input
   */
  @Prop() customOptions: DropdownOptionProps[] = [];
  /**
   * The state to show whether dropdown is shown
   */
  @State() menuOpen: boolean = false;
  /**
   * The index of selected option
   */
  @State() selectedIndex: number = -1;

  /**
   * The index of hovered option
   */
  @State() hoveredIndex: number = -1;

  /**
   * The dropdown trigger button focused state
   */
  @State() isButtonFocused: boolean = false;

  /**
   * Fires when an option is selected
   */
  @Event() optionSelected: EventEmitter<DropdownOptionProps>;

  /**
   * Fires when the dropdown is closed
   */
  @Event() dropdownClosed: EventEmitter<string>;

  /**
   * Fires when the trigger button blur
   */
  @Event() dropdownButtonBlur: EventEmitter<string>;

  /**
   * Public method to clear selected value
   */
  @Method()
  async clearSelectedValue() {
    this.selectedIndex = -1;
    this.hoveredIndex = -1;
    this.menuOpen = false;
  }

  /**
   * internalised Unique ID for the validation text
   */
  private uniqueHintValidationId: string = generateRandomNumber();

  /**
   * The options for the dropdownbox where user can choose from
   */
  private options: DropdownOptionProps[] = [];

  /**
   * Refer to the ul item
   */
  private listboxNode: HTMLUListElement;

  /**
   * Refer to the trigger button
   */
  private dropdownButton: HTMLButtonElement;

  private keyCodes = {
    13: 'enter',
    27: 'escape',
    32: 'space',
    38: 'up',
    40: 'down'
  };
  private handleListNodeKeyDown(event) {
    switch (this.keyCodes[event.keyCode]) {
      case 'up':
        this.handleUpArrow(event);
        break;
      case 'down':
        this.handleDownArrow(event);
        break;
      case 'enter':
        this.handleEnter(event);
        break;
      case 'escape':
        this.handleListNodeBlur();
        break;
      default:
        break;
    }
  }

  private handleButtonKeyDown(event: KeyboardEvent) {
    switch (this.keyCodes[event.keyCode]) {
      case 'up':
        this.handleButtonClick();
        this.handleUpArrow(event);
        break;
      case 'down':
        this.handleButtonClick();
        this.handleDownArrow(event);
        break;
      case 'escape':
        this.handleButtonBlur();
        break;
      default:
        break;
    }
  }

  private handleDownArrow(event) {
    event.preventDefault();

    const { menuOpen, options, hoveredIndex } = this;
    const isNotAtBottom = hoveredIndex !== options.length - 1;
    const allowMoveDown = isNotAtBottom && menuOpen;
    if (allowMoveDown) {
      this.handleOptionFocus(hoveredIndex + 1);
    }
  }

  private handleUpArrow(event) {
    event.preventDefault();
    const { menuOpen, hoveredIndex } = this;
    const isNotAtTop = hoveredIndex > 0;
    const allowMoveUp = isNotAtTop && menuOpen;
    if (allowMoveUp) {
      this.handleOptionFocus(hoveredIndex - 1);
    }
  }

  private handleOptionFocus(index) {
    this.hoveredIndex = index;
    this.selectedIndex = index;
  }

  private handleEnter(event) {
    event.preventDefault();
    const hasSelectedOption = this.hoveredIndex >= 0;
    if (hasSelectedOption) {
      this.handleOptionClick(this.hoveredIndex);
    }
  }

  private handleOptionClick(index) {
    this.selectedIndex = index;
    this.hoveredIndex = index;
    this.menuOpen = false;
    this.focusOnDropdownButton();
    this.selectedValue = this.options[index].value;
    this.optionSelected.emit(this.options[index]);
  }

  private handleListNodeFocus() {
    this.onElementReady(this.listboxNode).then(() => {
      this.listboxNode.focus();
    });
  }

  private handleListNodeBlur() {
    this.menuOpen = false;
    this.focusOnDropdownButton();
    const selectedValue = this.selectedIndex < 0 ? '' : this.options[this.selectedIndex].value;
    this.dropdownClosed.emit(selectedValue);
  }

  private handleButtonClick() {
    if (!this.menuOpen) {
      this.menuOpen = true;
      this.handleListNodeFocus();
    } else {
      this.handleListNodeBlur();
    }
  }

  private handleButtonBlur() {
    this.isButtonFocused = false;
    const selectedValue = this.selectedIndex < 0 ? '' : this.options[this.selectedIndex].value;
    this.dropdownButtonBlur.emit(selectedValue);
  }

  private focusOnDropdownButton() {
    this.dropdownButton.focus();
    this.isButtonFocused = true;
  }

  private onElementReady = (elem: HTMLElement) =>
    new Promise((resolve) => {
      const waitForElement = () => {
        if (elem.offsetParent) {
          resolve(elem);
        } else {
          window.requestAnimationFrame(waitForElement);
        }
      };
      waitForElement();
    });

  @Listen('dropdownOptionSelected')
  handleOptionSelected(event) {
    this.handleOptionClick(event.detail);
  }

  @Watch('value')
  valueWatchHandler(newValue: string) {
    this.selectedValue = newValue;
    if (this.options.find((option) => option.value === newValue)) {
      const index = this.options.indexOf(this.options.find((option) => option.value === newValue));
      this.selectedIndex = index;
      this.hoveredIndex = index;
    } else {
      this.selectedIndex = -1;
      this.hoveredIndex = -1;
    }
  }

  @Watch('selectedIndex')
  updateSelectedOption(selectedIndex) {
    Array.from(this.host.querySelectorAll('agl-ds-dropdown-option')).forEach(function (item) {
      (item as HTMLAglDsDropdownOptionElement).selectedIndex = selectedIndex;
    });
  }

  @Watch('hoveredIndex')
  updateHoveredOption(hoveredIndex) {
    Array.from(this.host.querySelectorAll('agl-ds-dropdown-option')).forEach(function (item) {
      (item as HTMLAglDsDropdownOptionElement).hoveredIndex = hoveredIndex;
    });
  }

  @Watch('customOptions')
  onCustomOptionsChanged() {
    this.options = this.customOptions;
    const selectedOptionIndex = this.customOptions.findIndex((option) => option.selected);
    this.selectedIndex = selectedOptionIndex;
    this.hoveredIndex = selectedOptionIndex;
  }

  //Ensure that the drop down options always have their index property set (for cases where the consuming SPA may have dynamically added / removed options)
  async connectedCallback() {
    // once options attached to the dom, this function triggered to get the options from slot to the options prop.
    // it happens before the lifecycle of stencil
    if (!this.customOptions?.length) {
      const optionElements = this.host.querySelectorAll('agl-ds-dropdown-option');

      for (let i = 0; i < optionElements.length; i++) {
        this.options.push({
          text: (optionElements[i] as HTMLAglDsDropdownOptionElement).text,
          value: (optionElements[i] as HTMLAglDsDropdownOptionElement).value,
          selected: (optionElements[i] as HTMLAglDsDropdownOptionElement).selected
        });

        (optionElements[i] as HTMLAglDsDropdownOptionElement).index = i;
        (optionElements[i] as HTMLAglDsDropdownOptionElement).selId = this.selectId;
        (optionElements[i] as HTMLAglDsDropdownOptionElement).setSize = optionElements.length;

        // set default selected option from child
        if ((optionElements[i] as HTMLAglDsDropdownOptionElement).selected) {
          this.selectedIndex = i;
          this.hoveredIndex = i;
        }
      }
    } else {
      //setup the initial options passed through the prop from consuming SPA
      this.onCustomOptionsChanged();
    }
  }

  componentWillLoad() {
    // set default selected option from parent
    if (this.value && this.options.find((option) => option.value === this.value)) {
      const index = this.options.indexOf(this.options.find((option) => option.value === this.value));
      this.selectedIndex = index;
      this.hoveredIndex = index;
    }
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.dropdownButton);
    checkSlottedContentForInvalidHTML(this.host.querySelector('ul'), ['ul', 'agl-ds-dropdown-option']);
  }
  private renderOptions() {
    if (!this.customOptions?.length) {
      return <slot />;
    }
    return this.options.map((option, index) => (
      <agl-ds-dropdown-option
        selId={this.selectId}
        selected={option.selected}
        value={option.value}
        text={option.text}
        setSize={this.options.length}
        index={index}
      ></agl-ds-dropdown-option>
    ));
  }

  render() {
    const isDropdownActive = this.menuOpen || this.selectedIndex !== -1;
    return (
      <Host>
        <div class="agl-ds-dropdownbox__container">
          <span
            id={`${this.selectId}`}
            class={{
              'agl-ds-dropdownbox__label': true,
              'agl-ds-dropdownbox__label--active': isDropdownActive,
              'agl-ds-dropdownbox__label--error': this.hasError
            }}
          >
            {this.label}
          </span>
          <button
            type="button"
            aria-haspopup="listbox"
            aria-labelledby={`${this.selectId} ${this.selectId}__button`}
            aria-owns={`${this.selectId}__listbox`}
            aria-expanded={this.menuOpen ? 'true' : 'false'}
            aria-describedBy={this.uniqueHintValidationId}
            id={`${this.selectId}__button`}
            class={{
              'agl-ds-dropdownbox__button': true,
              'agl-ds-dropdownbox__button--inverse': this.type === 'default-inverse',
              'agl-ds-dropdownbox__button--active': isDropdownActive,
              'agl-ds-dropdownbox__button--error': this.hasError
            }}
            ref={(el) => (this.dropdownButton = el)}
            onClick={() => {
              this.handleButtonClick();
            }}
            onBlur={() => {
              this.handleButtonBlur();
            }}
            onKeyDown={(event) => {
              this.handleButtonKeyDown(event);
            }}
          >
            {this.selectedIndex !== -1 && this.options[this.selectedIndex].text}
            <span
              class={{
                'agl-ds-dropdownbox__icon': true,
                'agl-ds-dropdownbox__icon--up': this.menuOpen,
                'agl-ds-dropdownbox__icon--down': !this.menuOpen
              }}
              innerHTML={chevronDownIcon}
            />
          </button>

          <ul
            id={`${this.selectId}__listbox`}
            tabindex={-1}
            role="listbox"
            aria-labelledby={`${this.selectId}`}
            aria-activedescendant={`${this.selectId}__option--${this.selectedIndex}`}
            class={{
              'agl-ds-dropdownbox__options-container': true,
              'agl-ds-dropdownbox__options-container--hidden': !this.menuOpen,
              'agl-ds-dropdownbox__options-container--up': this.dropdownDirection === 'up'
            }}
            ref={(el) => (this.listboxNode = el)}
            onKeyDown={(event) => {
              this.handleListNodeKeyDown(event);
            }}
            onBlur={(e) => {
              if (e.relatedTarget === this.dropdownButton || document.activeElement === this.dropdownButton) {
                return;
              }
              this.handleListNodeBlur();
            }}
          >
            {this.renderOptions()}
          </ul>
          {!this.hasError && (
            <span
              class={{
                ['agl-ds-dropdownbox__bar']: true,
                ['agl-ds-dropdownbox__bar--active']: this.menuOpen || this.isButtonFocused
              }}
            />
          )}
          <agl-ds-hint-validation-message asDescribedbyId={this.uniqueHintValidationId} hasError={this.hasError}>
            <div slot="validation-text">{this.validationText}</div>
            <div slot="hint-text">{this.hintText}</div>
          </agl-ds-hint-validation-message>
        </div>
      </Host>
    );
  }
}
