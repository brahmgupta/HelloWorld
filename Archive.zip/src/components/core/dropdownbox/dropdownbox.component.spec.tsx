import { h } from '@stencil/core';
import { newSpecPage } from '@stencil/core/testing';
import * as utils from '../../../global/utils/utils';
import { DropdownBoxComponent } from './dropdownbox.component';
import { DropdownOptionComponent } from './dropdownoption/dropdownoption.component';

describe('dropdowncomponent', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  beforeEach(() => {
    jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => '123');
  });
  it('should render default dropdownbox', async () => {
    const page = await newSpecPage({
      components: [DropdownBoxComponent],
      html: `<agl-ds-dropdownbox sel-id="123" has-error="false" label="test" hint-text="hint text"></agl-ds-dropdownbox>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-dropdownbox sel-id="123" label="test" has-error="false" hint-text="hint text">
          <div class="agl-ds-dropdownbox__container">
            <span  class="agl-ds-dropdownbox__label" id="123">test</span>
            <button type="button" aria-expanded="false" aria-haspopup="listbox" aria-labelledby="123 123__button" aria-owns="123__listbox" aria-describedBy="123" class="agl-ds-dropdownbox__button" id="123__button">
            <span class="agl-ds-dropdownbox__icon  agl-ds-dropdownbox__icon--down">
              svg contents from: src/assets/Icon-chevron-down.svg
            </span>
            </button>
            <ul aria-activedescendant="123__option---1" aria-labelledby="123" class="agl-ds-dropdownbox__options-container agl-ds-dropdownbox__options-container--hidden" id="123__listbox" role="listbox" tabindex="-1"></ul>
            <span class="agl-ds-dropdownbox__bar"></span>
            <agl-ds-hint-validation-message asdescribedbyid="123">
                <div slot="validation-text"></div>
                <div slot="hint-text">hint text</div>
              </agl-ds-hint-validation-message>
          </div>
		</agl-ds-dropdownbox>`
    );
  });

  it('should add error classes when has error true', async () => {
    const page = await newSpecPage({
      components: [DropdownBoxComponent],
      html: `<agl-ds-dropdownbox has-error="true"></agl-ds-dropdownbox>`
    });

    const button = page.root.querySelector('button');
    const label = page.root.querySelector('span');
    expect(button.classList.contains('agl-ds-dropdownbox__button--error')).toBe(true);
    expect(label.classList.contains('agl-ds-dropdownbox__label--error')).toBe(true);
  });

  it('should fire dropdown close event on blur of the ul', async () => {
    const page = await newSpecPage({
      components: [DropdownBoxComponent],
      html: `<agl-ds-dropdownbox></agl-ds-dropdownbox>`
    });
    const closeSpy = jest.fn();
    page.win.addEventListener('dropdownClosed', closeSpy);
    const button = page.root.querySelector('button');
    button.focus = jest.fn();

    const ul = page.root.querySelector('ul');
    ul.focus = jest.fn();
    button.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    ul.dispatchEvent(new Event('blur'));
    await page.waitForChanges();
    expect(closeSpy).toHaveBeenCalled();
  });

  it('should show dropdown menu when button clicked', async () => {
    const page = await newSpecPage({
      components: [DropdownBoxComponent],
      html: `<agl-ds-dropdownbox></agl-ds-dropdownbox>`
    });
    const button = page.root.querySelector('button');
    const ul = page.root.querySelector('ul');
    ul.focus = jest.fn();
    button.click();

    await page.waitForChanges();
    expect(page.root.querySelector('ul')).toBeTruthy();
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [DropdownBoxComponent, DropdownOptionComponent],
      html: `<agl-ds-dropdownbox>
      <agl-ds-dropdown-option text='VIC' value='vic'></agl-ds-dropdown-option>
     </agl-ds-dropdownbox>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [DropdownBoxComponent, DropdownOptionComponent],
      html: `<agl-ds-dropdownbox>
                <p>dummy text</P>
                <agl-ds-dropdown-option text='VIC' value='vic'></agl-ds-dropdown-option>
               </agl-ds-dropdownbox>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should render out option from the customOptions Prop', async () => {
    const options = [];
    let dynamicOptionCounter = 0;
    for (dynamicOptionCounter = 0; dynamicOptionCounter < 5; dynamicOptionCounter++) {
      options.push({ value: dynamicOptionCounter.toString(), text: dynamicOptionCounter.toString(), selected: false });
    }
    options[4].selected = true;
    const page = await newSpecPage({
      components: [DropdownBoxComponent, DropdownOptionComponent],
      template: () => <agl-ds-dropdownbox customOptions={options}></agl-ds-dropdownbox>
    });
    const renderedOptions = page.root.querySelectorAll('agl-ds-dropdown-option');
    expect(renderedOptions).not.toBeNull();
    expect(renderedOptions.length).toEqual(5);
    expect(renderedOptions[4].selected).toEqual(true);

    const button = page.root.querySelector('button');
    expect(button.innerText).toEqual('4svg contents from: src/assets/Icon-chevron-down.svg');
  });
});
