# agl-ds-dropdown-option



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                                                 | Type      | Default     |
| --------------- | ---------------- | --------------------------------------------------------------------------- | --------- | ----------- |
| `hoveredIndex`  | `hovered-index`  | The hovered index of the option for display, passed in from parent          | `number`  | `-1`        |
| `index`         | `index`          | The index of the option in options list                                     | `number`  | `undefined` |
| `selId`         | `sel-id`         | The selId from parent                                                       | `string`  | `''`        |
| `selected`      | `selected`       | Flag to set if the option is selected, passed in from the current component | `boolean` | `false`     |
| `selectedIndex` | `selected-index` | The selected index of the option, passed in from parent                     | `number`  | `-1`        |
| `setSize`       | `set-size`       | The length of option elements                                               | `number`  | `undefined` |
| `text`          | `text`           | The text of the option for display                                          | `string`  | `''`        |
| `value`         | `value`          | The value of the option                                                     | `string`  | `''`        |


## Events

| Event                    | Description                      | Type                  |
| ------------------------ | -------------------------------- | --------------------- |
| `dropdownOptionSelected` | Fires when an option is selected | `CustomEvent<number>` |


## Dependencies

### Used by

 - [agl-ds-dropdownbox](..)
 - [agl-ds-manual-address-entry](../../../composite/addresssearch/manual-address-entry)

### Graph
```mermaid
graph TD;
  agl-ds-dropdownbox --> agl-ds-dropdown-option
  agl-ds-manual-address-entry --> agl-ds-dropdown-option
  style agl-ds-dropdown-option fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
