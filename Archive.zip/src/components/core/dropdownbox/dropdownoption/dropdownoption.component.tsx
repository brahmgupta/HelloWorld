import { Component, Host, h, Prop, Event, EventEmitter, ComponentInterface } from '@stencil/core';
import { hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';

@Component({
  tag: 'agl-ds-dropdown-option',
  styleUrl: 'dropdownoption.component.scss',
  shadow: false,
  scoped: true
})
export class DropdownOptionComponent implements ComponentInterface {
  /**
   * The selId from parent
   */
  @Prop() selId: string = '';

  /**
   * The value of the option
   */
  @Prop() value: string = '';

  /**
   * The text of the option for display
   */
  @Prop() text: string = '';

  /**
   * The index of the option in options list
   */
  @Prop() index: number;

  /**
   * The selected index of the option, passed in from parent
   */
  @Prop() selectedIndex: number = -1;

  /**
   * The hovered index of the option for display, passed in from parent
   */
  @Prop() hoveredIndex: number = -1;

  /**
   *  Flag to set if the option is selected, passed in from the current component
   */
  @Prop() selected: boolean = false;

  /**
   *  The length of option elements
   */
  @Prop() setSize: number;

  /**
   * Fires when an option is selected
   */
  @Event() dropdownOptionSelected: EventEmitter<number>;

  private handleOptionClick(index: number) {
    this.dropdownOptionSelected.emit(index);
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.listItem);
  }

  private listItem: HTMLLIElement;
  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    return (
      <Host>
        <li
          ref={(el) => (this.listItem = el)}
          aria-selected={this.selectedIndex === this.index ? 'true' : 'false'}
          aria-labelledby={`${this.selId}-option`}
          role="option"
          onMouseDown={() => this.handleOptionClick(this.index)}
          class={{
            'agl-ds-dropdownbox-option': true,
            'agl-ds-dropdownbox-option--hovered': this.hoveredIndex === this.index,
            'agl-ds-dropdownbox-option--selected': this.selectedIndex === this.index
          }}
          id={`${this.selId}__option--${this.index}`}
          aria-posinset={this.index + 1}
          aria-setsize={this.setSize}
          value={this.value}
        >
          <span class="agl-ds-dropdownbox-option__text">{this.text}</span>
        </li>
      </Host>
    );
  }
}
