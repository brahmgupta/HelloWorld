export type DropdownDirection = 'up' | 'down' | 'dynamic';
