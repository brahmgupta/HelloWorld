export interface DropdownOptionProps {
  value: string;
  text: string;
  selected: boolean;
}
