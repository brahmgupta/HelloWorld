import { text, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Dropdownbox'
};

export const Dropdownbox = () => html`
  <agl-ds-dropdownbox
    id="myId1"
    type="${select('type', ['default', 'default-inverse'], 'default')}"
    validation-text="${text('validation text', 'validation text')}"
    hint-text="${text('hint text', 'hint text')}"
    label="${text('label', 'State')}"
  >
    <agl-ds-dropdown-option text="VIC" value="vic"></agl-ds-dropdown-option>
    <agl-ds-dropdown-option text="NSW" value="nsw"></agl-ds-dropdown-option>
    <agl-ds-dropdown-option text="WA" value="wa"></agl-ds-dropdown-option>
    <agl-ds-dropdown-option text="SA" value="sa"></agl-ds-dropdown-option>
    <agl-ds-dropdown-option text="QLD" value="qld"></agl-ds-dropdown-option>
  </agl-ds-dropdownbox>
  <label><input type="checkbox" onClick="document.getElementById('myId1').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br /><br />TODO: this component is not accessible for screen readers
`;

Dropdownbox.storyName = 'dropdownbox';
Dropdownbox.parameters = { notes };

export const DropdownboxWithDefaultValue = () =>
  /**
   *There are two ways to set default value,
   *1: set from option slot, something like: <agl-ds-dropdown-option text='QLD' value='qld' selected=true></agl-ds-dropdown-option>,
   *2: set from value prop of the dropbox component
   *And 2 will take over 1
   */
  html`
    <agl-ds-dropdownbox
      id="myId2"
      type="${select('type', ['default', 'default-inverse'], 'default')}"
      validation-text="${text('validation text', 'validation text')}"
      hint-text="${text('hint text', 'hint text')}"
      label="${text('label', 'State')}"
      value="${text('default value', 'wa')}"
    >
      <agl-ds-dropdown-option text="VIC" value="vic"></agl-ds-dropdown-option>
      <agl-ds-dropdown-option text="NSW" value="nsw"></agl-ds-dropdown-option>
      <agl-ds-dropdown-option text="WA" value="wa"></agl-ds-dropdown-option>
      <agl-ds-dropdown-option text="SA" value="sa"></agl-ds-dropdown-option>
      <agl-ds-dropdown-option text="QLD" value="qld" selected="true"></agl-ds-dropdown-option>
    </agl-ds-dropdownbox>
    <label><input type="checkbox" onClick="document.getElementById('myId2').setAttribute('has-error',this.checked)" />Toggle Error</label>
    <br /><br />TODO: this component is not accessible for screen readers
  `;

DropdownboxWithDefaultValue.storyName = 'dropdownbox with default value';
DropdownboxWithDefaultValue.parameters = { notes };

export const DropdownboxWithDynamicValue = () =>
  /**
   *There are two ways to set default value,
   *1: set from option slot, something like: <agl-ds-dropdown-option text='QLD' value='qld' selected=true></agl-ds-dropdown-option>,
   *2: set from value prop of the dropbox component
   *And 2 will take over 1
   */
  html`
    <agl-ds-dropdownbox id="myDynamicDropdown" label="Dynamic"> </agl-ds-dropdownbox>
    <script>
      var options = [];
      var dynamicOptionCounter = 0;
      for (dynamicOptionCounter = 0; dynamicOptionCounter < 5; dynamicOptionCounter++) {
        options.push({ value: dynamicOptionCounter.toString(), text: dynamicOptionCounter.toString(), selected: false });
      }
      var dropDown = document.getElementById('myDynamicDropdown');
      dropDown.customOptions = options;
    </script>
    <agl-ds-button
      id="btnAddDynamicOption"
      onClick="options.push({ value: dynamicOptionCounter.toString(), text: dynamicOptionCounter.toString(), selected: false });dynamicOptionCounter +=1;"
      >Add Item to list</agl-ds-button
    >
    <agl-ds-button
      id="btnRemoveDynamicOption"
      onClick="dropDown.clearSelectedValue();if(options.length) {options.pop();dynamicOptionCounter -=1;}"
      >Remove Item from list</agl-ds-button
    >
    <br /><br />TODO: this component is not accessible for screen readers
  `;

DropdownboxWithDynamicValue.storyName = 'dropdownbox with dynamic value';
DropdownboxWithDynamicValue.parameters = {
  notes,
  storyshots: {
    visualRegression: {
      screenshotHeight: 400,
      beforeScreenshotAsyncFunc: async (page) => {
        await page.waitForSelector('agl-ds-dropdownbox', { visible: true });
        await page.click('agl-ds-dropdownbox');
      }
    }
  }
};
