export type DropdownboxType = 'default' | 'default-inverse';
