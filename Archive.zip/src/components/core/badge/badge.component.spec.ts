import { newSpecPage } from '@stencil/core/testing';
import { BadgeComponent } from './badge.component';
import { BadgeTheme, BadgeSize } from './badge.types';

describe('badge component', () => {
  it('should render the badge component', async () => {
    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge>
          <mock:shadow-root>
              <div class="badge badge--md badge--default">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with default theme', async () => {
    const badgeTheme: BadgeTheme = 'default';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with default inverted type', async () => {
    const badgeTheme: BadgeTheme = 'default';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}" type="inverted"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}" type="inverted">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}-inverted">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with information theme', async () => {
    const badgeTheme: BadgeTheme = 'information';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with success theme', async () => {
    const badgeTheme: BadgeTheme = 'success';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with warning theme', async () => {
    const badgeTheme: BadgeTheme = 'warning';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with attention theme', async () => {
    const badgeTheme: BadgeTheme = 'attention';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="${badgeTheme}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="${badgeTheme}">
          <mock:shadow-root>
              <div class="badge badge--md badge--${badgeTheme}">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with small size', async () => {
    const badgeSize: BadgeSize = 'sm';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge size="${badgeSize}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge size="${badgeSize}">
          <mock:shadow-root>
              <div class="badge badge--${badgeSize} badge--default">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with medium size', async () => {
    const badgeSize: BadgeSize = 'md';

    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge size="${badgeSize}"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge size="${badgeSize}">
          <mock:shadow-root>
              <div class="badge badge--${badgeSize} badge--default">
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should render the badge component with secondary type and pip', async () => {
    const page = await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge theme="information" type="secondary"></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-badge theme="information" type="secondary">
          <mock:shadow-root>
              <div class="badge badge--md badge--information-secondary">
                <span class="badge--information-secondary-pip"></span>
                <span class="badge-label">
                  <slot></slot>
                </span>
              </div>
          </mock:shadow-root>
        </agl-ds-badge>
      `
    );
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge>dummy text</agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [BadgeComponent],
      html: `<agl-ds-badge><p>dummy text</p></agl-ds-badge>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
