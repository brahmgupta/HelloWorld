import { Component, Host, Prop, h, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { BadgeSize, BadgeTheme, BadgeType } from './badge.types';

@Component({
  tag: 'agl-ds-badge',
  styleUrl: 'badge.component.scss',
  shadow: true
})
export class BadgeComponent implements ComponentInterface {
  @Element() host: HTMLAglDsBadgeElement;
  /**
   * Indicates badge theme
   * Available themes: `"default"`, `"information"`, `"success"`, `"attention"`, `"warning"`
   * `"default"` will be applied when type is not specified
   */
  @Prop() theme?: BadgeTheme = 'default';

  /**
   * Indicates badge type
   * Available types: `"primary"`, `"secondary"`, `"inverted"`
   * If not specified, then it will be primary
   */
  @Prop() type: BadgeType = 'primary';

  /**
   * Size of badge
   * `"md"` will be applied when the size is not specified
   */
  @Prop() size?: BadgeSize = 'md';

  /**
   * Provide screen reader users with additional context or to convey information not available in HTML alone
   */
  @Prop() srContext?: string = '';

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-badge']);
  }

  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    const { size, theme, type, srContext } = this;

    return (
      <Host>
        <div
          class={{
            ['badge']: true,
            [`badge--${size}`]: true,
            [`badge--${theme}`]: type === 'primary',
            [`badge--${theme}-secondary`]: type === 'secondary',
            [`badge--${theme}-inverted`]: type === 'inverted'
          }}
        >
          {type === 'secondary' ? <span class={{ [`badge--${theme}-secondary-pip`]: true }}></span> : null}
          <span class="badge-label">
            <slot></slot>
            {srContext ? <span class="sr-only"> {srContext}</span> : ''}
          </span>
        </div>
      </Host>
    );
  }
}
