import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

const BadgeSize = {
  sm: 'sm',
  md: 'md'
};

const BadgeTheme = {
  default: 'default',
  information: 'information',
  success: 'success',
  attention: 'attention',
  warning: 'warning'
};

const BadgeType = {
  primary: 'primary',
  secondary: 'secondary',
  inverted: 'inverted'
};

const badgeTextKnob = () => text('Badge content', 'I am a badge!!');
const badgeSizeKnob = () => select('Size', Object.values(BadgeSize), BadgeSize.md);
const badgeThemeKnob = () => select('Theme', Object.values(BadgeTheme), BadgeTheme.default);
const badgeTypeKnob = () => select('Type', Object.values(BadgeType), BadgeType.primary);

export default {
  title: 'Core/Badge'
};

export const Badge = () => html`
  <div style="margin: 10px">
    <agl-ds-badge theme="${badgeThemeKnob()}" type="${badgeTypeKnob()}" size="${badgeSizeKnob()}">${badgeTextKnob()}</agl-ds-badge>
  </div>
`;

Badge.parameters = {
  notes
};

export const Cheatsheet = () => html`
  <table border="1" style="margin: 10px; width: 60%">
    <thead>
      <th style="padding: 5px">Primary</th>
      <th style="padding: 5px">Secondary</th>
      <th style="padding: 5px">Inverted</th>
      <th style="padding: 5px">Medium</th>
      <th style="padding: 5px">Small</th>
    </thead>
    <tbody>
      <tr>
        <td>
          <div style="display: grid; grid-gap: 5px; margin: 5px">
            <agl-ds-badge>Default</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.information}">Information</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.success}">Success</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.warning}">Warning</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.attention}">Attention</agl-ds-badge>
          </div>
        </td>
        <td>
          <div style="display: grid; grid-gap: 5px; margin: 5px">
            <agl-ds-badge size="md" type="secondary">Default</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.information}" size="md" type="secondary">Information</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.success}" size="md" type="secondary">Success</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.warning}" size="md" type="secondary">Warning</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.attention}" size="md" type="secondary">Attention</agl-ds-badge>
          </div>
        </td>
        <td>
          <div style="display: grid; grid-gap: 5px; margin: 5px">
            <agl-ds-badge theme="${BadgeTheme.default}" size="md" type="inverted">Default</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.information}" size="md" type="inverted">Information</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.success}" size="md" type="inverted">Success</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.warning}" size="md" type="inverted">Warning</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.attention}" size="md" type="inverted">Attention</agl-ds-badge>
          </div>
        </td>
        <td>
          <div style="display: grid; grid-gap: 5px; margin: 5px">
            <agl-ds-badge size="md">Default</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.information}" size="md">Information</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.success}" size="md">Success</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.warning}" size="md">Warning</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.attention}" size="md">Attention</agl-ds-badge>
          </div>
        </td>
        <td>
          <div style="display: grid; grid-gap: 5px; margin: 5px">
            <agl-ds-badge size="sm">Small</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.information}" size="sm">Information</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.success}" size="sm">Success</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.warning}" size="sm">Warning</agl-ds-badge>
            <agl-ds-badge theme="${BadgeTheme.attention}" size="sm">Attention</agl-ds-badge>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
`;

Cheatsheet.parameters = { notes };
