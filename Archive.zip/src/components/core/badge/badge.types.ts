export type BadgeSize = 'sm' | 'md';

export type BadgeType = 'primary' | 'secondary' | 'inverted';

export type BadgeTheme = 'default' | 'information' | 'success' | 'attention' | 'warning';
