# agl-ds-badge



<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                                                                                                                                                          | Type                                                                  | Default     |
| ----------- | ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- | ----------- |
| `size`      | `size`       | Size of badge `"md"` will be applied when the size is not specified                                                                                                  | `"md" \| "sm"`                                                        | `'md'`      |
| `srContext` | `sr-context` | Provide screen reader users with additional context or to convey information not available in HTML alone                                                             | `string`                                                              | `''`        |
| `theme`     | `theme`      | Indicates badge theme Available themes: `"default"`, `"information"`, `"success"`, `"attention"`, `"warning"` `"default"` will be applied when type is not specified | `"attention" \| "default" \| "information" \| "success" \| "warning"` | `'default'` |
| `type`      | `type`       | Indicates badge type Available types: `"primary"`, `"secondary"`, `"inverted"` If not specified, then it will be primary                                             | `"inverted" \| "primary" \| "secondary"`                              | `'primary'` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
