import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Hint-Validation message'
};

export const HintValidationMessage = () => html`
  <div class="reference-div">
    This is a container to give a reference point for the hint and validation message. If you delete the hint text in the knobs section you
    will only see the validation message. The dotted border illustrates the available area to display the hint/validation message
  </div>
  <agl-ds-hint-validation-message id="myId" as-describedby-id="uniqueid" has-error="false">
    <div slot="hint-text">I am a hint text message with a link <agl-ds-link>click here</agl-ds-link></div>
    <div slot="validation-text">${text('validation text', 'I am a validation text message')}</div>
  </agl-ds-hint-validation-message>
  <div class="reference-div">Next component</div>
  <label><input type="checkbox" onClick="document.getElementById('myId').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <style>
    .container {
      border: 1px dotted #d6d9e0;
    }
    .reference-div {
      background: #a7a9b3;
    }
  </style>
`;

HintValidationMessage.storyName = 'hint-validation message';
HintValidationMessage.parameters = { notes: notes };
