import { newSpecPage } from '@stencil/core/testing';
import { HintValidationMessageComponent } from './hint-validation-message.component';

describe('Hint Validation component', () => {
  const validtionText = 'dummy validation text';
  const hintText = 'dummy hint text';
  const uniqueId = '111';

  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `
      <agl-ds-hint-validation-message as-describedby-id=` +
        uniqueId +
        ` has-error="false">
        <div slot="hint-text">Dummy hint text</div>
        <div slot="validation-text">Dummy validation text</div>
      </agl-ds-hint-validation-message>
      `
    });
    expect(page.root).toEqualHtml(
      `
    <agl-ds-hint-validation-message has-error="false" as-describedby-id="` +
        uniqueId +
        `">
    <div class="message-container">
      <div class="message-container__hint-text-section" id="` +
        uniqueId +
        `">
        <div slot="hint-text">
          Dummy hint text
        </div>
      </div>
      <div class="hidden message-container__validation-text-section">
        <div hidden="" slot="validation-text">
          Dummy validation text
        </div>
      </div>
    </div>
  </agl-ds-hint-validation-message>
    `
    );
  });

  it('should render the component when hint text is not passed in', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `
      <agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="false">
        <div slot="validation-text">Dummy validation text</div>
      </agl-ds-hint-validation-message>
      `
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-hint-validation-message has-error="false" as-describedby-id="` +
        uniqueId +
        `">
        <div class="message-container">
          <div class="message-container__hint-text-section" id="` +
        uniqueId +
        `"></div>
          <div  class="hidden message-container__validation-text-section">
            <div hidden="" slot="validation-text">
              Dummy validation text
            </div>
          </div>
        </div>
      </agl-ds-hint-validation-message>
    `
    );
  });

  it('should render the component when validation text is not passed in', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `
      <agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="false">
        <div slot="hint-text">Dummy hint text</div>
      </agl-ds-hint-validation-message>
      `
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-hint-validation-message has-error="false" as-describedby-id="` +
        uniqueId +
        `">
        <div class="message-container">
          <div class="message-container__hint-text-section" id="` +
        uniqueId +
        `">
            <div slot="hint-text">
              Dummy hint text
            </div>
          </div>
          <div class="hidden message-container__validation-text-section"></div>
        </div>
      </agl-ds-hint-validation-message>
      `
    );
  });

  it('should show the validation text and hide the hint text when they are passed in and has-error = true', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="true">
          <div slot="hint-text">` +
        hintText +
        `</div>
          <div slot="validation-text">` +
        validtionText +
        `</div>
        </agl-ds-hint-validation-message>`,
      supportsShadowDom: false
    });

    const validtionTextDiv = page.root.querySelector('.message-container__validation-text-section');
    const hintTextDiv = page.root.querySelector('.message-container__hint-text-section');
    expect(validtionTextDiv.classList.contains('hidden')).toBeFalsy();
    expect(hintTextDiv.classList.contains('hidden')).toBeTruthy();
  });

  it('should show the hint text and hide the validation text when they are passed in and has-error = false', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="false">
          <div slot="hint-text">` +
        hintText +
        `</div>
          <div slot="validation-text">` +
        validtionText +
        `</div>
        </agl-ds-hint-validation-message>`,
      supportsShadowDom: false
    });

    const validtionTextDiv = page.root.querySelector('.message-container__validation-text-section') as HTMLDivElement;
    const hintTextDiv = page.root.querySelector('.message-container__hint-text-section') as HTMLDivElement;
    expect(validtionTextDiv.classList.contains('hidden')).toBeTruthy();
    expect(hintTextDiv.classList.contains('hidden')).toBeFalsy();
  });

  it('should set the aria attributes on the hint text when has-error = false', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="false">
          <div slot="hint-text">` +
        hintText +
        `</div>
          <div slot="validation-text">` +
        validtionText +
        `</div>
        </agl-ds-hint-validation-message>`,
      supportsShadowDom: false
    });

    const validtionTextDiv = page.root.querySelector('.message-container__validation-text-section') as HTMLDivElement;
    const hintTextDiv = page.root.querySelector('.message-container__hint-text-section') as HTMLDivElement;
    expect((validtionTextDiv.children[0] as HTMLDivElement).hidden).toEqual(true);
    expect(validtionTextDiv.getAttribute('id')).toBeNull();
    expect((hintTextDiv.children[0] as HTMLDivElement).hidden).toEqual(false);
    expect(hintTextDiv.getAttribute('id')).toEqual(uniqueId);
  });

  it('should set the id on the validation text when has-error = true', async () => {
    const page = await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id="` +
        uniqueId +
        `" has-error="true">
          <div slot="hint-text">` +
        hintText +
        `</div>
          <div slot="validation-text">` +
        validtionText +
        `</div>
        </agl-ds-hint-validation-message>`,
      supportsShadowDom: false
    });

    const validtionTextDiv = page.root.querySelector('.message-container__validation-text-section') as HTMLDivElement;
    const hintTextDiv = page.root.querySelector('.message-container__hint-text-section') as HTMLDivElement;
    expect(validtionTextDiv.getAttribute('id')).toEqual(uniqueId);
    expect(hintTextDiv.getAttribute('id')).toBeNull();
  });

  it('should not console.error when valid html tags are passed in via the validation-text and the hint-text slots', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id=` +
        uniqueId +
        ` has-error="false">
        <div slot="validation-text">
          <agl-ds-text>Dummy  text</agl-ds-text><agl-ds-link>Dummy  text</agl-ds-link>
        </div>
        <div slot="hint-text">
        <agl-ds-text>Dummy  text</agl-ds-text><agl-ds-link>Dummy  text</agl-ds-link>
      </div>
      </agl-ds-hint-validation-message>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the hint-text slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id=` +
        uniqueId +
        ` has-error="false">
        <div slot="hint-text"><p>dummy text</p></div>

      </agl-ds-hint-validation-message>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should console.error when an invalid html tag is passed in via the validation-text slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [HintValidationMessageComponent],
      html:
        `<agl-ds-hint-validation-message as-describedby-id=` +
        uniqueId +
        ` has-error="false">
          <div slot="validation-text"><p>dummy text</p></div>
        </agl-ds-hint-validation-message>
    `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
