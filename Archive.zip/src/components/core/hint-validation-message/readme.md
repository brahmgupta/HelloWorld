# agl-ds-hint-validation-message



<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                  | Type      | Default |
| ----------------- | ------------------- | ------------------------------------------------------------ | --------- | ------- |
| `asDescribedbyId` | `as-describedby-id` | The id of the validation text used mainly for accessability. | `string`  | `''`    |
| `hasError`        | `has-error`         | show or hide the validation message.                         | `boolean` | `false` |


## Slots

| Slot | Description                                                                                                                                                 |
| ---- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
|      | Name = validation-text. The contents of this slot is the validation text.                                                                                   |
|      | Name = hint-text. The contents of this slot is the hint text. Note that the component will toggle between the hint and error texts based on the error state |


## Dependencies

### Used by

 - [agl-ds-checkbox](../checkboxes/checkbox)
 - [agl-ds-day-of-month-picker](../day-of-month-picker)
 - [agl-ds-dropdownbox](../dropdownbox)
 - [agl-ds-radio-button-group](../radio-buttons/radio-button-group)
 - [agl-ds-selection-card-group](../../composite/selection-card/selection-card-group)
 - [agl-ds-textbox](../textbox)

### Graph
```mermaid
graph TD;
  agl-ds-checkbox --> agl-ds-hint-validation-message
  agl-ds-day-of-month-picker --> agl-ds-hint-validation-message
  agl-ds-dropdownbox --> agl-ds-hint-validation-message
  agl-ds-radio-button-group --> agl-ds-hint-validation-message
  agl-ds-selection-card-group --> agl-ds-hint-validation-message
  agl-ds-textbox --> agl-ds-hint-validation-message
  style agl-ds-hint-validation-message fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
