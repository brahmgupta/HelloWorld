import { Component, h, Prop, Host, Watch, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';

/**
 * @slot - Name = validation-text. The contents of this slot is the validation text.
 * @slot - Name = hint-text. The contents of this slot is the hint text.
 * Note that the component will toggle between the hint and error texts based on the error state
 */

@Component({
  tag: 'agl-ds-hint-validation-message',
  styleUrl: 'hint-validation-message.component.scss',
  shadow: false
})
export class HintValidationMessageComponent implements ComponentInterface {
  private hintDiv!: HTMLDivElement;
  private validationDiv!: HTMLDivElement;

  @Element() host: HTMLAglDsHintValidationMessageElement;

  /**
   * The id of the validation text used mainly for accessability.
   */
  @Prop() asDescribedbyId: string = '';

  /**
   * show or hide the validation message.
   */
  @Prop() hasError: boolean = false;

  @Watch('hasError')
  valueWatchHandler(hasError: boolean) {
    if (this.hintDiv && this.hintDiv.children[0]) {
      (this.hintDiv.children[0] as HTMLElement).hidden = hasError;
    }
    if (this.validationDiv && this.validationDiv.children[0]) {
      (this.validationDiv.children[0] as HTMLElement).hidden = !hasError;
    }
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="hint-text"]'), ['div', 'agl-ds-text', 'agl-ds-link']);
    checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="validation-text"]'), ['div', 'agl-ds-text', 'agl-ds-link']);
  }

  componentDidLoad() {
    this.valueWatchHandler(this.hasError);
  }

  render() {
    if (this.asDescribedbyId === '') {
      throw new Error('This component requires an message id');
    }

    return (
      <Host>
        <div class="message-container">
          <div
            ref={(el) => (this.hintDiv = el as HTMLDivElement)}
            id={!this.hasError === true ? this.asDescribedbyId : null}
            class={{
              'message-container__hint-text-section': true,
              hidden: this.hasError
            }}
          >
            <slot name="hint-text"></slot>
          </div>
          <div
            ref={(el) => (this.validationDiv = el as HTMLDivElement)}
            id={this.hasError === true ? this.asDescribedbyId : null}
            class={{
              'message-container__validation-text-section': true,
              hidden: !this.hasError
            }}
          >
            <slot name="validation-text"></slot>
          </div>
        </div>
      </Host>
    );
  }
}
