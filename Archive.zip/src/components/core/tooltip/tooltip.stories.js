import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Tooltip'
};

export const Tooltip = () => {
  const content = text('Sample content', 'Example text: Site size is in an indication of energy consumed.');

  return html`<agl-ds-p style="background-color: #ffdcdc;"
      >Please resize this window until it fits with the border-box below to illustrate how the tool tip is displayed relative to the side of
      the window</agl-ds-p
    >
    <div style="border: 5px solid #EDEBE5; width: 600px">
      <img alt="random content" src="https://via.placeholder.com/600x100/EDEBE5/?text=Random+Content+Above" />
      <agl-ds-p>
        Default tooltip, appearing on the <agl-ds-text font-weight="semibold">right</agl-ds-text><agl-ds-tooltip>${content}</agl-ds-tooltip>
      </agl-ds-p>
      <img alt="random content" src="https://via.placeholder.com/600x50/EDEBE5/?text=Random+Content+Separator" />
      <agl-ds-p>
        Pushed to the <agl-ds-text font-weight="semibold">left</agl-ds-text> tooltip, because we don't have enough space<agl-ds-tooltip
          >${content}</agl-ds-tooltip
        >
      </agl-ds-p>
      <img alt="random content" src="https://via.placeholder.com/600x50/EDEBE5/?text=Random+Content+Separator" />
      <agl-ds-p>
        <agl-ds-text font-weight="semibold">Centered</agl-ds-text> tooltip, only when both conditions above not met. Please resize this
        window further 50%
        <agl-ds-tooltip>${content}</agl-ds-tooltip>
      </agl-ds-p>
      <img alt="random content" src="https://via.placeholder.com/600x100/EDEBE5/?text=Random+Content+Below" />
    </div>`;
};

Tooltip.parameters = { notes };
