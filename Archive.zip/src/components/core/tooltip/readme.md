# agl-ds-tooltip

Tooltip component with fixed 256px width content



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [agl-ds-icon](../icon)

### Graph
```mermaid
graph TD;
  agl-ds-tooltip --> agl-ds-icon
  style agl-ds-tooltip fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
