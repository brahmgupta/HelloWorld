import { Component, Host, h, State, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, hideFocusRingWhenUsingMouse } from '../../../global/utils/utils';
import IconInformation from '../../../assets/icon-Information.svg';
import { EventType, TooltipPositionX } from './tooltip.types';

/**
 * Tooltip component with fixed 256px width content
 */
@Component({
  tag: 'agl-ds-tooltip',
  styleUrl: 'tooltip.component.scss',
  shadow: true
})
export class TooltipComponent implements ComponentInterface {
  /**
   *this component as HTML Element
   */
  @Element() host: HTMLAglDsTooltipElement;

  /** Show tooltip content */
  @State() isDisplayed?: boolean = false;

  /** Tooltip content position */
  @State() positionX?: TooltipPositionX = 'right';

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.triggerElement);
  }

  private triggerElement: HTMLButtonElement;
  private tooltipElement: HTMLDivElement;

  /** Tooltip unique ID */
  private id: string = `tooltip${generateRandomNumber()}`;

  /** Determine x-axis automatically */
  private setPositionX(x: number): void {
    const contentWidth: number = 256; // fix from design
    const windowWidth: number = window.innerWidth || 0;

    if (x && windowWidth) {
      if (x + contentWidth > windowWidth) {
        if (x - contentWidth > 0) {
          // fit to push left
          this.positionX = 'left';
        } else {
          // limited space to push left - centering instead
          this.positionX = 'center';
        }
      } else {
        // fit for default right
        this.positionX = 'right';
      }
    } else {
      this.positionX = 'right'; // default
    }
  }

  private beenThruFocusOrTouch = false; //this is used to cater for the screen reader in browse mode so that the user can toggle the state of the tooltip

  /** Show tooltip content */
  private displayToolTip(eventType: EventType, show: boolean) {
    if (!show) {
      this.hide();
    } else {
      switch (eventType) {
        case 'touch':
          this.doShow();
          this.beenThruFocusOrTouch = true;
          break;
        case 'mouse':
          this.doShow();
          break;
        case 'focus':
          this.doShow();
          this.beenThruFocusOrTouch = true;
          break;
        case 'click':
          if (this.beenThruFocusOrTouch) {
            this.beenThruFocusOrTouch = false;
          } else {
            if (!this.isDisplayed) {
              this.doShow();
            } else {
              this.hide();
            }
          }
          break;
      }
    }
  }
  private doShow() {
    const left = this.triggerElement.getBoundingClientRect().left;
    this.setPositionX(left);
    this.triggerElement.setAttribute('aria-expanded', 'true');
    this.tooltipElement.setAttribute('aria-hidden', 'false');
    this.isDisplayed = true;
  }

  /** Dismiss tooltip */
  private hide() {
    this.triggerElement.setAttribute('aria-expanded', 'false');
    this.tooltipElement.setAttribute('aria-hidden', 'true');
    this.isDisplayed = false;
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-tooltip', 'agl-ds-text']);
  }

  render() {
    const { isDisplayed, id, positionX } = this;
    return (
      <Host>
        <div class="agl-ds-tooltip">
          <div class="agl-ds-tooltip__container">
            <button
              aria-expanded="false"
              aria-label="Information tooltip:"
              aria-describedby={`${id}_desc`}
              class="agl-ds-tooltip__trigger"
              onClick={() => this.displayToolTip('click', true)}
              onTouchStart={() => this.displayToolTip('touch', true)}
              onMouseOver={() => this.displayToolTip('mouse', true)}
              onMouseOut={() => this.displayToolTip('mouse', false)}
              onFocus={() => this.displayToolTip('focus', true)}
              onBlur={() => this.displayToolTip('blur', false)}
              ref={(el) => (this.triggerElement = el)}
            >
              <agl-ds-icon icon={IconInformation} size="xs"></agl-ds-icon>
            </button>

            <div
              ref={(el) => (this.tooltipElement = el)}
              id={`${id}`}
              aria-hidden="true"
              class={{
                'agl-ds-tooltip__content': true,
                'agl-ds-tooltip__content--show': isDisplayed,
                'agl-ds-tooltip__content--left': positionX === 'left',
                'agl-ds-tooltip__content--center': positionX === 'center'
              }}
            >
              <div
                class={{
                  'agl-ds-tooltip__content-hat': true,
                  'agl-ds-tooltip__content-hat--right': positionX === 'right',
                  'agl-ds-tooltip__content-hat--left': positionX === 'left',
                  'agl-ds-tooltip__content-hat--center': positionX === 'center'
                }}
              ></div>
              <div
                id={`${id}_desc`}
                role="tooltip"
                class={{
                  'agl-ds-tooltip__content-paragraph': true,
                  'agl-ds-tooltip__content-paragraph--show': isDisplayed
                }}
              >
                <slot></slot>
              </div>
            </div>
          </div>
        </div>
      </Host>
    );
  }
}
