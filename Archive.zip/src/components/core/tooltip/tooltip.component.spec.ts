jest.doMock('../../../global/utils/utils', () => {
  return {
    generateRandomNumber: () => 1,
    hideFocusRingWhenUsingMouse: () => null,
    checkSlottedContentForInvalidHTML: () => null
  };
});
import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { TooltipComponent } from './tooltip.component';

describe('tooltip component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [TooltipComponent],
      html: `<agl-ds-tooltip><span slot="content">word</span></agl-ds-tooltip>`
    });

    expect(page.root).toEqualHtml(`
    <agl-ds-tooltip>
      <mock:shadow-root>
        <div class="agl-ds-tooltip">
          <div class="agl-ds-tooltip__container">
            <button aria-describedby="tooltip1_desc" aria-expanded="false" aria-label="Information tooltip:" class="agl-ds-tooltip__trigger">
              <agl-ds-icon icon="svg contents from: src/assets/icon-Information.svg" size="xs"></agl-ds-icon>
            </button>
            <div aria-hidden="true" class="agl-ds-tooltip__content" id="tooltip1">
              <div class="agl-ds-tooltip__content-hat agl-ds-tooltip__content-hat--right"></div>
              <div class="agl-ds-tooltip__content-paragraph" id="tooltip1_desc" role="tooltip">
                <slot></slot>
              </div>
            </div>
          </div>
        </div>
      </mock:shadow-root>
      <span slot="content">
        word
      </span>
    </agl-ds-tooltip>
    `);
  });

  it('should be able to show on click of the trigger button', async () => {
    const page: SpecPage = await newSpecPage({
      components: [TooltipComponent],
      html: `<agl-ds-tooltip><span slot="content">word</span></agl-ds-tooltip>`,
      supportsShadowDom: false
    });

    const paragraphElement = page.root.querySelector('.agl-ds-tooltip__content-paragraph');
    expect(paragraphElement.className).not.toContain(`--show`);

    const triggerElement = page.root.querySelector('.agl-ds-tooltip__trigger');
    expect(triggerElement).toBeTruthy();

    triggerElement.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    expect(paragraphElement.className).toContain(`--show`);
  });

  it('should be able to close the tooltip on click of the trigger button once its open', async () => {
    const page: SpecPage = await newSpecPage({
      components: [TooltipComponent],
      html: `<agl-ds-tooltip><span slot="content">word</span></agl-ds-tooltip>`,
      supportsShadowDom: false
    });

    const paragraphElement = page.root.querySelector('.agl-ds-tooltip__content-paragraph');
    expect(paragraphElement.className).not.toContain(`--show`);

    const triggerElement = page.root.querySelector('.agl-ds-tooltip__trigger');
    expect(triggerElement).toBeTruthy();

    triggerElement.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    expect(paragraphElement.className).toContain(`--show`);

    triggerElement.dispatchEvent(new Event('click'));
    await page.waitForChanges();

    expect(paragraphElement.className).not.toContain(`--show`);
  });

  it('should be able to open and close the tooltip on the mouseover and mouseout of the trigger', async () => {
    const page: SpecPage = await newSpecPage({
      components: [TooltipComponent],
      html: `<agl-ds-tooltip><span slot="content">word</span></agl-ds-tooltip>`,
      supportsShadowDom: false
    });

    const paragraphElement = page.root.querySelector('.agl-ds-tooltip__content-paragraph');
    expect(paragraphElement.className).not.toContain(`--show`);

    const triggerElement = page.root.querySelector('.agl-ds-tooltip__trigger');
    expect(triggerElement).toBeTruthy();

    triggerElement.dispatchEvent(new Event('mouseover'));
    await page.waitForChanges();

    expect(paragraphElement.className).toContain(`--show`);

    triggerElement.dispatchEvent(new Event('mouseout'));
    await page.waitForChanges();

    expect(paragraphElement.className).not.toContain(`--show`);
  });

  it('should be able to open and close the tooltip on the focus and blur of the trigger', async () => {
    const page: SpecPage = await newSpecPage({
      components: [TooltipComponent],
      html: `<agl-ds-tooltip><span slot="content">word</span></agl-ds-tooltip>`,
      supportsShadowDom: false
    });

    const paragraphElement = page.root.querySelector('.agl-ds-tooltip__content-paragraph');
    expect(paragraphElement.className).not.toContain(`--show`);

    const triggerElement = page.root.querySelector('.agl-ds-tooltip__trigger');
    expect(triggerElement).toBeTruthy();

    triggerElement.dispatchEvent(new Event('focus'));
    await page.waitForChanges();

    expect(paragraphElement.className).toContain(`--show`);

    triggerElement.dispatchEvent(new Event('blur'));
    await page.waitForChanges();

    expect(paragraphElement.className).not.toContain(`--show`);
  });
});
