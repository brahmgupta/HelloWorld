export type TooltipPositionX = 'center' | 'left' | 'right';
export type EventType = 'click' | 'touch' | 'mouse' | 'focus' | 'blur';
