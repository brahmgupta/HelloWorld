# agl-ds-text



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                      | Type                                                                                   | Default     |
| --------------- | ---------------- | ------------------------------------------------ | -------------------------------------------------------------------------------------- | ----------- |
| `appearance`    | `appearance`     | Determines the over-ride font colour of the text | `"default" \| "error" \| "highlight" \| "inverse" \| "muted" \| "secondary-highlight"` | `'default'` |
| `fontWeight`    | `font-weight`    | Determines the over-ride weight of the text      | `"inherit" \| "regular" \| "semibold"`                                                 | `'inherit'` |
| `letterSpacing` | `letter-spacing` | Determines the letter spacing of the text        | `"default" \| "sm"`                                                                    | `'default'` |
| `styledAs`      | `styled-as`      | Determines the over-ride size of the text        | `"display01" \| "display02" \| "inherit" \| "lg" \| "md" \| "sm" \| "xl" \| "xs"`      | `'inherit'` |


## Slots

| Slot                                                                      | Description |
| ------------------------------------------------------------------------- | ----------- |
| `"The content placed in this slot will be styled according to the props"` |             |


## Dependencies

### Used by

 - [agl-ds-autocomplete](../../composite/autocomplete)
 - [agl-ds-day-of-month-picker](../day-of-month-picker)
 - [agl-ds-feature-card](../../composite/icon-text-card/feature-card)
 - [agl-ds-feature-item](../../composite/icon-text-card/feature-item)
 - [agl-ds-form-field-label](../form-field-label)
 - [agl-ds-fulfilment-container](../../layout/fulfilment-container)
 - [agl-ds-menu-dropdown-item](../../composite/menu-dropdown/menu-dropdown-item)
 - [agl-ds-next-steps-item](../next-steps/next-steps-item)
 - [agl-ds-prefooter](../../composite/icon-text-card/prefooter)
 - [agl-ds-promo-card](../../composite/icon-text-card/promo-card)
 - [agl-ds-segmented-card](../../composite/segmented-card)
 - [agl-ds-stepper](../../composite/stepper)

### Graph
```mermaid
graph TD;
  agl-ds-autocomplete --> agl-ds-text
  agl-ds-day-of-month-picker --> agl-ds-text
  agl-ds-feature-card --> agl-ds-text
  agl-ds-feature-item --> agl-ds-text
  agl-ds-form-field-label --> agl-ds-text
  agl-ds-fulfilment-container --> agl-ds-text
  agl-ds-menu-dropdown-item --> agl-ds-text
  agl-ds-next-steps-item --> agl-ds-text
  agl-ds-prefooter --> agl-ds-text
  agl-ds-promo-card --> agl-ds-text
  agl-ds-segmented-card --> agl-ds-text
  agl-ds-stepper --> agl-ds-text
  style agl-ds-text fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
