import { newSpecPage } from '@stencil/core/testing';
import { TextComponent } from './text.component';

describe('text component', () => {
  it('should render the component', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: `<agl-ds-text>dummy text</agl-ds-text>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-text>
        <mock:shadow-root>
          <span class="agl-ds-default-colour agl-ds-text--font-weight-inherit agl-ds-text--font-size-inherit">
            <slot></slot>
          </span>
        </mock:shadow-root>
        dummy text
      </agl-ds-text>
    `);
  });

  it('should render the component with a span tag and styled with xl font', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text styled-as="xl">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-size-xl');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a span tag and styled with lg font', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text styled-as="lg">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-size-lg');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a span tag and styled with md font', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text styled-as="md">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-size-md');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a span tag and styled with sm font', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text styled-as="sm">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-size-sm');
    expect(classList).toBeTruthy();
  });

  it('should render the component with a span tag and styled with xs font', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text styled-as="xs">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-size-xs');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the default colour', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text>dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-default-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the muted colour', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text appearance="muted">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-muted-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the highlighted colour', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text appearance="highlight">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-highlight-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the inverse colour', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text appearance="inverse">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-inverse-colour');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the inherited fontWeight', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text font-weight="inherit">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-weight-inherit');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the semi bold fontWeight', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text font-weight="semibold">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-weight-semibold');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the regular fontWeight', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text font-weight="regular">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--font-weight-regular');
    expect(classList).toBeTruthy();
  });

  it('should render the component with the letter spacing small', async () => {
    const page = await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text letter-spacing="sm">dummy text</agl-ds-text>',
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('span');
    const classList = element.classList.contains('agl-ds-text--letter-spacing-sm');
    expect(classList).toBeTruthy();
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text><agl-ds-text>dummy text<agl-ds-text><agl-ds-link>dummy text</agl-ds-link></agl-ds-text>',
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [TextComponent],
      html: '<agl-ds-text><p>dummy text</p></agl-ds-text>',
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
