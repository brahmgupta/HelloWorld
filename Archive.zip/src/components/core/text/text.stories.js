import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/text'
};

export const Default = () => html`
  <agl-ds-p styled-as="${select('p tag styled as', ['xs', 'sm', 'md', 'lg', 'xl'], 'md')}">
    <agl-ds-text
      styled-as="${select('span tag styled as', ['inherit', 'xs', 'sm', 'md', 'lg', 'xl', 'display01', 'display02'], 'inherit')}"
      appearance="${select('appearance', ['default', 'muted', 'highlight', 'inverse', 'secondary-highlight', 'error'], 'highlight')}"
      font-weight="${select('font weight', ['inherit', 'semibold', 'regular'], 'semibold')}"
      letter-spacing="${select('letter spacing', ['default', 'sm'], 'default')}"
    >
      ${text('body text', "I'm an example of a span with text styles that override the parent p tag styles")}
    </agl-ds-text>
    and I am not highlighted
  </agl-ds-p>
  <br />
  <agl-ds-text
    styled-as="${select('styled as eg 2', ['inherit', 'xs', 'sm', 'md', 'lg', 'xl'], 'inherit')}"
    appearance="${select('appearance eg 2', ['default', 'muted', 'highlight', 'inverse', 'secondary-highlight', 'error'], 'default')}"
    font-weight="${select('font weight eg 2', ['inherit', 'semibold', 'regular'], 'inherit')}"
  >
    ${text('body text eg 2', "Eg 2 I'm an example of stand alone text")}
  </agl-ds-text>
`;

Default.storyName = 'default';
Default.parameters = { notes };
