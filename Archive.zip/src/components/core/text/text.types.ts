export type LetterSpacing = 'default' | 'sm';
