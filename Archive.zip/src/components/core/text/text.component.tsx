import { Component, h, Host, Prop, Element, ComponentInterface } from '@stencil/core';
import { FontSizes, FontWeight, TextAppearance } from '../../../global/component.types';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { LetterSpacing } from './text.types';

/**
 *@slot The content placed in this slot will be styled according to the props
 */

@Component({
  tag: 'agl-ds-text',
  styleUrl: 'text.component.scss',
  shadow: true
})
export class TextComponent implements ComponentInterface {
  /**
   *this component as HTML Element
   */
  @Element() host: HTMLAglDsTextElement;

  /**
   * Determines the over-ride size of the text
   */
  @Prop() styledAs: FontSizes = 'inherit';

  /**
   * Determines the over-ride weight of the text
   */
  @Prop() fontWeight: FontWeight = 'inherit';

  /**
   * Determines the over-ride font colour of the text
   */
  @Prop() appearance: TextAppearance = 'default';

  /**
   * Determines the letter spacing of the text
   */
  @Prop() letterSpacing: LetterSpacing = 'default';

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-text', 'agl-ds-link', 'slot', 'span']);
  }

  render() {
    return (
      <Host>
        <span
          class={{
            ['agl-ds-text--font-size-' + this.styledAs]: true,
            ['agl-ds-text--font-weight-' + this.fontWeight]: true,
            ['agl-ds-' + this.appearance + '-colour']: true,
            ['agl-ds-text--letter-spacing-' + this.letterSpacing]: this.letterSpacing !== 'default'
          }}
        >
          <slot />
        </span>
      </Host>
    );
  }
}
