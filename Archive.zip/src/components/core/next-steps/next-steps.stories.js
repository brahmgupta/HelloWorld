import { text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './next-steps-item/readme.md';

export default {
  title: 'Core/next-steps'
};

export const Default = () => html`
  <agl-ds-next-steps>
    <agl-ds-next-steps-item
      is-complete="true"
      heading="${text('Heading', 'Quote accepted')}"
      sub-heading="${text('Sub heading', '24 April 2020')}"
      content="${text('Content', 'You’re in the 5-business-day cooling off period right now. ( this content is passed in via the prop)')}"
    >
    </agl-ds-next-steps-item>

    <agl-ds-next-steps-item is-complete="false" heading="Deposit payment">
      <agl-ds-p styled-as="md">
        This is when your deposit of $594.45 is due. This will automatically be deducted from your VISA card ending in XXXX. (this content
        is passed in via the slot)
      </agl-ds-p>
    </agl-ds-next-steps-item>
    <agl-ds-next-steps-item is-complete="false" heading="Deposit payment">
      <agl-ds-p styled-as="md"> This is a random other piece of content </agl-ds-p>
    </agl-ds-next-steps-item>
  </agl-ds-next-steps>
`;

Default.storyName = 'default';
Default.parameters = { notes };
