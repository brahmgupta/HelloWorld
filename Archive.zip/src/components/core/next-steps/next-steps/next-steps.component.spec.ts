import { newSpecPage } from '@stencil/core/testing';
import { NextStepsItemComponent } from './../next-steps-item/next-steps-item.component';
import { NextStepsComponent } from './next-steps.component';

describe('next-steps-item component', () => {
  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [NextStepsComponent, NextStepsItemComponent],
      html: `
        <agl-ds-next-steps>
          <agl-ds-next-steps-item>dummy text </agl-ds-next-steps-item>
        </agl-ds-next-steps>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [NextStepsComponent, NextStepsItemComponent],
      html: `
        <agl-ds-next-steps>
          <p>dummy text</p>
          <agl-ds-next-steps-item>dummy text</agl-ds-next-steps-item>
        </agl-ds-next-steps>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
