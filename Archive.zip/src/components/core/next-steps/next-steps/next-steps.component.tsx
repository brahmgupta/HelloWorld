import { Component, h, Host, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../../global/utils/utils';

/**
 *@slot content - The content placed into this slot is one to many agl-ds-next-steps-item components or
 */

@Component({
  tag: 'agl-ds-next-steps',
  styleUrl: 'next-steps.component.scss',
  shadow: true
})
export class NextStepsComponent implements ComponentInterface {
  @Element() host: HTMLAglDsNextStepsElement;

  componentDidLoad() {
    const nextStepsSection = this.host.children;
    if (nextStepsSection[0]) {
      const connectingLine = nextStepsSection[nextStepsSection.length - 1].shadowRoot.querySelector(
        '.container__left-connecting-line'
      ) as HTMLElement;
      // remove the last dotted line
      connectingLine.classList.add('hidden');
    }
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-next-steps', 'agl-ds-next-steps-item']);
  }

  render() {
    return (
      <Host>
        <slot />
      </Host>
    );
  }
}
