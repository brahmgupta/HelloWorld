# agl-ds-next-steps



<!-- Auto Generated Below -->


## Slots

| Slot        | Description                                                                           |
| ----------- | ------------------------------------------------------------------------------------- |
| `"content"` | The content placed into this slot is one to many agl-ds-next-steps-item components or |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
