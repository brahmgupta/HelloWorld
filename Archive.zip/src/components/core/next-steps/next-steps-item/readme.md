# agl-ds-next-steps-item



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description                                                                                                 | Type      | Default |
| ------------ | ------------- | ----------------------------------------------------------------------------------------------------------- | --------- | ------- |
| `content`    | `content`     | Default styled text for the content part of the section (this is an alternate to passing HTML via the slot) | `string`  | `''`    |
| `heading`    | `heading`     | Text for the first part of the heading                                                                      | `string`  | `''`    |
| `isComplete` | `is-complete` | Determines if the section is complete                                                                       | `boolean` | `false` |
| `subHeading` | `sub-heading` | Text for the second part of the heading                                                                     | `string`  | `''`    |


## Slots

| Slot        | Description                                                            |
| ----------- | ---------------------------------------------------------------------- |
| `"content"` | Use the slot to pass in HTML to the section or the prop for plain text |


## Dependencies

### Depends on

- [agl-ds-text](../../text)
- [agl-ds-p](../../paragraph)

### Graph
```mermaid
graph TD;
  agl-ds-next-steps-item --> agl-ds-text
  agl-ds-next-steps-item --> agl-ds-p
  style agl-ds-next-steps-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
