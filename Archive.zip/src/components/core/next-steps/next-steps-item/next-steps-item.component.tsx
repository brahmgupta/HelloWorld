import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import completeStep from '../../../../assets/circle-with-tick.svg';
import inCompleteStep from '../../../../assets/empty_circle.svg';
import connectingLine from '../../../../assets/connecting-line.svg';
import { resizeSVGsForEdge } from '../../../../global/utils/utils';

/**
 *@slot content - Use the slot to pass in HTML to the section or the prop for plain text
 */

@Component({
  tag: 'agl-ds-next-steps-item',
  styleUrl: 'next-steps-item.component.scss',
  shadow: true
})
export class NextStepsItemComponent implements ComponentInterface {
  private svgSpan: HTMLSpanElement;
  /**
   * Determines if the section is complete
   */
  @Prop() isComplete: boolean = false;

  /**
   * Text for the first part of the heading
   */
  @Prop() heading: string = '';

  /**
   * Text for the second part of the heading
   */
  @Prop() subHeading: string = '';

  /**
   * Default styled text for the content part of the section (this is an alternate to passing HTML via the slot)
   */
  @Prop() content: string = '';

  componentDidLoad() {
    resizeSVGsForEdge(this.svgSpan, '24', '24', '40', '40', '48', '48');
  }

  render() {
    return (
      <Host>
        <div class="container">
          <div class="container__left">
            <span
              ref={(el) => (this.svgSpan = el)}
              aria-hidden="true"
              class="container__left-image"
              innerHTML={this.isComplete ? completeStep : inCompleteStep}
            />
            <span aria-hidden="true" class="container__left-connecting-line" innerHTML={connectingLine} />
          </div>
          <div class="container__right">
            <div class="container__right-header">
              <div>
                <agl-ds-text styledAs="lg" fontWeight="semibold">
                  {this.heading}
                </agl-ds-text>
              </div>
              {this.subHeading && (
                <div>
                  <agl-ds-text styledAs="lg" fontWeight="semibold" appearance="highlight">
                    {this.subHeading}
                  </agl-ds-text>
                </div>
              )}
            </div>
            <div class="container__right-content">{this.content === '' ? <slot /> : <agl-ds-p styledAs="md">{this.content}</agl-ds-p>}</div>
          </div>
        </div>
      </Host>
    );
  }
}
