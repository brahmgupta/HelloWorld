import { newSpecPage } from '@stencil/core/testing';
import { NextStepsItemComponent } from './next-steps-item.component';

describe('next-steps-item component', () => {
  it('should render the component with content passed as a prop', async () => {
    const page = await newSpecPage({
      components: [NextStepsItemComponent],
      html: `
      <agl-ds-next-steps-item
        is-complete="false"
        heading="dummy heading"
        sub-heading="dummy sub heading"
        content="dummy content">
      </agl-ds-next-steps-item>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-next-steps-item content="dummy content" heading="dummy heading" sub-heading="dummy sub heading" is-complete="false">
      <mock:shadow-root>
        <div class="container">
          <div class="container__left">
            <span aria-hidden="true" class="container__left-image">
              svg contents from: src/assets/empty_circle.svg
            </span>
            <span aria-hidden="true" class="container__left-connecting-line">
              svg contents from: src/assets/connecting-line.svg
            </span>
          </div>
          <div class="container__right">
            <div class="container__right-header">
              <div>
                <agl-ds-text fontweight="semibold" styledas="lg">
                  dummy heading
                </agl-ds-text>
              </div>
              <div>
                <agl-ds-text appearance="highlight" fontweight="semibold" styledas="lg">
                  dummy sub heading
                </agl-ds-text>
              </div>
            </div>
            <div class="container__right-content">
              <agl-ds-p styledas="md">
                dummy content
              </agl-ds-p>
            </div>
          </div>
        </div>
      </mock:shadow-root>
    </agl-ds-next-steps-item>
    `);
  });

  it('should render the component with content passed as a slot', async () => {
    const page = await newSpecPage({
      components: [NextStepsItemComponent],
      html: `
      <agl-ds-next-steps-item
        is-complete="false"
        heading="dummy heading"
        sub-heading="dummy sub heading">
        Dummy slotted content
      </agl-ds-next-steps-item>
      `,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(`
      <agl-ds-next-steps-item heading="dummy heading" sub-heading="dummy sub heading" is-complete="false">
        <mock:shadow-root>
          <div class="container">
            <div class="container__left">
              <span aria-hidden="true" class="container__left-image">
                svg contents from: src/assets/empty_circle.svg
              </span>
              <span aria-hidden="true" class="container__left-connecting-line">
                svg contents from: src/assets/connecting-line.svg
              </span>
            </div>
            <div class="container__right">
              <div class="container__right-header">
                <div>
                  <agl-ds-text fontweight="semibold" styledas="lg">
                    dummy heading
                  </agl-ds-text>
                </div>
                <div>
                  <agl-ds-text appearance="highlight" fontweight="semibold" styledas="lg">
                    dummy sub heading
                  </agl-ds-text>
                </div>
              </div>
              <div class="container__right-content">
                <slot></slot>
              </div>
            </div>
          </div>
        </mock:shadow-root>
        Dummy slotted content
      </agl-ds-next-steps-item>
    `);
  });

  it('should render the component with an icon on the left', async () => {
    const page = await newSpecPage({
      components: [NextStepsItemComponent],
      html: `<agl-ds-next-steps-item
              is-complete="true"
              heading="dummy heading"
              sub-heading="dummy sub heading"
              content="dummy content">
            </agl-ds-next-steps-item>
            `,
      supportsShadowDom: false
    });
    const element = await page.doc.querySelector('.container__left-image');
    expect(element).toBeTruthy();
  });
});
