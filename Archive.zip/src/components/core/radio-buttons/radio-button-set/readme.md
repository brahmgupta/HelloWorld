# agl-ds-radio-button-set



<!-- Auto Generated Below -->


## Slots

| Slot | Description                                                                        |
| ---- | ---------------------------------------------------------------------------------- |
|      | The content placed in this slot must be one to many agl-ds-radio-button components |


## Dependencies

### Used by

 - [agl-ds-manual-address-entry](../../../composite/addresssearch/manual-address-entry)

### Graph
```mermaid
graph TD;
  agl-ds-manual-address-entry --> agl-ds-radio-button-set
  style agl-ds-radio-button-set fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
