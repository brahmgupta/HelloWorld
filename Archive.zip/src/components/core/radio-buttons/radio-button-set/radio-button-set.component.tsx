import { Component, h, Host, Element, ComponentInterface } from '@stencil/core';
import { checkSlottedContentForInvalidHTML } from '../../../../global/utils/utils';

/**
 * @slot - The content placed in this slot must be one to many agl-ds-radio-button components
 */

@Component({
  tag: 'agl-ds-radio-button-set',
  styleUrl: 'radio-button-set.component.scss',
  shadow: false // needs to be false to allow the ids to find the aria-describedby
})
export class RadioButtonSetComponent implements ComponentInterface {
  @Element() host: HTMLAglDsRadioButtonSetElement;

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host, ['agl-ds-radio-button-set', 'agl-ds-radio-button']);
  }

  render() {
    return (
      <Host>
        <div class="grid-container grid-container-override">
          <div class="row">
            <slot />
          </div>
        </div>
      </Host>
    );
  }
}
