import { newSpecPage } from '@stencil/core/testing';
import { RadioButtonSetComponent } from '../radio-button-set/radio-button-set.component';
import { FormFieldLabelComponent } from '../../form-field-label/form-field-label.component';
import { RadioButtonComponent } from './../radio-button/radio-button.component';
import { SpacerComponent } from './../../spacer/spacer.component';
import { RadioButtonGroupComponent } from './radio-button-group.component';
import * as utils from './../../../../global/utils/utils';

//TODO fill out the tests when the font details come from ux

describe('Radio button component', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  const dummyUniqueId = '11';
  describe('Display the default component', () => {
    it('should render the component with the default radio buttons ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group">
      <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
      <agl-ds-radio-button-group heading="This is a label for the radio button group">
      <agl-ds-form-field-label>
        <mock:shadow-root>
          <fieldset>
              <legend>
                <span class="agl-ds-default-colour agl-ds-title5">
                This is a label for the radio button group
                </span>
              </legend>
              <agl-ds-spacer>
                <mock:shadow-root>
                  <span class="spacer__border--none spacer__display--block spacer__vertical--space02"></span>
                </mock:shadow-root>
              </agl-ds-spacer>
               <slot></slot>
          </fieldset>
        </mock:shadow-root>
        <agl-ds-radio-button-set>
          <div class="grid-container grid-container-override">
            <div class="row">
              <agl-ds-radio-button group-name="my-group" type="basic" value="1">
                <div class="basic-radio radio-wrapper">
                  <input id="11" name="my-group" type="radio" value="1">
                  <label htmlfor="` +
          dummyUniqueId +
          `"></label>
                </div>
              </agl-ds-radio-button>
              <agl-ds-radio-button group-name="my-group" type="basic" value="2">
                <div class="basic-radio radio-wrapper">
                  <input id="11" name="my-group" type="radio" value="2">
                  <label htmlfor="` +
          dummyUniqueId +
          `"></label>
                </div>
              </agl-ds-radio-button>
            </div>
          </div>
        </agl-ds-radio-button-set>
      </agl-ds-form-field-label>
    </agl-ds-radio-button-group>
    `
      );
    });

    it('should render the component with a sub heading using the attribute', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group" sub-heading="This is a sub heading">
      </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
      <agl-ds-radio-button-group heading="This is a label for the radio button group" sub-heading="This is a sub heading">
      <agl-ds-form-field-label heading="This is a label for the radio button group" styledas="title5">
        <span slot="sub-heading">
          This is a sub heading
        </span>
      </agl-ds-form-field-label>
    </agl-ds-radio-button-group>
    `
      );
    });

    it('should render the component with a sub heading using the slot', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group">
      <span slot="sub-heading">This is a sub heading</span>
      </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
      <agl-ds-radio-button-group heading="This is a label for the radio button group">
      <agl-ds-form-field-label heading="This is a label for the radio button group" styledas="title5">
        <span slot="sub-heading">
          <span slot="sub-heading">
            This is a sub heading
          </span>
        </span>
      </agl-ds-form-field-label>
    </agl-ds-radio-button-group>
    `
      );
    });

    it('should be checked by default when the checked property is passed through as true', async () => {
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" checked="true">A pre-checked radio button</agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`
      });

      const radioButton = page.root.querySelector('agl-ds-radio-button');
      expect(radioButton.attributes.getNamedItem('checked').value).toEqual('true');
    });

    it('should be unchecked by default when the checked property is passed through as false or not passed at all', async () => {
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group" group-name="my-group">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" value="1" checked="false"></agl-ds-radio-button>
      <agl-ds-radio-button group-name="my-group" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`
      });

      const radioButton1 = page.root.querySelector('agl-ds-radio-button[value="1"]');
      expect(radioButton1.attributes.getNamedItem('checked').value).toEqual('false');
      const radioButton2 = page.root.querySelector('agl-ds-radio-button[value="2"]');
      expect(radioButton2.attributes.getNamedItem('checked')).toBeFalsy();
    });

    it('should render the component with the validation text and error-state class is defined', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();

      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent],
        html:
          `<agl-ds-radio-button-group heading="This is a label for the radio button group" sub-heading="This is a sub heading" has-error="true" validation-text="` +
          errorText +
          `"></agl-ds-radio-button-group>`,
        supportsShadowDom: false
      });
      expect(page.root).toEqualHtml(
        `
      <agl-ds-radio-button-group has-error="true" heading="This is a label for the radio button group" sub-heading="This is a sub heading" validation-text="dummy error text">
      <agl-ds-form-field-label heading="This is a label for the radio button group" styledas="title5">
        <span slot="sub-heading">
          This is a sub heading
        </span>
      </agl-ds-form-field-label>
      <div>
        <agl-ds-hint-validation-message asdescribedbyid="` +
          dummyUniqueId +
          `" class="default-radio-button-validation-message" has-error="">
          <div slot="validation-text">` +
          errorText +
          `</div>
        </agl-ds-hint-validation-message>
      </div>
    </agl-ds-radio-button-group>
      `
      );
      const hasError = page.root.querySelector('.error-state');
      expect(hasError).toBeDefined();
    });
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
      html: `
      <agl-ds-radio-button-group group-name="my-group1" value="2" id="myId1">
        <agl-ds-radio-button-set>
        <agl-ds-radio-button group-name="my-group1" value="1">What about this radio. This one has longer text to wrap</agl-ds-radio-button>
        <agl-ds-radio-button group-name="my-group1" value="2">What about this radio</agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the agl-ds-radio-button-group slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
      html: `
      <agl-ds-radio-button-group group-name="my-group1" value="2" id="myId1">
        <p>dummy text</p>
        <agl-ds-radio-button-set>
        <agl-ds-radio-button group-name="my-group1" value="1">What about this radio. This one has longer text to wrap</agl-ds-radio-button>
        <agl-ds-radio-button group-name="my-group1" value="2">What about this radio</agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should console.error when an invalid html tag is passed in via the agl-ds-radio-button-set slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
      html: `
      <agl-ds-radio-button-group group-name="my-group1" value="2" id="myId1">
        <agl-ds-radio-button-set >
          <p>dummy text</p>
          <agl-ds-radio-button group-name="my-group1" value="1">What about this radio. This one has longer text to wrap</agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group1" value="2">What about this radio</agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  it('should console.error when an invalid html tag is passed in via the agl-ds-radio-button slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
      html: `
      <agl-ds-radio-button-group group-name="my-group1" value="2" id="myId1">
        <agl-ds-radio-button-set >
          <agl-ds-radio-button group-name="my-group1" value="1">What about this radio. This one has longer text to wrap</agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group1" value="2">What about this radio</agl-ds-radio-button>
          <p>dummy text</p>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>
      `,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });

  describe('Icon Radio button component', () => {
    it('should render the component with the icon radio buttons ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" value="1" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" value="2" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
        <agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-form-field-label>
          <mock:shadow-root>
            <fieldset>
              <legend>
                <span class="agl-ds-default-colour agl-ds-title5">
                This is a label for the radio button group
                </span>
              </legend>

                <agl-ds-spacer>
                  <mock:shadow-root>
                    <span class="spacer__border--none spacer__display--block spacer__vertical--space02"></span>
                  </mock:shadow-root>
                </agl-ds-spacer>
              <slot></slot>
            </fieldset>
          </mock:shadow-root>
          <agl-ds-radio-button-set>
            <div class="grid-container grid-container-override">
              <div class="row">
                <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="1">
                  <div class="icon-or-image-radio radio-wrapper">
                    <input id="11" name="my-group" type="radio" value="1">
                    <label class="large-icon-radio-button" htmlfor="11">
                      <agl-ds-icon class="tick" icon="svg contents from: src/assets/tick.svg" size="xs"></agl-ds-icon>
                      <span class="large-svg">
                        svg contents from: src/assets/agl_icon_dig_battery_32px.svg
                      </span>
                    </label>
                  </div>
                </agl-ds-radio-button>
                <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="2">
                  <div class="icon-or-image-radio radio-wrapper">
                    <input id="11" name="my-group" type="radio" value="2">
                    <label class="large-icon-radio-button" htmlfor="11">
                      <agl-ds-icon class="tick" icon="svg contents from: src/assets/tick.svg" size="xs"></agl-ds-icon>
                      <span class="large-svg">
                        svg contents from: src/assets/agl_icon_dig_battery_32px.svg
                      </span>
                    </label>
                  </div>
                </agl-ds-radio-button>
              </div>
            </div>
          </agl-ds-radio-button-set>
        </agl-ds-form-field-label>
      </agl-ds-radio-button-group>
      `
      );
    });

    it('should set the aria attributes on error for the icon radio button', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="true" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toEqual(dummyUniqueId);
      expect(radioButton.getAttribute('aria-invalid')).toEqual('true');
    });

    it('should not set the aria attributes on error for the icon radio button when no error', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="false" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="agl_icon_dig_battery_32px"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toBeNull();
      expect(radioButton.getAttribute('aria-invalid')).toBeNull();
    });
  });

  describe('Content Radio button component', () => {
    it('should set the aria attributes on error for the content radio button', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="true" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="content"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="content"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toEqual(dummyUniqueId);
      expect(radioButton.getAttribute('aria-invalid')).toEqual('true');
    });

    it('should not set the aria attributes on error for the content radio button when no error', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="false" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="content"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="content"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toBeNull();
      expect(radioButton.getAttribute('aria-invalid')).toBeNull();
    });
  });

  describe('Panel Radio button component', () => {
    it('should render the component with the panel radio buttons ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" value="1" type="panel"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" value="2" type="panel"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
        <agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-form-field-label>
          <mock:shadow-root>
            <fieldset>
              <legend>
                <span class="agl-ds-default-colour agl-ds-title5">
                This is a label for the radio button group
                </span>
              </legend>

                <agl-ds-spacer>
                  <mock:shadow-root>
                    <span class="spacer__border--none spacer__display--block spacer__vertical--space02"></span>
                  </mock:shadow-root>
                </agl-ds-spacer>
            <slot></slot>
            </fieldset>
          </mock:shadow-root>
          <agl-ds-radio-button-set>
            <div class="grid-container grid-container-override">
              <div class="row">
                <agl-ds-radio-button group-name="my-group" type="panel" value="1">
                  <div class="panel-radio radio-wrapper" data-group-name="my-group">
                    <input id="11" name="my-group" type="radio" value="1">
                    <label htmlfor="11"></label>
                  </div>
                </agl-ds-radio-button>
                <agl-ds-radio-button group-name="my-group" type="panel" value="2">
                  <div class="panel-radio radio-wrapper" data-group-name="my-group">
                    <input id="11" name="my-group" type="radio" value="2">
                    <label htmlfor="11"></label>
                  </div>
                </agl-ds-radio-button>
              </div>
            </div>
          </agl-ds-radio-button-set>
        </agl-ds-form-field-label>
      </agl-ds-radio-button-group>
      `
      );
    });

    it('should set the aria attributes on error for the panel radio button', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="true" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="panel"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="panel"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toEqual(dummyUniqueId);
      expect(radioButton.getAttribute('aria-invalid')).toEqual('true');
    });

    it('should not set the aria attributes on error for the panel radio button when no error', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="false" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1" type="panel"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="panel"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toBeNull();
      expect(radioButton.getAttribute('aria-invalid')).toBeNull();
    });

    it('should display the panel for the panel radio button when passed', async () => {
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `
      <agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group">
        <agl-ds-radio-button-set>
        <agl-ds-radio-button group-name="my-group" value="1" type="panel">
        <div slot="panel">dummy panel text</div>
          </agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2" type="panel"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
          </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const panelRadioButton = page.doc.querySelectorAll('[type="panel"]');
      expect(panelRadioButton[0].querySelectorAll('.expand-panel')).toBeTruthy();
      expect(panelRadioButton[1].querySelectorAll('.expand-panel')).toEqual([]);
    });
  });

  describe('Image Radio button component', () => {
    it('should render the component with the image radio buttons ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      jest.spyOn(utils, 'getSiblings').mockImplementation();
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" value="1" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" value="2" image-path="https://via.placeholder.com/240x360/0bf/fff?text=B" type="image"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`
      });
      expect(page.root).toEqualHtml(
        `
        <agl-ds-radio-button-group heading="This is a label for the radio button group">
        <agl-ds-form-field-label>
          <mock:shadow-root>
            <fieldset>
                <legend>
                  <span class="agl-ds-default-colour agl-ds-title5">
                  This is a label for the radio button group
                  </span>
                </legend>
                <agl-ds-spacer>
                  <mock:shadow-root>
                    <span class="spacer__border--none spacer__display--block spacer__vertical--space02"></span>
                  </mock:shadow-root>
                </agl-ds-spacer>
            <slot></slot>
            </fieldset>
          </mock:shadow-root>
          <agl-ds-radio-button-set>
            <div class="grid-container grid-container-override">
              <div class="row">
                <agl-ds-radio-button group-name="my-group" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image" value="1">
                  <div class="icon-or-image-radio radio-wrapper">
                    <input id="11" name="my-group" type="radio" value="1">
                    <label htmlfor="11">
                      <agl-ds-icon class="tick" icon="svg contents from: src/assets/tick.svg" size="xs"></agl-ds-icon>
                      <img aria-hidden="true" class="icon-or-image-radio__image" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
                    </label>
                  </div>
                </agl-ds-radio-button>
                <agl-ds-radio-button group-name="my-group" image-path="https://via.placeholder.com/240x360/0bf/fff?text=B" type="image" value="2">
                  <div class="icon-or-image-radio radio-wrapper">
                    <input id="11" name="my-group" type="radio" value="2">
                    <label htmlfor="11">
                    <agl-ds-icon class="tick" icon="svg contents from: src/assets/tick.svg" size="xs"></agl-ds-icon>
                      <img aria-hidden="true" class="icon-or-image-radio__image" src="https://via.placeholder.com/240x360/0bf/fff?text=B">
                    </label>
                  </div>
                </agl-ds-radio-button>
              </div>
            </div>
          </agl-ds-radio-button-set>
        </agl-ds-form-field-label>
      </agl-ds-radio-button-group>
      `
      );
    });

    it('should set the aria attributes on error for the image radio button', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="true" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" value="1" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" value="2" image-path="https://via.placeholder.com/240x360/0bf/fff?text=B" type="image"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toEqual(dummyUniqueId);
      expect(radioButton.getAttribute('aria-invalid')).toEqual('true');
    });

    it('should not set the aria attributes on error for the image radio button when no error', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const errorText = 'dummy error text';
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, FormFieldLabelComponent, SpacerComponent, RadioButtonSetComponent, RadioButtonComponent],
        html:
          `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" has-error="false" validation-text="` +
          errorText +
          `">
        <agl-ds-radio-button-set>
        <agl-ds-radio-button group-name="my-group" value="1" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image"></agl-ds-radio-button>
        <agl-ds-radio-button group-name="my-group" value="2" image-path="https://via.placeholder.com/240x360/0bf/fff?text=B" type="image"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.root.querySelector('[type=radio]');
      expect(radioButton.getAttribute('aria-describedby')).toBeNull();
      expect(radioButton.getAttribute('aria-invalid')).toBeNull();
    });
  });

  describe('Display as single column when layout="one-column"', () => {
    it('should display the basic radio buttons in a column when layout="one-column"', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" layout="one-column">
      <agl-ds-radio-button-set>
        <agl-ds-radio-button group-name="my-group" value="1"></agl-ds-radio-button>
        <agl-ds-radio-button group-name="my-group" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
    </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.doc.querySelector('agl-ds-radio-button');
      const hasColSm12 = radioButton.classList.contains('col-sm-12');
      expect(hasColSm12).toBeTruthy();
    });

    it('should display the icon radio buttons in a row when layout is not passed', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" >
          <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="1"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="2"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.doc.querySelector('agl-ds-radio-button');
      const hasColSm12 = radioButton.classList.contains('col-sm-12');
      const hasColMd6 = radioButton.classList.contains('col-md-6');
      expect(hasColMd6).toBeTruthy();
      expect(hasColSm12).toBeTruthy();
    });

    it('should display the icon radio buttons in a column when layout="one-column"', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" layout="one-column">
          <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="1"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="2"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="3"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.doc.querySelector('agl-ds-radio-button');
      const hasColSm12 = radioButton.classList.contains('col-sm-12');
      const hasColMd6 = radioButton.classList.contains('col-md-6');
      expect(hasColSm12).toBeTruthy();
      expect(hasColMd6).toBeFalsy();
    });

    it('should display the icon radio buttons in a column when layout="two-column"', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" layout="two-column">
          <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="1"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="2"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="3"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.doc.querySelector('agl-ds-radio-button');
      const hasColSm12 = radioButton.classList.contains('col-sm-12');
      const hasColMd6 = radioButton.classList.contains('col-md-6');
      expect(hasColSm12).toBeTruthy();
      expect(hasColMd6).toBeTruthy();
    });

    it('should display the panel radio buttons in a single column when layout is not passed', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="This is a label for the radio button group" group-name="my-group" >
          <agl-ds-radio-button-set>
            <agl-ds-radio-button group-name="my-group" type="panel" value="1"></agl-ds-radio-button>
            <agl-ds-radio-button group-name="my-group" type="panel" value="2"></agl-ds-radio-button>
          </agl-ds-radio-button-set>
        </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButton = page.doc.querySelector('agl-ds-radio-button');
      const hasColMd6 = radioButton.classList.contains('col-md-6');
      const hasColSm12 = radioButton.classList.contains('col-sm-12');
      expect(hasColMd6).toBeFalsy();
      expect(hasColSm12).toBeTruthy();
    });
  });

  describe('Selected value of the radio button', () => {
    it('should display radio buttons with none pre selected', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeFalsy();
    });

    it('should display the second basic radio button as the default ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group" selected-value="2">
        <agl-ds-radio-button-set>
          <agl-ds-radio-button group-name="my-group" value="1"></agl-ds-radio-button>
          <agl-ds-radio-button group-name="my-group" value="2"></agl-ds-radio-button>
        </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeTruthy();
    });

    it('should display the second panel radio button as the default ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group" selected-value="2">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" type="panel" value="1"></agl-ds-radio-button>
      <agl-ds-radio-button group-name="my-group" type="panel" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeTruthy();
    });

    it('should display the second icon radio button as the default ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group" selected-value="2">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="1"></agl-ds-radio-button>
      <agl-ds-radio-button group-name="my-group" type="agl_icon_dig_battery_32px" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeTruthy();
    });

    it('should display the second image radio button as the default ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group" selected-value="2">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image" value="1"></agl-ds-radio-button>
      <agl-ds-radio-button group-name="my-group" image-path="https://via.placeholder.com/240x360/0bf/fff?text=A" type="image" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeTruthy();
    });

    it('should display the second content radio button as the default ', async () => {
      jest.spyOn(utils, 'generateRandomNumber').mockImplementation(() => dummyUniqueId);
      const page = await newSpecPage({
        components: [RadioButtonGroupComponent, RadioButtonSetComponent, RadioButtonComponent],
        html: `<agl-ds-radio-button-group legend="Dummy Label" group-name="my-group" selected-value="2">
      <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="my-group" type="content" value="1"></agl-ds-radio-button>
      <agl-ds-radio-button group-name="my-group" type="content" value="2"></agl-ds-radio-button>
      </agl-ds-radio-button-set>
      </agl-ds-radio-button-group>`,
        supportsShadowDom: true
      });

      const radioButtons = page.doc.querySelectorAll('input[type=radio]');
      expect((radioButtons[0] as HTMLInputElement).checked).toBeFalsy();
      expect((radioButtons[1] as HTMLInputElement).checked).toBeTruthy();
    });
  });
});
