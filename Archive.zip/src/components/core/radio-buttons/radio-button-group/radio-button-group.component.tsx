import { Component, h, Host, Prop, Element, Watch, Listen, EventEmitter, Event, ComponentInterface } from '@stencil/core';
import { FormFieldTitleType } from '../../form-field-label/form-field-label.types';
import { checkSlottedContentForInvalidHTML, generateRandomNumber, getSiblings } from '../../../../global/utils/utils';
import { Layout } from '../common/radio-button.types';

/**
 * @slot sub-heading - Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading
 * @slot default - The content placed in this slot must be a agl-ds-radio-button-set.<br>The radio-button-group is to be used as a wrapper around a radio-button-set.<br>The radio-button-set then in turn houses the radio buttons.<dl><dt>A radio-button-set has built in layout behaviour to designate the following</dt><dt>2 radios results in each button taking up 50% each in 1 row</dt><dt>3 radios results in each button taking up 33% each in 1 row</dt><dt>4 radios results in each button taking up 50% each in 2 rows ( 2 in each)</dt><dt>5 radios results in each button taking up 33% each in 2 rows ( 3 and 2 in each)</dt><dt>6 radios results in each button taking up 33% each in 2 row  ( 3 each)</dt><dt>7 radios results in each button taking up 33% each in 3 row  ( 3, 3 and 1)</dt></dl> Image Radio buttons with a total button count not equal to 2 or 4 on mobile and desktop will have cropped images.
 */

@Component({
  tag: 'agl-ds-radio-button-group',
  styleUrl: 'radio-button-group.component.scss',
  shadow: false, // needs to be false to allow the ids to find the aria-describedby
  scoped: true
})
export class RadioButtonGroupComponent implements ComponentInterface {
  private isBasicRadioButton = false;
  private isPanelRadioButton = false;

  @Element() host: HTMLAglDsRadioButtonGroupElement;

  /**
   *  Unique ID for the radio button group
   */
  @Prop() radioButtonGroupId: string = generateRandomNumber();

  /**
   * The group name for the radio button
   */
  @Prop() groupName!: string;

  /**
   * The legend/heading for the radio button input field
   */
  @Prop() heading: string;

  /**
   * The sub heading for the radio button input field. There is also a slot which can be used for the inclusion of Phrasing content
   * (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading
   */
  @Prop() subHeading: string;

  /**
   * The validation/ error text for the radio button group
   */
  @Prop() validationText: string = null;

  /**
   * Shows the radio buttons in the group in an error state
   */
  @Prop() hasError: boolean = false;

  /**
   * Sets the default value of the radio button group
   */
  @Prop({ mutable: true }) selectedValue: string;

  /**
   * Sets the default value of the radio button group
   * @deprecated use selectedValue
   */
  @Prop() value: string;

  /**
   * Determines the layout direction of the radio buttons on medium and large devices. This will override the default layout behavior of the radio buttons. Note single-column= false can't be used with the panel radio buttons.
   * @deprecated use layout
   */
  @Prop() singleColumn: boolean = false;

  /**
   * Determines the no of columns the radio buttons will be allocated to on medium and large devices. This will override the default layout behavior of the radio buttons. Note noOfColumns can't be used with the panel radio buttons.
   */
  @Prop({ mutable: true }) layout: Layout = 'default';

  /**
   * Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present.
   */
  @Prop() styledAs: FormFieldTitleType = 'title5';

  /**
   * Radio button value changed event
   */
  @Event({ bubbles: false }) valueChange: EventEmitter;

  @Listen('dsCheckedChange')
  dsCheckedChangeHandler(event: CustomEvent) {
    // check to make sure that its the correct event that is being listened to as a child radio button group within a panel radio button will fire the parents event as well
    // if this check is not made then the parent panel radio button will close once a child radio button is selected
    if ((event.composedPath()[0] as HTMLAglDsRadioButtonElement).groupName === this.groupName) {
      this.selectedValue = event.detail.value; //needs to be set for ngmodel and formcontrolname
      this.valueChange.emit(event.detail.value); // emit the value for the valuechange event
    }
  }

  @Watch('selectedValue')
  selectedValueChanged() {
    this.init(this.hasError);
  }

  @Watch('value')
  valueChanged(value: string) {
    if (this.value) {
      this.selectedValue = value;
    }
    this.init(this.hasError);
  }

  @Watch('hasError')
  init(hasError: boolean) {
    // TODO look at splitting out this function as many parts do not need to be run on every watch change especially the layout function
    const radioButtonSets = getSiblings(this.host.querySelector('agl-ds-radio-button-set'));
    if (radioButtonSets?.length > 0) {
      for (let x = 0; x < radioButtonSets.length; x++) {
        const radioButtons = getSiblings(radioButtonSets[x].querySelector('agl-ds-radio-button'));
        if (radioButtons?.length > 0) {
          for (let y = 0; y < radioButtons.length; y++) {
            const radioButton = (radioButtons[y] as unknown) as HTMLAglDsRadioButtonElement;
            const radioButtonInput = (radioButton.querySelectorAll('input')[0] as unknown) as HTMLInputElement;
            //select the default radio button if required
            if (this.selectedValue && radioButtonInput) {
              radioButton.checked = radioButtonInput.value === this.selectedValue;
            } else {
              radioButton.checked = false;
            }
            let radioButtonBorderElement = null;
            radioButtonBorderElement = radioButton;
            this.isBasicRadioButton = radioButton.type === 'basic';
            this.isPanelRadioButton = radioButton.type === 'panel';

            if (!this.isPanelRadioButton) {
              radioButtonBorderElement = (radioButton.querySelectorAll('label')[0] as unknown) as HTMLLabelElement;
            } else {
              this.layout = 'one-column';
            }
            if (radioButtonBorderElement && radioButtonInput) {
              if (hasError) {
                if (this.isBasicRadioButton || this.isPanelRadioButton) {
                  radioButtonInput.classList.add('basic-radio-button-error-state');
                }
                if (!this.isBasicRadioButton) {
                  radioButtonBorderElement.classList.add('error-state');
                }
                radioButtonInput.setAttribute('aria-describedby', this.radioButtonGroupId);
                radioButtonInput.setAttribute('aria-invalid', 'true');
              } else {
                if (this.isBasicRadioButton || this.isPanelRadioButton) {
                  radioButtonInput.classList.remove('basic-radio-button-error-state');
                }
                if (!this.isBasicRadioButton) {
                  radioButtonBorderElement.classList.remove('error-state');
                }
                radioButtonInput.removeAttribute('aria-describedby');
                radioButtonInput.removeAttribute('aria-invalid');
              }
            }
            this.layoutRadioButtons(radioButton, radioButtons.length, radioButtonInput);
          }
        }
      }
    }
  }

  private layoutRadioButtons(radioButton: HTMLAglDsRadioButtonElement, radioButtonCount: number, radioButtonInput: any) {
    //here to cater for the deprecated prop singleColumn

    if (this.singleColumn) {
      this.layout = 'one-column';
    }
    if (this.layout !== 'default' && radioButton.type !== 'panel') {
      if (this.layout === 'one-column') {
        radioButton.classList.add('col-sm-12');
      } else if (this.layout === 'two-column') {
        radioButton.classList.add('col-sm-12');
        radioButton.classList.add('col-md-6');
        radioButton.classList.add('remove-horizonal-padding');
      }
    } else {
      if (radioButton.type === 'basic') {
        //just sit the radio buttons side by side
        return;
      } else if (radioButton.type === 'panel') {
        radioButton.classList.add('col-sm-12');
      } else {
        radioButton.classList.add('remove-horizonal-padding');
        if (radioButton.size === 'small' && radioButtonCount === 2) {
          radioButton.classList.add('col-sm-12');
          radioButton.classList.add('col-md-5');
        } else {
          if (radioButtonCount === 2 || radioButtonCount === 4) {
            radioButton.classList.add('col-sm-12');
            radioButton.classList.add('col-md-6');
            if (radioButtonInput && radioButton.type === 'image') {
              radioButtonInput.classList.remove('icon-or-image-radio__cropped-image');
            }
          } else {
            radioButton.classList.add('col-sm-12');
            radioButton.classList.add('col-md-4');
            if (radioButtonInput && radioButton.type === 'image') {
              radioButtonInput.classList.add('icon-or-image-radio__cropped-image');
            }
          }
        }
      }
    }
  }

  componentDidLoad() {
    this.init(this.hasError);
  }

  componentWillLoad() {
    checkSlottedContentForInvalidHTML(this.host as HTMLElement, ['agl-ds-radio-button-group', 'agl-ds-radio-button-set', 'span']);
    this.valueChanged(this.value);
  }

  private renderSubHeading() {
    if (this.subHeading?.length > 0 || this.host.querySelector('[slot="sub-heading"]')?.innerHTML.length > 0) {
      return <span slot="sub-heading">{this.subHeading ? this.subHeading : <slot name="sub-heading" />}</span>;
    }
    return '';
  }

  render() {
    return (
      <Host>
        <agl-ds-form-field-label heading={this.heading} styledAs={this.styledAs}>
          {this.renderSubHeading()}
          <slot />
        </agl-ds-form-field-label>
        {this.validationText && (
          <div>
            <agl-ds-hint-validation-message
              class={{ ['default-radio-button-validation-message']: !this.isPanelRadioButton && !this.isBasicRadioButton }}
              asDescribedbyId={this.radioButtonGroupId}
              has-error={this.hasError}
            >
              <div slot="validation-text">{this.validationText}</div>
            </agl-ds-hint-validation-message>
          </div>
        )}
      </Host>
    );
  }
}
