# agl-ds-radio-button-group

<!-- Auto Generated Below -->


## Properties

| Property                 | Attribute               | Description                                                                                                                                                                                                                                                                                      | Type                                        | Default                  |
| ------------------------ | ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------- | ------------------------ |
| `groupName` _(required)_ | `group-name`            | The group name for the radio button                                                                                                                                                                                                                                                              | `string`                                    | `undefined`              |
| `hasError`               | `has-error`             | Shows the radio buttons in the group in an error state                                                                                                                                                                                                                                           | `boolean`                                   | `false`                  |
| `heading`                | `heading`               | The legend/heading for the radio button input field                                                                                                                                                                                                                                              | `string`                                    | `undefined`              |
| `layout`                 | `layout`                | Determines the no of columns the radio buttons will be allocated to on medium and large devices. This will override the default layout behavior of the radio buttons. Note noOfColumns can't be used with the panel radio buttons.                                                               | `"default" \| "one-column" \| "two-column"` | `'default'`              |
| `radioButtonGroupId`     | `radio-button-group-id` | Unique ID for the radio button group                                                                                                                                                                                                                                                             | `string`                                    | `generateRandomNumber()` |
| `selectedValue`          | `selected-value`        | Sets the default value of the radio button group                                                                                                                                                                                                                                                 | `string`                                    | `undefined`              |
| `singleColumn`           | `single-column`         | <span style="color:red">**[DEPRECATED]**</span> use layout<br/><br/>Determines the layout direction of the radio buttons on medium and large devices. This will override the default layout behavior of the radio buttons. Note single-column= false can't be used with the panel radio buttons. | `boolean`                                   | `false`                  |
| `styledAs`               | `styled-as`             | Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present.                                                                                                                         | `"title3" \| "title5"`                      | `'title5'`               |
| `subHeading`             | `sub-heading`           | The sub heading for the radio button input field. There is also a slot which can be used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading                             | `string`                                    | `undefined`              |
| `validationText`         | `validation-text`       | The validation/ error text for the radio button group                                                                                                                                                                                                                                            | `string`                                    | `null`                   |
| `value`                  | `value`                 | <span style="color:red">**[DEPRECATED]**</span> use selectedValue<br/><br/>Sets the default value of the radio button group                                                                                                                                                                      | `string`                                    | `undefined`              |


## Events

| Event         | Description                      | Type               |
| ------------- | -------------------------------- | ------------------ |
| `valueChange` | Radio button value changed event | `CustomEvent<any>` |


## Slots

| Slot            | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `"default"`     | The content placed in this slot must be a agl-ds-radio-button-set.<br>The radio-button-group is to be used as a wrapper around a radio-button-set.<br>The radio-button-set then in turn houses the radio buttons.<dl><dt>A radio-button-set has built in layout behaviour to designate the following</dt><dt>2 radios results in each button taking up 50% each in 1 row</dt><dt>3 radios results in each button taking up 33% each in 1 row</dt><dt>4 radios results in each button taking up 50% each in 2 rows ( 2 in each)</dt><dt>5 radios results in each button taking up 33% each in 2 rows ( 3 and 2 in each)</dt><dt>6 radios results in each button taking up 33% each in 2 row  ( 3 each)</dt><dt>7 radios results in each button taking up 33% each in 3 row  ( 3, 3 and 1)</dt></dl> Image Radio buttons with a total button count not equal to 2 or 4 on mobile and desktop will have cropped images. |
| `"sub-heading"` | Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |


## Dependencies

### Used by

 - [agl-ds-manual-address-entry](../../../composite/addresssearch/manual-address-entry)

### Depends on

- [agl-ds-form-field-label](../../form-field-label)
- [agl-ds-hint-validation-message](../../hint-validation-message)

### Graph
```mermaid
graph TD;
  agl-ds-radio-button-group --> agl-ds-form-field-label
  agl-ds-radio-button-group --> agl-ds-hint-validation-message
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-text
  agl-ds-manual-address-entry --> agl-ds-radio-button-group
  style agl-ds-radio-button-group fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
