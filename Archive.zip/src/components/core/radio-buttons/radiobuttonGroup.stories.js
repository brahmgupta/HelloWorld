import { select, boolean, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import * as rbGroupNotes from './radio-button-group/readme.md';
import * as rbSetNotes from './radio-button-set/readme.md';
import * as rbNotes from './radio-button/readme.md';

const allNotes = `${rbGroupNotes.default}\n\n${rbSetNotes.default}\n\n${rbNotes.default}`;

export default {
  title: 'Core/Radio Buttons'
};

export const Basic = () => html`
  <agl-ds-radio-button-group
    group-name="basic-group-1"
    selected-value="2"
    id="basic-id"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    validation-text="${text('Validation text', 'This is validation error text')}"
    heading="${text('heading', 'basic radio buttons')}"
  >
    <span slot="sub-heading">Sample sub heading with a <agl-ds-link>link</agl-ds-link></span>
    <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="basic-group-1" value="1"
        >What about this radio. This one has longer text to wrap</agl-ds-radio-button
      >
      <agl-ds-radio-button group-name="basic-group-1" value="2">What about this radio</agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>

  <label><input type="checkbox" onClick="document.getElementById('basic-id').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br />
  <br />
  <br />
  <agl-ds-radio-button-group
    group-name="basic-group-2"
    selected-value="1"
    heading="basic radio buttons"
    sub-heading="Sample sub heading"
    id="basic-id-2"
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="basic-group-2" value="1">I am really not sure</agl-ds-radio-button>
      <agl-ds-radio-button group-name="basic-group-2" value="2">You know what, I really do love radio buttons</agl-ds-radio-button>
      <agl-ds-radio-button group-name="basic-group-2" value="3">You know what, I really do love radio buttons</agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
`;

Basic.storyName = 'basic';
Basic.parameters = { notes: allNotes };

export const RadioButtonPanel = () => html`
  <agl-ds-radio-button-group
    group-name="radio-button-panel-group1"
    id="radio-button-panel-id-1"
    heading="${text('heading text', 'Do you like radio buttons?')}"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    sub-heading="${text('Sub heading text', 'Sample sub heading text')}"
    validation-text="${text('Validation text', 'This is validation error text')}"
    has-error=${boolean('has error', false)}
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="panel"
        group-name="radio-button-panel-group1"
        value="1"
        checked="${select('First Radio Button checked', ['true', 'false'], 'false')}"
      >
        <span slot="heading"> ${text('body text (first radio button)', 'I kinda like radio buttons')} </span>
        <span slot="panel">
          <agl-ds-radio-button-group
            group-name="icon-group"
            id="icon-id"
            heading="${text('heading text', 'Do you like radio buttons?')}"
            sub-heading="${text('Sub heading text', 'Sub heading as an attribute')}"
            styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
            validation-text="${text('Validation text', 'This is validation error text')}"
            layout="${select('Layout', ['default', 'one-column', 'two-column'], 'two-column')}"
          >
            <agl-ds-radio-button-set>
              <agl-ds-radio-button
                type="${select('Type (first radio button)', radioButtonSvgs, 'agl_icon_dig_internet_32px')}"
                group-name="icon-group"
                value="1"
                size="${select('size', ['large', 'small'], 'large')}"
              >
                ${text('body text (first radio button)', 'I am really not sure')}
              </agl-ds-radio-button>

              <agl-ds-radio-button
                type="agl_icon_dig_battery_32px"
                group-name="icon-group"
                value="2"
                size="${select('size', ['large', 'small'], 'large')}"
              >
                You know what, I really do love radio buttons
              </agl-ds-radio-button>

              <agl-ds-radio-button
                type="agl_icon_dig_moving_32px"
                group-name="icon-group"
                value="3"
                size="${select('size', ['large', 'small'], 'large')}"
              >
                I kinda like radio buttons
              </agl-ds-radio-button>
              <agl-ds-radio-button
                type="agl_icon_dig_question_32px"
                group-name="icon-group"
                value="4"
                size="${select('size', ['large', 'small'], 'large')}"
              >
                I have never liked radio buttons
              </agl-ds-radio-button>

              <agl-ds-radio-button
                type="agl_icon_dig_voip_no_32px"
                group-name="icon-group"
                value="5"
                size="${select('size', ['large', 'small'], 'large')}"
              >
                Sure do
              </agl-ds-radio-button>
            </agl-ds-radio-button-set>
          </agl-ds-radio-button-group>
        </span>
      </agl-ds-radio-button>

      <agl-ds-radio-button type="panel" group-name="radio-button-panel-group1" value="2">
        <span slot="heading">You know what, I really do love radio buttons</span>
        <div slot="panel">
          panel content<br />more content<br />more content
          <agl-ds-radio-button-group
            group-name="radio-button-panel-sub-group2"
            id="myId-sg2"
            heading="Do you like image radio buttons?"
            layout="two-column"
          >
            <agl-ds-radio-button-set>
              <agl-ds-radio-button
                type="image"
                image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
                group-name="radio-button-panel-sub-group2"
                value="1"
                size="large"
              >
                They look great
              </agl-ds-radio-button>
              <agl-ds-radio-button
                type="image"
                image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_townhouse.jpg"
                group-name="radio-button-panel-sub-group2"
                value="2"
                size="large"
              >
                They are ok
              </agl-ds-radio-button>
              <agl-ds-radio-button
                type="image"
                image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_unit.jpg"
                group-name="radio-button-panel-sub-group2"
                value="3"
                size="large"
              >
                I prefer normal ones
              </agl-ds-radio-button>
            </agl-ds-radio-button-set>
          </agl-ds-radio-button-group>
          <agl-ds-form-field-label heading="${text('Heading text', 'Sample heading')}">
            <div class="grid-container">
              <div class="row">
                <div class="col-sm-12 col-md-6">
                  <agl-ds-button>button 1</agl-ds-button>
                </div>
                <div class="col-sm-12 col-md-6">
                  <agl-ds-button>button 2</agl-ds-button>
                </div>
              </div>
            </div>
          </agl-ds-form-field-label>
        </div>
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="panel"
        group-name="radio-button-panel-group1"
        value="3"
        bottom-margin="${select('bottom margin ( demo on 3rd button/panel)', ['none', 'space02', 'space03', 'space04'], 'space03')}"
      >
        <span slot="heading">I have never liked radio buttons</span>
        <div slot="panel">
          panel content<br />more content<br />more content<br />more content<br />more content
          <agl-ds-dropdownbox
            id="mydropdown1"
            validation-text="${text('validation text', 'validation text')}"
            hint-text="${text('hint text', 'hint text')}"
            label="${text('label', 'State')}"
          >
            <agl-ds-dropdown-option text="VIC" value="vic"></agl-ds-dropdown-option>
            <agl-ds-dropdown-option text="NSW" value="nsw"></agl-ds-dropdown-option>
            <agl-ds-dropdown-option text="WA" value="wa"></agl-ds-dropdown-option>
            <agl-ds-dropdown-option text="SA" value="sa"></agl-ds-dropdown-option>
            <agl-ds-dropdown-option text="QLD" value="qld"></agl-ds-dropdown-option>
          </agl-ds-dropdownbox>
          <agl-ds-p>
            Here is some text to test the tooltip under the dropdown list
            <agl-ds-tooltip>The details of the tool tip with some text to wrap onto the next lines</agl-ds-tooltip>
          </agl-ds-p>
        </div>
      </agl-ds-radio-button>

      <agl-ds-radio-button type="panel" group-name="radio-button-panel-group1" value="4">
        <span slot="heading">I dont have a panel</span>
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <label
    ><input type="checkbox" onClick="document.getElementById('radio-button-panel-id-1').setAttribute('has-error',this.checked)" />Toggle
    Error</label
  >
`;

RadioButtonPanel.storyName = 'radio button panel';
RadioButtonPanel.parameters = {
  notes: allNotes,
  a11y: {
    options: {
      rules: {
        // this rule is excluded as its a false error caused by the construction technique using pseudo elements to create the radio button
        'color-contrast': { enabled: false }
      }
    }
  }
};

const radioButtonSvgs = [
  'agl_icon_dig_account_no_32px',
  'agl_icon_dig_account_yes_32px',
  'agl_icon_dig_battery_32px',
  'agl_icon_dig_battery_new_32px',
  'agl_icon_dig_calendar_48px',
  'agl_icon_dig_calendar_dollar_48px',
  'agl_icon_dig_heart_32px',
  'agl_icon_dig_home_32px',
  'agl_icon_dig_internet_32px',
  'agl_icon_dig_internet_no_32px',
  'agl_icon_dig_life_support_32px',
  'agl_icon_dig_listing_no_32px',
  'agl_icon_dig_medical_alarm_32px',
  'agl_icon_dig_modem_32px',
  'agl_icon_dig_modem_use_own_32px',
  'agl_icon_dig_moving_32px',
  'agl_icon_carbon_neutral_on_32px',
  'agl_icon_carbon_neutral_off_32px',
  'agl_icon_dig_pencil_32px',
  'agl_icon_dig_plan_add_32px',
  'agl_icon_dig_plan_edit_32px',
  'agl_icon_dig_question_32px',
  'agl_icon_dig_rent_32px',
  'agl_icon_dig_solar_bundle_32px',
  'agl_icon_dig_solar_no_32px',
  'agl_icon_dig_solar_yes_32px',
  'agl_icon_dig_voip_no_32px',
  'agl_icon_dig_access_no_32px',
  'agl_icon_dig_cross_32px',
  'agl_icon_dig_fix_32px',
  'agl_icon_dig_fix_no_32px',
  'agl_icon_dig_inspect_no_32px',
  'agl_icon_dig_lights_normal_32px',
  'agl_icon_dig_lights_red_32px',
  'agl_icon_dig_lights_screen_error_32px',
  'agl_icon_dig_service_32px',
  'agl_icon_dig_service_no_32px',
  'agl_icon_dig_solar_32px',
  'agl_icon_dig_solar_damage_32px',
  'agl_icon_dig_solar_dirty_32px',
  'agl_icon_dig_solar_shaded_32px',
  'agl_icon_dig_switch_off_32px',
  'agl_icon_dig_switch_on_32px',
  'agl_icon_dig_tick_in_circle_32px',
  'agl_icon_dig_usage_high_32px'
];

function buildAvailableIcons() {
  let icons = [];
  const iconRows = [];

  for (let x = 0; x < radioButtonSvgs.length; x++) {
    if (x % 2) {
      icons.push(html` <div style=" flex: 1; padding: 8px 0;">
        <image alt="eg image" style="width:33px;margin-right:8px;" src="../../assets/${radioButtonSvgs[x]}.svg"></image> ${radioButtonSvgs[
          x
        ]}
      </div>`);
      iconRows.push(html` <div style="display:flex;">${icons}</div>`);
      icons = [];
      if (x === radioButtonSvgs.length - 2) {
        iconRows.push(html` <div style="display:flex;">
          <div style=" flex: 1; padding: 8px 0;">
            <image alt="eg image" style="width:33px;margin-right:8px;" src="../../assets/${radioButtonSvgs[x + 1]}.svg"></image>
            ${radioButtonSvgs[x + 1]}
          </div>
        </div>`);
      }
    } else {
      icons.push(html`
        <div style=" flex: 1; padding: 8px 0;">
          <image alt="eg image" style="width:33px;margin-right:8px;" src="../../assets/${radioButtonSvgs[x]}.svg"></image>
          ${radioButtonSvgs[x]}
        </div>
      `);
    }
  }

  return iconRows;
}

export const Icon = () => html`
  <agl-ds-radio-button-group
    group-name="icon-group"
    id="icon-id"
    heading="${text('heading text', 'Do you like radio buttons?')}"
    sub-heading="${text('Sub heading text', 'Sub heading as an attribute')}"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    validation-text="${text('Validation text', 'This is validation error text')}"
    layout="${select('Layout', ['default', 'one-column', 'two-column'], 'two-column')}"
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="${select('Type (first radio button)', radioButtonSvgs, 'agl_icon_dig_internet_32px')}"
        group-name="icon-group"
        value="1"
        size="${select('size', ['large', 'small'], 'large')}"
      >
        ${text('body text (first radio button)', 'I am really not sure')}
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="agl_icon_dig_battery_32px"
        group-name="icon-group"
        value="2"
        size="${select('size', ['large', 'small'], 'large')}"
      >
        You know what, I really do love radio buttons
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="agl_icon_dig_moving_32px"
        group-name="icon-group"
        value="3"
        size="${select('size', ['large', 'small'], 'large')}"
      >
        I kinda like radio buttons
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="agl_icon_dig_question_32px"
        group-name="icon-group"
        value="4"
        size="${select('size', ['large', 'small'], 'large')}"
      >
        I have never liked radio buttons
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="agl_icon_dig_voip_no_32px"
        group-name="icon-group"
        value="5"
        size="${select('size', ['large', 'small'], 'large')}"
      >
        Sure do
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <label><input type="checkbox" onClick="document.getElementById('icon-id').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br />
  <br />
  <br />
  <br />
  <agl-ds-radio-button-group
    group-name="icon-group-2"
    id="icon-id-2"
    heading="Do you like radio buttons?"
    layout="${select('Layout', ['default', 'one-column', 'two-column'], 'default')}"
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button type="agl_icon_dig_listing_no_32px" group-name="icon-group-2" value="1" size="large">
        I am really not sure
      </agl-ds-radio-button>
      <agl-ds-radio-button type="agl_icon_dig_battery_32px" group-name="icon-group-2" value="2" size="large">
        You know what, I really do love radio buttons
      </agl-ds-radio-button>
      <agl-ds-radio-button type="agl_icon_dig_moving_32px" group-name="icon-group-2" value="3" size="large">
        I kinda like radio buttons
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <br />
  <agl-ds-h5>Available icons</agl-ds-h5>

  ${buildAvailableIcons()}
`;

Icon.storyName = 'icon';
Icon.parameters = { notes: allNotes };

export const Image = () => html`
  <agl-ds-radio-button-group
    group-name="image-group-1"
    id="image-id"
    heading="Do you like radio buttons with cropped images?"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    validation-text="${text('Validation text', 'This is validation error text')}"
    layout="${select('Layout', ['default', 'one-column', 'two-column'], 'default')}"
  >
    <span slot="sub-heading"
      >Image type radio buttons with a total button count not equal to 2 or 4 on tablet and desktop will have cropped images</span
    >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
        value="1"
        group-name="image-group-1"
      >
        I am really not sure but I have some long text to wrap to show that the image will be centered if the text goes over 4 lines
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_townhouse.jpg"
        group-name="image-group-1"
        id="myId1"
        value="2"
      >
        You know what, I really do love radio buttons
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_unit.jpg"
        group-name="image-group-1"
        value="3"
      >
        I kinda like radio buttons
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <label><input type="checkbox" onClick="document.getElementById('image-id').setAttribute('has-error',this.checked)" />Toggle Error</label>
  <br />
  <br />
  <br />
  <agl-ds-radio-button-group
    group-name="image-group-2"
    id="image-id-2"
    heading="Do you like radio buttons with non-cropped images?"
    sub-heading="Image type radio buttons with a total button count equaling 2 or 4 will have full width images"
    styled-as="${select('Styled as', ['title3', 'title5'], 'title3')}"
    layout="${select('Layout', ['default', 'one-column', 'two-column'], 'default')}"
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
        value="1"
        group-name="image-group-2"
      >
        I am really not sure
      </agl-ds-radio-button>

      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_townhouse.jpg"
        group-name="image-group-2"
        value="2"
      >
        You know what, I really do love radio buttons
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_unit.jpg"
        group-name="image-group-2"
        value="3"
      >
        Yes
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_apartment.jpg"
        group-name="image-group-2"
        value="4"
      >
        No
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
`;

Image.storyName = 'image';
Image.parameters = { notes: allNotes };

export const MultipleSets = () => html`
  <agl-ds-radio-button-group
    group-name="multiple-set-group-1"
    id="multiple-set-id"
    heading="Do you like radio buttons?"
    sub-heading="This is the sub heading"
    validation-text="This is validation error text"
    layout="${select('Layout', ['default', 'one-column', 'two-column'], 'default')}"
    has-error=${boolean('has error', false)}
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_house.jpg"
        group-name="multiple-set-group-1"
        value="1"
      >
        I am really not sure
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_townhouse.jpg"
        group-name="multiple-set-group-1"
        value="2"
      >
        You know what, I really do love radio buttons
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_unit.jpg"
        group-name="multiple-set-group-1"
        value="3"
      >
        Yes
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="image"
        image-path="https://www.agl.com.au/content/dam/digital/agl/images/solar-batteries/prequal/property_type_apartment.jpg"
        group-name="multiple-set-group-1"
        value="4"
      >
        No
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
    <agl-ds-radio-button-set>
      <agl-ds-radio-button
        type="agl_icon_dig_internet_32px"
        group-name="multiple-set-group-1"
        value="5"
        size="${select('size', ['large', 'small'], 'small')}"
      >
        I am really not sure
      </agl-ds-radio-button>
      <agl-ds-radio-button
        type="agl_icon_dig_battery_32px"
        group-name="multiple-set-group-1"
        value="6"
        size="${select('size', ['large', 'small'], 'small')}"
      >
        You know what, I really do love radio buttons
      </agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <label
    ><input type="checkbox" onClick="document.getElementById('multiple-set-id').setAttribute('has-error',this.checked)" />Toggle
    Error</label
  >
`;

MultipleSets.storyName = 'multiple sets';
MultipleSets.parameters = { notes: allNotes };

export const Programmatically = () => html`
  <agl-ds-radio-button-group
    group-name="prog-group"
    heading="single radio button that can be checked programmatically"
    id="prog-id"
    validation-text="${text('Validation text', 'This is validation error text')}"
  >
    <agl-ds-radio-button-set>
      <agl-ds-radio-button group-name="prog-group" checked="${select('First Radio Button checked', ['true', 'false'], 'false')}" value="1">
        Use the knobs to change my state
      </agl-ds-radio-button>
      <agl-ds-radio-button group-name="prog-group" value="2">This is a second radio button in the same group</agl-ds-radio-button>
    </agl-ds-radio-button-set>
  </agl-ds-radio-button-group>
  <label><input type="checkbox" onClick="document.getElementById('prog-id').setAttribute('has-error',this.checked)" />Toggle Error</label>
`;

Programmatically.storyName = 'programmatically';
Programmatically.parameters = { notes: allNotes };

//Added styles to give a border around the radio buttons
const style = document.createElement('style');
document.head.appendChild(style);
style.sheet.insertRule('body {margin: 50px !important;}');
style.sheet.insertRule('hr {width: 100%;}');
style.sheet.insertRule('.grid-width {width: 100%;}');
style.sheet.insertRule('.img {display:inline-block; height: 100%;}');
style.sheet.insertRule('.hideme {display: none;}');
style.sheet.insertRule('.myspan {position:absolute; top:50%; transform: translateY(-50%);}');
