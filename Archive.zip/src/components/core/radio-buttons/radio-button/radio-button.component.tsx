import { Component, h, Prop, Host, Element, EventEmitter, Event, Watch, ComponentInterface } from '@stencil/core';
import { BottomMargin, RadioButtonType, Size } from '../common/radio-button.types';
import { generateRandomNumber, checkSlottedContentForInvalidHTML, hideFocusRingWhenUsingMouse } from '../../../../global/utils/utils';
import accountNo from '../../../../assets/agl_icon_dig_account_no_32px.svg';
import accountYes from '../../../../assets/agl_icon_dig_account_yes_32px.svg';
import batteryIcon from '../../../../assets/agl_icon_dig_battery_32px.svg';
import batteryNew from '../../../../assets/agl_icon_dig_battery_new_32px.svg';
import calendar from '../../../../assets/agl_icon_dig_calendar_48px.svg';
import calendarDollar from '../../../../assets/agl_icon_dig_calendar_dollar_48px.svg';
import carbonNeutralOff from '../../../../assets/agl_icon_carbon_neutral_off_32px.svg';
import carbonNeutralOn from '../../../../assets/agl_icon_carbon_neutral_on_32px.svg';
import heartIcon from '../../../../assets/agl_icon_dig_heart_32px.svg';
import homeIcon from '../../../../assets/agl_icon_dig_home_32px.svg';
import internetIcon from '../../../../assets/agl_icon_dig_internet_32px.svg';
import lifeSupportIcon from '../../../../assets/agl_icon_dig_life_support_32px.svg';
import medicalAlarm from '../../../../assets/agl_icon_dig_medical_alarm_32px.svg';
import modemIcon from '../../../../assets/agl_icon_dig_modem_32px.svg';
import modemUseOwnIcon from '../../../../assets/agl_icon_dig_modem_use_own_32px.svg';
import movingIcon from '../../../../assets/agl_icon_dig_moving_32px.svg';
import noInternetIcon from '../../../../assets/agl_icon_dig_internet_no_32px.svg';
import nolistIcon from '../../../../assets/agl_icon_dig_listing_no_32px.svg';
import pencilIcon from '../../../../assets/agl_icon_dig_pencil_32px.svg';
import planAddIcon from '../../../../assets/agl_icon_dig_plan_add_32px.svg';
import planEditIcon from '../../../../assets/agl_icon_dig_plan_edit_32px.svg';
import questionIcon from '../../../../assets/agl_icon_dig_question_32px.svg';
import rentIcon from '../../../../assets/agl_icon_dig_rent_32px.svg';
import solarBundle from '../../../../assets/agl_icon_dig_solar_bundle_32px.svg';
import solarNo from '../../../../assets/agl_icon_dig_solar_no_32px.svg';
import solarYes from '../../../../assets/agl_icon_dig_solar_yes_32px.svg';
import tick from '../../../../assets/tick.svg';
import voipNo from '../../../../assets/agl_icon_dig_voip_no_32px.svg';
import voipYes from '../../../../assets/agl_icon_dig_voip_yes_32px.svg';
import accessNo from '../../../../assets/agl_icon_dig_access_no_32px.svg';
import cross from '../../../../assets/agl_icon_dig_cross_32px.svg';
import fix from '../../../../assets/agl_icon_dig_fix_32px.svg';
import fixNo from '../../../../assets/agl_icon_dig_fix_no_32px.svg';
import inspectNo from '../../../../assets/agl_icon_dig_inspect_no_32px.svg';
import lightsNormal from '../../../../assets/agl_icon_dig_lights_normal_32px.svg';
import lightsRed from '../../../../assets/agl_icon_dig_lights_red_32px.svg';
import lightsScreenError from '../../../../assets/agl_icon_dig_lights_screen_error_32px.svg';
import service from '../../../../assets/agl_icon_dig_service_32px.svg';
import serviceNo from '../../../../assets/agl_icon_dig_service_no_32px.svg';
import solar from '../../../../assets/agl_icon_dig_solar_32px.svg';
import solarDamage from '../../../../assets/agl_icon_dig_solar_damage_32px.svg';
import solarDirty from '../../../../assets/agl_icon_dig_solar_dirty_32px.svg';
import solarShaded from '../../../../assets/agl_icon_dig_solar_shaded_32px.svg';
import switchOff from '../../../../assets/agl_icon_dig_switch_off_32px.svg';
import switchOn from '../../../../assets/agl_icon_dig_switch_on_32px.svg';
import tickInCircle from '../../../../assets/agl_icon_dig_tick_in_circle_32px.svg';
import usageHigh from '../../../../assets/agl_icon_dig_usage_high_32px.svg';

/**
 * @slot sub-heading - Used for the inclusion of Phrasing content (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html) eg. an anchor tag in the sub heading
 */
@Component({
  tag: 'agl-ds-radio-button',
  styleUrl: 'radio-button.component.scss',
  shadow: false // needs to be false so that the radio button web components remain in the group,
  // cannot be scoped as the agl-ds-radio button classes ( that are added by the agl-ds-group component), need to have the scoped class name added as well (ie sc-agl-ds-radio-button)
})
export class RadioButtonComponent implements ComponentInterface {
  @Element() host: HTMLAglDsRadioButtonElement;

  /**
   * The group name for the radio button
   */
  @Prop() groupName: string;

  /**
   * The value for the radio button
   */
  @Prop() value: string;

  /**
   * The type of radio button to be displayed
   */
  @Prop({ reflect: true }) type: RadioButtonType = 'basic';

  /**
   * The type of radio button to be displayed
   */
  @Prop() size: Size = 'large';

  /**
   * Is the radio button in a checked state or not when first displayed.
   */
  @Prop() checked: boolean = false;

  /**
   * Determines the over-ride bottom margin size of the radio button panel
   */
  @Prop({ mutable: true }) bottomMargin: BottomMargin;

  /**
   * The path of the image to be displayed on the image type radio button. Note this image is set at 96px x 128px and its the responsibility of UX to provide an image with the correct 4:3 ratio.
   * Radio buttons with a total button count not equal to 2 or 4 on mobile and desktop will have cropped images 96px x 96px.
   */
  @Prop() imagePath: string;

  /**
   * Radio button changed event (DO NOT USE THIS EVENT IN A SYSTEM THAT USES THE DESIGN LIBRARY) - this is accessed by the radio button group component
   */
  @Event() dsCheckedChange: EventEmitter<CustomEvent>;

  // propagate value change from model to view
  @Watch('checked')
  valueChange() {
    if (this.inputElement) {
      this.inputElement.checked = this.checked;
    }
    if (this.type === 'panel') {
      this.setPanelVisibility(this.inputElement);
    }
  }

  private radioButtonTypes: RadioButtonType[] = [
    'basic',
    'panel',
    'content',
    'image',
    'agl_icon_carbon_neutral_off_32px',
    'agl_icon_carbon_neutral_on_32px',
    'agl_icon_dig_account_no_32px',
    'agl_icon_dig_account_yes_32px',
    'agl_icon_dig_battery_32px',
    'agl_icon_dig_battery_new_32px',
    'agl_icon_dig_calendar_48px',
    'agl_icon_dig_calendar_dollar_48px',
    'agl_icon_dig_heart_32px',
    'agl_icon_dig_home_32px',
    'agl_icon_dig_internet_32px',
    'agl_icon_dig_internet_no_32px',
    'agl_icon_dig_life_support_32px',
    'agl_icon_dig_listing_no_32px',
    'agl_icon_dig_medical_alarm_32px',
    'agl_icon_dig_modem_32px',
    'agl_icon_dig_modem_use_own_32px',
    'agl_icon_dig_moving_32px',
    'agl_icon_dig_pencil_32px',
    'agl_icon_dig_plan_add_32px',
    'agl_icon_dig_plan_edit_32px',
    'agl_icon_dig_question_32px',
    'agl_icon_dig_rent_32px',
    'agl_icon_dig_solar_bundle_32px',
    'agl_icon_dig_solar_no_32px',
    'agl_icon_dig_solar_yes_32px',
    'agl_icon_dig_voip_no_32px',
    'agl_icon_dig_voip_yes_32px',
    'agl_icon_dig_access_no_32px',
    'agl_icon_dig_cross_32px',
    'agl_icon_dig_fix_32px',
    'agl_icon_dig_fix_no_32px',
    'agl_icon_dig_inspect_no_32px',
    'agl_icon_dig_lights_normal_32px',
    'agl_icon_dig_lights_red_32px',
    'agl_icon_dig_lights_screen_error_32px',
    'agl_icon_dig_service_32px',
    'agl_icon_dig_service_no_32px',
    'agl_icon_dig_solar_32px',
    'agl_icon_dig_solar_damage_32px',
    'agl_icon_dig_solar_dirty_32px',
    'agl_icon_dig_solar_shaded_32px',
    'agl_icon_dig_switch_off_32px',
    'agl_icon_dig_switch_on_32px',
    'agl_icon_dig_tick_in_circle_32px',
    'agl_icon_dig_usage_high_32px'
  ];

  componentWillLoad() {
    const illegalDivTags = document.querySelectorAll('.radio-wrapper label div');
    if (illegalDivTags.length > 0) {
      throw new Error('To be semantically correct, the slot can not contain a div tag');
    }
    if (this.bottomMargin && this.type !== 'panel') {
      throw new Error('The bottomMargin prop is only valid with the RadioButtonType.panel type');
    }

    if (!this.radioButtonTypes.includes(this.type)) {
      throw new Error(this.type + ' is not a valid radio button type');
    }

    if (this.type === 'image' && this.size == 'small') {
      throw new Error(this.size + ' is not a valid size for the image radio button type');
    }

    if (!(['large', 'small'] as Size[]).includes(this.size)) {
      throw new Error(this.size + ' is not a valid radio button size');
    }

    if (this.type === 'panel' && !this.bottomMargin) {
      this.bottomMargin = 'space03';
    }

    this.hasPanel = !!this.host.querySelector('[slot="panel"]');

    if (this.host?.children.length > 0) {
      // content radio button type is slatted to be deprecated. so it allows a range of tags for the moment
      if (this.type === 'content') {
        checkSlottedContentForInvalidHTML(this.host, ['agl-ds-text', 'img', 'span', 'hr', 'br', 'p']);
      } else if (this.type !== 'panel') {
        checkSlottedContentForInvalidHTML(this.host, ['agl-ds-text']);
      }
    }
  }

  componentDidLoad() {
    hideFocusRingWhenUsingMouse(this.inputElement);
  }

  // propagate value change from view to model
  private inputChanged(ev: UIEvent) {
    const eventTarget = ev.target;
    this.dsCheckedChange.emit((eventTarget as unknown) as CustomEvent);
    if (this.type === 'panel') {
      this.setPanelVisibility(ev.target as HTMLInputElement);
    }
  }

  private hasPanel: boolean = false;
  private overflowSet: boolean = false;
  private inputElement: HTMLInputElement;
  private panel: HTMLDivElement;
  private getIcon(): string {
    switch (this.type) {
      case 'agl_icon_dig_account_no_32px':
        return accountNo;
      case 'agl_icon_dig_account_yes_32px':
        return accountYes;
      case 'agl_icon_dig_battery_32px':
        return batteryIcon;
      case 'agl_icon_dig_battery_new_32px':
        return batteryNew;
      case 'agl_icon_dig_calendar_48px':
        return calendar;
      case 'agl_icon_dig_calendar_dollar_48px':
        return calendarDollar;
      case 'agl_icon_carbon_neutral_off_32px':
        return carbonNeutralOff;
      case 'agl_icon_carbon_neutral_on_32px':
        return carbonNeutralOn;
      case 'agl_icon_dig_heart_32px':
        return heartIcon;
      case 'agl_icon_dig_home_32px':
        return homeIcon;
      case 'agl_icon_dig_internet_32px':
        return internetIcon;
      case 'agl_icon_dig_internet_no_32px':
        return noInternetIcon;
      case 'agl_icon_dig_life_support_32px':
        return lifeSupportIcon;
      case 'agl_icon_dig_listing_no_32px':
        return nolistIcon;
      case 'agl_icon_dig_medical_alarm_32px':
        return medicalAlarm;
      case 'agl_icon_dig_modem_32px':
        return modemIcon;
      case 'agl_icon_dig_modem_use_own_32px':
        return modemUseOwnIcon;
      case 'agl_icon_dig_moving_32px':
        return movingIcon;
      case 'agl_icon_dig_pencil_32px':
        return pencilIcon;
      case 'agl_icon_dig_plan_add_32px':
        return planAddIcon;
      case 'agl_icon_dig_plan_edit_32px':
        return planEditIcon;
      case 'agl_icon_dig_question_32px':
        return questionIcon;
      case 'agl_icon_dig_rent_32px':
        return rentIcon;
      case 'agl_icon_dig_solar_bundle_32px':
        return solarBundle;
      case 'agl_icon_dig_solar_no_32px':
        return solarNo;
      case 'agl_icon_dig_solar_yes_32px':
        return solarYes;
      case 'agl_icon_dig_voip_no_32px':
        return voipNo;
      case 'agl_icon_dig_voip_yes_32px':
        return voipYes;
      case 'agl_icon_dig_access_no_32px':
        return accessNo;
      case 'agl_icon_dig_cross_32px':
        return cross;
      case 'agl_icon_dig_fix_32px':
        return fix;
      case 'agl_icon_dig_fix_no_32px':
        return fixNo;
      case 'agl_icon_dig_inspect_no_32px':
        return inspectNo;
      case 'agl_icon_dig_lights_normal_32px':
        return lightsNormal;
      case 'agl_icon_dig_lights_red_32px':
        return lightsRed;
      case 'agl_icon_dig_lights_screen_error_32px':
        return lightsScreenError;
      case 'agl_icon_dig_service_32px':
        return service;
      case 'agl_icon_dig_service_no_32px':
        return serviceNo;
      case 'agl_icon_dig_solar_32px':
        return solar;
      case 'agl_icon_dig_solar_damage_32px':
        return solarDamage;
      case 'agl_icon_dig_solar_dirty_32px':
        return solarDirty;
      case 'agl_icon_dig_solar_shaded_32px':
        return solarShaded;
      case 'agl_icon_dig_switch_off_32px':
        return switchOff;
      case 'agl_icon_dig_switch_on_32px':
        return switchOn;
      case 'agl_icon_dig_tick_in_circle_32px':
        return tickInCircle;
      case 'agl_icon_dig_usage_high_32px':
        return usageHigh;

      default:
        throw new Error(this.type + ' is not a valid radio button type');
    }
  }

  private setPanelVisibility(srcElement: HTMLInputElement): void {
    const srcElementParent = srcElement.parentElement;
    (srcElementParent.lastElementChild as HTMLElement).style.overflow = '';
    this.overflowSet = false;
    // make the panels not visible to stop the user being able to tab to the elements in the hidden panel
    if (this.panel) {
      const panels = document.querySelectorAll(`[data-group-name="${this.groupName}"]  .expand-panel`);

      if (panels.length > 0) {
        panels.forEach((panel) => {
          panel.classList.add('not-visible');
        });
        this.panel.classList.remove('not-visible');
      }
    }
  }

  private setPanelOverflowVisible() {
    if (!this.overflowSet) {
      this.overflowSet = true;
      //need to give the animation time to finish, otherwise the panel could show over the top of other panel radio buttons
      setTimeout(() => {
        this.panel.style.overflow = 'visible';
      }, 800);
    }
  }

  private renderInput(id: string) {
    let attributes = {};
    if (this.type === 'panel' && this.hasPanel) {
      attributes = { 'aria-describedby': 'panel-' + id, 'aria-controls': 'panel-' + id };
    }
    return (
      <input
        type="radio"
        ref={(l) => (this.inputElement = l)}
        id={id}
        name={this.groupName}
        checked={this.checked}
        value={this.value}
        onChange={(event: UIEvent) => this.inputChanged(event)}
        {...attributes}
      />
    );
  }

  render() {
    const id = generateRandomNumber();
    if (this.type === 'basic') {
      return (
        <Host>
          <div class="radio-wrapper basic-radio">
            {this.renderInput(id)}
            <label htmlFor={id}>
              <slot />
            </label>
          </div>
        </Host>
      );
    } else if (this.type === 'panel') {
      return (
        <Host>
          <div class="radio-wrapper panel-radio" data-group-name={this.groupName}>
            {this.renderInput(id)}
            <label htmlFor={id}>
              <slot name="heading"></slot>
            </label>
            {this.hasPanel ? (
              <div
                id={'panel-' + id}
                class="expand-panel not-visible"
                aria-label="Expanded content"
                ref={(l) => (this.panel = l)}
                onMouseOver={() => this.setPanelOverflowVisible()}
              >
                <div
                  class={{
                    ['expand-panel__inner']: true,
                    ['agl-ds--bottom-margin-' + this.bottomMargin]: true
                  }}
                >
                  <slot name="panel"></slot>
                </div>
              </div>
            ) : (
              ''
            )}
          </div>
        </Host>
      );
    } else if (this.type.indexOf('icon') >= 0) {
      return (
        <Host>
          <div class="radio-wrapper icon-or-image-radio">
            {this.renderInput(id)}
            <label htmlFor={id} class={this.size + '-icon-radio-button'}>
              <agl-ds-icon class="tick" icon={tick} size="xs"></agl-ds-icon>
              <span class={this.size + '-svg'} innerHTML={this.getIcon()} />
              <slot />
            </label>
          </div>
        </Host>
      );
    } else if (this.type === 'image') {
      return (
        <Host>
          <div class="radio-wrapper icon-or-image-radio">
            {this.renderInput(id)}
            <label htmlFor={id}>
              <agl-ds-icon class="tick" icon={tick} size="xs"></agl-ds-icon>
              <img class="icon-or-image-radio__image" aria-hidden="true" src={this.imagePath} />
              <slot />
            </label>
          </div>
        </Host>
      );
    } else if (this.type === 'content') {
      return (
        <Host>
          <div class="radio-wrapper content-radio">
            {this.renderInput(id)}
            <label htmlFor={id}>
              <agl-ds-icon class="tick" icon={tick} size="xs"></agl-ds-icon>
              <slot />
            </label>
          </div>
        </Host>
      );
    }
  }
}
