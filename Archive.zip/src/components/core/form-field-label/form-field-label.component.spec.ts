import { newSpecPage } from '@stencil/core/testing';
import { FormFieldLabelComponent } from './form-field-label.component';

describe('Formfield label component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [FormFieldLabelComponent],
      html: `<agl-ds-form-field-label heading="Sample heading"></agl-ds-form-field-label>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-form-field-label heading="Sample heading">
        <mock:shadow-root>
          <fieldset>
            <legend>
              <span class="agl-ds-default-colour agl-ds-title5">
                Sample heading
              </span>
            </legend>
            <agl-ds-spacer orientation="vertical" size="space02"></agl-ds-spacer>
            <slot></slot>
          </fieldset>
        </mock:shadow-root>
      </agl-ds-form-field-label>
      `
    );
  });

  it('should render my component with the sub heading using the attribute', async () => {
    const page = await newSpecPage({
      components: [FormFieldLabelComponent],
      html: `<agl-ds-form-field-label heading="Sample heading" sub-heading="sample sub heading"></agl-ds-form-field-label>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-form-field-label heading="Sample heading" sub-heading="sample sub heading">
        <mock:shadow-root>
          <fieldset>
            <legend>
              <span class="agl-ds-default-colour agl-ds-title5">
                Sample heading
              </span>
              <div>
                <agl-ds-spacer orientation="vertical" size="space00"></agl-ds-spacer>
                <agl-ds-text appearance="muted" styledas="xs">
                  sample sub heading
                </agl-ds-text>
              </div>
            </legend>
            <agl-ds-spacer orientation="vertical" size="space02"></agl-ds-spacer>
            <slot></slot>
          </fieldset>
        </mock:shadow-root>
      </agl-ds-form-field-label>
      `
    );
  });

  it('should render my component with the sub heading using the slot', async () => {
    const page = await newSpecPage({
      components: [FormFieldLabelComponent],
      html: `<agl-ds-form-field-label heading="Sample heading"><span slot="sub-heading">sample sub heading</span></agl-ds-form-field-label>`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
      <agl-ds-form-field-label heading="Sample heading">
        <mock:shadow-root>
          <fieldset>
            <legend>
              <span class="agl-ds-default-colour agl-ds-title5">
                Sample heading
              </span>
              <div>
                <agl-ds-spacer orientation="vertical" size="space00"></agl-ds-spacer>
                <agl-ds-text appearance="muted" styledas="xs">
                  <slot name="sub-heading"></slot>
                </agl-ds-text>
              </div>
            </legend>
            <agl-ds-spacer orientation="vertical" size="space02"></agl-ds-spacer>
            <slot></slot>
          </fieldset>
        </mock:shadow-root>
        <span slot="sub-heading">
          sample sub heading
        </span>
      </agl-ds-form-field-label>
      `
    );
  });

  it('should not console.error when valid html tags are passed in via the slot', async () => {
    console.error = () => {
      /**/
    };

    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FormFieldLabelComponent],
      html: `<agl-ds-form-field-label heading="Sample heading"><span slot="sub-heading">sample sub heading <agl-ds-text>test1</agl-ds-text><agl-ds-link>test2</agl-ds-link><span>test3</span></span></agl-ds-form-field-label>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).not.toHaveBeenCalled();
  });

  it('should console.error when an invalid html tag is passed in via the slot', async () => {
    console.error = () => {
      /**/
    };
    const consoleSpy = jest.spyOn(console, 'error');
    await newSpecPage({
      components: [FormFieldLabelComponent],
      html: `<agl-ds-form-field-label heading="Sample heading"><span slot="sub-heading">sample sub heading<p>dummy text</p></span></agl-ds-form-field-label>`,
      supportsShadowDom: true
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      'The following tag(s) (P :innerHTML(dummy text) ) are not considered valid HTML content for the default slot'
    );
  });
});
