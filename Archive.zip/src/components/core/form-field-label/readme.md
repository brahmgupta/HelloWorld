# agl-ds-form-field-label



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description                                                                                                                                                                                                                                                           | Type                   | Default     |
| ------------ | ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ----------- |
| `heading`    | `heading`     | The legend/heading for the form field component                                                                                                                                                                                                                       | `string`               | `undefined` |
| `styledAs`   | `styled-as`   | Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present                                                                                               | `"title3" \| "title5"` | `'title5'`  |
| `subHeading` | `sub-heading` | The sub heading for the radio button input field. There is also a slot which can be used for the inclusion of Phrasing elements (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading | `string`               | `undefined` |


## Slots

| Slot | Description                                                                                                                                                                                                            |
| ---- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|      | The contents of this slot should be used for the inclusion of Phrasing elements (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing). eg. an anchor tag in the sub heading |


## Dependencies

### Used by

 - [agl-ds-radio-button-group](../radio-buttons/radio-button-group)
 - [agl-ds-selection-card-group](../../composite/selection-card/selection-card-group)

### Depends on

- [agl-ds-spacer](../spacer)
- [agl-ds-text](../text)

### Graph
```mermaid
graph TD;
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-text
  agl-ds-radio-button-group --> agl-ds-form-field-label
  agl-ds-selection-card-group --> agl-ds-form-field-label
  style agl-ds-form-field-label fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
