import { text, select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/Form field label'
};

export const Default = () => html`
  <agl-ds-h3> Headings styled as title 3</agl-ds-h3>
  <agl-ds-form-field-label heading="${text('Heading text', 'Sample heading')}" styled-as="title3">
    <span slot="sub-heading"> Sample sub heading with <agl-ds-link>a link</agl-ds-link> using the slot </span>
    <agl-ds-textbox label="input 1"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
  <br />
  <br />
  <agl-ds-form-field-label
    heading="${text('Heading text', 'Sample heading')}"
    styled-as="title3"
    sub-heading="${text('Sub heading text (attribute-optional)', 'Sample sub heading using the attribute/prop')}"
  >
    <agl-ds-textbox label="input 2"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
  <br />
  <br />
  <agl-ds-form-field-label heading="${text('Heading text', 'Sample heading')}" styled-as="title3">
    <agl-ds-textbox label="input label"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
  <br />
  <br />
  <agl-ds-h3>Headings styled as title 5</agl-ds-h3>
  <agl-ds-form-field-label heading="${text('Heading text', 'Sample heading')}" styled-as="title5">
    <span slot="sub-heading"> Sample sub heading with <agl-ds-link>a link</agl-ds-link> using the slot </span>
    <agl-ds-textbox label="input label"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
  <br />
  <br />
  <agl-ds-form-field-label
    heading="${text('Heading text', 'Sample heading')}"
    styled-as="title5"
    sub-heading="${text('Sub heading text (attribute-optional)', 'Sample sub heading using the attribute/prop')}"
  >
    <agl-ds-textbox label="input 3"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
  <br />
  <br />
  <agl-ds-form-field-label heading="${text('Heading text', 'Sample heading')}" styled-as="title5">
    <agl-ds-textbox label="input label"> </agl-ds-textbox>The text box is for illustration purpose only
  </agl-ds-form-field-label>
`;

Default.storyName = 'Form field label';
Default.parameters = { notes };
