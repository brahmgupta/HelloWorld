import { Component, Host, h, Prop, Element, ComponentInterface } from '@stencil/core';
import { FontSizes } from '../../../global/component.types';
import { checkSlottedContentForInvalidHTML } from '../../../global/utils/utils';
import { SpaceSize } from '../spacer/spacer.types';
import { FormFieldTitleType } from './form-field-label.types';
/**
  @slot - The contents of this slot should be used for the inclusion of Phrasing elements (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing). eg. an anchor tag in the sub heading
*/

@Component({
  tag: 'agl-ds-form-field-label',
  styleUrl: 'form-field-label.component.scss',
  shadow: true
})
export class FormFieldLabelComponent implements ComponentInterface {
  /**
   *this component as HTML Element
   */
  @Element() host: HTMLAglDsFormFieldLabelElement;

  /**
   * The legend/heading for the form field component
   */
  @Prop() heading: string;

  /**
   * The sub heading for the radio button input field. There is also a slot which can be used for the inclusion of Phrasing elements
   * (see https://www.w3.org/TR/2012/WD-html-markup-20121025/common-models.html#common.elem.phrasing) eg. an anchor tag in the sub heading
   */
  @Prop() subHeading: string;

  /**
   * Determines the size of the heading (legend element). Note this will also automatically change the sub heading font to the correct value when the sub heading is present
   */
  @Prop() styledAs: FormFieldTitleType = 'title5';

  private spaceTop: SpaceSize = 'space00';
  private spaceBotttom: SpaceSize = 'space02';
  private fontSize: FontSizes = 'xs';
  private hasSubHeading: boolean = false;

  componentWillLoad() {
    if (this.styledAs === 'title3') {
      this.spaceTop = 'space01';
      this.spaceBotttom = 'space04';
      this.fontSize = 'md';
    }
    if (this.subHeading?.length > 0 || this.host.querySelector('[slot="sub-heading"]')) {
      this.hasSubHeading = true;
      checkSlottedContentForInvalidHTML(this.host.querySelector('[slot="sub-heading"]'), ['agl-ds-text', 'agl-ds-link', 'span']);
    }
  }

  private renderSubHeading() {
    // The sub-heading prop was included for consistency with the radio button group where the prop sub-heading was retained for
    // backward compatibility
    if (this.hasSubHeading) {
      return (
        <div>
          <agl-ds-spacer orientation="vertical" size={this.spaceTop}></agl-ds-spacer>
          <agl-ds-text styledAs={this.fontSize} appearance="muted">
            {this.subHeading ? this.subHeading : <slot name="sub-heading" />}
          </agl-ds-text>
        </div>
      );
    }
  }

  render() {
    return (
      <Host>
        <fieldset>
          <legend>
            <span
              class={{
                ['agl-ds-' + this.styledAs]: true,
                'agl-ds-default-colour': true
              }}
            >
              {this.heading}
            </span>
            {this.renderSubHeading()}
          </legend>
          <agl-ds-spacer orientation="vertical" size={this.spaceBotttom}></agl-ds-spacer>
          <slot />
        </fieldset>
      </Host>
    );
  }
}
