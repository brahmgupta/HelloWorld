export type SpaceOrientation = 'horizontal' | 'vertical';

export type SpaceSize =
  | 'space00'
  | 'space01'
  | 'space02'
  | 'space03'
  | 'space04'
  | 'space04'
  | 'space06'
  | 'resp-space04'
  | 'resp-space06'
  | 'resp-space08';

export type SpaceDisplay = 'inline' | 'block';

export type BorderType = 'bottom' | 'top' | 'none';
