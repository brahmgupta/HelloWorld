import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/spacer'
};

export const SpacerHorizontal = () => html`
  <div>
    <agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm"></agl-ds-icon>
    <agl-ds-spacer
      orientation="horizontal"
      display="inline"
      size="${select('space size', ['space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06'], 'space02')}"
      border="none"
    >
    </agl-ds-spacer>
    <agl-ds-text bottom-margin="none">heading</agl-ds-text>
  </div>
`;

SpacerHorizontal.storyName = 'Spacer--horizontal';
SpacerHorizontal.parameters = { notes };

export const SpacerVertical = () => html`
  <div>
    <agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm"></agl-ds-icon>
    <agl-ds-spacer
      orientation="vertical"
      size="${select(
        'space size',
        ['space00', 'space01', 'space02', 'space03', 'space04', 'space05', 'space06', 'resp-space04', 'resp-space06', 'resp-space08'],
        'space02'
      )}"
      border=${select('border', ['bottom', 'top', 'none'], 'none')}
    >
    </agl-ds-spacer>
    <agl-ds-h3 bottom-margin="none">heading</agl-ds-h3>
  </div>
`;

SpacerVertical.storyName = 'Spacer--vertical';
SpacerVertical.parameters = { notes };
