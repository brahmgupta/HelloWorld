import { newSpecPage } from '@stencil/core/testing';
import { SpacerComponent } from './spacer.component';

describe('Spacer Component', () => {
  it('should render component', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer>
      <mock:shadow-root>
        <span class='spacer__border--none spacer__horizontal--space02 spacer__display--block'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });

  it('should render vertical spacer component when orientation set to vertical', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer orientation='vertical'></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer orientation='vertical'>
      <mock:shadow-root>
        <span class='spacer__border--none spacer__vertical--space02 spacer__display--block'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });

  it('should render space03 when size set to space03', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer size='space03'></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer size='space03'>
      <mock:shadow-root>
        <span class='spacer__border--none spacer__horizontal--space03 spacer__display--block'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });

  it('should render component when size set to resp-space04', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer orientation='vertical' size='resp-space04'></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer orientation='vertical' size='resp-space04'>
      <mock:shadow-root>
        <span class='spacer__border--none spacer__vertical--resp-space04 spacer__display--block'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });

  it('should render a top border on the vertical spacer when set to top', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer orientation='vertical' border="top"></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer orientation='vertical' border="top">
      <mock:shadow-root>
        <span class='spacer__vertical--space02 spacer__display--block spacer__border--top'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });

  it('should render a bottom border on the vertical spacer when set to bottom', async () => {
    const page = await newSpecPage({
      components: [SpacerComponent],
      html: `<agl-ds-spacer orientation='vertical' border="bottom"></agl-ds-spacer>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-spacer orientation='vertical' border="bottom">
      <mock:shadow-root>
        <span class='spacer__vertical--space02 spacer__display--block spacer__border--bottom'></span>
        </mock:shadow-root>
		</agl-ds-spacer>`
    );
  });
});
