# agl-ds-spacer



<!-- Auto Generated Below -->


## Properties

| Property      | Attribute     | Description                                                                                                                                                                                                                                                                                                                                                             | Type                                                                                                                               | Default        |
| ------------- | ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| `border`      | `border`      | shows the border on the top or bottom of the spacer                                                                                                                                                                                                                                                                                                                     | `"bottom" \| "none" \| "top"`                                                                                                      | `'none'`       |
| `display`     | `display`     | The display mode of the space. inline or block                                                                                                                                                                                                                                                                                                                          | `"block" \| "inline"`                                                                                                              | `'block'`      |
| `orientation` | `orientation` | The orientation of the space.  horizontal or vertical                                                                                                                                                                                                                                                                                                                   | `"horizontal" \| "vertical"`                                                                                                       | `'horizontal'` |
| `size`        | `size`        | The size of the space ( Note: Only a vertical orientation has access to 3 responsive sizes which designed to be mobile first eg 'resp-space04': ('small': $space-04, 'medium': $space-06, 'large':$space-08), 'resp-space06': ('small': $space-06, 'medium': $space-09, 'large':$space-12), 'resp-space08': ('small': $space-08 'medium': $space-12, 'large':$space-16) | `"resp-space04" \| "resp-space06" \| "resp-space08" \| "space00" \| "space01" \| "space02" \| "space03" \| "space04" \| "space06"` | `'space02'`    |


## Dependencies

### Used by

 - [agl-ds-error-summary](../../composite/error-summary)
 - [agl-ds-form-field-label](../form-field-label)
 - [agl-ds-fulfilment-container](../../layout/fulfilment-container)
 - [agl-ds-grid-example](../../layout/grid)
 - [agl-ds-manual-address-entry](../../composite/addresssearch/manual-address-entry)
 - [agl-ds-selection-card](../../composite/selection-card)

### Graph
```mermaid
graph TD;
  agl-ds-error-summary --> agl-ds-spacer
  agl-ds-form-field-label --> agl-ds-spacer
  agl-ds-fulfilment-container --> agl-ds-spacer
  agl-ds-grid-example --> agl-ds-spacer
  agl-ds-manual-address-entry --> agl-ds-spacer
  agl-ds-selection-card --> agl-ds-spacer
  style agl-ds-spacer fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
