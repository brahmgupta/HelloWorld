import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { SpaceOrientation, SpaceSize, SpaceDisplay, BorderType } from './spacer.types';

@Component({
  tag: 'agl-ds-spacer',
  styleUrl: 'spacer.component.scss',
  shadow: true
})
export class SpacerComponent implements ComponentInterface {
  /**
   * The orientation of the space.  horizontal or vertical
   */
  @Prop() orientation: SpaceOrientation = 'horizontal';

  /**
   * The size of the space ( Note: Only a vertical orientation has access to 3 responsive sizes which designed to be mobile first eg
   * 'resp-space04': ('small': $space-04, 'medium': $space-06, 'large':$space-08),
   * 'resp-space06': ('small': $space-06, 'medium': $space-09, 'large':$space-12),
   * 'resp-space08': ('small': $space-08 'medium': $space-12, 'large':$space-16)
   */
  @Prop() size: SpaceSize = 'space02';

  /**
   * The display mode of the space. inline or block
   */
  @Prop() display: SpaceDisplay = 'block';

  /**
   * shows the border on the top or bottom of the spacer
   */
  @Prop() border: BorderType = 'none';

  render() {
    if (this.orientation === 'horizontal' && this.border !== 'none') {
      throw new Error('Border type none must be used with a horizontal spacer');
    }
    if (this.orientation === 'horizontal' && this.size.indexOf('resp') > -1) {
      throw new Error('Responsive sizes can not be used with horizontal orientation');
    }
    return (
      <Host>
        <span class={`spacer__display--${this.display} spacer__${this.orientation}--${this.size} spacer__border--${this.border}`}></span>
      </Host>
    );
  }
}
