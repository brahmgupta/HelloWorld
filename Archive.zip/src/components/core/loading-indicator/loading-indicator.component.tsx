import { Component, Host, Prop, h, ComponentInterface } from '@stencil/core';
import { LoadingIndicatorSize, LoadingIndicatorType } from './loading-indicator.types';

@Component({
  tag: 'agl-ds-loading-indicator',
  styleUrl: 'loading-indicator.component.scss',
  shadow: true
})
export class LoadingIndicatorComponent implements ComponentInterface {
  /**
   * Size of Loading Indicator
   * `"medium"` will be applied when size is not specified
   */
  @Prop() size?: LoadingIndicatorSize = 'md';

  /**
   * Type of Loading Indicator
   * `"default"` will be applied when type is not specified
   */
  @Prop() type?: LoadingIndicatorType = 'default';

  /**
   * Provide screen reader users with additional context or to convey information not available in HTML alone
   */
  @Prop() srContext?: string = 'loading...';

  /**
	 * Create HTML representation of component DOM and return this
	 for output to the browser DOM
	 */
  render() {
    const { size, type, srContext } = this;

    return (
      <Host>
        <span
          aria-hidden="true"
          class={{
            ['loading-indicator']: true,
            [`loading-indicator--${size}`]: true,
            [`loading-indicator--${type}`]: true
          }}
        />
        {srContext ? <span class="sr-only">{srContext}</span> : ''}
      </Host>
    );
  }
}
