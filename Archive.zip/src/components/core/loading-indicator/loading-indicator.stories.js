import { select } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

const LoadingIndicatorSize = {
  sm: 'sm',
  md: 'md',
  lg: 'lg'
};

const LoadingIndicatorType = {
  default: 'default',
  muted: 'muted',
  inverse: 'inverse'
};

export default {
  title: 'Core/Loading Indicator'
};

export const LoadingIndicator = () => {
  const loadingIndicatorSize = select('Size', Object.values(LoadingIndicatorSize), LoadingIndicatorSize.md);
  const loadingIndicatorType = select('Type', Object.values(LoadingIndicatorType), LoadingIndicatorType.default);

  return html`<style>
      .inverse {
        background: #001cb0;
      }
    </style>

    <div class="${loadingIndicatorType}">
      <agl-ds-loading-indicator size="${loadingIndicatorSize}" type="${loadingIndicatorType}" />
    </div>`;
};

LoadingIndicator.parameters = {
  notes,
  storyshots: { disable: true } // the continuous animation in the loading indicator means that screenshot testing will be flakey - so we disable it
};
