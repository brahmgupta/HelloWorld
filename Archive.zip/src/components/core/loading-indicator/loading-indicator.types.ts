export type LoadingIndicatorSize = 'sm' | 'md' | 'lg';

export type LoadingIndicatorType = 'default' | 'muted' | 'inverse';
