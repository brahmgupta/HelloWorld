import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { LoadingIndicatorComponent } from './loading-indicator.component';
import { LoadingIndicatorSize, LoadingIndicatorType } from './loading-indicator.types';

describe('Loading indicator component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [LoadingIndicatorComponent],
      html: `<agl-ds-loading-indicator />`,
      supportsShadowDom: true
    });
    expect(page.root).toEqualHtml(
      `
        <agl-ds-loading-indicator>
          <mock:shadow-root>
            <span aria-hidden="true" class="loading-indicator loading-indicator--default loading-indicator--md"></span>
            <span class="sr-only">
              loading...
            </span>
          </mock:shadow-root>
        </agl-ds-loading-indicator>
      `
    );
  });

  describe('pass details to display the correct loading indicator size', () => {
    let page: SpecPage;

    (['lg', 'md', 'sm'] as LoadingIndicatorSize[]).map((loadingIndicatorSize) => {
      it(`should present a "${loadingIndicatorSize}" loading indicator`, async () => {
        page = await newSpecPage({
          components: [LoadingIndicatorComponent],
          html: `<agl-ds-loading-indicator size="${loadingIndicatorSize}" />`,
          supportsShadowDom: false
        });
        const loadingIndicator = page.doc.querySelector(`.loading-indicator--${loadingIndicatorSize}`);
        expect(loadingIndicator).toBeTruthy();
      });
    });
  });

  describe('pass details to display the correct loading indicator type', () => {
    let page: SpecPage;

    (['default', 'inverse', 'muted'] as LoadingIndicatorType[]).map((loadingIndicatorType) => {
      it(`should present a "${loadingIndicatorType}" loading indicator`, async () => {
        page = await newSpecPage({
          components: [LoadingIndicatorComponent],
          html: `<agl-ds-loading-indicator type="${loadingIndicatorType}" />`,
          supportsShadowDom: false
        });
        const loadingIndicator = page.doc.querySelector(`.loading-indicator--${loadingIndicatorType}`);
        expect(loadingIndicator).toBeTruthy();
      });
    });
  });
});
