# agl-ds-loading-indicator

<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                                                                                              | Type                                | Default        |
| ----------- | ------------ | -------------------------------------------------------------------------------------------------------- | ----------------------------------- | -------------- |
| `size`      | `size`       | Size of Loading Indicator `"medium"` will be applied when size is not specified                          | `"lg" \| "md" \| "sm"`              | `'md'`         |
| `srContext` | `sr-context` | Provide screen reader users with additional context or to convey information not available in HTML alone | `string`                            | `'loading...'` |
| `type`      | `type`       | Type of Loading Indicator `"default"` will be applied when type is not specified                         | `"default" \| "inverse" \| "muted"` | `'default'`    |


## Dependencies

### Used by

 - [agl-ds-autocomplete](../../composite/autocomplete)
 - [agl-ds-button](../button)

### Graph
```mermaid
graph TD;
  agl-ds-autocomplete --> agl-ds-loading-indicator
  agl-ds-button --> agl-ds-loading-indicator
  style agl-ds-loading-indicator fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
