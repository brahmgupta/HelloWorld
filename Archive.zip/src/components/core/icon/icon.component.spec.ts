import { newSpecPage, SpecPage } from '@stencil/core/testing';
import { IconComponent } from './icon.component';

describe('Icon Component', () => {
  it('should render my component', async () => {
    const page = await newSpecPage({
      components: [IconComponent],
      html: `<agl-ds-icon  icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
            size="sm">
        </agl-ds-icon>`
    });
    expect(page.root).toEqualHtml(
      `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm">
			<mock:shadow-root>
				<img aria-hidden="true" src="https://via.placeholder.com/240x360/0bf/fff?text=A" class="icon icon__size--sm">
			</mock:shadow-root>
		</agl-ds-icon>`
    );
  });

  it('should render my component with "alt text"', async () => {
    const page = await newSpecPage({
      components: [IconComponent],
      html: `<agl-ds-icon  icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" alt-text="dummy alt text"
            size="sm">
        </agl-ds-icon>`
    });
    expect(page.root).toEqualHtml(`
    <agl-ds-icon alt-text="dummy alt text" icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A" size="sm">
      <mock:shadow-root>
        <span class="sr-only">
          Image: dummy alt text
        </span>
        <img aria-hidden="true" class="icon icon__size--sm" src="https://via.placeholder.com/240x360/0bf/fff?text=A">
      </mock:shadow-root>
    </agl-ds-icon>
    `);
  });

  describe('pass details to display the icon size', () => {
    let page: SpecPage;

    it('should present a "extra extra small" icon', async () => {
      const text = 'xxs';
      page = await newSpecPage({
        components: [IconComponent],
        html: `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				size=${text}>
				</agl-ds-icon>`,
        supportsShadowDom: false
      });
      const icon = page.doc.querySelector('.icon__size--xxs');
      expect(icon).toBeTruthy();
    });

    it('should present a "extra small" icon', async () => {
      const text = 'xs';
      page = await newSpecPage({
        components: [IconComponent],
        html: `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				size=${text}>
				</agl-ds-icon>`,
        supportsShadowDom: false
      });
      const icon = page.doc.querySelector('.icon__size--xs');
      expect(icon).toBeTruthy();
    });

    it('should present a "small" icon', async () => {
      const text = 'sm';
      page = await newSpecPage({
        components: [IconComponent],
        html: `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				size=${text}>
				</agl-ds-icon>`,
        supportsShadowDom: false
      });
      const icon = page.doc.querySelector('.icon__size--sm');
      expect(icon).toBeTruthy();
    });

    it('should present a "medium" icon', async () => {
      const text = 'md';
      page = await newSpecPage({
        components: [IconComponent],
        html: `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				size=${text}>
				</agl-ds-icon>`,
        supportsShadowDom: false
      });
      const icon = page.doc.querySelector('.icon__size--md');
      expect(icon).toBeTruthy();
    });

    it('should present a "large" icon', async () => {
      const text = 'lg';
      page = await newSpecPage({
        components: [IconComponent],
        html: `<agl-ds-icon icon-path="https://via.placeholder.com/240x360/0bf/fff?text=A"
				size=${text}>
				</agl-ds-icon>`,
        supportsShadowDom: false
      });
      const icon = page.doc.querySelector('.icon__size--lg');
      expect(icon).toBeTruthy();
    });
  });
});
