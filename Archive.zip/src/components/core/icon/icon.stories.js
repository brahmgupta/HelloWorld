import { select, text } from '@storybook/addon-knobs';
import { html } from 'lit-html';
import notes from './readme.md';

export default {
  title: 'Core/icon'
};

const iconKnob = () =>
  text(
    'Icon',
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.4141,12,17.207,8.207a1,1,0,1,0-1.414-1.414L12,10.5859,8.207,6.793A1,1,0,1,0,6.793,8.207L10.5859,12,6.793,15.793a1,1,0,1,0,1.414,1.414L12,13.4141l3.793,3.7929a1,1,0,0,0,1.414-1.414Z" fill="#001cb0" class="primary-fill"></path><rect width="24" height="24" fill="none"></rect></svg>'
  );

export const Icon = () => html`
  <div><button>Focusable element before</button></div>
  <div>
    <agl-ds-icon
      icon="${iconKnob()}"
      icon-path="${text('Icon path', 'https://via.placeholder.com/40x60/0bf/fff?text=A')}"
      size="${select('Icon size', ['xxs', 'xs', 'sm', 'md', 'lg'], 'sm')}"
      alt-text="${text('Alt text', 'here is some text that describes the svg/image for screen readers to announce')}"
    >
    </agl-ds-icon>
  </div>
  <div><button>Focusable element after</button></div>
`;

Icon.parameters = { notes };
