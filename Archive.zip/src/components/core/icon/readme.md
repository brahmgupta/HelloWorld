# agl-ds-icon



<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description                                                                                                                                                                                 | Type                                    | Default     |
| ---------- | ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------- | ----------- |
| `altText`  | `alt-text`  | Adds alt text to svg and images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text | `string`                                | `''`        |
| `icon`     | `icon`      | The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps) If both iconPath and icon are set, icon will be preferred over iconPath                                           | `string`                                | `undefined` |
| `iconPath` | `icon-path` | The path of the icon to be displayed                                                                                                                                                        | `string`                                | `undefined` |
| `size`     | `size`      | The size of the icon to be displayed                                                                                                                                                        | `"lg" \| "md" \| "sm" \| "xs" \| "xxs"` | `'sm'`      |


## Dependencies

### Used by

 - [agl-ds-button](../button)
 - [agl-ds-feature-card](../../composite/icon-text-card/feature-card)
 - [agl-ds-feature-item](../../composite/icon-text-card/feature-item)
 - [agl-ds-menu-dropdown-item](../../composite/menu-dropdown/menu-dropdown-item)
 - [agl-ds-modal](../modal/modal)
 - [agl-ds-navigation-card](../../composite/navigation-card)
 - [agl-ds-prefooter](../../composite/icon-text-card/prefooter)
 - [agl-ds-promo-card](../../composite/icon-text-card/promo-card)
 - [agl-ds-radio-button](../radio-buttons/radio-button)
 - [agl-ds-spotlight](../../composite/image-text-card/spotlight)
 - [agl-ds-tooltip](../tooltip)
 - [agl-ds-triptych](../../composite/image-text-card/triptych)

### Graph
```mermaid
graph TD;
  agl-ds-button --> agl-ds-icon
  agl-ds-feature-card --> agl-ds-icon
  agl-ds-feature-item --> agl-ds-icon
  agl-ds-menu-dropdown-item --> agl-ds-icon
  agl-ds-modal --> agl-ds-icon
  agl-ds-navigation-card --> agl-ds-icon
  agl-ds-prefooter --> agl-ds-icon
  agl-ds-promo-card --> agl-ds-icon
  agl-ds-radio-button --> agl-ds-icon
  agl-ds-spotlight --> agl-ds-icon
  agl-ds-tooltip --> agl-ds-icon
  agl-ds-triptych --> agl-ds-icon
  style agl-ds-icon fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
