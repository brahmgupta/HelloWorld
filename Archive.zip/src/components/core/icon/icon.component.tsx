import { Component, ComponentInterface, h, Host, Prop } from '@stencil/core';
import { resizeSVGsForEdge } from '../../../global/utils/utils';
import { IconSize } from './icon.types';

@Component({
  tag: 'agl-ds-icon',
  styleUrl: 'icon.component.scss',
  shadow: true
})
export class IconComponent implements ComponentInterface {
  private svgSpan: HTMLSpanElement;
  /**
   * The raw string of the icon (E.G Raw SVG or a base 64 encoded png perhaps)
   * If both iconPath and icon are set, icon will be preferred over iconPath
   */
  @Prop() icon: string;
  /**
   * The path of the icon to be displayed
   */
  @Prop() iconPath: string;

  /**
   * The size of the icon to be displayed
   */
  @Prop() size: IconSize = 'sm';

  /**
   * Adds alt text to svg and images so that screen readers can announce the meaning of the image. Note this does not add the alt attribute but makes use of a hidden span tag to house the text
   */
  @Prop() altText: string = '';
  /**
   * This function is a temporary solution to deal with the pre chromium version of the Edge and will be removed once AGL update their SOE
   */
  componentDidLoad() {
    let dimension = '';
    switch (this.size) {
      case 'xxs':
        dimension = '16';
        break;
      case 'xs':
        dimension = '24';
        break;
      case 'sm':
        dimension = '32';
        break;
      case 'md':
        dimension = '48';
        break;
      case 'lg':
        dimension = '64';
        break;
    }
    //if a reference to svgSpan is present it means it is for svg icon that we need to manually set dimension for edge and IE. Note this does not add the alt attribute but makes use of a hidden span tag to house the text
    if (this.svgSpan) {
      resizeSVGsForEdge(this.svgSpan, dimension, dimension);
    }
  }

  render() {
    const isSvg = this.icon && this.icon.includes('<svg ') && this.icon.includes('</svg>');
    const imageSrc = this.icon ? this.icon : this.iconPath;
    return (
      <Host>
        {this.altText && <span class="sr-only">Image: {this.altText}</span>}
        {isSvg && (
          <span
            ref={(el) => (this.svgSpan = el)}
            aria-hidden="true"
            class={{ icon: true, ['icon__size--' + this.size]: true }}
            innerHTML={this.icon}
          ></span>
        )}
        {!isSvg && <img aria-hidden="true" src={imageSrc} class={{ icon: true, ['icon__size--' + this.size]: true }} />}
      </Host>
    );
  }
}
