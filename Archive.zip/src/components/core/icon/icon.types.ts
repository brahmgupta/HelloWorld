export type IconSize = 'xxs' | 'xs' | 'sm' | 'md' | 'lg';
