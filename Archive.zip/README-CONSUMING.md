# Consuming the design system npm package in your project

## Step 1 - Generate a GitHub access token

1. Open GitHub and click on your profile in the top right of the window to access the drop-down menu.

2. Click on 'Settings' &rarr; 'Developer Settings' &rarr; 'Personal Access Tokens' <https://github.com/settings/tokens>

   1. Click on 'Generate new token' to create a new token
   2. Ensure that it has `repo`, `read:packages` and `write:packages` permissions
   3. Click 'Generate token' to create the token
   4. At the moment, your token is only valid for the repositories hosted in your own account. You need to Enable SSO so the token has access to the AGLEnergy Organisation by clicking `Enable SSO`
      > NOTE: if you modify permissions of your token, it will reset your SSO access. You need to grant SSO access again after any change to your token.
   5. Copy the generated token to your clipboard (or notepad for now so you don't lose it)

## Step 2 - Authenticate yourself to GitHub packages via npm

OK, at this stage we have your access token. Now we need to login to the GitHub package repository via NPM with this token, so that we can access our packages.

Open up a command prompt at the root of your project (the same directory that contains your package.json)

- Run `npm login --registry=https://npm.pkg.github.com`
  1. For `Username`, enter your GitHub username
  2. For `Password` - **DO NOT enter your GitHub password**, instead paste the token you got from step 1 above
  3. For `email`, enter your GitHub account email address

You should now be fully authenticated to access AGL packages

## Step 3 - Install the npm package

### **yarn**

Create/edit your `.yarnrc` file, add the following. This tells yarn that any packages that start with `@aglenergy` are sourced from GitHub.

```
"@aglenergy:registry" "https://npm.pkg.github.com"
```

Then run the following command

```bash
yarn add @aglenergy/design-system
```

### **npm**

Create/edit your `.npmrc` file, add the following. This tells npm that any packages that start with `@aglenergy` are sourced from GitHub.

```
@aglenergy:registry=https://npm.pkg.github.com/AGLEnergy
```

Then run the following command

```bash
npm install @aglenergy/design-system
```

- This should work the same as any other package installation. If you experience a 401 error, then you may have encountered an issue authenticating yourself. Double check your token, re-generate it if you need to.

## How to use the components in your application

>## Note on the use of design system tokens (aka exported scss variables)
>
>The design system npm package contains numerous design system tokens in the `scss-export` folder.
>
>These are intended for use in a limited capacity in the AEM system. We ask that other consuming systems like Angular and Stencil SPAs do not use these, but rather build their UIs exclusively from design system components.
>
>For example if you need a specific layout, then a [layout](./src/components/layout) component from the design system should be used, rather than using a `$space-03` design system token to separate design elements in the consuming system. You could also use the `agl-ds-spacer` component for vertical and horizontal spacing.
>
>We ask this to reduce the amount of coupling between the design system tokens and the consuming systems - where it's easy for the tokens to be used in unexpected and unintended ways. This reduced coupling will alow AGL to produce more consistent designs and allow for smoother upgrades in future design system versions.
>
>Whilst there are always rare exceptions to the rule, basically the only exported scss details that should be consumed are the breakpoint `agl-ds-screen-size` mixins and the [css grid](https://agl-design-system.azurewebsites.net/?path=/story/layout-grid--example-grid). The grid can be used to fine tune the layout in current Design System containers by adding built in gutters/paddings and to provide responsive behaviour.

## What if the consuming system's designs don't match the existing AGL Design System components

Across all the different AGL teams that consume the AGL Design System in their applications, there are many different designers at work across energy, NBN, batteries etc. The designs that are produced don't always match exactly with the design system, however it's our responsibly as developers to push back and ensure consistency and reusability across our AGL websites.

It's important that AGL websites have a consistent look and feel and even small differences in design can be costly to maintain if they are repeatedly being built externally to the AGL Design System in the consuming apps.

Red flags when consuming the design system include comments like:

- >"we wanted to use the design system radio buttons but they looked different to our designs so we wrote a native implementation in our SPA"
- >"we used the design system checkbox component, but it did not look exactly like our designs so we used shadow piercing css to customize the look and feel"

If a component or variation of an existing component does not exist in the Design System you can always raise it for consideration on the `#design-system-tech` slack channel. Contributions to the library are always welcome, but have to pass through a governance process to ensure consistency.

If you do decide to build something natively in your consuming application, please ensure that Will Clement (wclement@agl.com.au or `@will_c` in slack), the AGL Design System and UX Lead is across it, as he will be the ultimate arbiter on what should and what should not end up in the AGL design system.

## StencilJS SPA's

Any consumer of the Design System that is itself a stencil SPA's need to install and configure this plugin [stencil-inline-svg](https://www.npmjs.com/package/stencil-inline-svg) to support inline svg within the design system.

## Angular

Stencil make available a build step that allows all stencil components to be "wrapped" in angular directives so that they can be then included in your SPA (<https://stenciljs.com/docs/angular>). A description of the build process can be found below.

The benefits of wrapping the stencil components is they are then recognised by Angular as Angular components giving both IDE intellisense benefits and the ability to use them with ngModel for 2 way binding as well as Angular's reactive forms (formcontrolname)
in the same way that you can with a standard HTML element.

Please note that while you can still include stencil web components directly in your SPA, the recommended method is as follows. In doing this you will **NOT** need to use the deprecated `Import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'` approach.

Import the AglDsComponentLibraryModule module

- `import { AglDsComponentLibraryModule } from '@aglenergy/design-system/dist/angular` into your root module.
- add it to your `@NgModule` imports. For example:

  ```TypeScript
  @NgModule({
    declarations: [AppComponent],
    imports: [BrowserModule, FormsModule, AglDsComponentLibraryModule],
    bootstrap: [AppComponent],
  })
  ```

- Add the AglDsComponentLibraryModule TypeScript source code to the `include` configuration in your project's `tsconfig.app.json`/`tsconfig.spec.json` files:

  ```TypeScript
  "include": [
    ...
    "node_modules/@aglenergy/design-system/dist/angular/**/*.ts"
  ]
  ```

### Angular consuming the AGL Design Library version 7.0.0 onwards

- For applications using Angular 9+ with Ivy enabled you can enforce that the correct design system types are being used in your html templates by updating the Angular complier options to enable `strictTemplates`:

  ```TypeScript
  "angularCompilerOptions": {
    ...
    "strictTemplates": true
  }

- Add `agl-ds-custom-elements.json` to the `html.customData` array in `settings.json` for **html** intellisense support in vscode.

  ```json
  "html.customData": [
    "node_modules/@aglenergy/design-system/dist/agl-ds-custom-elements.json"
  ]
  ```

## Angular wrapper generation during the build process

In addition to the usual build process an extra step has been added to the ./stencil.config.ts configuration that copies files from ./src/angular to ./dist/angular. The destination ./dist/angular folder contains the directive "wrappers" for the stencil components.

The other change to the build process is the addition of the angularOutputTarget config to the ./stencil.config.ts file. This documents the destination of the relevant files required in the "wrapper" process

## Configuring for Bamboo build

1. Regardless of yarn or npm use, create/edit your `.npmrc` file, add the following.  This is needed so when Bamboo passes the Git token, the correct package is retrieved.

  ```
  registry=https://npm.pkg.github.com/AGLEnergy
  @aglenergy:registry=https://npm.pkg.github.com
  always-auth=true
  ```

2. In the Bamboo build package configuration:

- Create a new  Script  task  towards  the  beginning  of  the  task  list  - around where the source is checked out with the following settings:
  - **interpreter**: /bin/sh or cmd.exe
  - **Script location**: Inline
  - **Script body**:

    ```bash
    cd ./<directory that holds .npmrc file>
    echo //npm.pkg.github.com/:_authToken=${bamboo.npm_pkg_username_secret} >> .npmrc
    ```

The above script navigates from the root to the directory that holds the `.npmrc file` and then appends the file with auth credentials to allow Bamboo to authenticate and use the design system. Please note: This script solves two problems:

  1. Placing the auth token into the .nprmc file
  2. Allowing `yarn upgrade` to execute as expected - when the line the script is appending to the `.npmrc` file is present and the token value is not populated, `yarn upgrade` will throw an `"couldn't find @aglenergy/design-system"` error, ie don't commit that line to the repository.

## Deprecated Library properties/features

As with all libraries this code base is always evolving and from time to time properties/features will need to be altered/removed to better suit the needs of UX and the development community. In the course of events deprecated features/properties should be noted in respective components using "@deprecated  (in vx.xx.x)" in the property comment. These details can then be viewed by all consumers of the library in the Storybook story notes. The aim is to keep properties/features for 2 months after they are deprecated. This will hopefully minimise disruption to teams that consume the library and should allow 4 sprints to migrate off a feature/property once it is deprecated.

## Troubleshooting issues

### components.d.ts errors in consuming systems:

>**Issue**: Type error: `ERROR in node_modules/@aglenergy/design-system/dist/types/components.d.ts: error: Cannot find name 'someTypeName'` (for example `Cannot find name 'InputEvent'`)
>
> **Solution**:
>  - In the `./src` directory for the Angular app, create/update the `types.d.ts` file and add the following: `declare type someTypeName = any` (replacing the someTypeName with the actual erroring type from the error message.)
>  - Update all `tsconfig.json`'s, adding `"types.d.ts"` as the first item in the  `"typeRoots"` array - be sure to refer to the exact location of the file (eg `"src/types.d.ts"` when in the parent directory).
